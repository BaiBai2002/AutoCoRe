from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

from autocore.dsl.compiler import compile_dsl, CompilerOutput
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.dsl.schema import DSLSchema


@dataclass
class HardSafetyGateReport:
    passed: bool = True
    failures: list[str] = field(default_factory=list)
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "failures": list(self.failures),
            "diagnostics": dict(self.diagnostics),
        }


class HardSafetyGate:
    MAGNITUDE_THRESHOLD: float = 1000.0

    def __init__(
        self,
        predicate_library: Optional[PredicateLibrary] = None,
        potential_library: Optional[PotentialLibrary] = None,
        env_spec: Optional[dict[str, Any]] = None,
        available_state_variables: Optional[list[str]] = None,
    ) -> None:
        self._predicate_library = predicate_library or PredicateLibrary()
        self._potential_library = potential_library or PotentialLibrary()
        self._env_spec = env_spec if isinstance(env_spec, dict) else {}
        if isinstance(self._env_spec, dict):
            self._allowed_state_vars: set[str] = set(
                self._env_spec.get("available_state_variables", available_state_variables or [])
            )
        else:
            self._allowed_state_vars: set[str] = set(available_state_variables or [])
        self._valid_predicate_types: set[str] = set(self._predicate_library.list_types())
        self._valid_potential_types: set[str] = set(self._potential_library.list_types())

    def check(self, dsl: dict[str, Any]) -> HardSafetyGateReport:
        report = HardSafetyGateReport()

        self._rule_json_parse(report, dsl)
        self._rule_schema_valid(report, dsl)
        self._rule_unknown_predicate(report, dsl)
        self._rule_unknown_potential(report, dsl)
        self._rule_variable_binding(report, dsl)
        self._rule_compile(report, dsl)
        self._rule_nan_inf(report, dsl)
        self._rule_constant(report, dsl)
        self._rule_magnitude(report, dsl)
        self._rule_pbrs_formula(report, dsl)
        self._rule_env_rollout(report, dsl)

        report.passed = len(report.failures) == 0
        return report

    def _add_failure(self, report: HardSafetyGateReport, rule_name: str, message: str) -> None:
        report.failures.append(rule_name)
        report.diagnostics[rule_name] = message

    def _add_info(self, report: HardSafetyGateReport, rule_name: str, info: Any) -> None:
        report.diagnostics[rule_name] = info

    def _rule_json_parse(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            json.dumps(dsl)
            self._add_info(report, "01_json_parse", {"ok": True})
        except (TypeError, ValueError) as e:
            self._add_failure(report, "01_json_parse", f"JSON serialization failed: {e}")

    def _rule_schema_valid(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            DSLSchema.validate(dsl)
            self._add_info(report, "02_schema_valid", {"ok": True})
        except Exception as e:
            self._add_failure(report, "02_schema_valid", f"DSL schema validation failed: {e}")

    def _rule_unknown_predicate(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        subgoals = dsl.get("subgoals", [])
        unknowns: list[str] = []
        for i, sg in enumerate(subgoals):
            pred_type = sg.get("predicate", {}).get("type", "")
            if pred_type and pred_type not in self._valid_predicate_types:
                unknowns.append(f"subgoals[{i}]: '{pred_type}'")
        if unknowns:
            self._add_failure(
                report,
                "03_unknown_predicate",
                f"Unknown predicate types: {unknowns}. Known: {sorted(self._valid_predicate_types)}",
            )
        else:
            self._add_info(report, "03_unknown_predicate", {"ok": True})

    def _rule_unknown_potential(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        subgoals = dsl.get("subgoals", [])
        unknowns: list[str] = []
        for i, sg in enumerate(subgoals):
            pot_type = sg.get("potential", {}).get("type", "")
            if pot_type and pot_type not in self._valid_potential_types:
                unknowns.append(f"subgoals[{i}]: '{pot_type}'")
        if unknowns:
            self._add_failure(
                report,
                "04_unknown_potential",
                f"Unknown potential types: {unknowns}. Known: {sorted(self._valid_potential_types)}",
            )
        else:
            self._add_info(report, "04_unknown_potential", {"ok": True})

    def _rule_variable_binding(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        subgoals = dsl.get("subgoals", [])
        referenced: set[str] = set()
        for sg in subgoals:
            pred_args = sg.get("predicate", {}).get("args", {})
            if isinstance(pred_args, dict):
                for val in pred_args.values():
                    if isinstance(val, str) and "." in val:
                        parts = val.split(".")
                        for j in range(1, len(parts) + 1):
                            referenced.add(".".join(parts[:j]))
                        referenced.add(val)
        unknown = referenced - self._allowed_state_vars - {"agent_positions", "landmark_positions"}
        available = set(self._allowed_state_vars) | {"agent_positions", "landmark_positions"}
        actual_unknown = unknown - available
        if actual_unknown:
            self._add_failure(
                report,
                "05_invalid_variable_binding",
                f"Unknown state variables: {sorted(actual_unknown)}. Available: {sorted(self._allowed_state_vars)}",
            )
        else:
            self._add_info(report, "05_invalid_variable_binding", {"ok": True, "referenced": sorted(referenced)})

    def _rule_compile(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            compile_dsl(dsl, self._predicate_library, self._potential_library)
            self._add_info(report, "06_compile", {"ok": True})
        except Exception as e:
            self._add_failure(report, "06_compile", f"DSL compilation failed: {e}")

    def _rule_nan_inf(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states()
            nan_inf_details: list[str] = []
            for i, state in enumerate(states):
                for j, fn in enumerate(compiled.subgoal_functions):
                    val = float(fn(state))
                    if not math.isfinite(val):
                        nan_inf_details.append(f"subgoal[{j}] state[{i}]: {val}")
                total = compiled.total_potential(state)
                if not math.isfinite(float(total)):
                    nan_inf_details.append(f"total state[{i}]: {total}")
            if nan_inf_details:
                self._add_failure(
                    report,
                    "07_nan_inf",
                    f"NaN/Inf values: {'; '.join(nan_inf_details[:5])}",
                )
            else:
                self._add_info(report, "07_nan_inf", {"ok": True})
        except Exception as e:
            self._add_failure(report, "07_nan_inf", f"NaN/Inf check error: {e}")

    def _rule_constant(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states()
            if len(states) < 2:
                self._add_info(report, "08_constant", {"ok": True, "note": "insufficient states"})
                return
            values = [float(compiled.total_potential(s)) for s in states]
            values_arr = np.array(values, dtype=np.float64)
            value_range = float(np.max(values_arr) - np.min(values_arr))
            if value_range < 1e-12:
                self._add_failure(
                    report,
                    "08_constant",
                    f"Potential is constant (zero gradient) across {len(states)} diagnostic states (range={value_range:.2e})",
                )
            else:
                self._add_info(report, "08_constant", {"ok": True, "range": value_range})
        except Exception as e:
            self._add_failure(report, "08_constant", f"Constant check error: {e}")

    def _rule_magnitude(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states()
            max_abs = 0.0
            max_info: dict[str, Any] = {}
            for i, state in enumerate(states):
                for j, fn in enumerate(compiled.subgoal_functions):
                    val = abs(float(fn(state)))
                    if val > max_abs:
                        max_abs = val
                        max_info = {"subgoal": j, "state": i, "value": float(val)}
                total = abs(float(compiled.total_potential(state)))
                if total > max_abs:
                    max_abs = total
                    max_info = {"total": True, "state": i, "value": float(total)}
            if max_abs > self.MAGNITUDE_THRESHOLD:
                self._add_failure(
                    report,
                    "09_catastrophic_magnitude",
                    f"Max absolute value {max_abs:.2e} exceeds threshold {self.MAGNITUDE_THRESHOLD}: {max_info}",
                )
            else:
                self._add_info(report, "09_catastrophic_magnitude", {"ok": True, "max_abs": max_abs})
        except Exception as e:
            self._add_failure(report, "09_catastrophic_magnitude", f"Magnitude check error: {e}")

    def _rule_pbrs_formula(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        subgoals = dsl.get("subgoals", [])
        violations: list[str] = []
        for i, sg in enumerate(subgoals):
            pot = sg.get("potential", {})
            if not isinstance(pot, dict):
                violations.append(f"subgoal[{i}]: potential is not a dict")
                continue
            if "type" not in pot:
                violations.append(f"subgoal[{i}]: potential missing 'type' field")
        if violations:
            self._add_failure(
                report,
                "10_pbrs_formula",
                f"PBRS formula violations: {'; '.join(violations)}",
            )
        else:
            self._add_info(report, "10_pbrs_formula", {"ok": True, "subgoal_count": len(subgoals)})

    def _rule_env_rollout(self, report: HardSafetyGateReport, dsl: dict[str, Any]) -> None:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states()
            if len(states) < 3:
                states = states * 3
            states = states[:3]

            prev_state: Optional[dict[str, Any]] = None
            rollout_errors: list[str] = []
            for i, state in enumerate(states):
                try:
                    curr = float(compiled.total_potential(state))
                    if prev_state is not None:
                        prev_pot = float(compiled.total_potential(prev_state))
                        shaping = 0.99 * curr - prev_pot
                        if not math.isfinite(shaping):
                            rollout_errors.append(f"step[{i}]: shaping reward non-finite ({shaping})")
                    prev_state = state
                except Exception as step_err:
                    rollout_errors.append(f"step[{i}]: {step_err}")

            if rollout_errors:
                self._add_failure(
                    report,
                    "11_env_rollout",
                    f"Environment rollout exception: {'; '.join(rollout_errors)}",
                )
            else:
                self._add_info(report, "11_env_rollout", {"ok": True, "steps_simulated": len(states)})
        except Exception as e:
            self._add_failure(report, "11_env_rollout", f"Environment rollout check failed: {e}")

    def _build_diagnostic_states(self) -> list[dict[str, Any]]:
        states: list[dict[str, Any]] = []

        zero_state: dict[str, Any] = {}
        for var in self._allowed_state_vars:
            root = var.split(".")[0]
            if root not in zero_state:
                if "velocity" in root.lower():
                    zero_state[root] = np.zeros(
                        (self._env_spec.get("num_agents", 3), 2), dtype=np.float64
                    ).tolist()
                elif "landmark" in root.lower():
                    zero_state[root] = np.zeros(
                        (self._env_spec.get("num_landmarks", 3), 2), dtype=np.float64
                    ).tolist()
                else:
                    zero_state[root] = np.zeros(
                        (self._env_spec.get("num_agents", 3), 2), dtype=np.float64
                    ).tolist()
        states.append(zero_state)

        extreme_state: dict[str, Any] = {}
        for var in self._allowed_state_vars:
            root = var.split(".")[0]
            if root not in extreme_state:
                if "velocity" in root.lower():
                    extreme_state[root] = (
                        np.ones((self._env_spec.get("num_agents", 3), 2), dtype=np.float64) * 10.0
                    ).tolist()
                elif "landmark" in root.lower():
                    extreme_state[root] = (
                        np.ones((self._env_spec.get("num_landmarks", 3), 2), dtype=np.float64) * 5.0
                    ).tolist()
                else:
                    extreme_state[root] = (
                        np.ones((self._env_spec.get("num_agents", 3), 2), dtype=np.float64) * 5.0
                    ).tolist()
        states.append(extreme_state)

        try:
            rng = np.random.RandomState(42)
            for _ in range(8):
                s: dict[str, Any] = {}
                for var in self._allowed_state_vars:
                    root = var.split(".")[0]
                    if root not in s:
                        if "velocity" in root.lower():
                            s[root] = (
                                rng.randn(self._env_spec.get("num_agents", 3), 2) * 2.0
                            ).tolist()
                        elif "landmark" in root.lower():
                            s[root] = (
                                rng.randn(self._env_spec.get("num_landmarks", 3), 2) * 3.0
                            ).tolist()
                        else:
                            s[root] = (
                                rng.randn(self._env_spec.get("num_agents", 3), 2) * 3.0
                            ).tolist()
                states.append(s)
        except Exception:
            pass

        return states
