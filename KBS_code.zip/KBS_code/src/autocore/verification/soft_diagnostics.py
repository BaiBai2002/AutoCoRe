from __future__ import annotations

import hashlib
import json
from collections import Counter
from typing import Any, Optional

import numpy as np

from autocore.dsl.compiler import compile_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary


class SoftDiagnostics:
    _COLLISION_KEYWORDS = {"collision_count_or_margin", "collision_count", "collision", "collision_margin"}
    _BALANCE_KEYWORDS = {"coverage_entropy_or_balance", "coverage_balance", "balanced_coverage", "balance", "entropy"}
    _PROGRESS_KEYWORDS = {"min_distance_landmark_coverage", "mean_distance_to_nearest_landmark",
                          "max_uncovered_landmark_distance", "agent_target_assignment_distance",
                          "negative_normalized_sum_min_distance", "negative_mean_distance",
                          "pairwise_agent_distance"}

    def __init__(
        self,
        predicate_library: Optional[PredicateLibrary] = None,
        potential_library: Optional[PotentialLibrary] = None,
    ) -> None:
        self._predicate_library = predicate_library or PredicateLibrary()
        self._potential_library = potential_library or PotentialLibrary()

    def compute(self, dsl: dict[str, Any], env_spec: dict[str, Any]) -> dict[str, Any]:
        subgoals = dsl.get("subgoals", [])

        predicate_types = self._extract_predicate_types(subgoals)
        potential_types = self._extract_potential_types(subgoals)
        weights = self._extract_weights(subgoals)

        pred_counts = dict(Counter(predicate_types))
        pot_counts = dict(Counter(potential_types))

        available_predicates = set(self._predicate_library.list_types())
        available_potentials = set(self._potential_library.list_types())
        used_predicates = set(predicate_types)
        used_potentials = set(potential_types)

        predicate_coverage = (
            len(used_predicates & available_predicates) / len(available_predicates)
            if available_predicates else 1.0
        )
        potential_coverage = (
            len(used_potentials & available_potentials) / len(available_potentials)
            if available_potentials else 1.0
        )

        dominance_ratio = self._estimate_dominance_ratio(dsl, env_spec)
        saturation = self._check_saturation(dsl)

        result: dict[str, Any] = {
            "predicate_type_counts": pred_counts,
            "potential_type_counts": pot_counts,
            "num_subgoals": len(subgoals),
            "total_weight_sum": sum(weights),
            "weight_sum": sum(weights),
            "predicate_coverage": predicate_coverage,
            "potential_coverage": potential_coverage,
            "dominance_ratio_estimate": dominance_ratio,
            "potential_saturation": saturation,
            "has_collision": self._has_keyword(predicate_types, potential_types, self._COLLISION_KEYWORDS),
            "has_balance": self._has_keyword(predicate_types, potential_types, self._BALANCE_KEYWORDS),
            "has_progress": self._has_keyword(predicate_types, potential_types, self._PROGRESS_KEYWORDS),
            "predicate_types": predicate_types,
            "potential_types": potential_types,
            "weights": weights,
            "available_predicates": sorted(available_predicates),
            "available_potentials": sorted(available_potentials),
            "used_predicates": sorted(used_predicates),
            "used_potentials": sorted(used_potentials),
        }

        return result

    def _extract_predicate_types(self, subgoals: list[dict[str, Any]]) -> list[str]:
        preds: list[str] = []
        for sg in subgoals:
            pred_type = sg.get("predicate", {}).get("type", "")
            if pred_type:
                preds.append(pred_type)
        return preds

    def _extract_potential_types(self, subgoals: list[dict[str, Any]]) -> list[str]:
        pots: list[str] = []
        for sg in subgoals:
            pot_type = sg.get("potential", {}).get("type", "")
            if pot_type:
                pots.append(pot_type)
        return pots

    def _extract_weights(self, subgoals: list[dict[str, Any]]) -> list[float]:
        weights: list[float] = []
        for sg in subgoals:
            w = sg.get("weight", 0.0)
            try:
                weights.append(float(w))
            except (TypeError, ValueError):
                weights.append(0.0)
        return weights

    def _has_keyword(
        self, pred_types: list[str], pot_types: list[str], keywords: set[str]
    ) -> bool:
        for p in pred_types:
            for kw in keywords:
                if kw.lower() in p.lower():
                    return True
        for p in pot_types:
            for kw in keywords:
                if kw.lower() in p.lower():
                    return True
        return False

    def _estimate_dominance_ratio(
        self, dsl: dict[str, Any], env_spec: dict[str, Any]
    ) -> float:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states(env_spec)
            if len(states) < 2:
                return 0.0

            pot_values: list[float] = []
            for i in range(len(states) - 1):
                curr_pot = float(compiled.total_potential(states[i]))
                next_pot = float(compiled.total_potential(states[i + 1]))
                shaping = 0.99 * next_pot - curr_pot
                pot_values.append(shaping)

            raw_scale = float(env_spec.get("raw_reward_scale", 1.0)) if isinstance(env_spec, dict) else 1.0
            if len(pot_values) > 0:
                mean_abs_shaping = float(np.mean(np.abs(np.array(pot_values, dtype=np.float64))))
                denom = max(raw_scale, 1e-6)
                return float(mean_abs_shaping / denom)

            return 0.0
        except Exception:
            return 0.0

    def _check_saturation(self, dsl: dict[str, Any]) -> float:
        try:
            compiled = compile_dsl(dsl, self._predicate_library, self._potential_library)
            states = self._build_diagnostic_states({})
            if len(states) < 10:
                return 0.0

            abs_phi = np.abs(
                np.array([float(compiled.total_potential(s)) for s in states], dtype=np.float64)
            )
            p99 = float(np.percentile(abs_phi, 99))
            p50 = float(np.median(abs_phi))
            if p99 < 1e-8:
                return 0.0
            return float(p50 / p99)
        except Exception:
            return 0.0

    def _build_diagnostic_states(self, env_spec: dict[str, Any]) -> list[dict[str, Any]]:
        allowed_vars = env_spec.get("available_state_variables", []) if isinstance(env_spec, dict) else []
        states: list[dict[str, Any]] = []

        zero_state: dict[str, Any] = {}
        for var in allowed_vars:
            root = var.split(".")[0]
            if root not in zero_state:
                if "velocity" in root.lower():
                    zero_state[root] = np.zeros(
                        (env_spec.get("num_agents", 3), 2), dtype=np.float64
                    ).tolist()
                elif "landmark" in root.lower():
                    zero_state[root] = np.zeros(
                        (env_spec.get("num_landmarks", 3), 2), dtype=np.float64
                    ).tolist()
                else:
                    zero_state[root] = np.zeros(
                        (env_spec.get("num_agents", 3), 2), dtype=np.float64
                    ).tolist()
        states.append(zero_state)

        try:
            rng = np.random.RandomState(42)
            for _ in range(9):
                s: dict[str, Any] = {}
                for var in allowed_vars:
                    root = var.split(".")[0]
                    if root not in s:
                        if "velocity" in root.lower():
                            s[root] = (
                                rng.randn(env_spec.get("num_agents", 3), 2) * 2.0
                            ).tolist()
                        elif "landmark" in root.lower():
                            s[root] = (
                                rng.randn(env_spec.get("num_landmarks", 3), 2) * 3.0
                            ).tolist()
                        else:
                            s[root] = (
                                rng.randn(env_spec.get("num_agents", 3), 2) * 3.0
                            ).tolist()
                states.append(s)
        except Exception:
            pass

        return states
