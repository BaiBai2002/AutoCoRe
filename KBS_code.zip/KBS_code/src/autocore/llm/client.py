import time
from typing import Any, Dict, List, Optional, Union

import requests

from autocore.utils.logging import get_logger

logger = get_logger(__name__)


class LLMError(Exception):
    pass


class LLMConnectionError(LLMError):
    pass


class LLMResponseError(LLMError):
    pass


class LLMTimeoutError(LLMError):
    pass


class LLMAuthError(LLMError):
    pass


class LLMRateLimitError(LLMError):
    pass


class LLMClient:
    def __init__(self, provider_config: dict):
        self._name = provider_config.get("name", "unknown")
        self._api_key = provider_config.get("api_key")
        self._base_url = provider_config.get("base_url", "")
        self._model = provider_config.get("model", "")
        self._chat_endpoint = provider_config.get("chat_endpoint", "/chat/completions")
        self._timeout = provider_config.get("timeout", 120)
        self._max_retries = provider_config.get("max_retries", 3)
        self._retry_delay = provider_config.get("retry_delay", 5)

        if not self._api_key:
            raise LLMAuthError(
                f"No API key found for provider '{self._name}'. "
                f"Ensure the corresponding environment variable is set."
            )
        if not self._base_url:
            raise LLMError(f"No base URL configured for provider '{self._name}'.")

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            }
        )
        logger.info(
            f"LLMClient initialized for provider '{self._name}' "
            f"(model={self._model}, base_url={self._base_url})"
        )

    @property
    def provider_name(self) -> str:
        return self._name

    @property
    def model(self) -> str:
        return self._model

    @property
    def base_url(self) -> str:
        return self._base_url

    def generate(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> dict:
        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if extra_params:
            # Provider/gateway-specific request fields (e.g. a reasoning-effort hint). Merged
            # verbatim, so callers must include them in their own cache keys.
            payload.update(extra_params)

        url = f"{self._base_url.rstrip('/')}{self._chat_endpoint}"

        last_exception: Optional[Exception] = None
        start_time = time.perf_counter()

        for attempt in range(self._max_retries + 1):
            try:
                logger.debug(
                    f"[{self._name}] Attempt {attempt + 1}/{self._max_retries + 1} "
                    f"→ {url}"
                )
                response = self._session.post(
                    url,
                    json=payload,
                    timeout=self._timeout,
                )
                latency = time.perf_counter() - start_time
                return self._handle_response(response, latency)
            except requests.exceptions.Timeout as e:
                last_exception = e
                logger.warning(
                    f"[{self._name}] Timeout on attempt {attempt + 1}: {e}"
                )
                if attempt < self._max_retries:
                    wait = self._retry_delay * (2**attempt)
                    logger.info(f"[{self._name}] Retrying in {wait}s...")
                    time.sleep(wait)
            except requests.exceptions.ConnectionError as e:
                last_exception = e
                logger.warning(
                    f"[{self._name}] Connection error on attempt {attempt + 1}: {e}"
                )
                if attempt < self._max_retries:
                    wait = self._retry_delay * (2**attempt)
                    logger.info(f"[{self._name}] Retrying in {wait}s...")
                    time.sleep(wait)
            except requests.exceptions.RequestException as e:
                last_exception = e
                logger.warning(
                    f"[{self._name}] Request error on attempt {attempt + 1}: {e}"
                )
                if attempt < self._max_retries:
                    wait = self._retry_delay * (2**attempt)
                    logger.info(f"[{self._name}] Retrying in {wait}s...")
                    time.sleep(wait)

        if isinstance(last_exception, requests.exceptions.Timeout):
            raise LLMTimeoutError(
                f"[{self._name}] Request timed out after "
                f"{self._max_retries + 1} attempt(s): {last_exception}"
            )
        elif isinstance(last_exception, requests.exceptions.ConnectionError):
            raise LLMConnectionError(
                f"[{self._name}] Connection failed after "
                f"{self._max_retries + 1} attempt(s): {last_exception}"
            )
        else:
            raise LLMError(
                f"[{self._name}] Request failed after "
                f"{self._max_retries + 1} attempt(s): {last_exception}"
            )

    def _handle_response(self, response: requests.Response, latency: float) -> dict:
        if response.status_code == 200:
            data = response.json()
            try:
                choice = data["choices"][0]
                content = choice["message"]["content"]
                model = data.get("model", self._model)
                usage_raw = data.get("usage", {})
                usage = {
                    "prompt_tokens": usage_raw.get("prompt_tokens", 0),
                    "completion_tokens": usage_raw.get("completion_tokens", 0),
                    "total_tokens": usage_raw.get("total_tokens", 0),
                }
                result = {
                    "content": content,
                    "model": model,
                    "usage": usage,
                    "latency": round(latency, 4),
                }
                logger.info(
                    f"[{self._name}] OK ({latency:.2f}s, "
                    f"prompt={usage['prompt_tokens']}, "
                    f"completion={usage['completion_tokens']})"
                )
                return result
            except (KeyError, IndexError) as e:
                raise LLMResponseError(
                    f"[{self._name}] Unexpected response structure: {e}\n"
                    f"Response: {response.text[:500]}"
                )
        elif response.status_code == 401:
            raise LLMAuthError(
                f"[{self._name}] Authentication failed (401). "
                f"Check your API key. Response: {response.text[:500]}"
            )
        elif response.status_code == 429:
            raise LLMRateLimitError(
                f"[{self._name}] Rate limited (429). "
                f"Response: {response.text[:500]}"
            )
        elif response.status_code >= 500:
            raise LLMResponseError(
                f"[{self._name}] Server error ({response.status_code}). "
                f"Response: {response.text[:500]}"
            )
        else:
            raise LLMResponseError(
                f"[{self._name}] HTTP {response.status_code}. "
                f"Response: {response.text[:500]}"
            )

    def close(self) -> None:
        self._session.close()
        logger.debug(f"[{self._name}] Session closed")

    def __enter__(self):
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return (
            f"LLMClient(name={self._name!r}, model={self._model!r}, "
            f"base_url={self._base_url!r})"
        )
