import json
from typing import Any, Dict, List


class PromptBuilder:
    GENERATION_SYSTEM_PROMPT = """You are designing potential-based reward shaping for cooperative multi-agent reinforcement learning.
Use ONLY the state variables listed in the environment specification below.
Return valid JSON only, conforming to the DSL schema provided.

CRITICAL — VALID STATE VARIABLE NAMES:
The ONLY valid state variable names are: "agent_positions", "landmark_positions", "agent_velocities"
For predicate args, you MUST use exactly:
  agent_key: "agent_positions"
  landmark_key: "landmark_positions" (only for landmark-based predicates)

INVALID variable names (NEVER use these):
  "agents", "agent", "listener", "listeners", "speaker", "speakers"
  "adversary_key", "adversary", "box_center", "box_position"
  "agent_keys", "landmark_keys", "positions"

Do not use arbitrary code, Python expressions, or external libraries.
Prefer simple, interpretable, low-dimensional potentials.
Avoid potentials that directly encode the true terminal reward unless already available as dense structure.
Include a brief rationale for each subgoal.
Keep between 1 and 3 subgoals. Fewer high-quality subgoals are better than many weak ones.
Prioritize sample efficiency without changing the intended task.

CRITICAL DESIGN PRINCIPLE — FOCUS ON PRIMARY TASK PROGRESS:
- The PRIMARY task in cooperative MARL is completing the main objective (covering landmarks, reaching targets, pushing objects).
- Collision avoidance is SECONDARY: it is often already handled by the environment's raw reward.
- Collision-related potentials frequently cause negative interference with task progress.
- For optimal results, design potentials that purely measure PROGRESS TOWARD THE PRIMARY TASK.
- If you include collision avoidance, keep its weight LOW (≤0.2) or consider omitting it entirely.

AVAILABLE PREDICATE TYPES (for predicate.type field):
- min_distance_landmark_coverage: each landmark's min distance to nearest agent (args: agent_positions, landmark_positions) [PRIMARY]
- mean_distance_to_nearest_landmark: mean of min distances (args: agent_positions, landmark_positions) [PRIMARY]
- max_uncovered_landmark_distance: max of min distances (args: agent_positions, landmark_positions) [PRIMARY]
- coverage_entropy_or_balance: coverage distribution quality (args: agent_positions, landmark_positions) [SECONDARY]
- agent_target_assignment_distance: Hungarian assignment distance (args: agent_positions, landmark_positions) [PRIMARY]
- pairwise_agent_distance: distances between agents (args: agent_positions) [SECONDARY]
- collision_count_or_margin: collision count or safety margin (args: agent_positions) [OPTIONAL — use sparingly, weight ≤0.2]

AVAILABLE POTENTIAL TYPES (for potential.type field):
- negative_normalized_sum_min_distance: negative normalized sum of distances, clip [-1.0, 0.0] [PRIMARY — for distance-based predicates]
- negative_mean_distance: negative mean distance, clip [-1.0, 0.0] [PRIMARY — for distance-based predicates]
- collision_margin_bonus: bonus above collision threshold, clip [-1.0, 0.0] or [0.0, 1.0] [OPTIONAL — use only with collision predicates]
- balanced_coverage: scaled coverage balance, clip [-1.0, 1.0] [SECONDARY — use with coverage predicates]

RECOMMENDED DESIGN PATTERN (most effective):
Design 1-2 subgoals focused purely on minimizing agent-to-landmark distances.
This simple pattern consistently outperforms complex multi-objective designs.
Example: one subgoal with min_distance_landmark_coverage + negative_normalized_sum_min_distance.


REQUIRED DSL FORMAT (return EXACTLY this JSON structure):
{
  "task_name": "simple_spread_v3",
  "version": "1.0",
  "description": "Brief description of the shaping design",
  "subgoals": [
    {
      "name": "subgoal_name",
      "scope": "global",
      "weight": 1.0,
      "predicate": {
        "type": "min_distance_landmark_coverage",
        "args": {
          "agent_key": "agent_positions",
          "landmark_key": "landmark_positions"
        }
      },
      "potential": {
        "type": "negative_normalized_sum_min_distance",
        "clip": [-1.0, 0.0]
      },
      "rationale": "Why this subgoal helps"
    }
  ],
  "expected_effects": {
    "sample_efficiency": "increase",
    "final_return": "non_decrease",
    "interpretability": "increase"
  }
}

IMPORTANT: The args for predicates must use these keys:
- For landmark-based predicates: agent_key="agent_positions", landmark_key="landmark_positions"
- For agent-only predicates: agent_key="agent_positions"
The values like "agent_positions" and "landmark_positions" are the actual state variable names available in the environment.
"""

    REPAIR_SYSTEM_PROMPT = """You previously generated a DSL that failed validation.
Below are the original JSON, validation errors, and counterexample states.
Please fix ALL reported issues and return a corrected JSON that matches the DSL format EXACTLY.
Return JSON only. Do NOT include markdown code blocks or additional text."""

    CONSENSUS_SYSTEM_PROMPT = """You are given multiple candidate potential-based reward shaping DSL definitions 
for the same cooperative MARL environment. Your task is to analyze these candidates, 
identify the strongest ideas from each, and produce a single merged DSL definition.

Guidelines:
- Combine complementary subgoals from different candidates.
- Avoid redundant or overlapping subgoals.
- Preserve the best rationale from each subgoal.
- Ensure the merged DSL conforms to the DSL schema EXACTLY.
- Keep between 2 and 5 subgoals.
- Return valid JSON only without markdown code blocks.
- Prioritize sample efficiency without changing the intended task."""

    @staticmethod
    def _format_env_spec(env_spec: dict) -> str:
        lines: List[str] = []
        lines.append("=== Environment Specification ===")
        for key, value in env_spec.items():
            if isinstance(value, list):
                lines.append(f"{key}:")
                for item in value:
                    lines.append(f"  - {item}")
            elif isinstance(value, dict):
                lines.append(f"{key}:")
                for sub_key, sub_value in value.items():
                    lines.append(f"  {sub_key}: {sub_value}")
            else:
                lines.append(f"{key}: {value}")
        return "\n".join(lines)

    def build_generation_prompt(self, env_spec: dict) -> list:
        user_content = self._format_env_spec(env_spec)
        user_content += "\n\nPlease generate a potential-based reward shaping DSL for this environment."
        return [
            {"role": "system", "content": self.GENERATION_SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ]

    def build_repair_prompt(
        self,
        original_dsl: dict,
        counterexample: str,
        errors: list,
    ) -> list:
        user_parts: List[str] = []
        user_parts.append("=== Original DSL (JSON) ===")
        user_parts.append(json.dumps(original_dsl, indent=2, ensure_ascii=False))
        user_parts.append("")
        user_parts.append("=== Validation Errors ===")
        for i, error in enumerate(errors, 1):
            if isinstance(error, dict):
                user_parts.append(
                    f"Error {i}: {error.get('message', json.dumps(error))}"
                )
            else:
                user_parts.append(f"Error {i}: {error}")
        user_parts.append("")
        user_parts.append("=== Counterexample States ===")
        user_parts.append(counterexample)
        user_parts.append("")
        user_parts.append("Please fix ALL reported issues and return a corrected JSON.")

        return [
            {"role": "system", "content": self.REPAIR_SYSTEM_PROMPT},
            {"role": "user", "content": "\n".join(user_parts)},
        ]

    def build_consensus_prompt(
        self,
        candidate_dsls: list,
        env_spec: dict,
    ) -> list:
        user_parts: List[str] = []
        user_parts.append("=== Environment Specification ===")
        user_parts.append(self._format_env_spec(env_spec))
        user_parts.append("")
        user_parts.append(
            f"=== Candidate DSL Definitions ({len(candidate_dsls)} candidates) ==="
        )
        for i, candidate in enumerate(candidate_dsls, 1):
            user_parts.append(f"--- Candidate {i} ---")
            user_parts.append(json.dumps(candidate, indent=2, ensure_ascii=False))
            user_parts.append("")
        user_parts.append("Please merge these candidates into a single optimal DSL definition.")

        return [
            {"role": "system", "content": self.CONSENSUS_SYSTEM_PROMPT},
            {"role": "user", "content": "\n".join(user_parts)},
        ]
