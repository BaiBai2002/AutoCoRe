from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from autocore.llm.client import LLMClient
from autocore.llm.providers import ProviderConfig, load_providers
from autocore.llm.cache import LLMCache
from autocore.utils.logging import get_logger

logger = get_logger(__name__)

_FAMILY_NAMES = [
    "task-progress",
    "safety-collision",
    "coverage-assignment",
    "balance-role",
    "sparse-event",
    "conservative-low-dominance",
    "exploratory-high-signal",
    "environment-specific",
]

_TEMPERATURE_VALUES = [0.2, 0.4, 0.6, 0.8]

_DEFAULT_ALLOWED_PREDICATES = [
    ("min_distance_landmark_coverage", "Each landmark's minimum distance to nearest agent. Lower = better coverage. Args: agent_key, landmark_key."),
    ("mean_distance_to_nearest_landmark", "Mean of min distances from each landmark to nearest agent. Lower = better. Args: agent_key, landmark_key."),
    ("max_uncovered_landmark_distance", "Maximum of min distances across landmarks. Lower = worst case improved. Args: agent_key, landmark_key."),
    ("pairwise_agent_distance", "Distances between agent pairs. Higher = more spread. Args: agent_key."),
    ("collision_count_or_margin", "Collision count (lower better) or safety margin (higher better). Args: agent_key."),
    ("coverage_entropy_or_balance", "Entropy/balance of agent-to-landmark coverage distribution. Higher = more balanced. Args: agent_key, landmark_key."),
    ("agent_target_assignment_distance", "Hungarian algorithm optimal assignment total cost. Lower = better. Args: agent_key, landmark_key."),
    ("distance_to_assigned_target", "Distance from agents to Hungarian-assigned targets. Lower = better. Args: agent_key, landmark_key."),
    ("nearest_agent_target_gap", "Mean of nearest-agent distance to each target. Lower = better. Args: agent_key, landmark_key."),
    ("target_coverage_indicator", "Count of targets within coverage threshold. Higher = better. Args: agent_key, landmark_key."),
    ("uncovered_target_count", "Count of targets NOT covered. Lower = better. Args: agent_key, landmark_key."),
    ("agent_spread_regularizer", "Mean pairwise agent distance. Higher = more spread. Args: agent_key."),
    ("collision_margin_continuous", "Continuous collision margin. Higher = safer. Args: agent_key."),
    ("velocity_smoothness", "Negative std of agent velocities. Higher = smoother. Args: agent_key."),
    ("stagnation_penalty_indicator", "Penalty for lack of movement. Higher = more progress. Args: agent_key."),
    ("progress_toward_goal", "Delta distance toward goal center vs previous state. Higher = approaching. Args: agent_key, goal_key."),
]

_DEFAULT_ALLOWED_POTENTIALS = [
    ("negative_normalized_sum_min_distance", "Negative normalized sum of predicate value. Range [-1.0, 0.0]. Higher value (closer to 0) = better."),
    ("negative_mean_distance", "Negative mean of predicate value. Range [-1.0, 0.0]. Higher value (closer to 0) = better."),
    ("collision_margin_bonus", "Bonus when predicate value exceeds threshold. Range [0.0, 1.0] or [-1.0, 0.0]."),
    ("balanced_coverage", "Scaled coverage balance. Range [-1.0, 1.0]. Higher = more balanced coverage."),
]

_PROHIBITED_NAMES = [
    "agents", "agent", "listener", "listeners", "speaker", "speakers",
    "adversary_key", "adversary", "box_center", "box_position",
    "agent_keys", "landmark_keys", "positions",
]

_JSON_BLOCK_PATTERN = re.compile(r"```(?:json)?\s*\n?(.*?)\n?\s*```", re.DOTALL)


@dataclass
class SemanticCandidate:
    family_name: str
    intended_progress_metric: str
    expected_failure_mode: str
    expected_reward_scale: str
    rationale: str
    subgoals: list[dict[str, Any]] = field(default_factory=list)
    task_name: str = ""
    version: str = "1.0"
    description: str = ""
    candidate_id: str = ""
    family_description: str = ""
    expected_effects: dict[str, str] = field(default_factory=lambda: {
        "sample_efficiency": "increase",
        "final_return": "non_decrease",
        "interpretability": "increase",
    })

    def to_dsl_dict(self) -> dict[str, Any]:
        return {
            "family_name": self.family_name,
            "family_description": self.family_description,
            "candidate_id": self.candidate_id,
            "intended_progress_metric": self.intended_progress_metric,
            "expected_failure_mode": self.expected_failure_mode,
            "expected_reward_scale": self.expected_reward_scale,
            "rationale": self.rationale,
            "task_name": self.task_name,
            "version": self.version,
            "description": self.description,
            "subgoals": self.subgoals,
            "expected_effects": self.expected_effects,
        }


def _load_template(name: str = "autocore_select_v3") -> str:
    template_path = Path(__file__).resolve().parent / "prompt_templates" / f"{name}.txt"
    if not template_path.exists():
        raise FileNotFoundError(f"Prompt template not found: {template_path}")
    return template_path.read_text(encoding="utf-8")


def _build_allowed_predicates_desc(
    allowed_predicates: List[tuple[str, str]] | None = None,
) -> str:
    preds = allowed_predicates if allowed_predicates is not None else _DEFAULT_ALLOWED_PREDICATES
    lines = []
    for name, desc in preds:
        lines.append(f"  - {name}: {desc}")
    return "\n".join(lines)


def _build_allowed_potentials_desc(
    allowed_potentials: List[tuple[str, str]] | None = None,
) -> str:
    pots = allowed_potentials if allowed_potentials is not None else _DEFAULT_ALLOWED_POTENTIALS
    lines = []
    for name, desc in pots:
        lines.append(f"  - {name}: {desc}")
    return "\n".join(lines)


def _build_env_spec_text(env_spec: dict[str, Any]) -> str:
    lines: list[str] = []
    for key, value in env_spec.items():
        if isinstance(value, list):
            lines.append(f"{key}:")
            for item in value:
                lines.append(f"  - {item}")
        elif isinstance(value, dict):
            lines.append(f"{key}:")
            for sub_key, sub_value in value.items():
                lines.append(f"  {sub_key}: {sub_value}")
        else:
            lines.append(f"{key}: {value}")
    return "\n".join(lines)


def _build_messages(
    env_spec: dict[str, Any],
    allowed_predicates: List[tuple[str, str]] | None = None,
    allowed_potentials: List[tuple[str, str]] | None = None,
    template_name: str = "autocore_select_v3",
) -> list[dict[str, str]]:
    template = _load_template(template_name)

    allowed_vars = env_spec.get("available_state_variables", [])
    allowed_vars_list = "\n".join(f"  - {v}" for v in allowed_vars)

    env_id = env_spec.get("env_id", env_spec.get("env_name", "unknown"))
    num_families = len(_FAMILY_NAMES)
    min_total = num_families * 2

    prompt = template.format(
        num_families=num_families,
        allowed_state_variables_list=allowed_vars_list,
        allowed_predicates_desc=_build_allowed_predicates_desc(allowed_predicates),
        allowed_potentials_desc=_build_allowed_potentials_desc(allowed_potentials),
        env_spec_text=_build_env_spec_text(env_spec),
        env_id=env_id,
        min_total_candidates=min_total,
    )

    return [
        {"role": "system", "content": prompt},
        {"role": "user", "content": "Generate all 8 candidate families with at least 2 candidates each. Return ONLY the JSON."},
    ]


def _extract_json(text: str) -> dict[str, Any] | None:
    """Best-effort JSON extraction. Returns ``None`` on any parse failure.

    Returning ``None`` (rather than raising) matters for the verify-and-repair path:
    a single malformed repair response must be skipped, never allowed to abort the
    whole candidate search.
    """
    text = (text or "").strip()
    if not text:
        return None

    match = _JSON_BLOCK_PATTERN.search(text)
    if match:
        text = match.group(1).strip()

    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
        text = text[first_brace:last_brace + 1]

    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, ValueError):
        return None
    return obj if isinstance(obj, dict) else None


def _parse_raw_to_candidates(raw_output: dict[str, Any]) -> list[SemanticCandidate]:
    raw_candidates = raw_output.get("candidates", [])
    parsed: list[SemanticCandidate] = []

    for rc in raw_candidates:
        parsed.append(SemanticCandidate(
            family_name=rc.get("family_name", "unknown"),
            family_description=rc.get("family_description", ""),
            candidate_id=rc.get("candidate_id", ""),
            intended_progress_metric=rc.get("intended_progress_metric", ""),
            expected_failure_mode=rc.get("expected_failure_mode", ""),
            expected_reward_scale=rc.get("expected_reward_scale", ""),
            rationale=rc.get("rationale", ""),
            task_name=rc.get("task_name", ""),
            version=rc.get("version", "1.0"),
            description=rc.get("description", ""),
            subgoals=rc.get("subgoals", []),
            expected_effects=rc.get("expected_effects", {
                "sample_efficiency": "increase",
                "final_return": "non_decrease",
                "interpretability": "increase",
            }),
        ))

    return parsed


def _sanitize_candidate(candidate: SemanticCandidate) -> SemanticCandidate:
    for sg in candidate.subgoals:
        pred_args = sg.get("predicate", {}).get("args", {})
        for arg_key, arg_val in pred_args.items():
            if isinstance(arg_val, str) and arg_val.lower() in {
                n.lower() for n in _PROHIBITED_NAMES
            }:
                logger.warning(
                    f"Candidate {candidate.candidate_id}: "
                    f"prohibited arg value '{arg_val}' in predicate args, "
                    f"will be flagged for canonicalization"
                )

        pot = sg.get("potential", {})
        clip = pot.get("clip")
        if isinstance(clip, list) and len(clip) == 2:
            pot["clip"] = [float(clip[0]), float(clip[1])]

        weight = sg.get("weight")
        if isinstance(weight, (int, float)):
            if weight < 0.1:
                sg["weight"] = 0.1
            elif weight > 10.0:
                sg["weight"] = 10.0

    return candidate


class SemanticCandidateGenerator:
    def __init__(
        self,
        provider: str | ProviderConfig | None = None,
        config_path: str | None = None,
        cache: LLMCache | None = None,
    ) -> None:
        self._cache = cache if cache is not None else LLMCache()

        if provider is None:
            loaded = load_providers(config_path)
            available = [p for p in loaded.values() if p.is_available]
            if not available:
                raise RuntimeError("No available LLM provider found")
            self._provider = available[0]
        elif isinstance(provider, str):
            loaded = load_providers(config_path)
            if provider not in loaded:
                raise ValueError(f"Provider '{provider}' not found in config")
            self._provider = loaded[provider]
        else:
            self._provider = provider

        logger.info(
            f"SemanticCandidateGenerator using provider '{self._provider.name}' "
            f"(model={self._provider.model})"
        )

    def generate(
        self,
        env_spec: dict[str, Any],
        temperatures: list[float] | None = None,
        allowed_predicates: List[tuple[str, str]] | None = None,
        allowed_potentials: List[tuple[str, str]] | None = None,
        extra_params: dict[str, Any] | None = None,
        effort_tag: str = "",
        template: str = "autocore_select_v3",
    ) -> list[SemanticCandidate]:
        """Generate candidates. ``extra_params`` is merged into the request body (e.g. a
        reasoning-effort hint); ``effort_tag`` must change whenever ``extra_params`` changes
        so that the response cache never mixes inference-time-compute settings.

        ``template`` selects the prompt file. The default template keeps the historic
        cache key byte-for-byte, so switching prompts cannot silently reuse or invalidate
        an existing response.
        """
        temps = temperatures if temperatures is not None else _TEMPERATURE_VALUES
        messages = _build_messages(env_spec, allowed_predicates, allowed_potentials, template)
        tpl_tag = "" if template == "autocore_select_v3" else f"-{template}"
        env_id = env_spec.get("env_id", env_spec.get("env_name", "unknown"))
        all_candidates: list[SemanticCandidate] = []

        for family_idx, family_name in enumerate(_FAMILY_NAMES):
            temp = temps[family_idx % len(temps)]

            prompt_hash = LLMCache.hash_content(
                json.dumps(messages, sort_keys=True, ensure_ascii=False)
            )
            env_spec_hash = LLMCache.hash_content(
                json.dumps(env_spec, sort_keys=True, ensure_ascii=False)
            )
            cache_key = LLMCache.make_key(
                provider=self._provider.name,
                model=self._provider.model,
                prompt_hash=prompt_hash,
                env_spec_hash=env_spec_hash,
                method_version=f"semantic-v3-{family_name}-t{temp}{effort_tag}{tpl_tag}",
            )

            cached_response = self._cache.get(cache_key)
            if cached_response is not None:
                logger.info(
                    f"Cache HIT for family '{family_name}' (temp={temp})"
                )
                raw_output = cached_response
            else:
                provider_dict = self._provider.to_dict()
                provider_dict["api_key"] = self._provider.api_key
                with LLMClient(provider_dict) as client:
                    raw_response = client.generate(
                        messages=messages,
                        temperature=temp,
                        max_tokens=8192,
                        extra_params=extra_params,
                    )
                raw_output = {"content": raw_response["content"], "model": raw_response["model"]}
                self._cache.put(cache_key, raw_output)

            parsed = _extract_json(raw_output.get("content", ""))
            if parsed is None:
                logger.error(
                    f"Failed to parse JSON for family '{family_name}': "
                    f"response was not a valid JSON object"
                )
                continue

            family_candidates = _parse_raw_to_candidates(parsed)
            family_matched = [
                c for c in family_candidates
                if c.family_name.lower().replace(" ", "-") == family_name
            ]

            if not family_matched:
                family_matched = [
                    c for c in family_candidates
                    if family_name.split("-")[0] in c.family_name.lower().replace(" ", "-")
                ]

            if not family_matched and family_candidates:
                family_matched = [family_candidates[0]]

            for cand in family_matched:
                cand = _sanitize_candidate(cand)
                if cand.family_name.lower().replace(" ", "-") != family_name:
                    cand.family_name = family_name
                if not cand.candidate_id:
                    idx = len(all_candidates) + 1
                    cand.candidate_id = f"{family_name}-{idx:03d}"

            all_candidates.extend(family_matched)
            logger.info(
                f"Family '{family_name}': generated {len(family_matched)} candidate(s) "
                f"(temp={temp})"
            )

        logger.info(
            f"Total candidates generated for env '{env_id}': {len(all_candidates)}"
        )
        return all_candidates

    def generate_strict(
        self,
        env_spec: dict[str, Any],
        temperatures: list[float] | None = None,
        allowed_predicates: List[tuple[str, str]] | None = None,
        allowed_potentials: List[tuple[str, str]] | None = None,
    ) -> list[SemanticCandidate]:
        candidates = self.generate(
            env_spec=env_spec,
            temperatures=temperatures,
            allowed_predicates=allowed_predicates,
            allowed_potentials=allowed_potentials,
        )

        seen_families: set[str] = set()
        min_per_family: dict[str, int] = {}
        for cand in candidates:
            fn = cand.family_name
            seen_families.add(fn)
            min_per_family[fn] = min_per_family.get(fn, 0) + 1

        for family_name in _FAMILY_NAMES:
            if family_name not in seen_families:
                logger.warning(f"Missing family '{family_name}' in generation results")

        return candidates


def create_generator(
    provider_name: str | None = None,
    config_path: str | None = None,
) -> SemanticCandidateGenerator:
    return SemanticCandidateGenerator(
        provider=provider_name,
        config_path=config_path,
    )
