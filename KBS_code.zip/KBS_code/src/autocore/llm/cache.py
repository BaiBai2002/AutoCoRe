import hashlib
import json
import re
import time
from pathlib import Path
from typing import Optional

from autocore.utils.io import ensure_dir, load_json, save_json
from autocore.utils.logging import get_logger

logger = get_logger(__name__)

_API_KEY_PATTERN = re.compile(r"\b[a-zA-Z0-9_-]{32,}\b")

# A pure lowercase/underscore token of >=32 chars is a DSL identifier
# (e.g. "negative_normalized_sum_min_distance"), not a credential. Redacting it
# silently corrupts cached LLM responses and makes cache hits differ from the
# run that produced them. Credentials contain non-[a-z_] characters (digits,
# uppercase, or a scheme prefix such as "sk-"), so they are still redacted.
_DSL_IDENTIFIER_PATTERN = re.compile(r"^[a-z_]+$")


def _redact_secrets_in_text(text: str) -> str:
    def _replace(match: re.Match) -> str:
        token = match.group(0)
        if _DSL_IDENTIFIER_PATTERN.match(token):
            return token
        return "[REDACTED_API_KEY]"

    return _API_KEY_PATTERN.sub(_replace, text)


def _get_cache_dir() -> Path:
    return Path(__file__).resolve().parents[3] / "artifacts" / "llm_cache"


class LLMCache:
    def __init__(self, cache_dir: Optional[str] = None):
        if cache_dir is not None:
            self._cache_dir = Path(cache_dir)
        else:
            self._cache_dir = _get_cache_dir()
        ensure_dir(self._cache_dir)
        self._index_path = self._cache_dir / "cache_index.json"
        self._index: dict = self._load_index()
        logger.info(
            f"LLMCache initialized at {self._cache_dir} "
            f"({len(self._index)} entries in index)"
        )

    def _load_index(self) -> dict:
        if self._index_path.exists():
            try:
                return load_json(self._index_path)
            except (json.JSONDecodeError, OSError) as e:
                logger.warning(f"Failed to load cache index, starting fresh: {e}")
                return {}
        return {}

    def _save_index(self) -> None:
        save_json(self._index, self._index_path)

    def _key_to_filename(self, key: str) -> str:
        hashed = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return f"{hashed}.json"

    def _redact_api_keys(self, data: dict) -> dict:
        if not isinstance(data, dict):
            return data
        result = {}
        for k, v in data.items():
            if isinstance(v, str) and _API_KEY_PATTERN.search(v):
                result[k] = _redact_secrets_in_text(v)
            elif isinstance(v, dict):
                result[k] = self._redact_api_keys(v)
            elif isinstance(v, list):
                result[k] = [
                    self._redact_api_keys(item) if isinstance(item, dict) else item
                    for item in v
                ]
            else:
                result[k] = v
        return result

    def get(self, key: str) -> Optional[dict]:
        entry = self._index.get(key)
        if entry is None:
            logger.debug(f"Cache MISS: key not in index")
            return None

        filename = entry.get("filename")
        if filename is None:
            logger.debug(f"Cache MISS: no filename for key")
            return None

        cache_file = self._cache_dir / filename
        if not cache_file.exists():
            logger.debug(f"Cache MISS: file {filename} not found on disk")
            return None

        try:
            cached = load_json(cache_file)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Cache file {filename} corrupted: {e}")
            return None

        response = cached.get("response")
        if response is None:
            logger.debug(f"Cache MISS: no response data in {filename}")
            return None

        logger.info(
            f"Cache HIT: {filename} "
            f"(created={cached.get('timestamp', 'unknown')})"
        )
        return response

    def put(self, key: str, response: dict) -> None:
        filename = self._key_to_filename(key)
        safe_response = self._redact_api_keys(response)

        entry_data = {
            "key": key,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "provider_status": "ok",
            "response": safe_response,
        }

        cache_file = self._cache_dir / filename
        save_json(entry_data, cache_file)

        self._index[key] = {
            "filename": filename,
            "timestamp": entry_data["timestamp"],
            "provider_status": "ok",
        }
        self._save_index()
        logger.info(f"Cache PUT: {filename}")

    def has_key(self, key: str) -> bool:
        if key not in self._index:
            return False
        entry = self._index[key]
        filename = entry.get("filename")
        if filename is None:
            return False
        cache_file = self._cache_dir / filename
        return cache_file.exists()

    def invalidate(self, key: str) -> bool:
        if key not in self._index:
            return False
        entry = self._index.pop(key)
        filename = entry.get("filename")
        if filename:
            cache_file = self._cache_dir / filename
            if cache_file.exists():
                cache_file.unlink()
                logger.info(f"Cache INVALIDATED: {filename}")
        self._save_index()
        return True

    def clear(self) -> int:
        count = 0
        for entry in self._index.values():
            filename = entry.get("filename")
            if filename:
                cache_file = self._cache_dir / filename
                if cache_file.exists():
                    cache_file.unlink()
                    count += 1
        self._index.clear()
        self._save_index()
        logger.info(f"Cache CLEARED: {count} files removed")
        return count

    @property
    def size(self) -> int:
        return len(self._index)

    @staticmethod
    def make_key(
        provider: str,
        model: str,
        prompt_hash: str,
        env_spec_hash: str,
        method_version: str,
    ) -> str:
        raw = f"{provider}|{model}|{prompt_hash}|{env_spec_hash}|{method_version}"
        return raw

    @staticmethod
    def hash_content(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]
