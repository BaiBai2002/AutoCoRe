import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from dotenv import load_dotenv

from autocore.utils.io import load_yaml
from autocore.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ProviderConfig:
    name: str
    display_name: str
    api_key_env: str
    base_url_env: str
    model_env: str
    default_model: str
    default_base_url: str
    timeout: int = 120
    max_retries: int = 3
    retry_delay: int = 5
    chat_endpoint: str = "/chat/completions"
    _api_key: Optional[str] = field(default=None, repr=False)
    _base_url: Optional[str] = field(default=None, repr=False)
    _model: Optional[str] = field(default=None, repr=False)

    @property
    def api_key(self) -> Optional[str]:
        if self._api_key is None:
            self._api_key = os.getenv(self.api_key_env)
        return self._api_key

    @property
    def base_url(self) -> str:
        if self._base_url is None:
            self._base_url = os.getenv(self.base_url_env) or self.default_base_url
        return self._base_url

    @property
    def model(self) -> str:
        if self._model is None:
            self._model = os.getenv(self.model_env) or self.default_model
        return self._model

    @property
    def is_available(self) -> bool:
        return self.api_key is not None and len(self.api_key) > 0

    def resolve(self) -> None:
        _ = self.api_key
        _ = self.base_url
        _ = self.model

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "display_name": self.display_name,
            "model": self.model,
            "base_url": self.base_url,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "chat_endpoint": self.chat_endpoint,
            "is_available": self.is_available,
        }


def _get_project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def load_providers(config_path: Optional[str] = None) -> Dict[str, ProviderConfig]:
    load_dotenv(_get_project_root() / ".env")
    if config_path is None:
        config_path = str(_get_project_root() / "configs" / "providers.yaml")
    raw = load_yaml(config_path)
    providers_raw = raw.get("providers", {})
    providers: Dict[str, ProviderConfig] = {}
    for key, cfg in providers_raw.items():
        provider = ProviderConfig(
            name=cfg["name"],
            display_name=cfg["display_name"],
            api_key_env=cfg["api_key_env"],
            base_url_env=cfg["base_url_env"],
            model_env=cfg["model_env"],
            default_model=cfg.get("default_model", ""),
            default_base_url=cfg.get("default_base_url", ""),
            timeout=cfg.get("timeout", 120),
            max_retries=cfg.get("max_retries", 3),
            retry_delay=cfg.get("retry_delay", 5),
            chat_endpoint=cfg.get("chat_endpoint", "/chat/completions"),
        )
        provider.resolve()
        providers[key] = provider
    logger.info(f"Loaded {len(providers)} provider(s) from config")
    return providers


def get_available_providers(
    config_path: Optional[str] = None,
) -> List[ProviderConfig]:
    all_providers = load_providers(config_path)
    available: List[ProviderConfig] = []
    for name, provider in all_providers.items():
        if provider.is_available:
            available.append(provider)
            logger.info(f"Provider '{name}' is available (model={provider.model})")
        else:
            logger.warning(
                f"Provider '{name}' is NOT available: "
                f"environment variable '{provider.api_key_env}' is not set"
            )
    return available


def is_provider_available(provider_name: str, config_path: Optional[str] = None) -> bool:
    all_providers = load_providers(config_path)
    provider = all_providers.get(provider_name)
    if provider is None:
        logger.warning(f"Provider '{provider_name}' not found in configuration")
        return False
    return provider.is_available
