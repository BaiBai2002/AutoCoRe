from typing import Optional


def get_device(device: Optional[str] = None) -> str:
    try:
        import torch

        if device is not None:
            if device in ("cuda", "cpu") or device.startswith("cuda:"):
                return device
            return "cpu"

        if torch.cuda.is_available():
            return "cuda"
        return "cpu"
    except ImportError:
        return "cpu"
