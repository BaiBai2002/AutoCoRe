import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


def ensure_dir(path: Union[str, Path]) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_json(
    data: Union[Dict[str, Any], List[Any]],
    filepath: Union[str, Path],
    indent: int = 2,
    ensure_ascii: bool = False,
) -> None:
    p = Path(filepath)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=indent, ensure_ascii=ensure_ascii)


def load_json(filepath: Union[str, Path]) -> Any:
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def save_yaml(
    data: Any,
    filepath: Union[str, Path],
    default_flow_style: bool = False,
    allow_unicode: bool = True,
) -> None:
    import yaml

    p = Path(filepath)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=default_flow_style, allow_unicode=allow_unicode)


def load_yaml(filepath: Union[str, Path]) -> Any:
    import yaml

    with open(filepath, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)
