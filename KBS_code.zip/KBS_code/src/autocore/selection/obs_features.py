"""Observation-derived feature bank for environments without an MPE-style world.

MPE exposes particle positions, so the potential can be written over explicit
geometric quantities. PettingZoo SISL does not, but every parallel environment
does expose observations, and the joint observation is a function of the state.
The features below are therefore statistics of the joint observation, split by
observation channel when the observation is a spatial grid.

This is deliberately a *generic* family rather than a hand-designed one: the
point of the second benchmark is to test whether the protocol transfers, not to
tune a feature set per environment.
"""
from __future__ import annotations

from typing import Any, Callable

import numpy as np

from autocore.selection.landscape_search import FeatureBank
from autocore.envs.vec_pz import make_pz_env, state_from_obs

StateDict = dict[str, Any]


def _flat(state: StateDict) -> np.ndarray:
    mat = np.asarray(state.get("obs", np.zeros((0, 1))), dtype=np.float64)
    if mat.size == 0:
        return np.zeros(1)
    return mat.reshape(mat.shape[0], -1)


def observation_features(shape: tuple[int, ...]) -> list[tuple[str, Callable[[StateDict], float]]]:
    """Statistics of the joint observation, plus per-channel aggregates."""
    feats: list[tuple[str, Callable[[StateDict], float]]] = [
        ("obs_mean", lambda s: float(_flat(s).mean())),
        ("obs_std", lambda s: float(_flat(s).std())),
        ("obs_min", lambda s: float(_flat(s).min())),
        ("obs_max", lambda s: float(_flat(s).max())),
        ("obs_energy", lambda s: float((_flat(s) ** 2).mean())),
    ]
    if len(shape) >= 3:
        channels = int(shape[-1])
        total = int(np.prod(shape))
        per_channel = total // channels if channels else total

        def channel_slice(s: StateDict, c: int, agg: str) -> float:
            mat = _flat(s)
            if mat.shape[1] < total:
                return 0.0
            block = mat[:, c * per_channel:(c + 1) * per_channel]
            return float(block.mean() if agg == "mean" else block.max())

        for c in range(channels):
            feats.append((f"obs_ch{c}_mean",
                          (lambda s, c=c: channel_slice(s, c, "mean"))))
            feats.append((f"obs_ch{c}_max",
                          (lambda s, c=c: channel_slice(s, c, "max"))))
    return feats


def _seeded_action(space: Any, rng: np.random.Generator):
    """Draw one action from ``space`` using a caller-supplied generator.

    Gymnasium spaces carry their own ``np_random``, created from OS entropy when the
    space is built, so ``space.sample()`` is not reproducible across processes. Any
    reference rollout that must be reproducible has to draw from an explicitly
    seeded generator instead.
    """
    if hasattr(space, "n"):
        return int(rng.integers(0, int(space.n)))
    if hasattr(space, "nvec"):
        return np.asarray([rng.integers(0, int(k)) for k in space.nvec], dtype=np.int64)
    low = np.asarray(space.low, dtype=np.float64)
    high = np.asarray(space.high, dtype=np.float64)
    return np.asarray(rng.uniform(low, high), dtype=np.float32)


def build_obs_bank(env_id: str, max_cycles: int = 100, n_episodes: int = 6,
                   seed: int = 0, **env_kwargs: Any) -> FeatureBank:
    """Fit a feature bank on states visited by a random reference policy."""
    probe = make_pz_env(env_id, max_cycles=max_cycles, **env_kwargs)
    agent_names = list(probe.possible_agents)
    shape = tuple(probe.observation_space(agent_names[0]).shape)
    probe.close()

    bank = FeatureBank(extra_features=observation_features(shape))
    env = make_pz_env(env_id, max_cycles=max_cycles, **env_kwargs)
    states: list[StateDict] = []
    rng = np.random.default_rng(seed)
    for ep in range(n_episodes):
        res = env.reset(seed=int(seed) * 1000 + ep)
        raw = res[0] if isinstance(res, tuple) else res
        states.append(state_from_obs(raw, agent_names))
        done = False
        while not done and env.agents:
            # Draw from the seeded generator, never from the space's own RNG:
            # ``space.sample()`` is seeded from OS entropy, which would make the
            # fitted normalisation (and the constant-feature filter, hence the bank
            # dimension) vary between runs of the same command.
            acts = {a: _seeded_action(env.action_space(a), rng) for a in env.agents}
            raw, _r, term, trunc, _ = env.step(acts)
            states.append(state_from_obs(raw, agent_names))
            done = any(bool(term.get(a, False)) or bool(trunc.get(a, False))
                       for a in env.agents)
    env.close()
    return bank.fit(states, drop_constant=True)
