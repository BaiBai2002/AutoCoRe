"""
AutoCoRe Candidate Selector — Utility-aware DSL candidate selection.
"""
from __future__ import annotations
from typing import Any, Optional
import numpy as np

from autocore.selection.proxy_scores import (
    CandidateScore, compute_validity_score, compute_diversity_score,
    compute_progress_alignment_score, compute_reward_dominance_score,
    compute_non_interference_score, compute_interpretability_score,
    compute_composite_score,
)


class CandidateSelector:
    def __init__(self, config: Optional[dict[str, Any]] = None):
        cfg = config or {}
        self._score_weights = cfg.get("score_weights", {
            "validity": 0.25, "progress_alignment": 0.20,
            "reward_dominance": 0.20, "non_interference": 0.15,
            "diversity": 0.10, "interpretability": 0.10,
        })
        self._safe_reward_ratio = tuple(cfg.get("safe_reward_ratio", (0.05, 0.50)))
        self._max_reward_ratio = cfg.get("maximum_reward_ratio", 1.0)

    def score_candidate(
        self,
        dsl: dict[str, Any],
        static_checks_passed: list[bool],
        rollout_checks_passed: list[bool],
        repair_rounds: int,
        delta_phi_values: list[float],
        env_rewards: list[float],
        shaping_rewards: list[float],
        progress_metrics: Optional[list[float]] = None,
        transition_pairs: Optional[list[tuple[float, float, float, float]]] = None,
    ) -> CandidateScore:
        score = CandidateScore()
        score.validity_score = compute_validity_score(static_checks_passed, rollout_checks_passed, repair_rounds)
        score.is_valid = score.validity_score > 0.5
        if not score.is_valid:
            return score

        phi_vals = list(delta_phi_values) if len(delta_phi_values) > 0 else [0.0]
        score.diversity_score = compute_diversity_score(phi_vals)
        score.progress_alignment_score = compute_progress_alignment_score(
            delta_phi_values, env_rewards, progress_metrics)
        score.reward_dominance_score = compute_reward_dominance_score(
            shaping_rewards, env_rewards, self._safe_reward_ratio, self._max_reward_ratio)
        score.non_interference_score = compute_non_interference_score(
            transition_pairs or [])
        score.interpretability_score = compute_interpretability_score(dsl)
        score.composite_score = compute_composite_score(score)
        score.metadata = {
            "safe_ratio": self._safe_reward_ratio,
            "max_ratio": self._max_reward_ratio,
        }
        return score

    def select_best(
        self,
        candidates: list[tuple[dict[str, Any], CandidateScore]],
    ) -> tuple[dict[str, Any], CandidateScore, list[tuple[dict[str, Any], CandidateScore]]]:
        valid = [(dsl, sc) for dsl, sc in candidates if sc.is_valid]
        if not valid:
            invalid = [(dsl, sc) for dsl, sc in candidates]
            invalid.sort(key=lambda x: x[1].validity_score, reverse=True)
            best_dsl, best_score = invalid[0]
            return best_dsl, best_score, invalid
        valid.sort(key=lambda x: x[1].composite_score, reverse=True)
        return valid[0][0], valid[0][1], valid


def select_lambda(
    candidate: tuple[dict[str, Any], CandidateScore],
    lambda_values: list[float],
    shaping_evaluator: Any,
    env_rewards: list[float],
    safe_interval: tuple[float, float] = (0.05, 0.50),
    early_auc: Optional[dict[float, float]] = None,
) -> tuple[float, str]:
    best_lambda = lambda_values[len(lambda_values)//2]
    best_reason = "default middle lambda"
    best_dist = float("inf")

    safe_lambdas: list[tuple[float, float]] = []
    for lam in lambda_values:
        try:
            ratio = shaping_evaluator(lam, env_rewards)
        except Exception:
            continue
        if safe_interval[0] <= ratio <= safe_interval[1]:
            safe_lambdas.append((lam, ratio))

    if early_auc is not None and safe_lambdas:
        best_lam, _ = max(safe_lambdas, key=lambda x: early_auc.get(x[0], 0.0))
        return best_lam, f"highest early AUC among safe lambdas (n={len(safe_lambdas)})"

    if safe_lambdas:
        for lam, ratio in safe_lambdas:
            d = abs(ratio - 0.2)
            if d < best_dist:
                best_dist = d
                best_lambda = lam
        return best_lambda, f"safe lambda closest to ratio=0.2 (n={len(safe_lambdas)})"

    for lam in lambda_values:
        try:
            ratio = shaping_evaluator(lam, env_rewards)
        except Exception:
            continue
        d = abs(ratio - 0.2)
        if d < best_dist:
            best_dist = d
            best_lambda = lam
    return best_lambda, f"closest to ratio=0.2 (no safe lambdas found)"
