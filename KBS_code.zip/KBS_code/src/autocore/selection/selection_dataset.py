from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Optional

import pandas as pd


@dataclass
class SelectionRecord:
    candidate: dict[str, Any]
    lambda_value: float
    calibration: dict[str, Any] = field(default_factory=dict)
    probe_score: Optional[float] = None
    probe_metrics: Optional[dict[str, Any]] = None
    rank: int = -1

    @property
    def candidate_hash(self) -> str:
        return _hash_candidate(self.candidate)

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_hash": self.candidate_hash,
            "candidate": dict(self.candidate),
            "lambda": self.lambda_value,
            "calibration": dict(self.calibration),
            "probe_score": self.probe_score,
            "probe_metrics": dict(self.probe_metrics) if self.probe_metrics else None,
            "rank": self.rank,
        }


class SelectionDataset:
    def __init__(self) -> None:
        self._records: dict[str, dict[str, SelectionRecord]] = {}

    def add_candidate(self, rec: SelectionRecord) -> None:
        ch = rec.candidate_hash
        lam_key = f"{rec.lambda_value:.6f}"
        if ch not in self._records:
            self._records[ch] = {}
        self._records[ch][lam_key] = rec

    def add_calibration(self, candidate_hash: str, lam: float, metrics: dict[str, Any]) -> None:
        lam_key = f"{lam:.6f}"
        if candidate_hash in self._records and lam_key in self._records[candidate_hash]:
            self._records[candidate_hash][lam_key].calibration = dict(metrics)
        else:
            rec = SelectionRecord(
                candidate={},
                lambda_value=lam,
                calibration=dict(metrics),
            )
            if candidate_hash not in self._records:
                self._records[candidate_hash] = {}
            self._records[candidate_hash][lam_key] = rec

    def add_probe(self, candidate_hash: str, lam: float, probe_result: dict[str, Any]) -> None:
        lam_key = f"{lam:.6f}"
        score = probe_result.get("probe_score", None)
        if candidate_hash in self._records and lam_key in self._records[candidate_hash]:
            self._records[candidate_hash][lam_key].probe_score = score
            self._records[candidate_hash][lam_key].probe_metrics = dict(probe_result)
        else:
            rec = SelectionRecord(
                candidate={},
                lambda_value=lam,
                probe_score=score,
                probe_metrics=dict(probe_result),
            )
            if candidate_hash not in self._records:
                self._records[candidate_hash] = {}
            self._records[candidate_hash][lam_key] = rec

    def get_best(self, n: int = 1) -> list[SelectionRecord]:
        all_records: list[SelectionRecord] = []
        for ch_records in self._records.values():
            for rec in ch_records.values():
                if rec.probe_score is not None:
                    all_records.append(rec)

        all_records.sort(key=lambda r: r.probe_score or -float("inf"), reverse=True)
        return all_records[:n]

    def to_dataframe(self) -> pd.DataFrame:
        rows: list[dict[str, Any]] = []
        for ch_records in self._records.values():
            for rec in ch_records.values():
                rows.append(rec.to_dict())
        return pd.DataFrame(rows)

    def __len__(self) -> int:
        return sum(len(ch) for ch in self._records.values())

    def __iter__(self):
        for ch_records in self._records.values():
            yield from ch_records.values()


def _hash_candidate(candidate: dict[str, Any]) -> str:
    serialized = json.dumps(candidate, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]
