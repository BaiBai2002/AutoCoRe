from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from pathlib import Path

from autocore.dsl.compiler import CompilerOutput, compile_dsl
from autocore.dsl.canonicalizer import canonicalize_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.verifier.safety_gate import SafetyGate, SafetyGateReport
from autocore.verifier.conservative_repair import ConservativeRepair, ConservativeRepairResult
from autocore.selection.lambda_calibration import (
    LambdaCalibrator,
    LambdaCalibrationConfig,
    LambdaCalibrationResult,
)
from autocore.selection.early_probe_v3 import EarlyProbeV3, ProbeV3Result
from autocore.shaping.potentials import PotentialFunction, ShapingConfig
from autocore.utils.io import save_json, load_json, ensure_dir


@dataclass
class SelectorV3Config:
    lambda_values: list[float] = field(default_factory=lambda: [0.01, 0.05, 0.1, 0.2, 0.5])
    calibration_rollout_steps: int = 2000
    probe_num_steps: int = 10_000
    probe_seeds: list[int] = field(default_factory=lambda: [2026, 2027, 2028])
    base_checkpoint_path: Optional[str] = None
    output_dir: str = "artifacts/selector_v3"


@dataclass
class SelectorV3Result:
    selected_candidate: dict[str, Any] | None = None
    selected_lambda: float = 0.0
    candidate_id: str = ""
    selection_path: str = ""
    layer1_passed: int = 0
    layer2_passed: int = 0
    layer3_evaluated: int = 0
    layer1_reports: list[SafetyGateReport] = field(default_factory=list)
    layer2_reports: list[LambdaCalibrationResult] = field(default_factory=list)
    layer3_reports: list[ProbeV3Result] = field(default_factory=list)
    repair_results: list[ConservativeRepairResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "selected_lambda": self.selected_lambda,
            "selection_path": self.selection_path,
            "layer1_passed": self.layer1_passed,
            "layer2_passed": self.layer2_passed,
            "layer3_evaluated": self.layer3_evaluated,
            "layer1_reports": [r.to_dict() for r in self.layer1_reports],
            "layer2_reports": [r.to_dict() for r in self.layer2_reports],
            "layer3_reports": [r.to_dict() for r in self.layer3_reports],
            "repair_count": len(self.repair_results),
        }


class SelectorV3:
    def __init__(
        self,
        predicate_library: PredicateLibrary,
        potential_library: PotentialLibrary,
        env_spec: dict[str, Any],
        config: Optional[SelectorV3Config] = None,
    ) -> None:
        self._predicate_library = predicate_library
        self._potential_library = potential_library
        self._env_spec = env_spec
        self.config = config or SelectorV3Config()

        self._safety_gate = SafetyGate(predicate_library, potential_library, env_spec)
        self._repair = ConservativeRepair(predicate_library, potential_library, env_spec)
        self._calibrator = LambdaCalibrator(
            LambdaCalibrationConfig(rollout_steps=self.config.calibration_rollout_steps)
        )
        self._probe = EarlyProbeV3(
            num_steps=self.config.probe_num_steps,
            probe_seeds=self.config.probe_seeds,
        )
        self._original_candidates: list[dict[str, Any]] = []

    def select(
        self,
        candidates: list[dict[str, Any]],
        env_id: str,
        make_env_fn: Any,
        train_fn: Any,
        calibration_data_fn: Optional[Any] = None,
    ) -> SelectorV3Result:
        self._original_candidates = list(candidates)
        result = SelectorV3Result()

        layer1_survivors, repair_results = self._run_layer1(candidates)
        result.repair_results = repair_results
        result.layer1_passed = len(layer1_survivors)
        result.layer1_reports = [
            self._safety_gate.validate(c) for c in layer1_survivors
        ]

        if not layer1_survivors:
            result.selection_path = "Layer1: all candidates failed safety gate"
            return result

        layer2_survivors, layer2_reports = self._run_layer2(
            layer1_survivors, calibration_data_fn
        )
        result.layer2_reports = layer2_reports
        result.layer2_passed = len(layer2_survivors)

        if not layer2_survivors:
            result.selection_path = (
                f"Layer2: all {len(layer1_survivors)} candidates failed lambda calibration"
            )
            return result

        layer3_best, layer3_reports = self._run_layer3(
            layer2_survivors, env_id, make_env_fn, train_fn
        )
        result.layer3_reports = layer3_reports
        result.layer3_evaluated = len(layer2_survivors)

        if layer3_best is None:
            result.selection_path = "Layer3: all candidates failed early probe"
            return result

        best_candidate, best_lambda, best_cid = layer3_best
        result.selected_candidate = best_candidate
        result.selected_lambda = best_lambda
        result.candidate_id = best_cid
        result.selection_path = (
            f"Layer1({result.layer1_passed}) -> Layer2({result.layer2_passed}) -> Layer3(best)"
        )

        return result

    def _run_layer1(
        self, candidates: list[dict[str, Any]]
    ) -> tuple[list[dict[str, Any]], list[ConservativeRepairResult]]:
        survivors: list[dict[str, Any]] = []
        repair_results: list[ConservativeRepairResult] = []

        for candidate in candidates:
            canonical = canonicalize_dsl(candidate, self._env_spec)

            report = self._safety_gate.validate(canonical)
            if report.passed:
                survivors.append(canonical)
                continue

            repair_result = self._repair.repair(canonical)
            repair_results.append(repair_result)

            if repair_result.success and repair_result.repaired_candidate is not None:
                survivors.append(repair_result.repaired_candidate)

        return survivors, repair_results

    def _run_layer2(
        self,
        candidates: list[dict[str, Any]],
        calibration_data_fn: Optional[Any] = None,
    ) -> tuple[
        list[tuple[str, float, dict[str, Any]]],
        list[LambdaCalibrationResult],
    ]:
        survivors: list[tuple[str, float, dict[str, Any]]] = []
        results: list[LambdaCalibrationResult] = []

        for i, candidate in enumerate(candidates):
            cid = f"candidate_{i}"
            for lam in self.config.lambda_values:
                if calibration_data_fn is not None:
                    try:
                        env_r, shp_r, pot_v = calibration_data_fn(candidate, lam)
                    except Exception:
                        continue

                    cal_result = self._calibrator.calibrate(cid, lam, env_r, shp_r, pot_v)
                    results.append(cal_result)

                    if cal_result.passes_filters:
                        survivors.append((cid, lam, candidate))

        return survivors, results

    def _run_layer3(
        self,
        survivors: list[tuple[str, float, dict[str, Any]]],
        env_id: str,
        make_env_fn: Any,
        train_fn: Any,
    ) -> tuple[
        Optional[tuple[dict[str, Any], float, str]],
        list[ProbeV3Result],
    ]:
        probe_pairs: list[tuple[str, float, CompilerOutput]] = []

        for cid, lam, candidate in survivors:
            try:
                compiled = compile_dsl(
                    candidate, self._predicate_library, self._potential_library
                )
                probe_pairs.append((cid, lam, compiled))
            except Exception:
                continue

        if not probe_pairs:
            return None, []

        probe_results = self._probe.run_probe_batch(
            candidate_lambda_pairs=probe_pairs,
            env_id=env_id,
            make_env_fn=make_env_fn,
            train_fn=train_fn,
            base_checkpoint_path=self.config.base_checkpoint_path,
        )

        if not probe_results:
            return None, []

        best = max(probe_results, key=lambda r: r.probe_score)

        for cid, lam, candidate in survivors:
            if cid == best.candidate_id and abs(lam - best.lambda_value) < 1e-9:
                return (candidate, lam, cid), probe_results

        if survivors:
            cid, lam, candidate = survivors[0]
            return (candidate, lam, cid), probe_results

        return None, probe_results

    def save_report(
        self,
        result: SelectorV3Result,
        output_path: str | Path,
    ) -> None:
        path = Path(output_path)
        ensure_dir(path.parent)
        save_json(result.to_dict(), path)
