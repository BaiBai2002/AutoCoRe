"""
AutoCoRe Selection Report — Save detailed candidate selection reports.
"""
from __future__ import annotations
from typing import Any
import json, os, time
from pathlib import Path

from autocore.utils.io import ensure_dir


def save_selection_report(
    env_id: str,
    method: str,
    provider: str,
    candidates: list[tuple[dict[str, Any], Any]],
    selected_idx: int,
    selected_lambda: float,
    lambda_reason: str,
    output_dir: str = "artifacts/selection_reports",
):
    base = Path(output_dir) / env_id / method / provider
    ensure_dir(str(base))

    report = {
        "env_id": env_id,
        "method": method,
        "provider": provider,
        "timestamp": time.time(),
        "num_candidates": len(candidates),
        "selected_index": selected_idx,
        "selected_lambda": float(selected_lambda),
        "lambda_reason": lambda_reason,
        "candidates": [],
    }

    for dsl, sc in candidates:
        entry = {
            "dsl": dsl,
            "is_valid": sc.is_valid if hasattr(sc, 'is_valid') else False,
            "validity_score": getattr(sc, 'validity_score', 0.0),
            "progress_alignment_score": getattr(sc, 'progress_alignment_score', 0.0),
            "reward_dominance_score": getattr(sc, 'reward_dominance_score', 0.0),
            "non_interference_score": getattr(sc, 'non_interference_score', 0.0),
            "diversity_score": getattr(sc, 'diversity_score', 0.0),
            "interpretability_score": getattr(sc, 'interpretability_score', 0.0),
            "composite_score": getattr(sc, 'composite_score', 0.0),
            "metadata": getattr(sc, 'metadata', {}),
        }
        report["candidates"].append(entry)

    path = str(base / "selection_report.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)

    csv_path = str(base / "candidate_scores.csv")
    with open(csv_path, "w", encoding="utf-8") as f:
        headers = ["idx", "is_valid", "validity", "progress_align", "reward_dom",
                   "non_interfere", "diversity", "interpret", "composite"]
        f.write(",".join(headers) + "\n")
        for i, (_, sc) in enumerate(candidates):
            vals = [
                str(i),
                str(int(getattr(sc, 'is_valid', False))),
                f"{getattr(sc, 'validity_score', 0.0):.4f}",
                f"{getattr(sc, 'progress_alignment_score', 0.0):.4f}",
                f"{getattr(sc, 'reward_dominance_score', 0.0):.4f}",
                f"{getattr(sc, 'non_interference_score', 0.0):.4f}",
                f"{getattr(sc, 'diversity_score', 0.0):.4f}",
                f"{getattr(sc, 'interpretability_score', 0.0):.4f}",
                f"{getattr(sc, 'composite_score', 0.0):.4f}",
            ]
            f.write(",".join(vals) + "\n")
    return str(path)
