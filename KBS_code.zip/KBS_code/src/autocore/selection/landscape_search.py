"""Direct search over shaping landscapes.

The empirical picture established by the controlled experiments is that the
effect of a potential is decided by the optimisation attractor it induces, not
by whether it encodes task-relevant semantics. This module therefore exposes a
*searchable* family of potentials rather than a fixed library of hand-authored
ones: a linear combination of normalised state features, drawn from the same
predicate primitives that a language model would compose.

Because the calibrated coefficient is derived analytically from the potential
(see ``magnitude_calibration``), the magnitude is not part of the search. Only
the *direction* matters: scaling the weights and the coefficient inversely
leaves the injected signal unchanged, so directions are restricted to the unit
sphere.
"""
from __future__ import annotations

from typing import Any, Callable, Iterable, Optional, Sequence

import numpy as np

from autocore.dsl.predicates import PredicateLibrary

StateDict = dict[str, Any]

DEFAULT_FEATURES: list[tuple[str, dict[str, Any]]] = [
    ("min_distance_landmark_coverage", {}),
    ("mean_distance_to_nearest_landmark", {}),
    ("max_uncovered_landmark_distance", {}),
    ("pairwise_agent_distance", {}),
    ("collision_count_or_margin", {"collision_threshold": 0.5, "mode": "margin"}),
    ("coverage_entropy_or_balance", {}),
    ("agent_target_assignment_distance", {}),
]


class FeatureBank:
    """A fixed set of scalar state features, standardised for search."""

    def __init__(self, feature_specs: Optional[Sequence[tuple[str, dict[str, Any]]]] = None,
                 predicate_library: Optional[PredicateLibrary] = None,
                 extra_features: Optional[Sequence[tuple[str, Callable[[StateDict], float]]]] = None,
                 ) -> None:
        lib = predicate_library or PredicateLibrary()
        self.names: list[str] = []
        self.functions: list[Callable[[StateDict], float]] = []
        for name, args in (feature_specs or DEFAULT_FEATURES):
            try:
                self.functions.append(lib.build(name, dict(args)))
                self.names.append(name)
            except Exception:
                continue
        for name, fn in (extra_features or []):
            self.functions.append(fn)
            self.names.append(name)
        self._mean = np.zeros(len(self.functions), dtype=np.float64)
        self._std = np.ones(len(self.functions), dtype=np.float64)

    @property
    def dim(self) -> int:
        return len(self.functions)

    def raw(self, state: StateDict) -> np.ndarray:
        out = np.zeros(len(self.functions), dtype=np.float64)
        for i, fn in enumerate(self.functions):
            try:
                value = float(fn(state))
            except Exception:
                value = 0.0
            out[i] = value if np.isfinite(value) else 0.0
        return out

    def fit(self, states: Iterable[StateDict],
            drop_constant: bool = False) -> "FeatureBank":
        """Standardise the features; optionally drop any that never vary.

        Predicates written for one environment family can be constant on another,
        so dropping non-varying features keeps the bank specific to the
        environment in use without per-environment hand selection. The behaviour
        is opt-in because it changes the dimensionality, and therefore the weight
        vectors, of every candidate.
        """
        rows = [self.raw(s) for s in states]
        if not rows:
            return self
        matrix = np.asarray(rows, dtype=np.float64)
        if drop_constant:
            keep = matrix.std(axis=0) > 1e-9
            if not keep.all():
                self.names = [n for n, k in zip(self.names, keep) if k]
                self.functions = [f for f, k in zip(self.functions, keep) if k]
                matrix = matrix[:, keep]
        self._mean = matrix.mean(axis=0)
        std = matrix.std(axis=0)
        self._std = np.where(std > 1e-9, std, 1.0)
        return self

    def normalize(self, raw: np.ndarray) -> np.ndarray:
        return (raw - self._mean) / self._std

    def features(self, state: StateDict) -> np.ndarray:
        return self.normalize(self.raw(state))

    def describe(self) -> dict[str, Any]:
        return {"names": list(self.names), "dim": self.dim,
                "mean": self._mean.tolist(), "std": self._std.tolist()}


class LinearPotential:
    """``Phi(s) = sum_k w_k * standardised_feature_k(s)``, clipped."""

    def __init__(self, bank: FeatureBank, weights: Sequence[float],
                 clip: tuple[float, float] = (-10.0, 10.0)) -> None:
        self.bank = bank
        w = np.asarray(weights, dtype=np.float64).reshape(-1)
        if w.size != bank.dim:
            raise ValueError(f"expected {bank.dim} weights, got {w.size}")
        norm = np.linalg.norm(w)
        self.weights = w / norm if norm > 1e-12 else w
        self.clip = clip

    def __call__(self, state: StateDict) -> float:
        value = float(self.weights @ self.bank.features(state))
        return float(np.clip(value, self.clip[0], self.clip[1]))

    def describe(self) -> dict[str, Any]:
        return {"weights": self.weights.tolist(), "clip": list(self.clip)}


def sample_directions(n: int, dim: int, rng: np.random.Generator,
                      sparse_prob: float = 0.0) -> np.ndarray:
    """Unit-norm weight vectors; optionally zeroed entries for sparse potentials."""
    w = rng.normal(size=(n, dim))
    if sparse_prob > 0:
        mask = rng.random(size=(n, dim)) > sparse_prob
        mask[np.arange(n), rng.integers(0, dim, size=n)] = True
        w = w * mask
    norms = np.linalg.norm(w, axis=1, keepdims=True)
    norms[norms < 1e-12] = 1.0
    return w / norms


def one_hot_directions(bank: FeatureBank) -> dict[str, np.ndarray]:
    """The axis directions: each is a single primitive used on its own."""
    out = {}
    for i, name in enumerate(bank.names):
        w = np.zeros(bank.dim)
        w[i] = 1.0
        out[name] = w
    return out


def _positions(state: StateDict, key: str) -> np.ndarray:
    arr = np.asarray(state.get(key, []), dtype=np.float64)
    if arr.size == 0:
        return np.zeros((0, 2))
    return arr.reshape(-1, 2)


def per_landmark_min_distance(index: int) -> Callable[[StateDict], float]:
    """Minimum distance from any agent to one designated landmark.

    Averaging over landmarks destroys the information a task needs when only one
    landmark is the target. Exposing the per-landmark distances lets the search
    select the relevant one, so a task-aligned potential becomes reachable
    without hand-coding which landmark matters.
    """
    def fn(state: StateDict) -> float:
        agents = _positions(state, "agent_positions")
        marks = _positions(state, "landmark_positions")
        if agents.shape[0] == 0 or marks.shape[0] <= index:
            return 0.0
        return float(np.min(np.linalg.norm(agents - marks[index], axis=1)))
    return fn


def designated_agent_landmark_distance(agent_index: int,
                                       landmark_index: int) -> Callable[[StateDict], float]:
    """Distance from one designated agent to one designated landmark.

    Interaction tasks such as reference and push are governed by a single
    agent-to-landmark relationship rather than by the team average, so these
    features give the search the capacity to represent a task-aligned potential.
    ``agent_index = -1`` selects the last agent, which is the listener or the
    pushed agent in the standard MPE instantiations.
    """
    def fn(state: StateDict) -> float:
        agents = _positions(state, "agent_positions")
        marks = _positions(state, "landmark_positions")
        if agents.shape[0] == 0 or marks.shape[0] <= landmark_index:
            return 0.0
        a = agents[agent_index]
        return float(np.linalg.norm(a - marks[landmark_index]))
    return fn


def build_bank(env_id: str, num_agents: Optional[int] = None, max_cycles: int = 80,
               n_episodes: int = 6, seed: int = 0,
               per_landmark: bool = True) -> FeatureBank:
    """Feature bank for an environment, optionally with task-aligned capacity."""
    from autocore.envs.pettingzoo_mpe import make_mpe_env
    from autocore.selection.magnitude_calibration import collect_reference_states

    env = make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)
    try:
        n_landmarks = len(getattr(env.aec_env.world, "landmarks", []))
        n_agents = len(getattr(env.aec_env.world, "agents", []))
    except Exception:
        n_landmarks, n_agents = 0, 0
    env.close()

    extra: list[tuple[str, Callable[[StateDict], float]]] = []
    if per_landmark:
        for k in range(n_landmarks):
            extra.append((f"min_dist_to_landmark_{k}", per_landmark_min_distance(k)))
        if n_agents > 0:
            for k in range(n_landmarks):
                extra.append((f"last_agent_dist_to_landmark_{k}",
                              designated_agent_landmark_distance(-1, k)))
    bank = FeatureBank(extra_features=extra)
    states = collect_reference_states(env_id, max_cycles=max_cycles,
                                      n_episodes=n_episodes, seed=seed,
                                      num_agents=num_agents)
    return bank.fit(states)
