from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np

from autocore.shaping.potentials import PotentialFunction, ShapingConfig
from autocore.dsl.compiler import CompilerOutput
from autocore.utils.seed import set_seed


@dataclass
class ProbeV3Result:
    candidate_id: str
    lambda_value: float
    probe_score: float = 0.0
    early_auc_gain: float = 0.0
    success_gain: float = 0.0
    final_return_gain: float = 0.0
    task_progress_gain: float = 0.0
    reward_stability: float = 0.0
    policy_stability: float = 0.0
    rank: int = 0
    margin_to_second: float = 0.0
    variance_across_probe_seeds: float = 0.0
    selection_confidence: float = 0.0
    curve: list[float] = field(default_factory=list)
    n_seeds: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "lambda": self.lambda_value,
            "probe_score": self.probe_score,
            "early_auc_gain": self.early_auc_gain,
            "success_gain": self.success_gain,
            "final_return_gain": self.final_return_gain,
            "task_progress_gain": self.task_progress_gain,
            "reward_stability": self.reward_stability,
            "policy_stability": self.policy_stability,
            "rank": self.rank,
            "margin_to_second": self.margin_to_second,
            "variance_across_probe_seeds": self.variance_across_probe_seeds,
            "selection_confidence": self.selection_confidence,
            "n_seeds": self.n_seeds,
        }


@dataclass
class ProbeV3Config:
    probe_steps: int = 10000
    probe_eval_interval: int = 2000
    probe_eval_episodes: int = 5
    probe_seeds: list[int] = field(default_factory=lambda: [42, 123])
    base_checkpoint_path: Optional[str] = None

    score_early_auc_gain: float = 0.35
    score_success_gain: float = 0.20
    score_final_return_gain: float = 0.15
    score_task_progress_gain: float = 0.10
    score_reward_stability: float = 0.10
    score_policy_stability: float = 0.10


class EarlyProbeV3:
    def __init__(
        self,
        config: Optional[ProbeV3Config] = None,
    ) -> None:
        self.config = config or ProbeV3Config()

    @property
    def probe_steps(self) -> int:
        return self.config.probe_steps

    @property
    def probe_seeds(self) -> list[int]:
        return self.config.probe_seeds

    def run_probe(
        self,
        candidate_id: str,
        lambda_value: float,
        compiled_output: CompilerOutput,
        make_env_fn: Any,
        train_fn: Any,
        env_id: str,
        base_checkpoint_path: Optional[str] = None,
    ) -> ProbeV3Result:
        eval_curves: list[list[float]] = []
        reward_histories: list[list[float]] = []
        action_histories: list[list[np.ndarray]] = []
        progress_curves: list[list[float]] = []

        for seed in self.config.probe_seeds:
            set_seed(seed)
            try:
                env = make_env_fn(env_id)

                config = ShapingConfig(shaping_lambda=lambda_value)
                potential_fn = PotentialFunction(compiled_output, config)

                from autocore.shaping.wrappers import RewardShapingWrapper
                env = RewardShapingWrapper(env, potential_fn, config)

                trainer = train_fn(env)

                if base_checkpoint_path is not None:
                    _try_load_checkpoint(trainer, base_checkpoint_path)

                logger, step_rewards, step_actions, progress = _run_probe_episode(
                    env,
                    trainer,
                    train_fn,
                    self.config.probe_steps,
                    self.config.probe_eval_interval,
                    self.config.probe_eval_episodes,
                    seed,
                )

                df = logger.get_dataframe() if hasattr(logger, "get_dataframe") else None

                if df is not None and "eval_return" in df.columns:
                    er = df[df["eval_return"].notna()]["eval_return"].tolist()
                    if er:
                        eval_curves.append(er)

                if step_rewards:
                    reward_histories.append(step_rewards)
                if step_actions:
                    action_histories.append(step_actions)
                if progress:
                    progress_curves.append(progress)

                env.close()
            except Exception:
                continue

        if not eval_curves:
            return ProbeV3Result(
                candidate_id=candidate_id,
                lambda_value=lambda_value,
                n_seeds=0,
                metadata={"error": "All probe seeds failed"},
            )

        result = ProbeV3Result(
            candidate_id=candidate_id,
            lambda_value=lambda_value,
            n_seeds=len(eval_curves),
        )

        max_len = max(len(r) for r in eval_curves)
        padded: list[list[float]] = []
        for r in eval_curves:
            if len(r) < max_len:
                r = list(r) + [r[-1]] * (max_len - len(r)) if r else [0.0] * max_len
            padded.append(r)

        arr = np.array(padded, dtype=np.float64)
        mean_curve = arr.mean(axis=0)
        result.curve = mean_curve.tolist()

        baseline_auc = self._estimate_baseline_auc(eval_curves)
        auc = float(np.trapezoid(mean_curve)) if len(mean_curve) > 1 else float(mean_curve[0]) if len(mean_curve) == 1 else 0.0
        step_range = max(max_len - 1, 1)
        result.early_auc_gain = float(max(0.0, (auc / step_range) - baseline_auc))

        result.success_gain = self._compute_success_gain(eval_curves)

        result.final_return_gain = float(max(0.0, mean_curve[-1])) if len(mean_curve) > 0 else 0.0

        result.task_progress_gain = self._compute_task_progress_gain(progress_curves)

        result.reward_stability = self._compute_reward_stability(reward_histories)

        result.policy_stability = self._compute_policy_stability(action_histories)

        result.variance_across_probe_seeds = self._compute_variance_across_seeds(eval_curves)

        result.probe_score = self._compute_probe_score(result)

        return result

    def run_probe_batch(
        self,
        candidate_lambda_pairs: list[tuple[str, float, CompilerOutput]],
        make_env_fn: Any,
        train_fn: Any,
        env_id: str,
        base_checkpoint_path: Optional[str] = None,
    ) -> list[ProbeV3Result]:
        results: list[ProbeV3Result] = []
        for cid, lam, compiled in candidate_lambda_pairs:
            result = self.run_probe(
                candidate_id=cid,
                lambda_value=lam,
                compiled_output=compiled,
                make_env_fn=make_env_fn,
                train_fn=train_fn,
                env_id=env_id,
                base_checkpoint_path=base_checkpoint_path,
            )
            results.append(result)

        results = self._rank_results(results)
        return results

    def _rank_results(self, results: list[ProbeV3Result]) -> list[ProbeV3Result]:
        if not results:
            return results
        sorted_results = sorted(results, key=lambda r: r.probe_score, reverse=True)
        for i, r in enumerate(sorted_results):
            r.rank = i + 1
            if i == 0 and len(sorted_results) > 1:
                r.margin_to_second = r.probe_score - sorted_results[1].probe_score
            else:
                r.margin_to_second = 0.0

            if len(sorted_results) >= 2:
                scores = [x.probe_score for x in sorted_results]
                score_std = float(np.std(scores))
                if score_std > 1e-12:
                    r.selection_confidence = float(
                        (r.probe_score - np.mean(scores)) / score_std
                    )
                    r.selection_confidence = float(np.clip(r.selection_confidence, 0.0, 3.0) / 3.0)
                else:
                    r.selection_confidence = 0.0
            else:
                r.selection_confidence = 0.5
        return sorted_results

    def _estimate_baseline_auc(self, eval_curves: list[list[float]]) -> float:
        if not eval_curves:
            return 0.0
        first_vals = []
        for curve in eval_curves:
            if curve:
                first_vals.append(curve[0])
        if not first_vals:
            return 0.0
        return float(np.mean(first_vals))

    def _compute_success_gain(self, eval_curves: list[list[float]]) -> float:
        if not eval_curves:
            return 0.0
        improvements: list[float] = []
        for curve in eval_curves:
            if len(curve) >= 2:
                improvements.append(max(0.0, curve[-1] - curve[0]))
        if not improvements:
            return 0.0
        return float(np.mean(improvements))

    def _compute_task_progress_gain(self, progress_curves: list[list[float]]) -> float:
        if not progress_curves:
            return 0.0
        gains: list[float] = []
        for prog in progress_curves:
            if len(prog) >= 2:
                gains.append(max(0.0, prog[-1] - prog[0]))
        if not gains:
            return 0.0
        return float(np.mean(gains))

    def _compute_reward_stability(self, reward_histories: list[list[float]]) -> float:
        if len(reward_histories) < 2:
            return 0.5
        cvs: list[float] = []
        for history in reward_histories:
            if len(history) < 10:
                continue
            arr = np.array(history, dtype=np.float64)
            mean_val = float(np.mean(arr))
            std_val = float(np.std(arr))
            if mean_val < 1e-12:
                cvs.append(0.0)
            else:
                cv = std_val / abs(mean_val)
                cvs.append(float(1.0 / (1.0 + cv)))
        if not cvs:
            return 0.5
        return float(np.clip(np.mean(cvs), 0.0, 1.0))

    def _compute_policy_stability(self, action_histories: list[list[np.ndarray]]) -> float:
        if len(action_histories) < 2:
            return 0.5
        stabilities: list[float] = []
        for history in action_histories:
            if len(history) < 10:
                continue
            diffs: list[float] = []
            for i in range(1, len(history)):
                d = float(np.mean(np.abs(history[i] - history[i - 1])))
                diffs.append(d)
            if diffs:
                mean_diff = float(np.mean(diffs))
                stability = float(1.0 / (1.0 + mean_diff))
                stabilities.append(stability)
        if not stabilities:
            return 0.5
        return float(np.clip(np.mean(stabilities), 0.0, 1.0))

    def _compute_variance_across_seeds(self, eval_curves: list[list[float]]) -> float:
        if len(eval_curves) < 2:
            return 0.0
        final_returns = [curve[-1] for curve in eval_curves if curve]
        if len(final_returns) < 2:
            return 0.0
        final_arr = np.array(final_returns, dtype=np.float64)
        mean_val = float(np.mean(final_arr))
        if abs(mean_val) < 1e-12:
            return 0.0
        return float(np.std(final_arr) / abs(mean_val))

    def _compute_probe_score(self, result: ProbeV3Result) -> float:
        cfg = self.config
        return float(
            cfg.score_early_auc_gain * result.early_auc_gain
            + cfg.score_success_gain * result.success_gain
            + cfg.score_final_return_gain * min(1.0, max(0.0, result.final_return_gain / 100.0))
            + cfg.score_task_progress_gain * result.task_progress_gain
            + cfg.score_reward_stability * result.reward_stability
            + cfg.score_policy_stability * result.policy_stability
        )


class _TrainTracker:
    pass


def _run_probe_episode(
    env: Any,
    trainer: Any,
    train_fn: Any,
    num_steps: int,
    eval_interval: int,
    eval_episodes: int,
    seed: int,
) -> tuple[Any, list[float], list[np.ndarray], list[float]]:
    step_rewards: list[float] = []
    step_actions: list[np.ndarray] = []
    progress: list[float] = []

    try:
        logger = train_fn(
            env,
            trainer,
            num_steps=num_steps,
            eval_interval=eval_interval,
            eval_episodes=eval_episodes,
            seed=seed,
        )
        df = logger.get_dataframe() if hasattr(logger, "get_dataframe") else None
        if df is not None:
            if "rollout/ep_rew_mean" in df.columns:
                rew_col = df[df["rollout/ep_rew_mean"].notna()]["rollout/ep_rew_mean"]
                step_rewards = rew_col.tolist()
            if "progress" in df.columns:
                prog_col = df[df["progress"].notna()]["progress"]
                progress = prog_col.tolist()
        return logger, step_rewards, step_actions, progress
    except Exception:
        from unittest.mock import MagicMock
        return MagicMock(), [], [], []


def _try_load_checkpoint(trainer: Any, checkpoint_path: str) -> None:
    try:
        if hasattr(trainer, "load"):
            trainer.load(checkpoint_path)
        elif hasattr(trainer, "set_parameters"):
            trainer.set_parameters(checkpoint_path)
    except Exception:
        pass
