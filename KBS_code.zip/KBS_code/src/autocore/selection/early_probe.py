"""
AutoCoRe Early Training Probe — Quick candidate evaluation.
"""
from __future__ import annotations
from typing import Any, Optional
import numpy as np

from autocore.utils.seed import set_seed


class EarlyProbe:
    def __init__(
        self,
        num_steps: int = 10000,
        eval_interval: int = 2000,
        probe_seeds: list[int] | None = None,
    ):
        self.num_steps = num_steps
        self.eval_interval = eval_interval
        self.probe_seeds = probe_seeds or [2026, 2027]

    def run_probe(
        self,
        env_id: str,
        make_env_fn: Any,
        train_fn: Any,
        potential_fn: Any = None,
    ) -> dict[str, Any]:
        eval_returns = []
        for seed in self.probe_seeds:
            try:
                env = make_env_fn(env_id)
                trainer = train_fn(env)
                from autocore.shaping.wrappers import RewardShapingWrapper
                if potential_fn is not None:
                    env = RewardShapingWrapper(env, potential_fn, potential_fn.config)
                logger = train_fn(
                    env, trainer, num_steps=self.num_steps,
                    eval_interval=self.eval_interval, eval_episodes=3,
                    seed=seed,
                )
                df = logger.get_dataframe()
                if 'eval_return' in df.columns:
                    er = df[df['eval_return'].notna()]['eval_return'].tolist()
                    eval_returns.append(er)
                env.close()
            except Exception:
                continue
        if not eval_returns:
            return {"auc": 0.0, "final_return": 0.0, "n_seeds": 0, "curve": []}
        max_len = max(len(r) for r in eval_returns)
        padded = []
        for r in eval_returns:
            if len(r) < max_len:
                r = list(r) + [r[-1]] * (max_len - len(r)) if r else [0.0] * max_len
            padded.append(r)
        arr = np.array(padded)
        mean_curve = arr.mean(axis=0)
        auc = float(np.trapz(mean_curve) / max_len) if max_len > 0 else 0.0
        final = float(mean_curve[-1]) if len(mean_curve) > 0 else 0.0
        return {
            "auc": auc,
            "final_return": final,
            "n_seeds": len(eval_returns),
            "curve": mean_curve.tolist(),
        }
