"""
AutoCoRe Selection Module

Candidate scoring, utility-aware selection, early-training probes,
selection report generation, and lambda tuning.
"""
from autocore.selection.proxy_scores import (
    CandidateScore, compute_validity_score, compute_diversity_score,
    compute_progress_alignment_score, compute_reward_dominance_score,
    compute_non_interference_score, compute_interpretability_score,
    compute_composite_score,
)
from autocore.selection.candidate_selector import CandidateSelector, select_lambda
from autocore.selection.early_probe import EarlyProbe
from autocore.selection.selection_report import save_selection_report
from autocore.selection.probe_cache import ProbeCache
from autocore.selection.selection_dataset import SelectionRecord, SelectionDataset

__all__ = [
    "CandidateScore", "CandidateSelector", "EarlyProbe",
    "save_selection_report", "select_lambda",
    "compute_validity_score", "compute_diversity_score",
    "compute_progress_alignment_score", "compute_reward_dominance_score",
    "compute_non_interference_score", "compute_interpretability_score",
    "compute_composite_score",
    "ProbeCache",
    "SelectionRecord",
    "SelectionDataset",
]
