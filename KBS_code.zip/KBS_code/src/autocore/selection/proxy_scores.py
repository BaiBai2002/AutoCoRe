"""
AutoCoRe Selection Module — Candidate Scoring & Utility-Aware Selection
========================================================================
Proxy scores for evaluating DSL candidates before full training.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Optional
import numpy as np
from scipy import stats as scipy_stats


@dataclass
class CandidateScore:
    validity_score: float = 0.0
    progress_alignment_score: float = 0.0
    reward_dominance_score: float = 0.0
    non_interference_score: float = 0.0
    diversity_score: float = 0.0
    interpretability_score: float = 0.0
    composite_score: float = 0.0
    is_valid: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


def compute_validity_score(
    static_checks_passed: list[bool],
    rollout_checks_passed: list[bool],
    repair_rounds: int,
) -> float:
    if len(static_checks_passed) == 0:
        return 0.0
    static_rate = sum(static_checks_passed) / len(static_checks_passed)
    rollout_rate = sum(rollout_checks_passed) / max(len(rollout_checks_passed), 1)
    repair_penalty = min(repair_rounds / 5.0, 0.3)
    return max(0.0, 0.5 * static_rate + 0.5 * rollout_rate - repair_penalty)


def compute_diversity_score(
    potential_values: list[float],
    min_std: float = 0.01,
    max_magnitude: float = 5.0,
) -> float:
    if len(potential_values) < 2:
        return 0.0
    std = float(np.std(potential_values))
    mean_abs = float(np.mean(np.abs(potential_values)))
    if std < min_std:
        return 0.0
    mag_penalty = max(0.0, (mean_abs - 1.0) / max_magnitude)
    return 1.0 - mag_penalty if std > min_std else 0.0


def compute_progress_alignment_score(
    delta_phi: list[float],
    env_rewards: list[float],
    progress_metrics: Optional[list[float]] = None,
) -> float:
    if len(delta_phi) < 5 or len(env_rewards) < 5:
        return 0.5
    d_arr = np.array(delta_phi)
    r_arr = np.array(env_rewards)
    valid = np.isfinite(d_arr) & np.isfinite(r_arr)
    if valid.sum() < 5:
        return 0.5
    d_arr, r_arr = d_arr[valid], r_arr[valid]
    try:
        corr, _ = scipy_stats.spearmanr(d_arr, r_arr)
    except Exception:
        corr = 0.0
    corr = float(np.clip(corr, -1.0, 1.0)) if np.isfinite(corr) else 0.0
    if progress_metrics is not None and len(progress_metrics) == len(delta_phi):
        p_arr = np.array(progress_metrics)
        p_valid = np.isfinite(p_arr)
        if p_valid.sum() >= 5:
            try:
                p_corr, _ = scipy_stats.spearmanr(d_arr[p_valid], p_arr[p_valid])
                p_corr = float(np.clip(p_corr, -1.0, 1.0)) if np.isfinite(p_corr) else 0.0
                corr = 0.5 * corr + 0.5 * p_corr
            except Exception:
                pass
    return max(0.0, corr)


def compute_reward_dominance_score(
    shaping_rewards: list[float],
    env_rewards: list[float],
    safe_interval: tuple[float, float] = (0.05, 0.50),
    max_allowed: float = 1.0,
) -> float:
    if len(shaping_rewards) == 0 or len(env_rewards) == 0:
        return 0.5
    mean_shaping = float(np.mean(np.abs(shaping_rewards)))
    mean_env = float(np.mean(np.abs(env_rewards)))
    if mean_env < 1e-8:
        return mean_shaping < 0.5
    ratio = mean_shaping / mean_env
    lo, hi = safe_interval
    if lo <= ratio <= hi:
        return 1.0
    if ratio < lo:
        return max(0.0, ratio / lo)
    if ratio > max_allowed:
        return 0.0
    return max(0.0, 1.0 - (ratio - hi) / (max_allowed - hi))


def compute_non_interference_score(
    transition_pairs: list[tuple[float, float, float, float]],
) -> float:
    if len(transition_pairs) < 5:
        return 0.5
    violations = 0
    total_pairs = 0
    for env_a, shaped_a, env_b, shaped_b in transition_pairs:
        if not all(np.isfinite([env_a, shaped_a, env_b, shaped_b])):
            continue
        total_pairs += 1
        if env_a > env_b and shaped_a < shaped_b:
            violations += 1
        elif env_a < env_b and shaped_a > shaped_b:
            violations += 1
    if total_pairs == 0:
        return 0.5
    return 1.0 - (violations / total_pairs)


def compute_interpretability_score(dsl: dict[str, Any]) -> float:
    subgoals = dsl.get("subgoals", [])
    n = len(subgoals)
    if n == 0:
        return 0.0
    n_score = 1.0 if 2 <= n <= 4 else (0.7 if n == 1 or n == 5 else 0.4)
    has_rationale = sum(1 for sg in subgoals if len(sg.get("rationale", "")) > 10)
    rationale_score = has_rationale / max(n, 1)
    pred_pot_pairs = set()
    for sg in subgoals:
        pt = sg.get("predicate", {}).get("type", "")
        pot = sg.get("potential", {}).get("type", "")
        pred_pot_pairs.add((pt, pot))
    dedup_score = len(pred_pot_pairs) / max(n, 1)
    return float(0.4 * n_score + 0.4 * rationale_score + 0.2 * dedup_score)


def compute_composite_score(scores: CandidateScore) -> float:
    return float(
        0.25 * scores.validity_score
        + 0.20 * scores.progress_alignment_score
        + 0.20 * scores.reward_dominance_score
        + 0.15 * scores.non_interference_score
        + 0.10 * scores.diversity_score
        + 0.10 * scores.interpretability_score
    )
