from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np


@dataclass
class LambdaCalibrationResult:
    candidate_id: str
    lambda_value: float
    phi_mean: float = 0.0
    phi_std: float = 0.0
    phi_range: float = 0.0
    phi_saturation_rate: float = 0.0
    pbrs_delta_mean: float = 0.0
    pbrs_delta_std: float = 0.0
    pbrs_nonzero_fraction: float = 0.0
    shaping_reward_mean: float = 0.0
    shaping_reward_std: float = 0.0
    raw_reward_episode_abs_mean: float = 0.0
    shaping_reward_episode_abs_mean: float = 0.0
    episode_dominance_ratio: float = 0.0
    step_dominance_median: float = 0.0
    step_dominance_p90: float = 0.0
    step_dominance_p95: float = 0.0
    progress_sign_accuracy: float = 0.0
    spearman_correlation: float = 0.0
    kendall_tau: float = 0.0
    catastrophic_transition_rate: float = 0.0
    passes_filters: bool = False
    filter_violations: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "lambda": self.lambda_value,
            "phi_mean": self.phi_mean,
            "phi_std": self.phi_std,
            "phi_range": self.phi_range,
            "phi_saturation_rate": self.phi_saturation_rate,
            "pbrs_delta_mean": self.pbrs_delta_mean,
            "pbrs_delta_std": self.pbrs_delta_std,
            "pbrs_nonzero_fraction": self.pbrs_nonzero_fraction,
            "shaping_reward_mean": self.shaping_reward_mean,
            "shaping_reward_std": self.shaping_reward_std,
            "raw_reward_episode_abs_mean": self.raw_reward_episode_abs_mean,
            "shaping_reward_episode_abs_mean": self.shaping_reward_episode_abs_mean,
            "episode_dominance_ratio": self.episode_dominance_ratio,
            "step_dominance_median": self.step_dominance_median,
            "step_dominance_p90": self.step_dominance_p90,
            "step_dominance_p95": self.step_dominance_p95,
            "progress_sign_accuracy": self.progress_sign_accuracy,
            "spearman_correlation": self.spearman_correlation,
            "kendall_tau": self.kendall_tau,
            "catastrophic_transition_rate": self.catastrophic_transition_rate,
            "passes_filters": self.passes_filters,
            "filter_violations": list(self.filter_violations),
        }


@dataclass
class LambdaCalibrationConfig:
    lambda_grid: list[float] = field(default_factory=lambda: [0.02, 0.05, 0.10, 0.20, 0.30])
    rollout_episodes: int = 3
    rollout_steps_per_episode: int = 2000
    epsilon: float = 1e-8
    max_saturation: float = 0.90
    max_p95_dominance: float = 5.0
    min_shaping_nonzero_fraction: float = 0.001
    max_catastrophic_rate: float = 0.30
    env_spec_raw_reward_scale: float = 1.0


class LambdaCalibrator:
    def __init__(
        self,
        config: Optional[LambdaCalibrationConfig] = None,
    ) -> None:
        self.config = config or LambdaCalibrationConfig()

    def calibrate(
        self,
        candidate_id: str,
        lambda_value: float,
        raw_rewards: list[float],
        shaping_rewards: list[float],
        potential_values: list[float],
        task_progress: Optional[list[float]] = None,
    ) -> LambdaCalibrationResult:
        result = LambdaCalibrationResult(
            candidate_id=candidate_id,
            lambda_value=lambda_value,
        )

        raw_arr = np.asarray(raw_rewards, dtype=np.float64)
        shaping_arr = np.asarray(shaping_rewards, dtype=np.float64)
        phi_arr = np.asarray(potential_values, dtype=np.float64)

        finite_mask = (
            np.isfinite(raw_arr)
            & np.isfinite(shaping_arr)
            & np.isfinite(phi_arr)
        )
        raw_arr = raw_arr[finite_mask]
        shaping_arr = shaping_arr[finite_mask]
        phi_arr = phi_arr[finite_mask]

        if len(raw_arr) == 0 or len(shaping_arr) == 0:
            result.filter_violations.append("Empty or all-NaN calibration data")
            return result

        denominator = self._compute_robust_denominator(raw_arr, shaping_arr)

        result.phi_mean = float(np.mean(phi_arr)) if len(phi_arr) > 0 else 0.0
        result.phi_std = float(np.std(phi_arr)) if len(phi_arr) > 0 else 0.0
        result.phi_range = (
            float(np.max(phi_arr) - np.min(phi_arr)) if len(phi_arr) > 0 else 0.0
        )

        result.phi_saturation_rate = self._compute_saturation_rate(phi_arr)

        result.pbrs_delta_mean, result.pbrs_delta_std = self._compute_pbrs_delta_stats(
            phi_arr
        )
        result.pbrs_nonzero_fraction = self._compute_nonzero_fraction(shaping_arr)

        result.shaping_reward_mean = float(np.mean(shaping_arr)) if len(shaping_arr) > 0 else 0.0
        result.shaping_reward_std = float(np.std(shaping_arr)) if len(shaping_arr) > 0 else 0.0

        result.raw_reward_episode_abs_mean = float(np.mean(np.abs(raw_arr)))
        result.shaping_reward_episode_abs_mean = float(np.mean(np.abs(shaping_arr)))

        result.episode_dominance_ratio = (
            float(np.mean(np.abs(shaping_arr)) / denominator) if denominator > self.config.epsilon else 0.0
        )

        step_dominances = self._compute_step_dominances(shaping_arr, raw_arr, denominator)
        if len(step_dominances) > 0:
            dom_arr = np.array(step_dominances, dtype=np.float64)
            result.step_dominance_median = float(np.median(dom_arr))
            result.step_dominance_p90 = float(np.percentile(dom_arr, 90)) if len(dom_arr) >= 10 else result.step_dominance_median
            result.step_dominance_p95 = float(np.percentile(dom_arr, 95)) if len(dom_arr) >= 20 else result.step_dominance_median

        if task_progress is not None and len(task_progress) >= len(phi_arr):
            progress_arr = np.asarray(task_progress[:len(phi_arr)], dtype=np.float64)
            result.progress_sign_accuracy = self._compute_progress_sign_accuracy(
                phi_arr, progress_arr
            )
            result.spearman_correlation = self._compute_spearman(phi_arr, progress_arr)
            result.kendall_tau = self._compute_kendall_tau(phi_arr, progress_arr)

        result.catastrophic_transition_rate = self._compute_catastrophic_rate(shaping_arr)

        result.passes_filters, result.filter_violations = self._apply_filters(result)

        return result

    def calibrate_grid(
        self,
        candidate_id: str,
        lambda_grid: list[float],
        raw_rewards_per_lambda: dict[float, list[float]],
        shaping_rewards_per_lambda: dict[float, list[float]],
        potential_values_per_lambda: dict[float, list[float]],
        task_progress: Optional[list[float]] = None,
    ) -> list[LambdaCalibrationResult]:
        results: list[LambdaCalibrationResult] = []
        for lam in lambda_grid:
            raw_r = raw_rewards_per_lambda.get(lam, [])
            shp_r = shaping_rewards_per_lambda.get(lam, [])
            phi_v = potential_values_per_lambda.get(lam, [])
            if not raw_r or not shp_r:
                continue
            result = self.calibrate(candidate_id, lam, raw_r, shp_r, phi_v, task_progress)
            results.append(result)
        return results

    def _compute_robust_denominator(
        self,
        raw_arr: np.ndarray,
        shaping_arr: np.ndarray,
    ) -> float:
        candidates: list[float] = []

        mean_abs_raw = float(np.mean(np.abs(raw_arr)))
        if mean_abs_raw > self.config.epsilon:
            candidates.append(mean_abs_raw)

        nonzero_raw = raw_arr[np.abs(raw_arr) > self.config.epsilon]
        if len(nonzero_raw) > 0:
            candidates.append(float(np.median(np.abs(nonzero_raw))))

        if self.config.env_spec_raw_reward_scale > self.config.epsilon:
            candidates.append(self.config.env_spec_raw_reward_scale)

        candidates.append(self.config.epsilon)

        return max(candidates) if candidates else self.config.epsilon

    def _compute_saturation_rate(self, phi_arr: np.ndarray) -> float:
        if len(phi_arr) < 10:
            return 0.0
        abs_phi = np.abs(phi_arr)
        p99 = float(np.percentile(abs_phi, 99))
        p50 = float(np.median(abs_phi))
        if p99 < self.config.epsilon:
            return 0.0
        return float(p50 / p99)

    def _compute_pbrs_delta_stats(self, phi_arr: np.ndarray) -> tuple[float, float]:
        if len(phi_arr) < 2:
            return 0.0, 0.0
        deltas = np.diff(phi_arr)
        return float(np.mean(deltas)), float(np.std(deltas))

    def _compute_nonzero_fraction(self, shaping_arr: np.ndarray) -> float:
        if len(shaping_arr) == 0:
            return 0.0
        nonzero = np.sum(np.abs(shaping_arr) > self.config.epsilon)
        return float(nonzero / len(shaping_arr))

    def _compute_step_dominances(
        self,
        shaping_arr: np.ndarray,
        raw_arr: np.ndarray,
        denominator: float,
    ) -> list[float]:
        if denominator < self.config.epsilon:
            return []
        min_len = min(len(shaping_arr), len(raw_arr))
        if min_len == 0:
            return []
        dominances: list[float] = []
        for i in range(min_len):
            abs_shaping = abs(float(shaping_arr[i]))
            dominances.append(float(abs_shaping / denominator))
        return dominances

    def _compute_progress_sign_accuracy(
        self,
        phi_arr: np.ndarray,
        progress_arr: np.ndarray,
    ) -> float:
        if len(phi_arr) < 2 or len(progress_arr) < 2:
            return 0.5
        min_len = min(len(phi_arr) - 1, len(progress_arr) - 1)
        if min_len < 1:
            return 0.5
        phi_deltas = np.diff(phi_arr[:min_len + 1])
        prog_deltas = np.diff(progress_arr[:min_len + 1])
        phi_sign = np.sign(phi_deltas)
        prog_sign = np.sign(prog_deltas)
        nonzero = prog_sign != 0
        if np.sum(nonzero) == 0:
            return 0.5
        matches = np.sum(phi_sign[nonzero] == prog_sign[nonzero])
        return float(matches / np.sum(nonzero))

    def _compute_spearman(self, phi_arr: np.ndarray, progress_arr: np.ndarray) -> float:
        try:
            from scipy.stats import spearmanr
            min_len = min(len(phi_arr), len(progress_arr))
            if min_len < 3:
                return 0.0
            corr, _ = spearmanr(phi_arr[:min_len], progress_arr[:min_len])
            if np.isfinite(corr):
                return float(corr)
            return 0.0
        except Exception:
            return 0.0

    def _compute_kendall_tau(self, phi_arr: np.ndarray, progress_arr: np.ndarray) -> float:
        try:
            from scipy.stats import kendalltau
            min_len = min(len(phi_arr), len(progress_arr))
            if min_len < 3:
                return 0.0
            tau, _ = kendalltau(phi_arr[:min_len], progress_arr[:min_len])
            if np.isfinite(tau):
                return float(tau)
            return 0.0
        except Exception:
            return 0.0

    def _compute_catastrophic_rate(self, shaping_arr: np.ndarray) -> float:
        if len(shaping_arr) < 2:
            return 0.0
        transitions = np.diff(np.abs(shaping_arr))
        if len(transitions) == 0:
            return 0.0
        total_range = float(np.max(shaping_arr) - np.min(shaping_arr))
        if total_range < self.config.epsilon:
            return 0.0
        catastrophic = np.sum(np.abs(transitions) > 0.5 * total_range)
        return float(catastrophic / len(transitions))

    def _apply_filters(self, result: LambdaCalibrationResult) -> tuple[bool, list[str]]:
        violations: list[str] = []
        cfg = self.config

        if not np.isfinite(result.phi_mean) or not np.isfinite(result.phi_std):
            violations.append("Potential values contain NaN/Inf")
            return False, violations

        if result.phi_saturation_rate > cfg.max_saturation:
            violations.append(
                f"Potential saturation {result.phi_saturation_rate:.4f} above max {cfg.max_saturation}"
            )

        if result.pbrs_nonzero_fraction < cfg.min_shaping_nonzero_fraction:
            violations.append(
                f"Shaping nonzero fraction {result.pbrs_nonzero_fraction:.6f} below min {cfg.min_shaping_nonzero_fraction}"
            )

        if result.step_dominance_p95 > cfg.max_p95_dominance:
            violations.append(
                f"Step dominance p95 {result.step_dominance_p95:.4f} above max {cfg.max_p95_dominance}"
            )

        if result.catastrophic_transition_rate > cfg.max_catastrophic_rate:
            violations.append(
                f"Catastrophic transition rate {result.catastrophic_transition_rate:.4f} above max {cfg.max_catastrophic_rate}"
            )

        if result.shaping_reward_std < self.config.epsilon and result.shaping_reward_mean < self.config.epsilon:
            violations.append(
                "Shaping rewards are always near zero (no signal)"
            )

        passes = len(violations) == 0
        return passes, violations
