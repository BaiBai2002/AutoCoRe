from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional


class ProbeCache:
    def __init__(self, cache_dir: str = "artifacts/probe_cache"):
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    def get(self, candidate_hash: str) -> Optional[dict[str, Any]]:
        cache_file = self._cache_dir / f"{candidate_hash}.json"
        if not cache_file.exists():
            return None
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def put(self, candidate_hash: str, probe_result: dict[str, Any]) -> None:
        cache_file = self._cache_dir / f"{candidate_hash}.json"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(probe_result, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def has(self, candidate_hash: str) -> bool:
        cache_file = self._cache_dir / f"{candidate_hash}.json"
        return cache_file.exists()

    def clear(self) -> None:
        for f in self._cache_dir.glob("*.json"):
            try:
                f.unlink()
            except Exception:
                pass

    def list_entries(self) -> list[str]:
        return sorted(f.stem for f in self._cache_dir.glob("*.json"))
