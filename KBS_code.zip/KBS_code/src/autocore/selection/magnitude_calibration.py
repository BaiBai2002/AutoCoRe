"""Magnitude calibration for potential-based reward shaping.

Potential-based shaping preserves the optimal policy for *any* non-negative
coefficient, but whether it helps or hurts finite-budget optimization is
decided entirely by the magnitude of the injected signal. This module makes
that magnitude explicit and solvable instead of leaving it to a hand-picked
coefficient grid.

For an episode of length ``H`` with discount ``gamma``, the discounted shaping
total telescopes exactly::

    S(lambda) = sum_t gamma^t F_t = lambda * (gamma^H * Phi(s_H) - Phi(s_0))
             = lambda * dPhi

so the *episode-level dominance* of the shaping signal relative to the original
discounted return ``R`` is

    rho(lambda) = E|S(lambda)| / E|R| = lambda * E|dPhi| / E|R|.

Matching a target dominance ``rho*`` therefore determines the coefficient in
closed form, ``lambda* = rho* * E|R| / E|dPhi|``, with no search. A candidate is
magnitude-feasible for a pre-specified grid ``Lambda`` exactly when
``lambda* in [min Lambda, max Lambda]``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Optional, Sequence

import numpy as np

from autocore.algos.vec_mpe import state_from_world
from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.envs.vec_pz import state_from_obs

StateDict = dict[str, object]


@dataclass
class ScaleEstimate:
    """Calibration statistics gathered from a fixed reference policy."""

    env_id: str
    gamma: float
    max_cycles: int
    n_episodes: int
    mean_abs_return: float
    mean_abs_delta_phi: float
    mean_abs_phi: float
    phi_min: float
    phi_max: float
    phi_mean: float = 0.0
    phi_std: float = 0.0
    mean_abs_delta_phi_step: float = 0.0
    mean_abs_reward_step: float = 0.0
    # Per-episode magnitudes, kept so that the uncertainty of lambda* can be
    # bootstrapped over episodes without re-running the reference policy. They
    # are excluded from ``to_dict`` to keep the persisted table unchanged.
    episode_abs_returns: tuple[float, ...] = ()
    episode_abs_dphis: tuple[float, ...] = ()

    @property
    def step_signal_ratio(self) -> float:
        """E|dPhi_step| / E|r_step|: step-level signal injected per unit lambda.

        This is the quantity that controls high-frequency noise: the shaping
        increment lands on every single transition, whereas the episode-level
        telescoping total only measures the net drift of the potential.
        """
        return self.mean_abs_delta_phi_step / max(self.mean_abs_reward_step, 1e-12)

    @property
    def scale_ratio(self) -> float:
        """E|dPhi| / E|R|: the dominance produced per unit of lambda."""
        return self.mean_abs_delta_phi / max(self.mean_abs_return, 1e-12)

    def required_lambda(self, rho_target: float) -> float:
        return float(rho_target / max(self.scale_ratio, 1e-12))

    def attainable_dominance(self, grid: Sequence[float]) -> tuple[float, float]:
        lo, hi = min(grid), max(grid)
        return (lo * self.scale_ratio, hi * self.scale_ratio)

    def feasible(self, grid: Sequence[float], rho_target: float) -> bool:
        lam = self.required_lambda(rho_target)
        return bool(min(grid) <= lam <= max(grid))

    def to_dict(self) -> dict[str, float | int | str]:
        return {
            "env_id": self.env_id, "gamma": self.gamma, "max_cycles": self.max_cycles,
            "n_episodes": self.n_episodes,
            "mean_abs_return": self.mean_abs_return,
            "mean_abs_delta_phi": self.mean_abs_delta_phi,
            "mean_abs_phi": self.mean_abs_phi,
            "phi_min": self.phi_min, "phi_max": self.phi_max,
            "scale_ratio": self.scale_ratio,
        }


def _is_pz_env(env_id: str) -> bool:
    from autocore.envs.vec_pz import PZ_ENV_IDS
    return env_id in PZ_ENV_IDS


def _pz_env(env_id: str, max_cycles: int):
    from autocore.envs.vec_pz import make_pz_env
    env = make_pz_env(env_id, max_cycles=max_cycles)
    return env, list(env.possible_agents)


def _sample_action(env, agent: str, rng: np.random.Generator):
    space = env.action_space(agent)
    if hasattr(space, "n"):
        return int(rng.integers(0, int(space.n)))
    return np.asarray(space.sample(), dtype=np.float32)


def collect_reference_states(
    env_id: str,
    max_cycles: int = 80,
    n_episodes: int = 8,
    seed: int = 0,
    num_agents: Optional[int] = None,
) -> list[StateDict]:
    """States visited by the uniform random reference policy, for control fitting."""
    rng = np.random.default_rng(seed)
    states: list[StateDict] = []
    if _is_pz_env(env_id):
        env, names = _pz_env(env_id, max_cycles)
        for ep in range(n_episodes):
            res = env.reset(seed=seed * 1000 + ep)
            raw = res[0] if isinstance(res, tuple) else res
            states.append(state_from_obs(raw, names))
            for _ in range(max_cycles):
                acts = {a: _sample_action(env, a, rng) for a in env.agents}
                res = env.step(acts)
                raw = res[0]
                states.append(state_from_obs(raw, names))
        env.close()
        return states
    env = make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)
    for ep in range(n_episodes):
        env.reset(seed=seed * 1000 + ep)
        states.append(state_from_world(env.aec_env.world))
        for _ in range(max_cycles):
            acts = {a: int(rng.integers(0, env.action_space(a).n)) for a in env.agents}
            env.step(acts)
            states.append(state_from_world(env.aec_env.world))
    env.close()
    return states


def estimate_scales(
    env_id: str,
    potential_fn: Callable[[StateDict], float],
    gamma: float = 0.99,
    max_cycles: int = 80,
    n_episodes: int = 40,
    seed: int = 0,
    num_agents: Optional[int] = None,
) -> ScaleEstimate:
    """Measure E|R| and E|dPhi| under a uniform random reference policy.

    The reference policy is deliberately task-agnostic and reproducible: it only
    has to visit the region of state space the shaping term is defined on.
    ``num_agents`` must match the environment used for training, otherwise the
    return scale -- and therefore the calibrated coefficient -- is wrong.
    """
    pz = _is_pz_env(env_id)
    if pz:
        env, names = _pz_env(env_id, max_cycles)
    else:
        env = make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)

    def current_state(res=None) -> StateDict:
        if not pz:
            return state_from_world(env.aec_env.world)
        raw = res[0] if isinstance(res, tuple) else res
        return state_from_obs(raw, names)

    rng = np.random.default_rng(seed)
    abs_returns: list[float] = []
    abs_dphis: list[float] = []
    phis: list[float] = []
    step_dphis: list[float] = []
    step_rewards: list[float] = []

    for ep in range(n_episodes):
        res = env.reset(seed=seed * 1000 + ep)
        phi_start = float(potential_fn(current_state(res)))
        phis.append(phi_start)
        disc_raw = 0.0
        phi_last = phi_start
        phi_prev = phi_start
        for t in range(max_cycles):
            if pz:
                acts = {a: _sample_action(env, a, rng) for a in env.agents}
            else:
                acts = {a: int(rng.integers(0, env.action_space(a).n)) for a in env.agents}
            res = env.step(acts)
            step_r = float(sum(res[1].values()))
            disc_raw += (gamma ** t) * step_r
            phi_curr = float(potential_fn(current_state(res)))
            phis.append(phi_curr)
            step_dphis.append(gamma * phi_curr - phi_prev)
            step_rewards.append(step_r)
            phi_prev = phi_curr
            phi_last = phi_curr
        abs_returns.append(abs(disc_raw))
        # Per-episode telescoping total, Eq. (telescope): gamma^H Phi(s_H) - Phi(s_0)
        # for *this* episode. Using a state from an earlier episode here would make
        # E|dPhi| depend on the episode index rather than on the potential.
        abs_dphis.append(abs((gamma ** max_cycles) * phi_last - phi_start))

    env.close()
    phi_arr = np.asarray(phis, dtype=np.float64)
    return ScaleEstimate(
        env_id=env_id, gamma=gamma, max_cycles=max_cycles, n_episodes=n_episodes,
        mean_abs_return=float(np.mean(abs_returns)),
        mean_abs_delta_phi=float(np.mean(abs_dphis)),
        mean_abs_phi=float(np.mean(np.abs(phi_arr))),
        phi_min=float(phi_arr.min()), phi_max=float(phi_arr.max()),
        phi_mean=float(phi_arr.mean()), phi_std=float(phi_arr.std()),
        mean_abs_delta_phi_step=float(np.mean(np.abs(step_dphis))),
        mean_abs_reward_step=float(np.mean(np.abs(step_rewards))),
        episode_abs_returns=tuple(float(x) for x in abs_returns),
        episode_abs_dphis=tuple(float(x) for x in abs_dphis),
    )


class RandomProjectionPotential:
    """Task-uninformative control potential of matched dynamic range.

    A fixed random direction is applied to the concatenated entity coordinates
    and affinely mapped so that its empirical range coincides with that of a
    reference potential. Used to separate the effect of injecting a signal of a
    given magnitude from the effect of injecting *task-relevant* information.
    """

    def __init__(self, reference: ScaleEstimate, seed: int = 0, ndim: int = 12) -> None:
        self.reference = reference
        rng = np.random.default_rng(seed)
        self.w = rng.normal(size=ndim)
        self.w /= np.linalg.norm(self.w) + 1e-12
        self._center = 0.0
        self._scale = 1.0

    def _features(self, state: StateDict) -> np.ndarray:
        parts: list[float] = []
        for key in ("agent_positions", "landmark_positions"):
            for p in state.get(key, []):  # type: ignore[union-attr]
                parts.extend([float(p[0]), float(p[1])])
        arr = np.asarray(parts, dtype=np.float64)
        if arr.size == 0:
            return np.zeros(len(self.w))
        if arr.size < len(self.w):
            arr = np.pad(arr, (0, len(self.w) - arr.size))
        return arr[: len(self.w)]

    def raw(self, state: StateDict) -> float:
        return float(self.w @ self._features(state))

    def fit(self, states: Iterable[StateDict]) -> "RandomProjectionPotential":
        vals = np.asarray([self.raw(s) for s in states], dtype=np.float64)
        self._center = float(vals.mean())
        ref_std = self.reference.phi_std if self.reference.phi_std > 1e-9 else 1.0
        self._scale = float(ref_std / (vals.std() + 1e-12))
        return self

    def __call__(self, state: StateDict) -> float:
        value = (self.raw(state) - self._center) * self._scale + self.reference.phi_mean
        lo, hi = self.reference.phi_min, self.reference.phi_max
        return float(max(lo, min(hi, value)))


@dataclass
class CalibrationWindow:
    """Two-sided admissible window for the shaping coefficient.

    A usable coefficient must satisfy two conditions that pull in opposite
    directions. The shaping total over an episode has to be large enough to be
    visible relative to the original return, which gives a *floor*
    ``rho_min * E|R| / E|dPhi_episode|``. At the same time the per-transition
    increment must not swamp the per-transition reward, which gives a *ceiling*
    ``kappa * E|r_step| / E|dPhi_step|``. When the ceiling falls below the floor
    no coefficient is simultaneously visible and non-disruptive, and the
    potential is inadmissible for this environment.
    """

    lambda_lo: float
    lambda_hi: float
    feasible: bool
    lambda_star: float

    def to_dict(self) -> dict[str, float | bool]:
        return {"lambda_lo": self.lambda_lo, "lambda_hi": self.lambda_hi,
                "feasible": self.feasible, "lambda_star": self.lambda_star}


def calibration_window(est: ScaleEstimate, rho_min: float = 0.02,
                       kappa: float = 1.0) -> CalibrationWindow:
    lam_lo = float(rho_min / max(est.scale_ratio, 1e-12))
    lam_hi = float(kappa / max(est.step_signal_ratio, 1e-12))
    feasible = lam_lo <= lam_hi
    lam_star = float(np.sqrt(lam_lo * lam_hi)) if feasible else lam_hi
    return CalibrationWindow(lambda_lo=lam_lo, lambda_hi=lam_hi,
                             feasible=feasible, lambda_star=lam_star)


def calibrate_lambda(
    est: ScaleEstimate,
    rho_target: float,
    grid: Optional[Sequence[float]] = None,
) -> tuple[float, bool]:
    """Return the grid-feasible coefficient closest to the analytic optimum."""
    lam_star = est.required_lambda(rho_target)
    if grid is None:
        return lam_star, True
    lo, hi = min(grid), max(grid)
    if lam_star < lo:
        return float(lo), False
    if lam_star > hi:
        return float(hi), False
    return float(lam_star), True


def legacy_grid() -> list[float]:
    return [0.025, 0.05, 0.1, 0.2, 0.4]


@dataclass
class AlignmentDiagnostics:
    """Training-free diagnostics of how well a potential tracks the task reward.

    ``shaping_reward_alignment`` is the Spearman rank correlation between the
    per-step potential increment ``gamma*Phi(s') - Phi(s)`` and the per-step
    original reward. A potential whose increments are unrelated to the reward
    cannot steer credit assignment, no matter how the coefficient is scaled.
    """

    env_id: str
    shaping_reward_alignment: float
    pearson_alignment: float
    non_interference: float
    phi_range: float
    phi_std: float
    frac_phi_frozen: float
    n_samples: int
    value_alignment: float = float("nan")
    reward_redundancy_r2: float = float("nan")

    def to_dict(self) -> dict[str, float | int | str]:
        return {
            "env_id": self.env_id,
            "shaping_reward_alignment": self.shaping_reward_alignment,
            "pearson_alignment": self.pearson_alignment,
            "non_interference": self.non_interference,
            "phi_range": self.phi_range,
            "phi_std": self.phi_std,
            "frac_phi_frozen": self.frac_phi_frozen,
            "n_samples": self.n_samples,
            "value_alignment": self.value_alignment,
            "reward_redundancy_r2": self.reward_redundancy_r2,
        }


def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    denom = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / denom) if denom > 0 else float("nan")


def alignment_diagnostics(
    env_id: str,
    potential_fn: Callable[[StateDict], float],
    gamma: float = 0.99,
    max_cycles: int = 80,
    n_episodes: int = 40,
    seed: int = 0,
    n_pairs: int = 4000,
) -> AlignmentDiagnostics:
    """Diagnostics computable from random rollouts only, without any training."""
    env = make_mpe_env(env_id, max_cycles=max_cycles)
    rng = np.random.default_rng(seed)
    dphis: list[float] = []
    rewards: list[float] = []
    phi_values: list[float] = []
    phi_step: list[float] = []
    rtg_values: list[float] = []

    for ep in range(n_episodes):
        env.reset(seed=seed * 1000 + ep)
        phi_prev = float(potential_fn(state_from_world(env.aec_env.world)))
        phi_values.append(phi_prev)
        ep_phi: list[float] = []
        ep_rew: list[float] = []
        for _ in range(max_cycles):
            ep_phi.append(phi_prev)
            acts = {a: int(rng.integers(0, env.action_space(a).n)) for a in env.agents}
            res = env.step(acts)
            step_r = float(sum(res[1].values()))
            ep_rew.append(step_r)
            phi_curr = float(potential_fn(state_from_world(env.aec_env.world)))
            phi_values.append(phi_curr)
            dphis.append(gamma * phi_curr - phi_prev)
            rewards.append(step_r)
            phi_prev = phi_curr
        running = 0.0
        ep_rtg = [0.0] * len(ep_rew)
        for t in reversed(range(len(ep_rew))):
            running = ep_rew[t] + gamma * running
            ep_rtg[t] = running
        phi_step.extend(ep_phi)
        rtg_values.extend(ep_rtg)
    env.close()

    dphi = np.asarray(dphis, dtype=np.float64)
    rew = np.asarray(rewards, dtype=np.float64)
    phi = np.asarray(phi_values, dtype=np.float64)
    phi_s = np.asarray(phi_step, dtype=np.float64)
    rtg = np.asarray(rtg_values, dtype=np.float64)

    spearman = _spearman(dphi, rew)
    pearson = float(np.corrcoef(dphi, rew)[0, 1]) if dphi.std() > 0 and rew.std() > 0 else float("nan")
    value_alignment = _spearman(phi_s, rtg)

    if rew.std() > 0 and phi_s.std() > 0:
        slope, intercept = np.polyfit(rew, phi_s, 1)
        pred = slope * rew + intercept
        ss_res = float(((phi_s - pred) ** 2).sum())
        ss_tot = float(((phi_s - phi_s.mean()) ** 2).sum())
        redundancy_r2 = 1.0 - ss_res / max(ss_tot, 1e-12)
    else:
        redundancy_r2 = float("nan")

    idx_a = rng.integers(0, dphi.size, size=n_pairs)
    idx_b = rng.integers(0, dphi.size, size=n_pairs)
    keep = idx_a != idx_b
    da, db = dphi[idx_a[keep]], dphi[idx_b[keep]]
    ra, rb = rew[idx_a[keep]], rew[idx_b[keep]]
    comparable = (da != db) & (ra != rb)
    non_interference = float(np.mean(np.sign(da - db)[comparable] == np.sign(ra - rb)[comparable]))

    return AlignmentDiagnostics(
        env_id=env_id,
        shaping_reward_alignment=spearman,
        pearson_alignment=pearson,
        non_interference=non_interference,
        phi_range=float(phi.max() - phi.min()),
        phi_std=float(phi.std()),
        frac_phi_frozen=float(np.mean(np.abs(dphi) < 1e-9)),
        n_samples=int(dphi.size),
        value_alignment=value_alignment,
        reward_redundancy_r2=float(redundancy_r2),
    )

