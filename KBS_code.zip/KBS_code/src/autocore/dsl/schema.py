from __future__ import annotations

from typing import Any

import jsonschema

DSL_SCHEMA_JSON: dict[str, Any] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "required": ["task_name", "version", "description", "subgoals", "expected_effects"],
    "additionalProperties": False,
    "properties": {
        "task_name": {
            "type": "string",
            "minLength": 1,
        },
        "version": {
            "type": "string",
            "minLength": 1,
        },
        "description": {
            "type": "string",
            "minLength": 1,
        },
        "subgoals": {
            "type": "array",
            "minItems": 1,
            "maxItems": 5,
            "items": {
                "type": "object",
                "required": [
                    "name",
                    "scope",
                    "weight",
                    "predicate",
                    "potential",
                    "rationale",
                ],
                "additionalProperties": False,
                "properties": {
                    "name": {
                        "type": "string",
                        "minLength": 1,
                    },
                    "scope": {
                        "type": "string",
                        "enum": ["global", "agent_local"],
                    },
                    "weight": {
                        "type": "number",
                        "minimum": 0.1,
                        "maximum": 10.0,
                    },
                    "predicate": {
                        "type": "object",
                        "required": ["type", "args"],
                        "additionalProperties": False,
                        "properties": {
                            "type": {
                                "type": "string",
                                "minLength": 1,
                            },
                            "args": {
                                "type": "object",
                            },
                        },
                    },
                    "potential": {
                        "type": "object",
                        "required": ["type"],
                        "additionalProperties": False,
                        "properties": {
                            "type": {
                                "type": "string",
                                "minLength": 1,
                            },
                            "clip": {
                                "type": "array",
                                "minItems": 2,
                                "maxItems": 2,
                                "items": {"type": "number"},
                            },
                            "threshold": {
                                "type": "number",
                            },
                        },
                    },
                    "rationale": {
                        "type": "string",
                        "minLength": 1,
                    },
                },
            },
        },
        "expected_effects": {
            "type": "object",
            "required": ["sample_efficiency", "final_return", "interpretability"],
            "additionalProperties": False,
            "properties": {
                "sample_efficiency": {
                    "type": "string",
                    "minLength": 1,
                },
                "final_return": {
                    "type": "string",
                    "minLength": 1,
                },
                "interpretability": {
                    "type": "string",
                    "minLength": 1,
                },
            },
        },
    },
}


class DSLSchema:
    _validator: jsonschema.Draft202012Validator | None = None

    @classmethod
    def _get_validator(cls) -> jsonschema.Draft202012Validator:
        if cls._validator is None:
            cls._validator = jsonschema.Draft202012Validator(DSL_SCHEMA_JSON)
        return cls._validator

    @classmethod
    def validate(cls, instance: dict[str, Any]) -> None:
        validator = cls._get_validator()
        errors = sorted(validator.iter_errors(instance), key=lambda e: e.path)
        if errors:
            messages: list[str] = []
            for error in errors:
                path = " -> ".join(str(p) for p in error.path) if error.path else "root"
                messages.append(f"[{path}] {error.message}")
            raise jsonschema.ValidationError(
                f"DSL validation failed with {len(errors)} error(s):\n"
                + "\n".join(f"  {m}" for m in messages)
            )
