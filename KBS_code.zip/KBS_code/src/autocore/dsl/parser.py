from __future__ import annotations

import json
from typing import Any

from autocore.dsl.schema import DSL_SCHEMA_JSON, DSLSchema


class DSLParseError(Exception):
    pass


def validate_schema_raw(
    raw: str | dict[str, Any],
) -> dict[str, Any]:
    if isinstance(raw, dict):
        dsl_dict = raw
    elif isinstance(raw, str):
        try:
            dsl_dict = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise DSLParseError(
                f"Failed to parse DSL as valid JSON: {exc}"
            ) from exc
    else:
        raise DSLParseError(
            f"Expected string or dict, got {type(raw).__name__}"
        )

    try:
        DSLSchema.validate(dsl_dict)
    except Exception as exc:
        raise DSLParseError(str(exc)) from exc

    return dsl_dict


def parse_dsl(
    raw: str | dict[str, Any],
    strict: bool = True,
) -> dict[str, Any]:
    if isinstance(raw, dict):
        dsl_dict = dict(raw)
    elif isinstance(raw, str):
        try:
            dsl_dict = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise DSLParseError(
                f"Failed to parse DSL as valid JSON. "
                f"Line {exc.lineno}, Column {exc.colno}: {exc.msg}"
            ) from exc
    else:
        raise DSLParseError(
            f"Expected a JSON string or dict, got {type(raw).__name__}. "
            f"Provide a valid DSL specification."
        )

    if not isinstance(dsl_dict, dict):
        raise DSLParseError(
            f"DSL root must be a JSON object (dict), got {type(dsl_dict).__name__}"
        )

    try:
        DSLSchema.validate(dsl_dict)
    except Exception as exc:
        raise DSLParseError(
            f"DSL schema validation failed:\n{exc}"
        ) from exc

    if strict:
        _validate_predicate_potential_consistency(dsl_dict)

    return dsl_dict


def _validate_predicate_potential_consistency(dsl_dict: dict[str, Any]) -> None:
    valid_predicate_types = {
        "min_distance_landmark_coverage",
        "mean_distance_to_nearest_landmark",
        "max_uncovered_landmark_distance",
        "pairwise_agent_distance",
        "collision_count_or_margin",
        "coverage_entropy_or_balance",
        "agent_target_assignment_distance",
    }
    valid_potential_types = {
        "negative_normalized_sum_min_distance",
        "collision_margin_bonus",
        "negative_mean_distance",
        "balanced_coverage",
    }

    for i, subgoal in enumerate(dsl_dict["subgoals"]):
        pred_type = subgoal["predicate"]["type"]
        pot_type = subgoal["potential"]["type"]

        if pred_type not in valid_predicate_types:
            raise DSLParseError(
                f"Subgoal [{i}] ('{subgoal['name']}'): unknown predicate type "
                f"'{pred_type}'. Valid types: {sorted(valid_predicate_types)}"
            )
        if pot_type not in valid_potential_types:
            raise DSLParseError(
                f"Subgoal [{i}] ('{subgoal['name']}'): unknown potential type "
                f"'{pot_type}'. Valid types: {sorted(valid_potential_types)}"
            )
