from __future__ import annotations

from typing import Any, Callable

import numpy as np
from scipy.optimize import linear_sum_assignment


class PredicateLibrary:
    def __init__(self) -> None:
        self._registry: dict[str, Callable[..., Callable[[dict[str, Any]], float]]] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        self.register("min_distance_landmark_coverage", _build_min_distance_landmark_coverage)
        self.register("mean_distance_to_nearest_landmark", _build_mean_distance_to_nearest_landmark)
        self.register("max_uncovered_landmark_distance", _build_max_uncovered_landmark_distance)
        self.register("pairwise_agent_distance", _build_pairwise_agent_distance)
        self.register("collision_count_or_margin", _build_collision_count_or_margin)
        self.register("coverage_entropy_or_balance", _build_coverage_entropy_or_balance)
        self.register("agent_target_assignment_distance", _build_agent_target_assignment_distance)

    def register(
        self,
        name: str,
        builder: Callable[..., Callable[[dict[str, Any]], float]],
    ) -> None:
        self._registry[name] = builder

    def build(
        self,
        pred_type: str,
        args: dict[str, Any],
    ) -> Callable[[dict[str, Any]], float]:
        if pred_type not in self._registry:
            raise ValueError(
                f"Unknown predicate type '{pred_type}'. "
                f"Available: {sorted(self._registry.keys())}"
            )
        return self._registry[pred_type](**args)

    def list_types(self) -> list[str]:
        return sorted(self._registry.keys())


class PotentialLibrary:
    def __init__(self) -> None:
        self._registry: dict[
            str,
            Callable[..., Callable[[dict[str, Any]], float]],
        ] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        self.register("negative_normalized_sum_min_distance", _build_negative_normalized_sum_min_distance)
        self.register("collision_margin_bonus", _build_collision_margin_bonus)
        self.register("negative_mean_distance", _build_negative_mean_distance)
        self.register("balanced_coverage", _build_balanced_coverage)

    def register(
        self,
        name: str,
        builder: Callable[..., Callable[[dict[str, Any]], float]],
    ) -> None:
        self._registry[name] = builder

    def build(
        self,
        pot_type: str,
        predicate_fn: Callable[[dict[str, Any]], float],
        clip: float | None = None,
        threshold: float | None = None,
    ) -> Callable[[dict[str, Any]], float]:
        if pot_type not in self._registry:
            raise ValueError(
                f"Unknown potential type '{pot_type}'. "
                f"Available: {sorted(self._registry.keys())}"
            )
        return self._registry[pot_type](
            predicate_fn=predicate_fn,
            clip=clip,
            threshold=threshold,
        )

    def list_types(self) -> list[str]:
        return sorted(self._registry.keys())


def _extract_array(state: dict[str, Any], key: str) -> np.ndarray:
    value = state
    for part in key.split("."):
        if isinstance(value, dict):
            value = value[part]
        elif isinstance(value, (list, np.ndarray)):
            try:
                value = value[int(part)]
            except (ValueError, IndexError):
                value = value
        else:
            raise KeyError(f"Cannot resolve key '{key}' from state")
    arr = np.asarray(value, dtype=np.float64)
    if arr.ndim == 0:
        arr = arr.reshape(1)
    return arr


def _build_min_distance_landmark_coverage(
    agent_key: str = "agent_positions",
    landmark_key: str = "landmark_positions",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)
        landmark_pos = _extract_array(state, landmark_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)
        if landmark_pos.ndim != 2 or landmark_pos.shape[1] != 2:
            landmark_pos = landmark_pos.reshape(-1, 2)

        M = landmark_pos.shape[0]
        if M == 0:
            return 0.0

        min_dists = np.empty(M, dtype=np.float64)
        for j in range(M):
            diffs = agent_pos - landmark_pos[j]
            dists = np.sqrt(np.sum(diffs * diffs, axis=1))
            min_dists[j] = np.min(dists)

        return float(np.sum(min_dists))

    return predicate


def _build_mean_distance_to_nearest_landmark(
    agent_key: str = "agent_positions",
    landmark_key: str = "landmark_positions",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)
        landmark_pos = _extract_array(state, landmark_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)
        if landmark_pos.ndim != 2 or landmark_pos.shape[1] != 2:
            landmark_pos = landmark_pos.reshape(-1, 2)

        M = landmark_pos.shape[0]
        if M == 0:
            return 0.0

        min_dists = np.empty(M, dtype=np.float64)
        for j in range(M):
            diffs = agent_pos - landmark_pos[j]
            dists = np.sqrt(np.sum(diffs * diffs, axis=1))
            min_dists[j] = np.min(dists)

        return float(np.mean(min_dists))

    return predicate


def _build_max_uncovered_landmark_distance(
    agent_key: str = "agent_positions",
    landmark_key: str = "landmark_positions",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)
        landmark_pos = _extract_array(state, landmark_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)
        if landmark_pos.ndim != 2 or landmark_pos.shape[1] != 2:
            landmark_pos = landmark_pos.reshape(-1, 2)

        M = landmark_pos.shape[0]
        if M == 0:
            return 0.0

        min_dists = np.empty(M, dtype=np.float64)
        for j in range(M):
            diffs = agent_pos - landmark_pos[j]
            dists = np.sqrt(np.sum(diffs * diffs, axis=1))
            min_dists[j] = np.min(dists)

        return float(np.max(min_dists))

    return predicate


def _build_pairwise_agent_distance(
    agent_key: str = "agent_positions",
    aggregation: str = "mean",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)

        N = agent_pos.shape[0]
        if N < 2:
            return 0.0

        all_dists: list[float] = []
        for i in range(N):
            for j in range(i + 1, N):
                diff = agent_pos[i] - agent_pos[j]
                all_dists.append(float(np.sqrt(np.dot(diff, diff))))

        dists_arr = np.array(all_dists, dtype=np.float64)

        if aggregation == "mean":
            return float(np.mean(dists_arr))
        elif aggregation == "min":
            return float(np.min(dists_arr))
        elif aggregation == "max":
            return float(np.max(dists_arr))
        elif aggregation == "sum":
            return float(np.sum(dists_arr))
        else:
            raise ValueError(f"Unknown aggregation: {aggregation}")

    return predicate


def _build_collision_count_or_margin(
    agent_key: str = "agent_positions",
    collision_threshold: float = 0.5,
    mode: str = "margin",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)

        N = agent_pos.shape[0]
        if N < 2:
            return 0.0 if mode == "count" else float(collision_threshold)

        all_dists: list[float] = []
        for i in range(N):
            for j in range(i + 1, N):
                diff = agent_pos[i] - agent_pos[j]
                all_dists.append(float(np.sqrt(np.dot(diff, diff))))

        dists_arr = np.array(all_dists, dtype=np.float64)

        if mode == "count":
            return float(np.sum(dists_arr < collision_threshold))
        elif mode == "margin":
            return float(np.min(dists_arr) - collision_threshold)
        else:
            raise ValueError(f"Unknown mode: {mode}")

    return predicate


def _build_coverage_entropy_or_balance(
    agent_key: str = "agent_positions",
    landmark_key: str = "landmark_positions",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)
        landmark_pos = _extract_array(state, landmark_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)
        if landmark_pos.ndim != 2 or landmark_pos.shape[1] != 2:
            landmark_pos = landmark_pos.reshape(-1, 2)

        N = agent_pos.shape[0]
        M = landmark_pos.shape[0]

        if N == 0 or M == 0:
            return 0.0

        dists = np.zeros((M, N), dtype=np.float64)
        for j in range(M):
            diffs = agent_pos - landmark_pos[j]
            dists[j] = np.sqrt(np.sum(diffs * diffs, axis=1))

        assignments = np.argmin(dists, axis=1)

        counts = np.bincount(assignments, minlength=N) + 1e-12
        probs = counts / float(M)
        entropy = -np.sum(probs * np.log(probs))
        max_entropy = np.log(float(N))
        balance = entropy / max_entropy if max_entropy > 0 else 0.0

        return float(balance)

    return predicate


def _build_agent_target_assignment_distance(
    agent_key: str = "agent_positions",
    landmark_key: str = "landmark_positions",
) -> Callable[[dict[str, Any]], float]:
    def predicate(state: dict[str, Any]) -> float:
        agent_pos = _extract_array(state, agent_key)
        landmark_pos = _extract_array(state, landmark_key)

        if agent_pos.ndim != 2 or agent_pos.shape[1] != 2:
            agent_pos = agent_pos.reshape(-1, 2)
        if landmark_pos.ndim != 2 or landmark_pos.shape[1] != 2:
            landmark_pos = landmark_pos.reshape(-1, 2)

        N = agent_pos.shape[0]
        M = landmark_pos.shape[0]

        if N == 0 or M == 0:
            return 0.0

        cost_matrix = np.zeros((N, max(M, N)), dtype=np.float64)
        for i in range(N):
            for j in range(M):
                diff = agent_pos[i] - landmark_pos[j]
                cost_matrix[i, j] = np.sqrt(np.dot(diff, diff))

        for i in range(N):
            for j in range(M, cost_matrix.shape[1]):
                cost_matrix[i, j] = 1e12

        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        total_cost = float(cost_matrix[row_ind, col_ind].sum())

        return total_cost

    return predicate


def _build_negative_normalized_sum_min_distance(
    predicate_fn: Callable[[dict[str, Any]], float],
    clip: float | None = None,
    threshold: float | None = None,
) -> Callable[[dict[str, Any]], float]:
    _threshold = threshold if threshold is not None else 10.0

    def potential(state: dict[str, Any]) -> float:
        raw = predicate_fn(state)
        normalized = -raw / max(_threshold, 1e-12)
        if clip is not None:
            normalized = max(-abs(clip), min(abs(clip), normalized))
        return float(normalized)

    return potential


def _build_collision_margin_bonus(
    predicate_fn: Callable[[dict[str, Any]], float],
    clip: float | None = None,
    threshold: float | None = None,
) -> Callable[[dict[str, Any]], float]:
    _threshold = threshold if threshold is not None else 0.0

    def potential(state: dict[str, Any]) -> float:
        margin = predicate_fn(state)
        bonus = float(margin > _threshold)
        if clip is not None:
            bonus = max(0.0, min(clip, bonus))
        return bonus

    return potential


def _build_negative_mean_distance(
    predicate_fn: Callable[[dict[str, Any]], float],
    clip: float | None = None,
    threshold: float | None = None,
) -> Callable[[dict[str, Any]], float]:
    def potential(state: dict[str, Any]) -> float:
        raw = predicate_fn(state)
        value = -raw
        if clip is not None:
            value = max(-abs(clip), min(abs(clip), value))
        return float(value)

    return potential


def _build_balanced_coverage(
    predicate_fn: Callable[[dict[str, Any]], float],
    clip: float | None = None,
    threshold: float | None = None,
) -> Callable[[dict[str, Any]], float]:
    _scale = threshold if threshold is not None else 1.0

    def potential(state: dict[str, Any]) -> float:
        balance = predicate_fn(state)
        value = balance * _scale
        if clip is not None:
            value = max(0.0, min(clip, value))
        return float(value)

    return potential
