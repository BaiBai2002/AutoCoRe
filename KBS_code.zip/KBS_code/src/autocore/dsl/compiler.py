from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary


@dataclass
class CompilerOutput:
    subgoal_functions: list[Callable[[dict[str, Any]], float]]
    total_potential: Callable[[dict[str, Any]], float]
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _subgoal_fns = self.subgoal_functions
        _meta = self.meta

        def _total(state: dict[str, Any]) -> float:
            weights: list[float] = _meta.get("weights", [1.0] * len(_subgoal_fns))
            total = 0.0
            for fn, w in zip(_subgoal_fns, weights):
                total += w * float(fn(state))
            return total

        self.total_potential = _total


def compile_dsl(
    dsl_dict: dict[str, Any],
    predicate_lib: PredicateLibrary | None = None,
    potential_lib: PotentialLibrary | None = None,
) -> CompilerOutput:
    if predicate_lib is None:
        predicate_lib = PredicateLibrary()
    if potential_lib is None:
        potential_lib = PotentialLibrary()

    arg_name_map = {
        "agent_positions": "agent_key",
        "landmark_positions": "landmark_key",
    }

    subgoals = dsl_dict["subgoals"]
    subgoal_functions: list[Callable[[dict[str, Any]], float]] = []
    names: list[str] = []
    weights: list[float] = []
    scopes: list[str] = []
    pot_types: list[str] = []

    for subgoal in subgoals:
        pred_type = subgoal["predicate"]["type"]
        pred_args = dict(subgoal["predicate"]["args"])
        pot_type = subgoal["potential"]["type"]
        pot_clip = subgoal["potential"].get("clip")
        pot_threshold = subgoal["potential"].get("threshold")

        if isinstance(pot_clip, (list, tuple)) and len(pot_clip) == 2:
            pot_clip = max(abs(pot_clip[0]), abs(pot_clip[1]))

        mapped_args = {arg_name_map.get(k, k): v for k, v in pred_args.items()}

        predicate_fn = predicate_lib.build(pred_type, mapped_args)
        potential_fn = potential_lib.build(pot_type, predicate_fn, pot_clip, pot_threshold)

        subgoal_functions.append(potential_fn)
        names.append(subgoal["name"])
        weights.append(float(subgoal["weight"]))
        scopes.append(subgoal["scope"])
        pot_types.append(pot_type)

    output = CompilerOutput(
        subgoal_functions=subgoal_functions,
        total_potential=lambda s: 0.0,
        meta={
            "names": names,
            "weights": weights,
            "scopes": scopes,
            "pot_types": pot_types,
            "task_name": dsl_dict["task_name"],
            "version": dsl_dict["version"],
            "description": dsl_dict["description"],
        },
    )

    return output
