"""Expanded DSL predicates for AutoCoRe v3.
New predicates: distance_to_assigned_target, nearest_agent_target_gap, target_coverage_indicator,
uncovered_target_count, agent_spread_regularizer, collision_margin_continuous, velocity_smoothness,
stagnation_penalty_indicator, listener_to_correct_landmark_distance, speaker_listener_goal_consistency,
object_to_goal_distance, pusher_to_object_distance, etc.

Each predicate: (state_dict) -> float (higher = better progress)
"""
from __future__ import annotations
import numpy as np
from typing import Any, Callable

# ===== GENERAL PREDICATES (all environments) =====

def _build_distance_to_assigned_target(agent_key: str = "agent_positions",
                                        landmark_key: str = "landmark_positions"):
    """Distance from agents to their Hungarian-assigned targets."""
    from scipy.optimize import linear_sum_assignment
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if agents.size == 0 or landmarks.size == 0: return 0.0
        na, nl = len(agents), len(landmarks)
        cost = np.zeros((na, nl))
        for i in range(na):
            for j in range(nl):
                cost[i, j] = np.linalg.norm(agents[i] - landmarks[j])
        row, col = linear_sum_assignment(cost)
        return float(cost[row, col].sum())
    return fn

def _build_nearest_agent_target_gap(agent_key: str = "agent_positions",
                                     landmark_key: str = "landmark_positions"):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if agents.size == 0 or landmarks.size == 0: return 0.0
        gaps = []
        for lm in landmarks:
            dists = [np.linalg.norm(lm - a) for a in agents]
            gaps.append(min(dists))
        return float(np.mean(gaps))
    return fn

def _build_target_coverage_indicator(agent_key: str = "agent_positions",
                                      landmark_key: str = "landmark_positions",
                                      threshold: float = 0.15):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if agents.size == 0 or landmarks.size == 0: return 0.0
        covered = 0
        for lm in landmarks:
            dists = [np.linalg.norm(lm - a) for a in agents]
            if min(dists) < threshold: covered += 1
        return float(covered)
    return fn

def _build_uncovered_target_count(agent_key: str = "agent_positions",
                                   landmark_key: str = "landmark_positions",
                                   threshold: float = 0.15):
    """Number of targets NOT covered. Lower = better."""
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if agents.size == 0 or landmarks.size == 0: return float(len(landmarks))
        uncovered = 0
        for lm in landmarks:
            dists = [np.linalg.norm(lm - a) for a in agents]
            if min(dists) >= threshold: uncovered += 1
        return float(uncovered)
    return fn

def _build_agent_spread_regularizer(agent_key: str = "agent_positions"):
    """Mean pairwise distance. Higher = more spread."""
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        if len(agents) < 2: return 0.0
        dists = []
        for i in range(len(agents)):
            for j in range(i+1, len(agents)):
                dists.append(np.linalg.norm(agents[i] - agents[j]))
        return float(np.mean(dists))
    return fn

def _build_collision_margin_continuous(agent_key: str = "agent_positions",
                                        threshold: float = 0.15):
    """Mean of min(agent_pairwise_distance - threshold, 0). Values > 0 = safe."""
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        if len(agents) < 2: return 1.0
        margins = []
        for i in range(len(agents)):
            for j in range(i+1, len(agents)):
                d = np.linalg.norm(agents[i] - agents[j])
                margins.append(d - threshold)
        return float(np.mean(margins))
    return fn

def _build_velocity_smoothness(agent_key: str = "agent_velocities"):
    def fn(state):
        vels = np.array(state.get(agent_key, []))
        if vels.size == 0: return 1.0
        return float(-np.std(vels))
    return fn

def _build_stagnation_penalty_indicator(agent_key: str = "agent_positions",
                                        prev_state_key: str = "prev_agent_positions"):
    def fn(state):
        curr = np.array(state.get(agent_key, []))
        prev = np.array(state.get(prev_state_key, state.get(agent_key, [])))
        if curr.size == 0: return 0.0
        return float(-np.mean(np.linalg.norm(curr - prev, axis=-1) if curr.ndim > 1 else np.abs(curr - prev)))
    return fn

def _build_progress_toward_goal(agent_key: str = "agent_positions",
                                 goal_key: str = "landmark_positions",
                                 prev_state_key: str = "prev_agent_positions"):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        goals = np.array(state.get(goal_key, []))
        prev_agents = np.array(state.get(prev_state_key, agents))
        if agents.size == 0 or goals.size == 0: return 0.0
        if goals.ndim == 1: goals = goals.reshape(1, -1)
        goal_center = np.mean(goals, axis=0)
        curr_dist = np.mean([np.linalg.norm(a - goal_center) for a in agents])
        prev_dist = np.mean([np.linalg.norm(a - goal_center) for a in prev_agents])
        return float(prev_dist - curr_dist)
    return fn

# ===== SIMPLE REFERENCE PREDICATES =====

def _build_listener_to_correct_landmark_distance(agent_key: str = "agent_positions",
                                                  landmark_key: str = "landmark_positions",
                                                  listener_idx: int = 1):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if len(agents) <= listener_idx or landmarks.size == 0: return 10.0
        listener = agents[listener_idx]
        dists = [np.linalg.norm(listener - lm) for lm in landmarks]
        return float(min(dists))
    return fn

def _build_speaker_listener_goal_consistency(agent_key: str = "agent_positions",
                                              landmark_key: str = "landmark_positions",
                                              speaker_idx: int = 0, listener_idx: int = 1):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if len(agents) <= max(speaker_idx, listener_idx) or landmarks.size == 0: return 0.0
        speaker = agents[speaker_idx]; listener = agents[listener_idx]
        proximity = np.exp(-np.linalg.norm(speaker - listener))
        return float(proximity)
    return fn

# ===== SIMPLE PUSH PREDICATES =====

def _build_object_to_goal_distance(agent_key: str = "agent_positions",
                                    landmark_key: str = "landmark_positions",
                                    object_idx: int = 1):
    def fn(state):
        """Distance from object (the larger entity) to goal landmark."""
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        if len(agents) <= object_idx or landmarks.size == 0: return 10.0
        obj = agents[object_idx]
        return float(np.min([np.linalg.norm(obj - lm) for lm in landmarks]))
    return fn

def _build_pusher_to_object_distance(agent_key: str = "agent_positions",
                                      pusher_idx: int = 0, object_idx: int = 1):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        if len(agents) <= max(pusher_idx, object_idx): return 10.0
        return float(np.linalg.norm(agents[pusher_idx] - agents[object_idx]))
    return fn

def _build_object_progress_delta(agent_key: str = "agent_positions",
                                  landmark_key: str = "landmark_positions",
                                  object_idx: int = 1):
    def fn(state):
        """Check if object moved toward goal since last state."""
        agents = np.array(state.get(agent_key, []))
        landmarks = np.array(state.get(landmark_key, []))
        prev_key = f"prev_{agent_key}"
        prev_agents = np.array(state.get(prev_key, agents))
        if len(agents) <= object_idx or landmarks.size == 0: return 0.0
        obj = agents[object_idx]; prev_obj = prev_agents[object_idx] if len(prev_agents) > object_idx else obj
        goal_center = np.mean(landmarks, axis=0)
        delta = np.linalg.norm(prev_obj - goal_center) - np.linalg.norm(obj - goal_center)
        return float(delta)
    return fn

def _build_agent_object_contact_margin(agent_key: str = "agent_positions",
                                        pusher_idx: int = 0, object_idx: int = 1,
                                        threshold: float = 0.1):
    def fn(state):
        agents = np.array(state.get(agent_key, []))
        if len(agents) <= max(pusher_idx, object_idx): return 0.0
        d = np.linalg.norm(agents[pusher_idx] - agents[object_idx])
        return float(max(0.0, threshold - d))
    return fn

# ===== Register ALL expanded predicates =====

def register_expanded_predicates(predicate_library: Any):
    """Add all expanded predicates to an existing PredicateLibrary."""
    lib = predicate_library
    # General
    lib.register("distance_to_assigned_target", _build_distance_to_assigned_target)
    lib.register("nearest_agent_target_gap", _build_nearest_agent_target_gap)
    lib.register("target_coverage_indicator", _build_target_coverage_indicator)
    lib.register("uncovered_target_count", _build_uncovered_target_count)
    lib.register("agent_spread_regularizer", _build_agent_spread_regularizer)
    lib.register("collision_margin_continuous", _build_collision_margin_continuous)
    lib.register("velocity_smoothness", _build_velocity_smoothness)
    lib.register("stagnation_penalty_indicator", _build_stagnation_penalty_indicator)
    lib.register("progress_toward_goal", _build_progress_toward_goal)
    # Reference-specific
    lib.register("listener_to_correct_landmark_distance", _build_listener_to_correct_landmark_distance)
    lib.register("speaker_listener_goal_consistency", _build_speaker_listener_goal_consistency)
    # Push-specific
    lib.register("object_to_goal_distance", _build_object_to_goal_distance)
    lib.register("pusher_to_object_distance", _build_pusher_to_object_distance)
    lib.register("object_progress_delta", _build_object_progress_delta)
    lib.register("agent_object_contact_margin", _build_agent_object_contact_margin)
    return lib
