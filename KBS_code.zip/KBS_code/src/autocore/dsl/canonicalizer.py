from __future__ import annotations

from typing import Any


_MIN_CONTEXT_TOKEN_RATIO = 0.3

_VAR_ALIASES: dict[str, str] = {
    "agents": "agent_positions",
    "agent": "agent_positions",
    "agent_position": "agent_positions",
    "all_agent_positions": "agent_positions",
    "listener": "agent_positions",
    "listeners": "agent_positions",
    "speaker": "agent_positions",
    "speakers": "agent_positions",
    "landmarks": "landmark_positions",
    "landmark": "landmark_positions",
    "landmark_position": "landmark_positions",
    "all_landmark_positions": "landmark_positions",
    "velocities": "agent_velocities",
    "velocity": "agent_velocities",
    "agent_velocity": "agent_velocities",
}

_PREDICATE_ALIASES: dict[str, str] = {
    "min_dist_landmark": "min_distance_landmark_coverage",
    "min_distance": "min_distance_landmark_coverage",
    "nearest_landmark": "min_distance_landmark_coverage",
    "mean_dist_landmark": "mean_distance_to_nearest_landmark",
    "mean_distance_landmark": "mean_distance_to_nearest_landmark",
    "avg_distance_landmark": "mean_distance_to_nearest_landmark",
    "max_uncovered": "max_uncovered_landmark_distance",
    "pairwise_dist": "pairwise_agent_distance",
    "agent_distance": "pairwise_agent_distance",
    "collision_count": "collision_count_or_margin",
    "collision": "collision_count_or_margin",
    "coverage_entropy": "coverage_entropy_or_balance",
    "coverage_balance": "coverage_entropy_or_balance",
    "assignment_dist": "agent_target_assignment_distance",
    "target_assignment": "agent_target_assignment_distance",
}

_POTENTIAL_ALIASES: dict[str, str] = {
    "negative_sum_min_dist": "negative_normalized_sum_min_distance",
    "neg_sum_min": "negative_normalized_sum_min_distance",
    "collision_bonus": "collision_margin_bonus",
    "collision_margin": "collision_margin_bonus",
    "neg_mean_dist": "negative_mean_distance",
    "neg_mean": "negative_mean_distance",
    "balanced": "balanced_coverage",
    "balance": "balanced_coverage",
}


def canonicalize_dsl(
    dsl_dict: dict[str, Any],
    env_spec: dict[str, Any],
) -> dict[str, Any]:
    result = dict(dsl_dict)

    subgoals = result.get("subgoals", [])
    if isinstance(subgoals, list):
        result["subgoals"] = [
            _canonicalize_subgoal(sg, env_spec) for sg in subgoals
        ]

    return result


def _canonicalize_subgoal(
    sg: dict[str, Any],
    env_spec: dict[str, Any],
) -> dict[str, Any]:
    result = dict(sg)

    predicate = result.get("predicate", {})
    if isinstance(predicate, dict):
        result["predicate"] = _canonicalize_predicate(predicate, env_spec)

    potential = result.get("potential", {})
    if isinstance(potential, dict):
        result["potential"] = _canonicalize_potential(potential)

    return result


def _canonicalize_predicate(
    predicate: dict[str, Any],
    env_spec: dict[str, Any],
) -> dict[str, Any]:
    result = dict(predicate)

    pred_type = result.get("type", "")
    if pred_type in _PREDICATE_ALIASES:
        result["type"] = _PREDICATE_ALIASES[pred_type]

    args = result.get("args", {})
    if isinstance(args, dict):
        result["args"] = _canonicalize_args(args, env_spec)

    return result


def _canonicalize_potential(
    potential: dict[str, Any],
) -> dict[str, Any]:
    result = dict(potential)

    pot_type = result.get("type", "")
    if pot_type in _POTENTIAL_ALIASES:
        result["type"] = _POTENTIAL_ALIASES[pot_type]

    return result


def _canonicalize_args(
    args: dict[str, Any],
    env_spec: dict[str, Any],
) -> dict[str, Any]:
    result: dict[str, Any] = {}
    allowed_vars: set[str] = set(env_spec.get("available_state_variables", []))

    for key, value in args.items():
        if not isinstance(value, str):
            result[key] = value
            continue

        if value in allowed_vars:
            result[key] = value
            continue

        if value in _VAR_ALIASES:
            canonical = _VAR_ALIASES[value]
            if canonical in allowed_vars:
                result[key] = canonical
                continue

        if _is_var_alias_match(value, allowed_vars):
            matched = _best_match_var(value, allowed_vars)
            if matched is not None:
                result[key] = matched
                continue

        stripped = _strip_dotted_access(value)
        if stripped in _VAR_ALIASES:
            canonical = _VAR_ALIASES[stripped]
            if canonical in allowed_vars:
                result[key] = canonical
                continue
            result[key] = value
            continue

        if stripped in allowed_vars:
            result[key] = value
            continue

        result[key] = value

    return result


def _is_var_alias_match(value: str, allowed_vars: set[str]) -> bool:
    value_lower = value.lower().replace("_", "").replace("-", "").replace(" ", "")
    for allowed in allowed_vars:
        allowed_lower = allowed.lower().replace("_", "").replace("-", "").replace(" ", "")
        if value_lower == allowed_lower:
            return True
    return False


def _best_match_var(value: str, allowed_vars: set[str]) -> str | None:
    value_lower = value.lower().replace("_", "").replace("-", "").replace(" ", "")
    for allowed in allowed_vars:
        allowed_lower = allowed.lower().replace("_", "").replace("-", "").replace(" ", "")
        if value_lower == allowed_lower:
            return allowed
    return None


def _strip_dotted_access(value: str) -> str:
    return value.split(".")[0] if "." in value else value


def get_canonical_predicate_name(pred_type: str) -> str:
    return _PREDICATE_ALIASES.get(pred_type, pred_type)


def get_canonical_potential_name(pot_type: str) -> str:
    return _POTENTIAL_ALIASES.get(pot_type, pot_type)


def get_canonical_var_name(var_name: str, env_spec: dict[str, Any]) -> str:
    allowed_vars: set[str] = set(env_spec.get("available_state_variables", []))

    if var_name in allowed_vars:
        return var_name

    stripped = _strip_dotted_access(var_name)
    if stripped in _VAR_ALIASES:
        canonical = _VAR_ALIASES[stripped]
        if canonical in allowed_vars:
            return canonical

    matched = _best_match_var(stripped, allowed_vars)
    if matched is not None:
        return matched

    return var_name
