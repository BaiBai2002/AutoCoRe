import json
from pathlib import Path
from datetime import datetime
from typing import Optional


def generate_research_report(
    project_root: str,
    experiment_results: Optional[dict] = None,
) -> str:
    root = Path(project_root)
    summary_dir = root / "artifacts" / "paper_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)

    report: list[str] = []
    report.append("# AutoCoRe Research Report")
    report.append(f"\nGenerated: {datetime.now().isoformat()}\n")

    report.append("## Method Summary")
    report.append("AutoCoRe is a counterexample-guided LLM-to-potential reward shaping framework ")
    report.append("for cooperative multi-agent reinforcement learning. It uses a constrained DSL ")
    report.append("to convert natural language task descriptions into verified potential-based ")
    report.append("reward shaping functions.\n")

    report.append("## Novelty Claims")
    report.append("1. LLM-to-Potential Compiler: Constrained JSON/DSL output with compilation to executable code")
    report.append("2. Counterexample-Guided Verifier-Repair Loop: Multi-stage validation with automatic repair")
    report.append("3. Potential-Based Reward Shaping: Telescoping-form reward shaping for cooperative MARL")
    report.append("4. Cross-LLM Robustness: Multi-provider evaluation and consensus mechanism\n")

    report.append("## Environment Details")
    report.append("- simple_spread_v3: N agents spread to cover N landmarks")
    report.append("- simple_reference_v3: Speaker-listener cooperative communication")
    report.append("- simple_speaker_listener_v4: Communication-guided navigation\n")

    report.append("## Provider/Model Availability")
    report.append("- DeepSeek: deepseek-chat (via OpenAI-compatible API)")
    report.append("- GLM: glm-4-plus (via ZhipuAI API)")
    report.append("- MiMo: mimo-v2.5-pro")
    report.append("- Flash: flash-pro\n")

    report.append("## Experimental Configuration")
    report.append("- Smoke Tier: 1 env, 1 seed, 5000 steps")
    report.append("- Pilot Tier: 2 envs, 3 seeds, 50000 steps")
    report.append("- Full Tier: 3 envs, 5 seeds, 200000 steps\n")

    if experiment_results:
        report.append("## Experiment Results Summary")
        report.append(f"```json")
        report.append(json.dumps(experiment_results, indent=2))
        report.append(f"```\n")

    report.append("## Failure Cases")
    report.append("(To be populated after experiments)\n")

    report.append("## Limitations")
    report.append("- Policy invariance guarantees from MDP shaping do not fully transfer to partially observable MARL")
    report.append("- LLM API costs and latency may limit real-time applications")
    report.append("- DSL expressiveness is constrained by the predicate/potential whitelist")
    report.append("- Cross-provider reproducibility depends on API stability\n")

    report.append("## Recommended Next Experiments")
    report.append("- Extend to more complex MPE environments (simple_tag, simple_world_comm)")
    report.append("- Evaluate with off-policy MARL algorithms (QMIX, MADDPG)")
    report.append("- Study LLM cost-performance trade-offs more systematically")
    report.append("- Develop adaptive lambda selection during training\n")

    report_path = summary_dir / "autocore_research_report.md"
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report))

    versions = {
        "python": "3.10+",
        "pytorch": "2.0+",
        "pettingzoo": "1.24+",
        "gymnasium": "0.29+",
        "report_generated": datetime.now().isoformat(),
    }
    with open(summary_dir / "software_versions.json", 'w') as f:
        json.dump(versions, f, indent=2)

    return str(report_path)
