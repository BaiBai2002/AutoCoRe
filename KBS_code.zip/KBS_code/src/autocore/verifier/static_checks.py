from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any

from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary


@dataclass
class ValidationReport:
    passed: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checks: dict[str, bool] = field(default_factory=dict)

    def merge(self, other: ValidationReport) -> ValidationReport:
        return ValidationReport(
            passed=self.passed and other.passed,
            errors=self.errors + other.errors,
            warnings=self.warnings + other.warnings,
            checks={**self.checks, **other.checks},
        )

    @classmethod
    def ok(cls, checks: dict[str, bool] | None = None) -> ValidationReport:
        return cls(passed=True, checks=checks or {})

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "checks": dict(self.checks),
        }


class StaticValidator:
    _URL_PATTERN = re.compile(
        r"https?://|ftp://|file://|data:",
        re.IGNORECASE,
    )
    _SHELL_PATTERN = re.compile(
        r"(rm\s+-rf|sudo\s+|chmod\s+|wget\s+|curl\s+|exec\(|eval\(|__import__\(|subprocess\.|os\.system\(|os\.popen\(|popen\()",
        re.IGNORECASE,
    )
    _FILE_PATH_PATTERN = re.compile(
        r"(/etc/|/home/|/root/|/var/|C:\\Windows|C:\\Users|/proc/|/sys/)",
        re.IGNORECASE,
    )

    def __init__(
        self,
        predicate_library: PredicateLibrary,
        potential_library: PotentialLibrary,
        env_spec: dict[str, Any],
    ) -> None:
        self._predicate_library = predicate_library
        self._potential_library = potential_library
        self._env_spec = env_spec
        self._allowed_state_vars: set[str] = set(
            env_spec.get("available_state_variables", [])
        )
        self._valid_predicate_types: set[str] = set(predicate_library.list_types())
        self._valid_potential_types: set[str] = set(potential_library.list_types())
        self._max_domination_ratio: float = float(
            env_spec.get("repair", {}).get("max_domination_ratio", 10.0)
        )
        self._potential_clip_range: tuple[float, float] = (
            -1.0,
            1.0,
        )

    def validate(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        reports: list[ValidationReport] = []

        reports.append(self._check_schema_validity(dsl_dict))
        reports.append(self._check_subgoal_count(dsl_dict))
        reports.append(self._check_variable_bindings(dsl_dict))
        reports.append(self._check_predicate_whitelist(dsl_dict))
        reports.append(self._check_potential_whitelist(dsl_dict))
        reports.append(self._check_weights(dsl_dict))
        reports.append(self._check_clips(dsl_dict))
        reports.append(self._check_no_arbitrary_code(dsl_dict))
        reports.append(self._check_no_urls_or_commands(dsl_dict))
        reports.append(self._check_no_dominating_subgoal(dsl_dict))
        reports.append(self._check_rationale_present(dsl_dict))

        merged = reports[0]
        for r in reports[1:]:
            merged = merged.merge(r)

        return merged

    def _check_schema_validity(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        from autocore.dsl.parser import validate_schema_raw, DSLParseError

        checks: dict[str, bool] = {}
        errors: list[str] = []
        try:
            validate_schema_raw(dsl_dict)
            checks["schema_valid"] = True
        except DSLParseError as e:
            checks["schema_valid"] = False
            errors.append(f"Schema validation failed: {e}")
        except Exception as e:
            checks["schema_valid"] = False
            errors.append(f"Schema validation error: {e}")

        return ValidationReport(
            passed=checks.get("schema_valid", False),
            errors=errors,
            checks=checks,
        )

    def _check_subgoal_count(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        subgoals = dsl_dict.get("subgoals", [])
        count = len(subgoals)
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        if count < 1:
            checks["subgoal_count"] = False
            errors.append("DSL must contain at least 1 subgoal")
        elif count > 5:
            checks["subgoal_count"] = False
            errors.append(f"DSL contains {count} subgoals, maximum allowed is 5")
        else:
            checks["subgoal_count"] = True

        return ValidationReport(
            passed=checks.get("subgoal_count", False),
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_variable_bindings(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        state_var_keys = self._extract_state_var_references(subgoals)

        unknown_vars = state_var_keys - self._allowed_state_vars
        if unknown_vars:
            checks["variable_bindings"] = False
            errors.append(
                f"Unknown state variables referenced: {sorted(unknown_vars)}. "
                f"Available: {sorted(self._allowed_state_vars)}"
            )
        else:
            checks["variable_bindings"] = True

        unused_vars = self._allowed_state_vars - state_var_keys
        if unused_vars and len(unused_vars) >= len(self._allowed_state_vars) * 0.5:
            warnings.append(
                f"More than half of available state variables are not referenced: "
                f"{sorted(unused_vars)}"
            )

        return ValidationReport(
            passed=checks.get("variable_bindings", False),
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_predicate_whitelist(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        all_valid = True
        for i, sg in enumerate(subgoals):
            pred_type = sg.get("predicate", {}).get("type", "")
            if pred_type not in self._valid_predicate_types:
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{sg.get('name', '?')}'): unknown predicate type "
                    f"'{pred_type}'. Allowed: {sorted(self._valid_predicate_types)}"
                )

        checks["predicate_whitelist"] = all_valid
        return ValidationReport(
            passed=all_valid,
            errors=errors,
            checks=checks,
        )

    def _check_potential_whitelist(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        all_valid = True
        for i, sg in enumerate(subgoals):
            pot_type = sg.get("potential", {}).get("type", "")
            if pot_type not in self._valid_potential_types:
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{sg.get('name', '?')}'): unknown potential type "
                    f"'{pot_type}'. Allowed: {sorted(self._valid_potential_types)}"
                )

        checks["potential_whitelist"] = all_valid
        return ValidationReport(
            passed=all_valid,
            errors=errors,
            checks=checks,
        )

    def _check_weights(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        all_valid = True
        for i, sg in enumerate(subgoals):
            weight = sg.get("weight", 0)
            name = sg.get("name", "?")

            if not math.isfinite(float(weight)):
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{name}'): weight={weight} is not finite"
                )
                continue

            if weight < 0.1:
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{name}'): weight={weight} below minimum 0.1"
                )
            elif weight > 10.0:
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{name}'): weight={weight} above maximum 10.0"
                )

        checks["weights_valid"] = all_valid
        return ValidationReport(
            passed=all_valid,
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_clips(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        all_valid = True
        for i, sg in enumerate(subgoals):
            clip = sg.get("potential", {}).get("clip")
            name = sg.get("name", "?")

            if clip is not None:
                if not math.isfinite(float(clip)):
                    all_valid = False
                    errors.append(
                        f"Subgoal [{i}] ('{name}'): clip={clip} is not finite"
                    )

        checks["clips_valid"] = all_valid
        return ValidationReport(
            passed=all_valid,
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_no_arbitrary_code(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        dangerous_strings = [
            "exec(",
            "eval(",
            "__import__",
            "lambda ",
            "class ",
            "def ",
            "import ",
            "from ",
            ".py",
            "global ",
            "nonlocal ",
        ]

        def _scan(obj: Any, path: str = "root") -> None:
            if isinstance(obj, str):
                for ds in dangerous_strings:
                    if ds in obj:
                        errors.append(
                            f"[{path}] contains potentially dangerous string: '{ds}'"
                        )
                        return
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    _scan(v, f"{path}.{k}")
            elif isinstance(obj, list):
                for idx, item in enumerate(obj):
                    _scan(item, f"{path}[{idx}]")

        _scan(dsl_dict)
        checks["no_arbitrary_code"] = len(errors) == 0
        return ValidationReport(
            passed=checks["no_arbitrary_code"],
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_no_urls_or_commands(
        self, dsl_dict: dict[str, Any]
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        def _scan(obj: Any, path: str = "root") -> None:
            if isinstance(obj, str):
                if self._URL_PATTERN.search(obj):
                    errors.append(f"[{path}] contains URL-like pattern: '{obj[:80]}'")
                if self._SHELL_PATTERN.search(obj):
                    errors.append(
                        f"[{path}] contains shell-command-like pattern: '{obj[:80]}'"
                    )
                if self._FILE_PATH_PATTERN.search(obj):
                    errors.append(
                        f"[{path}] contains file-path-like pattern: '{obj[:80]}'"
                    )
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    _scan(v, f"{path}.{k}")
            elif isinstance(obj, list):
                for idx, item in enumerate(obj):
                    _scan(item, f"{path}[{idx}]")

        _scan(dsl_dict)
        checks["no_urls_or_commands"] = len(errors) == 0
        return ValidationReport(
            passed=checks["no_urls_or_commands"],
            errors=errors,
            checks=checks,
        )

    def _check_no_dominating_subgoal(
        self, dsl_dict: dict[str, Any]
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        weights = [float(sg.get("weight", 1.0)) for sg in subgoals]

        if len(weights) < 2:
            checks["no_domination"] = True
            return ValidationReport(passed=True, checks=checks)

        total_weight = sum(weights)
        if total_weight <= 0:
            checks["no_domination"] = False
            errors.append("Total weight sum is non-positive, cannot check domination")
            return ValidationReport(
                passed=False, errors=errors, checks=checks
            )

        max_weight = max(weights)
        max_ratio = max_weight / (total_weight - max_weight) if (total_weight - max_weight) > 0 else float("inf")

        if max_ratio > self._max_domination_ratio:
            max_idx = weights.index(max_weight)
            max_name = subgoals[max_idx].get("name", "?")
            checks["no_domination"] = False
            errors.append(
                f"Subgoal '{max_name}' dominates: its weight ({max_weight:.2f}) is "
                f"{max_ratio:.1f}x the sum of all other weights (ratio limit: "
                f"{self._max_domination_ratio:.1f}x)"
            )
            warnings.append(
                "Reduce the dominating subgoal's weight or increase others to balance"
            )
        else:
            checks["no_domination"] = True

        return ValidationReport(
            passed=checks.get("no_domination", True),
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_rationale_present(self, dsl_dict: dict[str, Any]) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        subgoals = dsl_dict.get("subgoals", [])
        all_valid = True
        for i, sg in enumerate(subgoals):
            rationale = sg.get("rationale", "")
            if not rationale or not isinstance(rationale, str) or not rationale.strip():
                all_valid = False
                errors.append(
                    f"Subgoal [{i}] ('{sg.get('name', '?')}'): rationale is missing or empty"
                )

        checks["rationale_present"] = all_valid
        return ValidationReport(
            passed=all_valid,
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    @staticmethod
    def _extract_state_var_references(subgoals: list[dict[str, Any]]) -> set[str]:
        keys: set[str] = set()
        for sg in subgoals:
            pred_args = sg.get("predicate", {}).get("args", {})
            if isinstance(pred_args, dict):
                for val in pred_args.values():
                    if isinstance(val, str) and "." in val:
                        keys.add(val)
        return keys
