from __future__ import annotations

import copy
import json
import math
from dataclasses import dataclass, field
from typing import Any

from autocore.dsl.canonicalizer import (
    canonicalize_dsl,
    get_canonical_predicate_name,
    get_canonical_potential_name,
    get_canonical_var_name,
)
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.dsl.schema import DSLSchema
from autocore.verifier.safety_gate import SafetyGate, SafetyGateReport


@dataclass
class ConservativeRepairResult:
    success: bool
    repaired_candidate: dict[str, Any] | None = None
    original_candidate: dict[str, Any] | None = None
    changes_made: list[str] = field(default_factory=list)
    errors_remaining: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "changes_made": list(self.changes_made),
            "errors_remaining": list(self.errors_remaining),
        }


class ConservativeRepair:
    _REQUIRED_TOP_FIELDS = [
        "task_name", "version", "description", "subgoals", "expected_effects",
    ]
    _REQUIRED_EFFECTS_FIELDS = [
        "sample_efficiency", "final_return", "interpretability",
    ]
    _REQUIRED_SUBGOAL_FIELDS = [
        "name", "scope", "weight", "predicate", "potential", "rationale",
    ]
    _REQUIRED_PREDICATE_FIELDS = ["type", "args"]
    _REQUIRED_POTENTIAL_FIELDS = ["type"]

    _MIN_WEIGHT = 0.1
    _MAX_WEIGHT = 10.0
    _MIN_CLIP = -100.0
    _MAX_CLIP = 100.0

    def __init__(
        self,
        predicate_library: PredicateLibrary,
        potential_library: PotentialLibrary,
        env_spec: dict[str, Any],
    ) -> None:
        self._predicate_library = predicate_library
        self._potential_library = potential_library
        self._env_spec = env_spec
        self._safety_gate = SafetyGate(
            predicate_library, potential_library, env_spec
        )

    def repair(
        self,
        candidate: dict[str, Any],
    ) -> ConservativeRepairResult:
        original = copy.deepcopy(candidate)
        repaired = copy.deepcopy(candidate)
        changes: list[str] = []

        repaired, json_changes = self._fix_json_format(repaired)
        changes.extend(json_changes)

        repaired, field_changes = self._fix_missing_fields(repaired)
        changes.extend(field_changes)

        repaired, var_changes = self._fix_illegal_variable_names(repaired)
        changes.extend(var_changes)

        repaired, pred_changes = self._fix_illegal_predicate_names(repaired)
        changes.extend(pred_changes)

        repaired, pot_changes = self._fix_illegal_potential_names(repaired)
        changes.extend(pot_changes)

        repaired, clip_changes = self._fix_clip_ranges(repaired)
        changes.extend(clip_changes)

        repaired, weight_changes = self._fix_weight_ranges(repaired)
        changes.extend(weight_changes)

        report = self._safety_gate.validate(repaired)
        errors_remaining = list(report.errors)

        return ConservativeRepairResult(
            success=report.passed,
            repaired_candidate=repaired,
            original_candidate=original,
            changes_made=changes,
            errors_remaining=errors_remaining,
        )

    def _fix_json_format(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []

        try:
            serialized = json.dumps(candidate)
            candidate = json.loads(serialized)
        except (TypeError, ValueError):
            pass

        def _sanitize(obj: Any) -> Any:
            if isinstance(obj, float):
                if math.isnan(obj) or math.isinf(obj):
                    changes.append("Replaced NaN/Inf float with 0.0")
                    return 0.0
                return obj
            elif isinstance(obj, dict):
                return {k: _sanitize(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [_sanitize(item) for item in obj]
            return obj

        candidate = _sanitize(candidate)
        return candidate, changes

    def _fix_missing_fields(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []

        for field in self._REQUIRED_TOP_FIELDS:
            if field not in candidate:
                if field == "subgoals":
                    candidate["subgoals"] = []
                    changes.append("Added missing 'subgoals' field")
                elif field == "expected_effects":
                    candidate["expected_effects"] = {
                        "sample_efficiency": "TBD",
                        "final_return": "TBD",
                        "interpretability": "TBD",
                    }
                    changes.append("Added missing 'expected_effects' field")
                elif field == "task_name":
                    candidate["task_name"] = "unknown_task"
                    changes.append("Added missing 'task_name' field")
                elif field == "version":
                    candidate["version"] = "1.0.0"
                    changes.append("Added missing 'version' field")
                elif field == "description":
                    candidate["description"] = "Auto-generated repair"
                    changes.append("Added missing 'description' field")

        effects = candidate.get("expected_effects", {})
        if isinstance(effects, dict):
            for field in self._REQUIRED_EFFECTS_FIELDS:
                if field not in effects:
                    effects[field] = "TBD"
                    changes.append(f"Added missing 'expected_effects.{field}' field")
            candidate["expected_effects"] = effects

        subgoals = candidate.get("subgoals", [])
        if isinstance(subgoals, list):
            for i, sg in enumerate(subgoals):
                if isinstance(sg, dict):
                    for field in self._REQUIRED_SUBGOAL_FIELDS:
                        if field not in sg:
                            if field == "predicate":
                                sg["predicate"] = {"type": "", "args": {}}
                                changes.append(f"Added missing 'subgoals[{i}].predicate' field")
                            elif field == "potential":
                                sg["potential"] = {"type": ""}
                                changes.append(f"Added missing 'subgoals[{i}].potential' field")
                            elif field == "weight":
                                sg["weight"] = 1.0
                                changes.append(f"Added missing 'subgoals[{i}].weight' field")
                            elif field == "name":
                                sg["name"] = f"subgoal_{i}"
                                changes.append(f"Added missing 'subgoals[{i}].name' field")
                            elif field == "scope":
                                sg["scope"] = "global"
                                changes.append(f"Added missing 'subgoals[{i}].scope' field")
                            elif field == "rationale":
                                sg["rationale"] = "Auto-generated repair rationale"
                                changes.append(f"Added missing 'subgoals[{i}].rationale' field")

                    pred = sg.get("predicate", {})
                    if isinstance(pred, dict):
                        for field in self._REQUIRED_PREDICATE_FIELDS:
                            if field not in pred:
                                if field == "type":
                                    pred["type"] = ""
                                    changes.append(f"Added missing 'subgoals[{i}].predicate.type' field")
                                elif field == "args":
                                    pred["args"] = {}
                                    changes.append(f"Added missing 'subgoals[{i}].predicate.args' field")
                        sg["predicate"] = pred

                    pot = sg.get("potential", {})
                    if isinstance(pot, dict):
                        for field in self._REQUIRED_POTENTIAL_FIELDS:
                            if field not in pot:
                                pot["type"] = ""
                                changes.append(f"Added missing 'subgoals[{i}].potential.type' field")
                        sg["potential"] = pot

        return candidate, changes

    def _fix_illegal_variable_names(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []
        allowed_vars: set[str] = set(
            self._env_spec.get("available_state_variables", [])
        )

        subgoals = candidate.get("subgoals", [])
        if not isinstance(subgoals, list):
            return candidate, changes

        for i, sg in enumerate(subgoals):
            pred_args = sg.get("predicate", {}).get("args", {})
            if not isinstance(pred_args, dict):
                continue

            for arg_key, arg_val in list(pred_args.items()):
                if not isinstance(arg_val, str):
                    continue
                if arg_val in allowed_vars:
                    continue

                canonical = get_canonical_var_name(arg_val, self._env_spec)
                if canonical != arg_val and canonical in allowed_vars:
                    pred_args[arg_key] = canonical
                    changes.append(
                        f"Renamed variable 'subgoals[{i}].predicate.args.{arg_key}': "
                        f"'{arg_val}' -> '{canonical}'"
                    )

        return candidate, changes

    def _fix_illegal_predicate_names(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []
        valid_types = set(self._predicate_library.list_types())

        subgoals = candidate.get("subgoals", [])
        if not isinstance(subgoals, list):
            return candidate, changes

        for i, sg in enumerate(subgoals):
            pred = sg.get("predicate", {})
            if not isinstance(pred, dict):
                continue
            pred_type = pred.get("type", "")
            if pred_type in valid_types:
                continue

            canonical = get_canonical_predicate_name(pred_type)
            if canonical != pred_type and canonical in valid_types:
                pred["type"] = canonical
                changes.append(
                    f"Renamed predicate 'subgoals[{i}].predicate.type': "
                    f"'{pred_type}' -> '{canonical}'"
                )

        return candidate, changes

    def _fix_illegal_potential_names(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []
        valid_types = set(self._potential_library.list_types())

        subgoals = candidate.get("subgoals", [])
        if not isinstance(subgoals, list):
            return candidate, changes

        for i, sg in enumerate(subgoals):
            pot = sg.get("potential", {})
            if not isinstance(pot, dict):
                continue
            pot_type = pot.get("type", "")
            if pot_type in valid_types:
                continue

            canonical = get_canonical_potential_name(pot_type)
            if canonical != pot_type and canonical in valid_types:
                pot["type"] = canonical
                changes.append(
                    f"Renamed potential 'subgoals[{i}].potential.type': "
                    f"'{pot_type}' -> '{canonical}'"
                )

        return candidate, changes

    def _fix_clip_ranges(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []

        subgoals = candidate.get("subgoals", [])
        if not isinstance(subgoals, list):
            return candidate, changes

        for i, sg in enumerate(subgoals):
            pot = sg.get("potential", {})
            if not isinstance(pot, dict):
                continue
            clip = pot.get("clip")
            if clip is None:
                continue

            if isinstance(clip, (list, tuple)) and len(clip) == 2:
                lo, hi = float(clip[0]), float(clip[1])
                if not (math.isfinite(lo) and math.isfinite(hi)):
                    pot["clip"] = [self._MIN_CLIP, self._MAX_CLIP]
                    changes.append(
                        f"Fixed non-finite clip 'subgoals[{i}].potential.clip' -> "
                        f"[{self._MIN_CLIP}, {self._MAX_CLIP}]"
                    )
                    continue

                fixed_lo = max(self._MIN_CLIP, min(self._MAX_CLIP, lo))
                fixed_hi = max(self._MIN_CLIP, min(self._MAX_CLIP, hi))
                if fixed_lo >= fixed_hi:
                    fixed_lo = self._MIN_CLIP
                    fixed_hi = self._MAX_CLIP

                if fixed_lo != lo or fixed_hi != hi:
                    pot["clip"] = [fixed_lo, fixed_hi]
                    changes.append(
                        f"Clamped clip 'subgoals[{i}].potential.clip': "
                        f"[{lo}, {hi}] -> [{fixed_lo}, {fixed_hi}]"
                    )

            elif isinstance(clip, (int, float)):
                fixed = max(self._MIN_CLIP, min(self._MAX_CLIP, float(clip)))
                if fixed != float(clip):
                    pot["clip"] = fixed
                    changes.append(
                        f"Clamped clip 'subgoals[{i}].potential.clip': "
                        f"{clip} -> {fixed}"
                    )

        return candidate, changes

    def _fix_weight_ranges(
        self, candidate: dict[str, Any]
    ) -> tuple[dict[str, Any], list[str]]:
        changes: list[str] = []

        subgoals = candidate.get("subgoals", [])
        if not isinstance(subgoals, list):
            return candidate, changes

        for i, sg in enumerate(subgoals):
            weight = sg.get("weight")
            if weight is None:
                sg["weight"] = 1.0
                changes.append(
                    f"Set missing weight 'subgoals[{i}].weight' -> 1.0"
                )
                continue

            try:
                w = float(weight)
            except (TypeError, ValueError):
                sg["weight"] = 1.0
                changes.append(
                    f"Fixed invalid weight 'subgoals[{i}].weight': "
                    f"'{weight}' -> 1.0"
                )
                continue

            if not math.isfinite(w):
                sg["weight"] = 1.0
                changes.append(
                    f"Fixed non-finite weight 'subgoals[{i}].weight' -> 1.0"
                )
            elif w < self._MIN_WEIGHT:
                sg["weight"] = self._MIN_WEIGHT
                changes.append(
                    f"Clamped weight 'subgoals[{i}].weight': "
                    f"{w} -> {self._MIN_WEIGHT}"
                )
            elif w > self._MAX_WEIGHT:
                sg["weight"] = self._MAX_WEIGHT
                changes.append(
                    f"Clamped weight 'subgoals[{i}].weight': "
                    f"{w} -> {self._MAX_WEIGHT}"
                )

        return candidate, changes
