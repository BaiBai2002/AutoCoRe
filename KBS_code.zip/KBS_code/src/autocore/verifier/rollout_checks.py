from __future__ import annotations

import math
from typing import Any

import numpy as np

from autocore.dsl.compiler import CompilerOutput
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.verifier.static_checks import ValidationReport


class RolloutValidator:
    def __init__(
        self,
        env: Any,
        predicate_library: PredicateLibrary,
        potential_library: PotentialLibrary,
        num_rollouts: int = 10,
    ) -> None:
        self._env = env
        self._predicate_library = predicate_library
        self._potential_library = potential_library
        self._num_rollouts = max(1, num_rollouts)
        self._max_potential_magnitude: float = 10.0
        self._constant_tolerance: float = 1e-6

    def validate(
        self,
        compiled_output: CompilerOutput,
        dsl_dict: dict[str, Any],
    ) -> ValidationReport:
        reports: list[ValidationReport] = []

        reports.append(
            self._check_can_compute_potential(compiled_output)
        )
        reports.append(
            self._check_potential_finite(compiled_output)
        )
        reports.append(
            self._check_potential_not_constant(compiled_output)
        )
        reports.append(
            self._check_shaped_reward_magnitude(compiled_output)
        )
        reports.append(
            self._check_signs_directionally_reasonable(compiled_output, dsl_dict)
        )
        reports.append(
            self._check_subgoal_functions_valid(compiled_output)
        )

        merged = reports[0]
        for r in reports[1:]:
            merged = merged.merge(r)

        return merged

    def _collect_random_states(self, num_states: int | None = None) -> list[dict[str, Any]]:
        n = num_states or self._num_rollouts
        states: list[dict[str, Any]] = []
        for _ in range(n):
            state = self._sample_random_state()
            if state is not None:
                states.append(state)
        return states

    def _sample_random_state(self) -> dict[str, Any] | None:
        if self._env is None:
            return self._generate_synthetic_state()

        try:
            if hasattr(self._env, "reset"):
                obs, _ = self._env.reset()
            elif hasattr(self._env, "observation_space"):
                obs = self._env.observation_space.sample()
            else:
                return self._generate_synthetic_state()
            return self._normalize_state(obs)
        except Exception:
            return self._generate_synthetic_state()

    def _generate_synthetic_state(self) -> dict[str, Any]:
        return {
            "agent_positions": np.random.uniform(-2.0, 2.0, (3, 2)).astype(np.float64),
            "agent_velocities": np.random.uniform(-1.0, 1.0, (3, 2)).astype(np.float64),
            "landmark_positions": np.random.uniform(-2.0, 2.0, (3, 2)).astype(np.float64),
            "agent_count": 3,
            "landmark_count": 3,
        }

    @staticmethod
    def _normalize_state(obs: Any) -> dict[str, Any]:
        if isinstance(obs, dict):
            return {k: v for k, v in obs.items()}
        if isinstance(obs, (tuple, list)):
            return {
                "observation": np.asarray(obs, dtype=np.float64),
            }
        return {"observation": np.asarray(obs, dtype=np.float64)}

    def _check_can_compute_potential(
        self, compiled_output: CompilerOutput
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        states = self._collect_random_states()
        if not states:
            checks["can_compute"] = False
            errors.append("Could not collect any states for rollout validation")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        all_ok = True
        for i, state in enumerate(states):
            try:
                val = compiled_output.total_potential(state)
                if not isinstance(val, (int, float)):
                    all_ok = False
                    errors.append(
                        f"State [{i}]: total_potential returned non-numeric type "
                        f"{type(val).__name__}"
                    )
            except Exception as e:
                all_ok = False
                errors.append(
                    f"State [{i}]: failed to compute total_potential: {e}"
                )

        checks["can_compute"] = all_ok
        return ValidationReport(
            passed=all_ok,
            errors=errors,
            checks=checks,
        )

    def _check_potential_finite(
        self, compiled_output: CompilerOutput
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        states = self._collect_random_states()
        if not states:
            checks["potential_finite"] = False
            errors.append("Could not collect any states for rollout validation")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        all_finite = True
        for i, state in enumerate(states):
            try:
                val = float(compiled_output.total_potential(state))
                if not math.isfinite(val):
                    all_finite = False
                    errors.append(
                        f"State [{i}]: total_potential is non-finite: {val}"
                    )
            except Exception as e:
                all_finite = False
                errors.append(f"State [{i}]: failed to evaluate: {e}")

        checks["potential_finite"] = all_finite
        return ValidationReport(
            passed=all_finite,
            errors=errors,
            checks=checks,
        )

    def _check_potential_not_constant(
        self, compiled_output: CompilerOutput
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        states = self._collect_random_states(self._num_rollouts * 3)
        if len(states) < 2:
            checks["potential_not_constant"] = False
            errors.append("Not enough states to check if potential is constant")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        try:
            values = np.array(
                [float(compiled_output.total_potential(s)) for s in states],
                dtype=np.float64,
            )
        except Exception as e:
            checks["potential_not_constant"] = False
            errors.append(f"Failed to evaluate potential across states: {e}")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        value_range = float(np.max(values) - np.min(values))
        if value_range < self._constant_tolerance:
            checks["potential_not_constant"] = False
            errors.append(
                f"Potential function is nearly constant across {len(states)} states "
                f"(range={value_range:.2e}). This means the shaping reward provides "
                f"no useful gradient."
            )
        else:
            checks["potential_not_constant"] = True

        return ValidationReport(
            passed=checks.get("potential_not_constant", True),
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_shaped_reward_magnitude(
        self, compiled_output: CompilerOutput
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []

        states = self._collect_random_states(self._num_rollouts * 2)
        if not states:
            checks["reward_magnitude_bounded"] = False
            errors.append("Could not collect states for magnitude check")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        try:
            values = np.array(
                [float(compiled_output.total_potential(s)) for s in states],
                dtype=np.float64,
            )
        except Exception as e:
            checks["reward_magnitude_bounded"] = False
            errors.append(f"Failed to compute potential values: {e}")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        max_abs = float(np.max(np.abs(values)))
        if max_abs > self._max_potential_magnitude:
            checks["reward_magnitude_bounded"] = False
            errors.append(
                f"Potential magnitude ({max_abs:.2f}) exceeds maximum "
                f"({self._max_potential_magnitude:.1f}). Shaped reward may dominate "
                f"the environment reward."
            )
        else:
            checks["reward_magnitude_bounded"] = True

        values_finite = values[np.isfinite(values)]
        if len(values_finite) > 0:
            std = float(np.std(values_finite))
            if std > self._max_potential_magnitude:
                warnings.append(
                    f"Potential standard deviation ({std:.2f}) is large relative to "
                    f"magnitude limit ({self._max_potential_magnitude:.1f})"
                )

        return ValidationReport(
            passed=checks.get("reward_magnitude_bounded", True),
            errors=errors,
            warnings=warnings,
            checks=checks,
        )

    def _check_signs_directionally_reasonable(
        self,
        compiled_output: CompilerOutput,
        dsl_dict: dict[str, Any],
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        warnings: list[str] = []

        subgoal_fns = compiled_output.subgoal_functions
        if not subgoal_fns:
            checks["signs_reasonable"] = True
            return ValidationReport(passed=True, checks=checks)

        states = self._collect_random_states(self._num_rollouts)
        if not states:
            checks["signs_reasonable"] = False
            return ValidationReport(
                passed=False,
                errors=["Could not collect states for sign check"],
                checks=checks,
            )

        subgoals = dsl_dict.get("subgoals", [])
        num_subgoals = len(subgoal_fns)

        try:
            for idx in range(num_subgoals):
                vals = np.array(
                    [float(subgoal_fns[idx](s)) for s in states],
                    dtype=np.float64,
                )
                pot_type = (
                    subgoals[idx].get("potential", {}).get("type", "unknown")
                    if idx < len(subgoals)
                    else "unknown"
                )

                all_pos = bool(np.all(vals >= 0))
                if all_pos and "negative" in pot_type.lower():
                    warnings.append(
                        f"Subgoal [{idx}] ('{subgoals[idx].get('name', '?')}'): "
                        f"potential type '{pot_type}' has 'negative' in name but "
                        f"all sampled values are non-negative. This may indicate "
                        f"a sign mismatch."
                    )

            checks["signs_reasonable"] = True
        except Exception as e:
            checks["signs_reasonable"] = False
            return ValidationReport(
                passed=False,
                errors=[f"Failed to check sign reasonableness: {e}"],
                checks=checks,
            )

        return ValidationReport(
            passed=True,
            warnings=warnings,
            checks=checks,
        )

    def _check_subgoal_functions_valid(
        self, compiled_output: CompilerOutput
    ) -> ValidationReport:
        checks: dict[str, bool] = {}
        errors: list[str] = []

        states = self._collect_random_states(self._num_rollouts)
        if not states:
            checks["subgoal_functions_valid"] = False
            errors.append("Could not collect states for subgoal function check")
            return ValidationReport(passed=False, errors=errors, checks=checks)

        all_ok = True
        for idx, fn in enumerate(compiled_output.subgoal_functions):
            for sidx, state in enumerate(states):
                try:
                    val = fn(state)
                    if not math.isfinite(float(val)):
                        all_ok = False
                        errors.append(
                            f"Subgoal [{idx}], State [{sidx}]: non-finite value {val}"
                        )
                        break
                except Exception as e:
                    all_ok = False
                    errors.append(
                        f"Subgoal [{idx}], State [{sidx}]: exception: {e}"
                    )
                    break

        checks["subgoal_functions_valid"] = all_ok
        return ValidationReport(
            passed=all_ok,
            errors=errors,
            checks=checks,
        )
