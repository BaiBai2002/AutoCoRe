from __future__ import annotations

from typing import Any

from autocore.verifier.static_checks import ValidationReport


class CounterExampleGenerator:
    def __init__(self) -> None:
        pass

    def generate(self, validation_report: ValidationReport) -> dict[str, Any]:
        all_errors = validation_report.errors
        all_warnings = validation_report.warnings
        checks = validation_report.checks

        failed_checks = [k for k, v in checks.items() if not v]
        passed_checks = [k for k, v in checks.items() if v]

        error_summary = self._summarize_errors(all_errors)
        specific_violations = self._categorize_errors(all_errors)
        suggested_fixes = self._generate_suggestions(
            all_errors, failed_checks, passed_checks
        )

        return {
            "passed": validation_report.passed,
            "failed_checks": failed_checks,
            "passed_checks": passed_checks,
            "total_errors": len(all_errors),
            "total_warnings": len(all_warnings),
            "error_summary": error_summary,
            "specific_violations": specific_violations,
            "suggested_fixes": suggested_fixes,
            "raw_errors": list(all_errors),
            "raw_warnings": list(all_warnings),
        }

    @staticmethod
    def format_for_prompt(counterexample: dict[str, Any]) -> str:
        lines: list[str] = []

        lines.append("=" * 60)
        lines.append("VALIDATION FAILURE REPORT - DSL Repair Required")
        lines.append("=" * 60)
        lines.append("")

        lines.append(
            f"Result: {'PASSED' if counterexample.get('passed') else 'FAILED'}"
        )
        lines.append(
            f"Failed checks: {len(counterexample.get('failed_checks', []))}"
        )
        lines.append(
            f"Total errors: {counterexample.get('total_errors', 0)}"
        )
        lines.append("")

        error_summary = counterexample.get("error_summary", "")
        if error_summary:
            lines.append("--- Error Summary ---")
            lines.append(error_summary)
            lines.append("")

        specific_violations = counterexample.get("specific_violations", {})
        if specific_violations:
            lines.append("--- Specific Violations ---")
            for category, violations in specific_violations.items():
                lines.append(f"\n[{category}]")
                for v in violations:
                    lines.append(f"  * {v}")
            lines.append("")

        suggested_fixes = counterexample.get("suggested_fixes", [])
        if suggested_fixes:
            lines.append("--- Suggested Fixes ---")
            for i, fix in enumerate(suggested_fixes, 1):
                lines.append(f"  {i}. {fix}")
            lines.append("")

        lines.append("--- Instructions ---")
        lines.append(
            "Please revise the DSL specification to address ALL errors above. "
            "Focus on the suggested fixes and ensure all validation checks pass. "
            "Return the complete corrected DSL as JSON."
        )
        lines.append("=" * 60)

        return "\n".join(lines)

    @staticmethod
    def _summarize_errors(errors: list[str]) -> str:
        if not errors:
            return "No errors found."
        if len(errors) == 1:
            return errors[0]

        by_type: dict[str, int] = {}
        for e in errors:
            prefix = e.split(":")[0].strip() if ":" in e else "Other"
            by_type[prefix] = by_type.get(prefix, 0) + 1

        parts: list[str] = []
        for ptype, count in sorted(by_type.items(), key=lambda x: -x[1]):
            parts.append(f"{ptype} ({count} error(s))")

        return "Multiple validation failures:\n  " + "\n  ".join(parts)

    @staticmethod
    def _categorize_errors(errors: list[str]) -> dict[str, list[str]]:
        categories: dict[str, list[str]] = {
            "Schema & Structure": [],
            "Predicate & Potential Types": [],
            "Weights & Parameters": [],
            "Variable Bindings": [],
            "Safety & Security": [],
            "Subgoal Balance": [],
            "Rationale": [],
            "Rollout & Execution": [],
            "Other": [],
        }

        for e in errors:
            lowered = e.lower()
            if any(kw in lowered for kw in ["schema", "json", "required", "additional"]):
                categories["Schema & Structure"].append(e)
            elif any(kw in lowered for kw in ["predicate", "potential type"]):
                categories["Predicate & Potential Types"].append(e)
            elif any(kw in lowered for kw in ["weight", "ratio", "clip", "finite"]):
                categories["Weights & Parameters"].append(e)
            elif any(kw in lowered for kw in ["variable", "state var", "agent_key", "landmark_key"]):
                categories["Variable Bindings"].append(e)
            elif any(kw in lowered for kw in ["url", "shell", "file path", "dangerous", "command"]):
                categories["Safety & Security"].append(e)
            elif any(kw in lowered for kw in ["dominat", "balance", "ratio limit"]):
                categories["Subgoal Balance"].append(e)
            elif any(kw in lowered for kw in ["rationale"]):
                categories["Rationale"].append(e)
            elif any(kw in lowered for kw in ["rollout", "state", "compute", "magnitude", "sign"]):
                categories["Rollout & Execution"].append(e)
            else:
                categories["Other"].append(e)

        return {k: v for k, v in categories.items() if v}

    @staticmethod
    def _generate_suggestions(
        errors: list[str],
        failed_checks: list[str],
        passed_checks: list[str],
    ) -> list[str]:
        suggestions: list[str] = []

        if "schema_valid" in failed_checks:
            suggestions.append(
                "Ensure the DSL follows the exact JSON schema: required fields are "
                "'task_name', 'version', 'description', 'subgoals', 'expected_effects'. "
                "Each subgoal must have 'name', 'scope', 'weight', 'predicate', "
                "'potential', 'rationale'."
            )

        if "predicate_whitelist" in failed_checks:
            suggestions.append(
                "Use only allowed predicate types from the predicate library. "
                "Check that predicate type names are spelled correctly."
            )

        if "potential_whitelist" in failed_checks:
            suggestions.append(
                "Use only allowed potential types from the potential library. "
                "Verify potential type names match the available types exactly."
            )

        if "weights_valid" in failed_checks:
            suggestions.append(
                "All subgoal weights must be finite numbers in the range [0.1, 10.0]. "
                "Adjust any weights that are outside this range."
            )

        if "clips_valid" in failed_checks:
            suggestions.append(
                "All clip values must be finite numbers when specified. "
                "Remove or fix any NaN or infinite clip values."
            )

        if "variable_bindings" in failed_checks:
            suggestions.append(
                "Predicate argument values that reference state variables must use "
                "only the available state variables for this environment. Check the "
                "environment specification for valid variable names."
            )

        if "no_arbitrary_code" in failed_checks:
            suggestions.append(
                "Remove any code-like strings (exec, eval, import, lambda, class, def) "
                "from the DSL. The DSL should be purely declarative."
            )

        if "no_urls_or_commands" in failed_checks:
            suggestions.append(
                "Remove any URLs, shell commands, or file path references from the DSL. "
                "The DSL should not contain any executable content."
            )

        if "no_domination" in failed_checks:
            suggestions.append(
                "Ensure no single subgoal's weight dominates the others. The ratio of "
                "the largest weight to the sum of all other weights should not exceed "
                "the limit. Either reduce the dominating weight or increase others."
            )

        if "rationale_present" in failed_checks:
            suggestions.append(
                "Every subgoal must have a non-empty 'rationale' field explaining "
                "why this subgoal and its potential function are appropriate."
            )

        if "can_compute" in failed_checks or "potential_finite" in failed_checks:
            suggestions.append(
                "The compiled potential function must be computable and return finite "
                "values on all sampled states. Check predicate/potential argument "
                "compatibility and function implementations."
            )

        if "potential_not_constant" in failed_checks:
            suggestions.append(
                "The potential function should produce varying values across different "
                "states. A constant potential provides no learning signal. Adjust "
                "predicate or potential parameters."
            )

        if "reward_magnitude_bounded" in failed_checks:
            suggestions.append(
                "The potential magnitude is too large. Reduce weights, adjust clips, "
                "or modify thresholds to keep the shaped reward within reasonable bounds."
            )

        if not suggestions:
            suggestions.append(
                "Review all validation errors carefully and revise the DSL "
                "specification to address each one."
            )

        return suggestions
