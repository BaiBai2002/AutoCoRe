from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from autocore.dsl.compiler import CompilerOutput, compile_dsl
from autocore.dsl.parser import DSLParseError, validate_schema_raw
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.utils.io import ensure_dir, save_json
from autocore.utils.logging import get_logger
from autocore.verifier.counterexamples import CounterExampleGenerator
from autocore.verifier.rollout_checks import RolloutValidator
from autocore.verifier.static_checks import StaticValidator, ValidationReport


@dataclass
class RepairResult:
    success: bool
    dsl_dict: dict[str, Any] | None = None
    compiled_output: CompilerOutput | None = None
    rounds_used: int = 0
    validation_history: list[ValidationReport] = field(default_factory=list)
    provider: str = ""
    model: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "rounds_used": self.rounds_used,
            "provider": self.provider,
            "model": self.model,
            "validation_history": [
                r.to_dict() for r in self.validation_history
            ],
        }


class RepairLoop:
    _ARTIFACTS_DSL_DIR = "artifacts/generated_dsl"
    _ARTIFACTS_REPORT_DIR = "artifacts/validation_reports"

    def __init__(
        self,
        llm_client: Any,
        static_validator: StaticValidator,
        rollout_validator: RolloutValidator,
        counterexample_generator: CounterExampleGenerator,
        max_rounds: int = 3,
        base_output_dir: str | Path = ".",
    ) -> None:
        self._llm_client = llm_client
        self._static_validator = static_validator
        self._rollout_validator = rollout_validator
        self._counterexample_generator = counterexample_generator
        self._max_rounds = max(1, max_rounds)
        self._base_output_dir = Path(base_output_dir)
        self._logger = get_logger("autocore.verifier.repair_loop")

    def run(
        self,
        env_spec: dict[str, Any],
        provider_name: str,
    ) -> RepairResult:
        provider_config = self._resolve_provider_config(provider_name)
        model = provider_config.get("default_model", "unknown")

        validation_history: list[ValidationReport] = []

        round_num = 0
        dsl_text: str | None = None
        dsl_dict: dict[str, Any] | None = None

        while round_num < self._max_rounds:
            round_num += 1
            self._logger.info(
                f"Round {round_num}/{self._max_rounds} — generating DSL via {provider_name}/{model}"
            )

            if round_num == 1:
                prompt = self._build_initial_prompt(env_spec)
                dsl_text = self._call_llm(prompt, provider_config)
                if dsl_text is None:
                    self._logger.error("LLM failed to generate initial DSL")
                    continue

                parsed = self._parse_dsl_response(dsl_text)
                if parsed is None:
                    continue
                dsl_dict = parsed
            else:
                if dsl_dict is None:
                    self._logger.error("No DSL dict available for repair round")
                    continue

                last_report = validation_history[-1]
                counterexample = self._counterexample_generator.generate(last_report)
                repair_prompt = self._build_repair_prompt(
                    dsl_dict, counterexample, env_spec
                )
                dsl_text = self._call_llm(repair_prompt, provider_config)
                if dsl_text is None:
                    self._logger.error("LLM failed to generate repair DSL")
                    continue

                parsed = self._parse_dsl_response(dsl_text)
                if parsed is None:
                    continue
                dsl_dict = parsed

            self._save_dsl_artifact(dsl_dict, round_num, env_spec)
            static_report = self._static_validator.validate(dsl_dict)
            validation_history.append(static_report)
            self._save_validation_report(static_report, round_num, "static", env_spec)

            if not static_report.passed:
                self._logger.warning(
                    f"Round {round_num}: static validation FAILED "
                    f"({len(static_report.errors)} errors). Proceeding to repair."
                )
                continue

            compiled_output = self._compile_dsl(dsl_dict)
            if compiled_output is None:
                compile_report = ValidationReport(
                    passed=False,
                    errors=["DSL compilation failed — cannot proceed to rollout validation"],
                    checks={"compilation": False},
                )
                validation_history.append(compile_report)
                self._save_validation_report(
                    compile_report, round_num, "compile", env_spec
                )
                continue

            rollout_report = self._rollout_validator.validate(
                compiled_output, dsl_dict
            )
            validation_history.append(rollout_report)
            self._save_validation_report(
                rollout_report, round_num, "rollout", env_spec
            )

            if rollout_report.passed:
                self._logger.info(
                    f"Round {round_num}: ALL validations PASSED. DSL is valid."
                )
                return RepairResult(
                    success=True,
                    dsl_dict=dsl_dict,
                    compiled_output=compiled_output,
                    rounds_used=round_num,
                    validation_history=validation_history,
                    provider=provider_name,
                    model=model,
                )
            else:
                self._logger.warning(
                    f"Round {round_num}: rollout validation FAILED "
                    f"({len(rollout_report.errors)} errors). Proceeding to repair."
                )

        self._logger.error(
            f"All {self._max_rounds} repair rounds exhausted without success."
        )
        return RepairResult(
            success=False,
            dsl_dict=None,
            compiled_output=None,
            rounds_used=round_num,
            validation_history=validation_history,
            provider=provider_name,
            model=model,
        )

    def _build_initial_prompt(self, env_spec: dict[str, Any]) -> str:
        task_desc = env_spec.get("task_description", "Unknown task")
        env_id = env_spec.get("env_id", "unknown")
        state_vars = env_spec.get("available_state_variables", [])
        num_agents = env_spec.get("num_agents", "?")
        num_landmarks = env_spec.get("num_landmarks", "?")
        reward_desc = env_spec.get("reward_description", "Unknown")

        parts: list[str] = []

        parts.append("You are a reinforcement learning expert specializing in reward shaping.")
        parts.append("")
        parts.append(f"Environment: {env_id}")
        parts.append(f"Description: {task_desc}")
        parts.append(f"Agents: {num_agents}, Landmarks: {num_landmarks}")
        parts.append(f"Base Reward: {reward_desc}")
        parts.append("")
        parts.append("Available state variables:")
        for sv in state_vars:
            parts.append(f"  - {sv}")
        parts.append("")
        parts.append(
            "Design a potential-based reward shaping function for this cooperative "
            "multi-agent task. The shaping function should guide agents toward efficient "
            "coordination using the available state variables."
        )
        parts.append("")
        parts.append(
            "Output a valid DSL specification in JSON format with the following structure:"
        )
        parts.append(json.dumps(self._dsl_template(), indent=2))
        parts.append("")
        parts.append("Rules:")
        parts.append("  1. Use 1-5 subgoals with meaningful names and rationales.")
        parts.append("  2. Each subgoal must use a predicate and potential from the allowed types.")
        parts.append("  3. Weights must be in [0.1, 10.0] and balanced across subgoals.")
        parts.append("  4. Predicate args must reference only the available state variables.")
        parts.append("  5. Do NOT include any code, URLs, shell commands, or file paths.")
        parts.append("")
        parts.append("Allowed predicate types: min_distance_landmark_coverage, "
                     "mean_distance_to_nearest_landmark, max_uncovered_landmark_distance, "
                     "pairwise_agent_distance, collision_count_or_margin, "
                     "coverage_entropy_or_balance, agent_target_assignment_distance")
        parts.append("")
        parts.append("Allowed potential types: negative_normalized_sum_min_distance, "
                     "collision_margin_bonus, negative_mean_distance, balanced_coverage")
        parts.append("")
        parts.append("Return ONLY the JSON, no additional text.")

        return "\n".join(parts)

    def _build_repair_prompt(
        self,
        previous_dsl: dict[str, Any],
        counterexample: dict[str, Any],
        env_spec: dict[str, Any],
    ) -> str:
        parts: list[str] = []

        parts.append("Your previous DSL specification FAILED validation.")
        parts.append("")
        parts.append("Here is the validation feedback:")
        parts.append("")
        parts.append(
            self._counterexample_generator.format_for_prompt(counterexample)
        )
        parts.append("")
        parts.append("Here is your PREVIOUS (FAILED) DSL for reference:")
        parts.append("```json")
        parts.append(json.dumps(previous_dsl, indent=2))
        parts.append("```")
        parts.append("")
        parts.append("Available state variables:")
        for sv in env_spec.get("available_state_variables", []):
            parts.append(f"  - {sv}")
        parts.append("")
        parts.append(
            "Please produce a CORRECTED DSL that addresses ALL validation errors "
            "listed above. Return ONLY the corrected JSON, no additional text."
        )

        return "\n".join(parts)

    def _call_llm(
        self, prompt: str, provider_config: dict[str, Any]
    ) -> str | None:
        try:
            if hasattr(self._llm_client, "chat"):
                response = self._llm_client.chat(
                    messages=[{"role": "user", "content": prompt}],
                    model=provider_config.get("default_model", ""),
                )
                if isinstance(response, dict):
                    content = response.get("content", "")
                    if content:
                        return str(content)
                    choices = response.get("choices", [])
                    if choices and isinstance(choices, list):
                        msg = choices[0].get("message", {})
                        return str(msg.get("content", ""))
                return str(response) if response else None

            if hasattr(self._llm_client, "generate"):
                return str(self._llm_client.generate(prompt))

            if hasattr(self._llm_client, "__call__"):
                return str(self._llm_client(prompt))

            self._logger.warning(
                f"LLM client type {type(self._llm_client).__name__} not recognized; "
                f"trying direct string call"
            )
            return str(self._llm_client(prompt))

        except Exception as e:
            self._logger.error(f"LLM call failed: {e}")
            return None

    @staticmethod
    def _parse_dsl_response(raw: str) -> dict[str, Any] | None:
        cleaned = raw.strip()

        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines)

        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

        import re
        json_match = re.search(r'\{[\s\S]*\}', cleaned)
        if json_match:
            try:
                parsed = json.loads(json_match.group(0))
                if isinstance(parsed, dict):
                    return parsed
            except json.JSONDecodeError:
                pass

        return None

    @staticmethod
    def _compile_dsl(
        dsl_dict: dict[str, Any],
    ) -> CompilerOutput | None:
        try:
            return compile_dsl(dsl_dict)
        except Exception:
            return None

    def _save_dsl_artifact(
        self,
        dsl_dict: dict[str, Any],
        round_num: int,
        env_spec: dict[str, Any],
    ) -> None:
        env_id = env_spec.get("env_id", "unknown")
        timestamp = int(time.time())
        filename = f"dsl_{env_id}_round{round_num:02d}_{timestamp}.json"
        output_path = self._base_output_dir / self._ARTIFACTS_DSL_DIR / filename
        ensure_dir(output_path.parent)
        save_json(dsl_dict, output_path)
        self._logger.debug(f"Saved DSL artifact: {output_path}")

    def _save_validation_report(
        self,
        report: ValidationReport,
        round_num: int,
        stage: str,
        env_spec: dict[str, Any],
    ) -> None:
        env_id = env_spec.get("env_id", "unknown")
        timestamp = int(time.time())
        filename = f"report_{env_id}_round{round_num:02d}_{stage}_{timestamp}.json"
        output_path = (
            self._base_output_dir / self._ARTIFACTS_REPORT_DIR / filename
        )
        ensure_dir(output_path.parent)
        save_json(report.to_dict(), output_path)
        self._logger.debug(f"Saved validation report: {output_path}")

    @staticmethod
    def _resolve_provider_config(provider_name: str) -> dict[str, Any]:
        try:
            from autocore.utils.io import load_yaml
            from pathlib import Path

            config_path = Path(__file__).parent.parent.parent.parent / "configs" / "providers.yaml"
            if config_path.exists():
                providers_cfg = load_yaml(config_path)
                providers = providers_cfg.get("providers", {})
                if provider_name in providers:
                    return providers[provider_name]
        except Exception:
            pass

        return {
            "name": provider_name,
            "default_model": "unknown",
        }

    @staticmethod
    def _dsl_template() -> dict[str, Any]:
        return {
            "task_name": "cooperative_landmark_coverage",
            "version": "1.0.0",
            "description": "Guides agents to efficiently cover landmarks while avoiding collisions",
            "subgoals": [
                {
                    "name": "minimize_landmark_distance",
                    "scope": "global",
                    "weight": 2.0,
                    "predicate": {
                        "type": "min_distance_landmark_coverage",
                        "args": {
                            "agent_key": "agent_positions",
                            "landmark_key": "landmark_positions",
                        },
                    },
                    "potential": {
                        "type": "negative_normalized_sum_min_distance",
                        "threshold": 10.0,
                    },
                    "rationale": "Encourages agents to stay close to landmarks for efficient coverage",
                }
            ],
            "expected_effects": {
                "sample_efficiency": "Reduces episodes needed for convergence by 30-40%",
                "final_return": "Improves final coverage performance by guiding exploration",
                "interpretability": "Each subgoal maps to a specific coordination behavior",
            },
        }
