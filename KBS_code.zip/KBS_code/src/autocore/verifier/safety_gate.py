from __future__ import annotations

import math
import json
import re
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from autocore.dsl.compiler import compile_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.dsl.schema import DSLSchema


@dataclass
class SafetyGateReport:
    passed: bool
    rule_results: dict[str, bool] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "rule_results": dict(self.rule_results),
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "details": dict(self.details),
        }


class SafetyGate:
    _URL_PATTERN = re.compile(
        r"https?://|ftp://|file://|data:",
        re.IGNORECASE,
    )
    _SHELL_PATTERN = re.compile(
        r"(rm\s+-rf|sudo\s+|chmod\s+|wget\s+|curl\s+|exec\(|eval\(|__import__\(|subprocess\.|os\.system\(|os\.popen\(|popen\()",
        re.IGNORECASE,
    )
    _FILE_PATH_PATTERN = re.compile(
        r"(/etc/|/home/|/root/|/var/|C:\\Windows|C:\\Users|/proc/|/sys/)",
        re.IGNORECASE,
    )

    def __init__(
        self,
        predicate_library: PredicateLibrary,
        potential_library: PotentialLibrary,
        env_spec: dict[str, Any],
    ) -> None:
        self._predicate_library = predicate_library
        self._potential_library = potential_library
        self._env_spec = env_spec
        self._allowed_state_vars: set[str] = set(
            env_spec.get("available_state_variables", [])
        )
        self._valid_predicate_types: set[str] = set(predicate_library.list_types())
        self._valid_potential_types: set[str] = set(potential_library.list_types())

    def validate(self, candidate: dict[str, Any]) -> SafetyGateReport:
        rules: dict[str, bool] = {}
        errors: list[str] = []
        warnings: list[str] = []
        details: dict[str, Any] = {}

        result = self._rule_json_parseable(candidate)
        rules["json_parseable"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_schema_valid(candidate)
        rules["schema_valid"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_no_executable_code(candidate)
        rules["no_executable_code"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_no_url_shell_path(candidate)
        rules["no_url_shell_path"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_predicate_whitelist(candidate)
        rules["predicate_whitelist"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_potential_whitelist(candidate)
        rules["potential_whitelist"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_args_bound_to_env_spec(candidate)
        rules["args_bound_to_env_spec"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_compile_success(candidate)
        rules["compile_success"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_finite_potentials(candidate)
        rules["finite_potentials"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_non_constant_potential(candidate)
        rules["non_constant_potential"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_pbrs_form_correct(candidate)
        rules["pbrs_form_correct"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_no_nan_inf(candidate)
        rules["no_nan_inf"] = result[0]
        if not result[0]:
            errors.append(result[1])

        result = self._rule_magnitude_ok(candidate)
        rules["magnitude_ok"] = result[0]
        if not result[0]:
            errors.append(result[1])

        passed = all(rules.values())

        return SafetyGateReport(
            passed=passed,
            rule_results=rules,
            errors=errors,
            warnings=warnings,
            details=details,
        )

    def _rule_json_parseable(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            json.dumps(candidate)
            return True, ""
        except (TypeError, ValueError) as e:
            return False, f"JSON serialization failed: {e}"

    def _rule_schema_valid(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            DSLSchema.validate(candidate)
            return True, ""
        except Exception as e:
            return False, f"Schema validation failed: {e}"

    def _rule_no_executable_code(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        dangerous = [
            "exec(", "eval(", "__import__", "lambda ", "class ",
            "def ", "import ", "from ", ".py", "global ", "nonlocal ",
        ]

        def _scan(obj: Any, path: str = "root") -> str | None:
            if isinstance(obj, str):
                for ds in dangerous:
                    if ds in obj:
                        return f"[{path}] contains potentially dangerous string: '{ds}'"
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    found = _scan(v, f"{path}.{k}")
                    if found:
                        return found
            elif isinstance(obj, list):
                for idx, item in enumerate(obj):
                    found = _scan(item, f"{path}[{idx}]")
                    if found:
                        return found
            return None

        violation = _scan(candidate)
        if violation:
            return False, violation
        return True, ""

    def _rule_no_url_shell_path(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        def _scan(obj: Any, path: str = "root") -> str | None:
            if isinstance(obj, str):
                if self._URL_PATTERN.search(obj):
                    return f"[{path}] contains URL-like pattern"
                if self._SHELL_PATTERN.search(obj):
                    return f"[{path}] contains shell-command-like pattern"
                if self._FILE_PATH_PATTERN.search(obj):
                    return f"[{path}] contains file-path-like pattern"
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    found = _scan(v, f"{path}.{k}")
                    if found:
                        return found
            elif isinstance(obj, list):
                for idx, item in enumerate(obj):
                    found = _scan(item, f"{path}[{idx}]")
                    if found:
                        return found
            return None

        violation = _scan(candidate)
        if violation:
            return False, violation
        return True, ""

    def _rule_predicate_whitelist(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        subgoals = candidate.get("subgoals", [])
        for i, sg in enumerate(subgoals):
            pred_type = sg.get("predicate", {}).get("type", "")
            if pred_type not in self._valid_predicate_types:
                return False, (
                    f"Subgoal [{i}] ('{sg.get('name', '?')}'): unknown predicate type "
                    f"'{pred_type}'. Allowed: {sorted(self._valid_predicate_types)}"
                )
        return True, ""

    def _rule_potential_whitelist(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        subgoals = candidate.get("subgoals", [])
        for i, sg in enumerate(subgoals):
            pot_type = sg.get("potential", {}).get("type", "")
            if pot_type not in self._valid_potential_types:
                return False, (
                    f"Subgoal [{i}] ('{sg.get('name', '?')}'): unknown potential type "
                    f"'{pot_type}'. Allowed: {sorted(self._valid_potential_types)}"
                )
        return True, ""

    def _rule_args_bound_to_env_spec(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        subgoals = candidate.get("subgoals", [])
        referenced_vars: set[str] = set()
        for sg in subgoals:
            pred_args = sg.get("predicate", {}).get("args", {})
            if isinstance(pred_args, dict):
                for val in pred_args.values():
                    if isinstance(val, str) and "." in val:
                        referenced_vars.add(val)

        unknown = referenced_vars - self._allowed_state_vars
        if unknown:
            return False, (
                f"Unknown state variables referenced: {sorted(unknown)}. "
                f"Available: {sorted(self._allowed_state_vars)}"
            )
        return True, ""

    def _rule_compile_success(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            compile_dsl(candidate, self._predicate_library, self._potential_library)
            return True, ""
        except Exception as e:
            return False, f"DSL compilation failed: {e}"

    def _rule_finite_potentials(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            compiled = compile_dsl(candidate, self._predicate_library, self._potential_library)

            test_state = self._build_zero_state()
            for fn in compiled.subgoal_functions:
                val = fn(test_state)
                if not math.isfinite(float(val)):
                    return False, f"Potential evaluates to non-finite value: {val} on zero-state"

            extreme_state = self._build_extreme_state()
            for fn in compiled.subgoal_functions:
                val = fn(extreme_state)
                if not math.isfinite(float(val)):
                    return False, f"Potential evaluates to non-finite value: {val} on extreme-state"

            return True, ""
        except Exception as e:
            return False, f"Finite potential check failed: {e}"

    def _rule_non_constant_potential(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            compiled = compile_dsl(candidate, self._predicate_library, self._potential_library)

            state_a = self._build_zero_state()
            state_b = self._build_extreme_state()

            all_same = True
            for fn in compiled.subgoal_functions:
                va = float(fn(state_a))
                vb = float(fn(state_b))
                if abs(va - vb) > 1e-12:
                    all_same = False
                    break

            if all_same:
                return False, "All subgoal potentials are constant across different states"

            total_a = compiled.total_potential(state_a)
            total_b = compiled.total_potential(state_b)
            if abs(total_a - total_b) < 1e-12:
                return False, "Total potential is constant across different states"

            return True, ""
        except Exception as e:
            return False, f"Non-constant potential check failed: {e}"

    def _rule_pbrs_form_correct(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        subgoals = candidate.get("subgoals", [])
        for i, sg in enumerate(subgoals):
            pot = sg.get("potential", {})
            if not isinstance(pot, dict):
                return False, f"Subgoal [{i}]: potential is not a dict"
            if "type" not in pot:
                return False, f"Subgoal [{i}]: potential missing 'type' field"

        return True, ""

    def _rule_no_nan_inf(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        def _scan(obj: Any, path: str = "root") -> str | None:
            if isinstance(obj, float):
                if math.isnan(obj):
                    return f"[{path}] contains NaN"
                if math.isinf(obj):
                    return f"[{path}] contains Inf"
            elif isinstance(obj, dict):
                for k, v in obj.items():
                    found = _scan(v, f"{path}.{k}")
                    if found:
                        return found
            elif isinstance(obj, list):
                for idx, item in enumerate(obj):
                    found = _scan(item, f"{path}[{idx}]")
                    if found:
                        return found
            return None

        violation = _scan(candidate)
        if violation:
            return False, violation
        return True, ""

    def _rule_magnitude_ok(self, candidate: dict[str, Any]) -> tuple[bool, str]:
        try:
            compiled = compile_dsl(candidate, self._predicate_library, self._potential_library)

            states = self._build_probe_states()
            max_abs = 0.0
            for state in states:
                for fn in compiled.subgoal_functions:
                    val = abs(float(fn(state)))
                    if val > max_abs:
                        max_abs = val

            if max_abs > 100.0:
                return False, f"Potential magnitude too large: max_abs={max_abs:.2f} > 100.0"

            return True, ""
        except Exception as e:
            return False, f"Magnitude check failed: {e}"

    def _build_zero_state(self) -> dict[str, Any]:
        state: dict[str, Any] = {}
        for var in self._allowed_state_vars:
            parts = var.split(".")
            root = parts[0]
            if root not in state:
                if "velocity" in root.lower():
                    state[root] = np.zeros((self._env_spec.get("num_agents", 3), 2), dtype=np.float64).tolist()
                elif "landmark" in root.lower():
                    state[root] = np.zeros((self._env_spec.get("num_landmarks", 3), 2), dtype=np.float64).tolist()
                else:
                    state[root] = np.zeros((self._env_spec.get("num_agents", 3), 2), dtype=np.float64).tolist()
        return state

    def _build_extreme_state(self) -> dict[str, Any]:
        state: dict[str, Any] = {}
        for var in self._allowed_state_vars:
            parts = var.split(".")
            root = parts[0]
            if root not in state:
                if "velocity" in root.lower():
                    state[root] = (np.ones((self._env_spec.get("num_agents", 3), 2), dtype=np.float64) * 10.0).tolist()
                elif "landmark" in root.lower():
                    state[root] = (np.ones((self._env_spec.get("num_landmarks", 3), 2), dtype=np.float64) * 5.0).tolist()
                else:
                    state[root] = (np.ones((self._env_spec.get("num_agents", 3), 2), dtype=np.float64) * 5.0).tolist()
        return state

    def _build_probe_states(self) -> list[dict[str, Any]]:
        states = [self._build_zero_state(), self._build_extreme_state()]
        try:
            rng = np.random.RandomState(42)
            for _ in range(8):
                s: dict[str, Any] = {}
                for var in self._allowed_state_vars:
                    parts = var.split(".")
                    root = parts[0]
                    if root not in s:
                        if "velocity" in root.lower():
                            s[root] = (rng.randn(self._env_spec.get("num_agents", 3), 2) * 2.0).tolist()
                        elif "landmark" in root.lower():
                            s[root] = (rng.randn(self._env_spec.get("num_landmarks", 3), 2) * 3.0).tolist()
                        else:
                            s[root] = (rng.randn(self._env_spec.get("num_agents", 3), 2) * 3.0).tolist()
                states.append(s)
        except Exception:
            pass
        return states
