from __future__ import annotations

import json
import os
import random
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch


@dataclass
class ExperimentConfig:
    name: str
    tier: str
    description: str
    environments: List[str]
    methods: List[str]
    providers: List[str]
    seeds: List[int]
    training: Dict[str, Any]
    algorithm: Dict[str, Any]
    shaping: Dict[str, Any]


class ExperimentRunner:

    def __init__(self, config: ExperimentConfig, project_root: str) -> None:
        self.config = config
        self.project_root = Path(project_root)
        self.results: List[Dict[str, Any]] = []

    def run(self) -> List[Dict[str, Any]]:
        import warnings

        warnings.filterwarnings("ignore")

        jobs: List[tuple] = []
        for env_id in self.config.environments:
            for method_name in self.config.methods:
                providers = self._get_method_providers(method_name)
                for provider in providers:
                    for seed in self.config.seeds:
                        jobs.append((env_id, method_name, provider, seed))

        print(f"[ExperimentRunner] {self.config.name}: {len(jobs)} jobs")

        for env_id, method_name, provider, seed in jobs:
            result = self._run_single_job(env_id, method_name, provider, seed)
            self.results.append(result)
            self._save_raw_result(result)

        return self.results

    def _get_method_providers(self, method_name: str) -> List[str]:
        if method_name in ["base", "human_pb", "random_valid_pb"]:
            return ["none"]
        if method_name == "llm_raw_schema_only":
            return self.config.providers
        if method_name == "autocore_single":
            return self.config.providers
        if method_name == "autocore_consensus":
            return ["consensus"]
        return self.config.providers

    def _run_single_job(
        self, env_id: str, method_name: str, provider: str, seed: int
    ) -> Dict[str, Any]:
        job_name = f"{env_id}_{method_name}_{provider}_{seed}"
        print(f"  Running: {job_name}")

        start_time = time.time()
        result: Dict[str, Any] = {
            "env_id": env_id,
            "method": method_name,
            "provider": provider,
            "seed": seed,
            "job_name": job_name,
            "status": "failed",
            "final_return": None,
            "eval_returns": [],
            "success_rate": None,
            "steps_to_threshold": None,
            "wall_time": 0.0,
            "error": None,
            "training_steps": 0,
        }

        try:
            from autocore.algos.ippo import IPPOTrainer, IPPOConfig
            from autocore.envs.pettingzoo_mpe import make_mpe_env
            from autocore.envs.specs import load_env_specs, load_shaping_config
            from autocore.shaping.potentials import PotentialFunction, ShapingConfig
            from autocore.shaping.wrappers import RewardShapingWrapper
            from autocore.experiments.train import train_agent, TrainingLogger

            configs_dir = self.project_root / "configs"
            env_config_path = str(configs_dir / "envs.yaml")

            env_specs = load_env_specs(env_config_path)
            shaping_cfg_raw = load_shaping_config(env_config_path)
            env_spec = env_specs.get(env_id)

            if env_spec is None:
                raise ValueError(f"Unknown env: {env_id}")

            base_env = make_mpe_env(env_spec.pettingzoo_id, max_cycles=env_spec.max_cycles)

            shaping_config = ShapingConfig(
                gamma=self.config.shaping.get("gamma", 0.99),
                shaping_lambda=self.config.shaping.get("lambda", 0.1),
            )

            if method_name in [
                "human_pb",
                "random_valid_pb",
                "llm_raw_schema_only",
                "autocore_single",
                "autocore_consensus",
            ]:
                if method_name == "human_pb":
                    potential_fn = self._get_human_potential(env_id)
                elif method_name == "random_valid_pb":
                    potential_fn = self._get_random_potential(env_id, seed)
                else:
                    potential_fn = self._get_llm_potential(
                        env_id, method_name, provider, seed, env_spec
                    )

                env = RewardShapingWrapper(base_env, potential_fn, shaping_config)
            else:
                env = base_env

            first_agent = env.possible_agents[0]
            obs_space = base_env.observation_space(first_agent)
            act_space = base_env.action_space(first_agent)

            import gymnasium as gym
            from gymnasium import spaces

            if isinstance(obs_space, spaces.Dict):
                obs_dim = sum(int(np.prod(v.shape)) for v in obs_space.values())
            elif isinstance(obs_space, spaces.Box):
                obs_dim = int(np.prod(obs_space.shape))
            elif isinstance(obs_space, spaces.Discrete):
                obs_dim = int(obs_space.n)
            else:
                obs_dim = int(obs_space.shape[0]) if hasattr(obs_space, "shape") else 16

            if isinstance(act_space, spaces.Box):
                act_dim = int(np.prod(act_space.shape))
                discrete_action = False
            elif isinstance(act_space, spaces.Discrete):
                act_dim = int(act_space.n)
                discrete_action = True
            else:
                act_dim = 5
                discrete_action = False

            ppo_config = IPPOConfig(
                lr=self.config.algorithm.get("lr", 3e-4),
                gamma=self.config.algorithm.get("gamma", 0.99),
                gae_lambda=self.config.algorithm.get("gae_lambda", 0.95),
                clip_epsilon=self.config.algorithm.get("clip_epsilon", 0.2),
                entropy_coef=self.config.algorithm.get("entropy_coef", 0.01),
                value_coef=self.config.algorithm.get("value_coef", 0.5),
                max_grad_norm=self.config.algorithm.get("max_grad_norm", 0.5),
                hidden_dim=self.config.algorithm.get("hidden_dim", 128),
                batch_size=self.config.algorithm.get("batch_size", 256),
                device="cuda" if torch.cuda.is_available() else "cpu",
            )
            trainer = IPPOTrainer(obs_dim, act_dim, ppo_config, discrete_action)

            logger = TrainingLogger()
            logger = train_agent(
                env,
                trainer,
                num_steps=self.config.training["total_steps"],
                eval_interval=self.config.training["eval_interval"],
                eval_episodes=self.config.training["eval_episodes"],
                logger=logger,
                seed=seed,
            )

            df = logger.get_dataframe()
            if "eval_return" in df.columns:
                eval_col = df[df["eval_return"].notna()]["eval_return"]
                eval_returns: List[float] = eval_col.tolist()
                result["eval_returns"] = eval_returns
                result["final_return"] = eval_returns[-1] if eval_returns else None

            result["status"] = "completed"
            result["training_steps"] = self.config.training["total_steps"]

            env.close()

        except Exception as e:
            result["error"] = str(e)
            result["traceback"] = traceback.format_exc()
            print(f"    FAILED: {e}")

        result["wall_time"] = time.time() - start_time
        return result

    def _get_human_potential(self, env_id: str) -> PotentialFunction:
        from autocore.dsl import compile_dsl
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig

        human_dsl: Dict[str, Any] = {
            "task_name": env_id,
            "version": "1.0",
            "description": "Human-designed heuristic potential",
            "subgoals": [
                {
                    "name": "cover_landmarks",
                    "scope": "global",
                    "weight": 1.0,
                    "predicate": {
                        "type": "min_distance_landmark_coverage",
                        "args": {
                            "agent_key": "agent_positions",
                            "landmark_key": "landmark_positions",
                        },
                    },
                    "potential": {
                        "type": "negative_normalized_sum_min_distance",
                        "threshold": 10.0,
                    },
                    "rationale": "Encourages covering all landmarks.",
                },
                {
                    "name": "avoid_collisions",
                    "scope": "global",
                    "weight": 0.25,
                    "predicate": {
                        "type": "collision_count_or_margin",
                        "args": {"agent_key": "agent_positions", "mode": "margin"},
                    },
                    "potential": {
                        "type": "collision_margin_bonus",
                        "threshold": 0.0,
                    },
                    "rationale": "Reduces collisions.",
                },
            ],
            "expected_effects": {
                "sample_efficiency": "increase",
                "final_return": "non_decrease",
                "interpretability": "increase",
            },
        }
        compiled = compile_dsl(human_dsl)
        config = ShapingConfig()
        return PotentialFunction(compiled, config)

    def _get_random_potential(self, env_id: str, seed: int) -> PotentialFunction:
        random.seed(seed)

        from autocore.dsl import compile_dsl
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig

        predicate_types = [
            "min_distance_landmark_coverage",
            "mean_distance_to_nearest_landmark",
            "pairwise_agent_distance",
        ]
        potential_types = [
            "negative_normalized_sum_min_distance",
            "negative_mean_distance",
            "collision_margin_bonus",
        ]

        num_subgoals = random.randint(2, 4)
        subgoals: List[Dict[str, Any]] = []
        for i in range(num_subgoals):
            ptype = random.choice(predicate_types)
            pot_type = random.choice(potential_types)
            subgoals.append(
                {
                    "name": f"random_subgoal_{i}",
                    "scope": "global",
                    "weight": round(random.uniform(0.3, 1.5), 2),
                    "predicate": {
                        "type": ptype,
                        "args": {
                            "agent_key": "agent_positions",
                            "landmark_key": "landmark_positions",
                        },
                    },
                    "potential": {"type": pot_type},
                    "rationale": f"Random valid subgoal {i}",
                }
            )

        random_dsl: Dict[str, Any] = {
            "task_name": env_id,
            "version": "1.0",
            "description": "Random valid potential from DSL library",
            "subgoals": subgoals,
            "expected_effects": {
                "sample_efficiency": "increase",
                "final_return": "non_decrease",
                "interpretability": "increase",
            },
        }
        compiled = compile_dsl(random_dsl)
        config = ShapingConfig()
        return PotentialFunction(compiled, config)

    def _get_llm_potential(
        self,
        env_id: str,
        method_name: str,
        provider: str,
        seed: int,
        env_spec: Any,
    ) -> PotentialFunction:
        from autocore.dsl import compile_dsl, parse_dsl
        from autocore.llm.client import LLMClient
        from autocore.llm.prompts import PromptBuilder
        from autocore.llm.providers import load_providers
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig

        config_path = str(self.project_root / "configs" / "providers.yaml")
        providers = load_providers(config_path)

        if provider not in providers:
            raise ValueError(f"Unknown provider: {provider}")

        provider_config = providers[provider]
        if not provider_config.is_available:
            raise RuntimeError(
                f"Provider {provider} is not available (API key not set)"
            )

        client_config: Dict[str, Any] = {
            "name": provider_config.name,
            "display_name": provider_config.display_name,
            "api_key": provider_config.api_key,
            "base_url": provider_config.base_url,
            "model": provider_config.model,
            "chat_endpoint": provider_config.chat_endpoint,
            "timeout": provider_config.timeout,
            "max_retries": provider_config.max_retries,
            "retry_delay": provider_config.retry_delay,
        }
        client = LLMClient(client_config)

        env_spec_dict: Dict[str, Any] = (
            env_spec.__dict__ if hasattr(env_spec, "__dict__") else dict(env_spec)
        )

        if method_name == "autocore_consensus":
            potential_fn = self._run_consensus(
                client, provider_config.name, env_spec_dict, env_id, seed
            )
        else:
            prompt_builder = PromptBuilder()
            messages = prompt_builder.build_generation_prompt(env_spec_dict)
            response = client.generate(messages, temperature=0.3, max_tokens=4096)
            dsl_text = response["content"].strip()

            if "```json" in dsl_text:
                dsl_text = dsl_text.split("```json")[1].split("```")[0].strip()
            elif "```" in dsl_text:
                dsl_text = dsl_text.split("```")[1].split("```")[0].strip()

            dsl_dict = parse_dsl(dsl_text)
            compiled = compile_dsl(dsl_dict)
            config = ShapingConfig()
            potential_fn = PotentialFunction(compiled, config)

        client.close()
        return potential_fn

    def _run_consensus(
        self,
        client: Any,
        provider_name: str,
        env_spec_dict: Dict[str, Any],
        env_id: str,
        seed: int,
    ) -> PotentialFunction:
        from autocore.dsl import compile_dsl, parse_dsl
        from autocore.llm.prompts import PromptBuilder
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig

        prompt_builder = PromptBuilder()
        candidates: List[Dict[str, Any]] = []
        temperatures = [0.3, 0.6, 0.9]

        for temp in temperatures:
            messages = prompt_builder.build_generation_prompt(env_spec_dict)
            response = client.generate(messages, temperature=temp, max_tokens=4096)
            dsl_text = response["content"].strip()

            if "```json" in dsl_text:
                dsl_text = dsl_text.split("```json")[1].split("```")[0].strip()
            elif "```" in dsl_text:
                dsl_text = dsl_text.split("```")[1].split("```")[0].strip()

            try:
                dsl_dict = parse_dsl(dsl_text)
                candidates.append(dsl_dict)
            except Exception:
                continue

        if not candidates:
            messages = prompt_builder.build_generation_prompt(env_spec_dict)
            response = client.generate(messages, temperature=0.3, max_tokens=4096)
            dsl_text = response["content"].strip()
            if "```json" in dsl_text:
                dsl_text = dsl_text.split("```json")[1].split("```")[0].strip()
            elif "```" in dsl_text:
                dsl_text = dsl_text.split("```")[1].split("```")[0].strip()
            dsl_dict = parse_dsl(dsl_text)
            compiled = compile_dsl(dsl_dict)
            config = ShapingConfig()
            return PotentialFunction(compiled, config)

        consensus_messages = prompt_builder.build_consensus_prompt(candidates, env_spec_dict)
        response = client.generate(consensus_messages, temperature=0.3, max_tokens=4096)
        dsl_text = response["content"].strip()

        if "```json" in dsl_text:
            dsl_text = dsl_text.split("```json")[1].split("```")[0].strip()
        elif "```" in dsl_text:
            dsl_text = dsl_text.split("```")[1].split("```")[0].strip()

        dsl_dict = parse_dsl(dsl_text)
        compiled = compile_dsl(dsl_dict)
        config = ShapingConfig()
        return PotentialFunction(compiled, config)

    def _save_raw_result(self, result: Dict[str, Any]) -> None:
        raw_dir = self.project_root / "artifacts" / "raw_runs"
        raw_dir.mkdir(parents=True, exist_ok=True)

        filename = f"{result['job_name']}_{int(time.time())}.json"
        with open(raw_dir / filename, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, default=str)
