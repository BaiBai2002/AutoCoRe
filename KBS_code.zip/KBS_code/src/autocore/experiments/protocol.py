from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExperimentProtocol:
    git_commit: str = ""
    dirty_worktree: bool = False
    protocol_version: str = "v3.0"
    envs: list[str] = field(default_factory=list)
    methods: list[str] = field(default_factory=list)
    seeds: list[int] = field(default_factory=list)
    training_steps: int = 0
    eval_interval: int = 0
    eval_episodes: int = 0
    candidate_budget: int = 0
    probe_budget: int = 0
    lambda_grid: list[float] = field(default_factory=list)
    lambda_mode: str = ""
    selector_weights: dict[str, float] = field(default_factory=dict)
    code_version: str = ""
    prompt_version: str = ""
    dsl_schema_version: str = ""
    env_spec_version: str = ""
    alg_config: dict[str, Any] = field(default_factory=dict)
    shp_config: dict[str, Any] = field(default_factory=dict)

    _frozen_hash: str = field(default="", repr=False, compare=False)
    _frozen: bool = field(default=False, repr=False, compare=False)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "git_commit": self.git_commit,
            "dirty_worktree": self.dirty_worktree,
            "protocol_version": self.protocol_version,
            "envs": list(self.envs),
            "methods": list(self.methods),
            "seeds": list(self.seeds),
            "training_steps": self.training_steps,
            "eval_interval": self.eval_interval,
            "eval_episodes": self.eval_episodes,
            "candidate_budget": self.candidate_budget,
            "probe_budget": self.probe_budget,
            "lambda_grid": list(self.lambda_grid),
            "lambda_mode": self.lambda_mode,
            "selector_weights": dict(self.selector_weights),
            "code_version": self.code_version,
            "prompt_version": self.prompt_version,
            "dsl_schema_version": self.dsl_schema_version,
            "env_spec_version": self.env_spec_version,
            "alg_config": dict(self.alg_config),
            "shp_config": dict(self.shp_config),
        }
        if self._frozen_hash:
            d["_frozen_hash"] = self._frozen_hash
        return d

    @classmethod
    def from_dict(cls, d: dict) -> ExperimentProtocol:
        return cls(
            git_commit=d.get("git_commit", ""),
            dirty_worktree=d.get("dirty_worktree", False),
            protocol_version=d.get("protocol_version", "v3.0"),
            envs=d.get("envs", []),
            methods=d.get("methods", []),
            seeds=d.get("seeds", []),
            training_steps=d.get("training_steps", 0),
            eval_interval=d.get("eval_interval", 0),
            eval_episodes=d.get("eval_episodes", 0),
            candidate_budget=d.get("candidate_budget", 0),
            probe_budget=d.get("probe_budget", 0),
            lambda_grid=d.get("lambda_grid", []),
            lambda_mode=d.get("lambda_mode", ""),
            selector_weights=d.get("selector_weights", {}),
            code_version=d.get("code_version", ""),
            prompt_version=d.get("prompt_version", ""),
            dsl_schema_version=d.get("dsl_schema_version", ""),
            env_spec_version=d.get("env_spec_version", ""),
            alg_config=d.get("alg_config", {}),
            shp_config=d.get("shp_config", {}),
        )

    def _compute_hash(self) -> str:
        payload = json.dumps(self.to_dict(), sort_keys=True, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def freeze(self) -> None:
        self._frozen_hash = self._compute_hash()
        self._frozen = True

    @property
    def is_frozen(self) -> bool:
        return self._frozen

    def verify_run(self, run: dict) -> bool:
        run_env = run.get("env_id") or run.get("env", "")
        run_method = run.get("method", "")
        run_seed = run.get("seed", run.get("training_seed"))
        if self.envs and run_env not in self.envs:
            return False
        if self.methods and run_method not in self.methods:
            return False
        if run_seed is not None and self.seeds and int(run_seed) not in self.seeds:
            return False
        return True


FROZEN_PROTOCOL = ExperimentProtocol(
    envs=["simple_spread_v3", "simple_reference_v3", "simple_push_v3"],
    methods=[
        "base", "human_pb", "random_valid_single", "random_valid_best_of_k",
        "llm_schema_only", "autocore_single", "autocore_select", "autocore_consensus",
    ],
    seeds=[789, 1024, 2026, 3407, 777],
    training_steps=100000,
    eval_interval=10000,
    eval_episodes=10,
    candidate_budget=12,
    probe_budget=10000,
    lambda_grid=[0.0, 0.05, 0.10, 0.20, 0.30],
    lambda_mode="per_env",
    selector_weights={},
    code_version="3.0",
    prompt_version="v3",
    dsl_schema_version="3.0",
    env_spec_version="3.0",
    alg_config={
        "lr": 3e-4, "gamma": 0.99, "gae_lambda": 0.95, "clip_epsilon": 0.2,
        "entropy_coef": 0.01, "value_coef": 0.5, "max_grad_norm": 0.5,
        "hidden_dim": 512, "batch_size": 256, "update_epochs": 8, "device": "cuda",
    },
    shp_config={
        "gamma": 0.99, "shaping_lambda": 0.1, "potential_clip": [-1.0, 1.0],
    },
)
