from __future__ import annotations

from typing import Any, Dict, List

import numpy as np


def evaluate_agent(
    env: Any,
    trainer: Any,
    num_episodes: int = 10,
    seed: int = 42,
) -> Dict[str, float]:
    episode_returns: List[float] = []
    episode_lengths: List[int] = []

    for ep in range(num_episodes):
        result = env.reset(seed=seed + ep * 1000)
        if isinstance(result, tuple):
            obs, _ = result
        else:
            obs = result

        ep_return = 0.0
        ep_length = 0

        for _step in range(1000):
            actions: Dict[str, Any] = {}
            for agent in env.agents:
                obs_a = obs.get(agent)
                if obs_a is None:
                    continue
                act, _, _ = trainer.get_action(obs_a, deterministic=True)
                actions[agent] = act[0] if act.ndim > 1 else act

            step_result = env.step(actions)
            obs, rewards, terminations, truncations = (
                step_result[0],
                step_result[1],
                step_result[2],
                step_result[3],
            )
            ep_return += sum(rewards.values())
            ep_length += 1

            if all(terminations.values()) or all(truncations.values()):
                break

        episode_returns.append(ep_return)
        episode_lengths.append(ep_length)

    returns_arr = np.array(episode_returns, dtype=np.float64)
    lengths_arr = np.array(episode_lengths, dtype=np.float64)

    return {
        "mean_return": float(np.mean(returns_arr)),
        "std_return": float(np.std(returns_arr)),
        "mean_length": float(np.mean(lengths_arr)),
        "std_length": float(np.std(lengths_arr)),
        "num_episodes": num_episodes,
    }
