from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


class AutoImproveLoop:
    def __init__(self, project_root: str) -> None:
        self.project_root = Path(project_root)

    def run(self) -> Dict[str, Any]:
        report: Dict[str, Any] = {
            "actions_taken": [],
            "improvements_made": [],
            "failed_jobs_analyzed": 0,
        }

        val_dir = self.project_root / "artifacts" / "validation_reports"
        if val_dir.exists():
            for f in val_dir.glob("*.json"):
                with open(f, "r", encoding="utf-8") as fp:
                    json.load(fp)
                    report["failed_jobs_analyzed"] += 1

        raw_dir = self.project_root / "artifacts" / "raw_runs"
        if raw_dir.exists():
            for f in raw_dir.glob("*.json"):
                with open(f, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                    if data.get("status") == "failed":
                        report["actions_taken"].append(
                            f"Analyzed failure: {data.get('job_name', f.name)}"
                        )

        return report
