from __future__ import annotations

from typing import Optional, Tuple

import numpy as np


def bootstrap_confidence_interval(
    data: np.ndarray,
    n_bootstrap: int = 10000,
    alpha: float = 0.05,
) -> Tuple[float, float]:
    if len(data) < 2:
        return float(np.nan), float(np.nan)

    rng = np.random.RandomState()
    means: list = []
    for _ in range(n_bootstrap):
        sample = rng.choice(data, size=len(data), replace=True)
        means.append(np.mean(sample))

    lower = np.percentile(means, 100 * alpha / 2)
    upper = np.percentile(means, 100 * (1 - alpha / 2))
    return float(lower), float(upper)


def compute_effect_size(
    group_a: np.ndarray,
    group_b: np.ndarray,
) -> float:
    if len(group_a) < 2 or len(group_b) < 2:
        return 0.0

    diff = np.mean(group_a) - np.mean(group_b)
    pooled_std = np.sqrt((np.var(group_a) + np.var(group_b)) / 2)

    if pooled_std < 1e-10:
        return 0.0

    return float(diff / pooled_std)
