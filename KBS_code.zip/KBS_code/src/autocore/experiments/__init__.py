from autocore.experiments.train import train_agent, TrainingLogger
from autocore.experiments.evaluate import evaluate_agent
from autocore.experiments.run_matrix import ExperimentRunner, ExperimentConfig
from autocore.experiments.aggregate import aggregate_results, compute_statistics
from autocore.experiments.stats import bootstrap_confidence_interval, compute_effect_size
from autocore.experiments.auto_improve import AutoImproveLoop

__all__ = [
    "train_agent",
    "TrainingLogger",
    "evaluate_agent",
    "ExperimentRunner",
    "ExperimentConfig",
    "aggregate_results",
    "compute_statistics",
    "bootstrap_confidence_interval",
    "compute_effect_size",
    "AutoImproveLoop",
]
