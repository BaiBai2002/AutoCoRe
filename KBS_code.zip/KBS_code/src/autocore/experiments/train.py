from __future__ import annotations

import json
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import numpy as np
import torch

if TYPE_CHECKING:
    from autocore.algos.ippo import IPPOTrainer


class TrainingLogger:
    def __init__(self) -> None:
        self.metrics: List[Dict[str, Any]] = []

    def log(self, step: int, **kwargs: Any) -> None:
        entry: Dict[str, Any] = {"step": step, "wall_time": time.time()}
        entry.update(kwargs)
        self.metrics.append(entry)

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.metrics, f, indent=2, default=str)

    def get_dataframe(self) -> Any:
        import pandas as pd
        return pd.DataFrame(self.metrics)


def evaluate_agent(
    env: Any,
    trainer: IPPOTrainer,
    num_episodes: int = 10,
    seed: int = 42,
    max_steps_per_episode: int = 200,
) -> float:
    total_returns: List[float] = []

    for ep in range(num_episodes):
        result = env.reset(seed=seed + ep)
        if isinstance(result, tuple):
            obs, _ = result
        else:
            obs = result

        episode_return = 0.0
        step_count = 0

        while step_count < max_steps_per_episode:
            step_count += 1
            actions: Dict[str, Any] = {}
            for agent in env.agents:
                obs_a = obs.get(agent)
                if obs_a is None:
                    obs_a = np.zeros(env.observation_space(agent).shape)
                act_raw, _, _ = trainer.get_action(obs_a, deterministic=True)
                if trainer.discrete_action:
                    act = int(act_raw.item()) if hasattr(act_raw, 'item') else int(act_raw)
                else:
                    if act_raw.ndim > 0:
                        act = np.squeeze(act_raw)
                    else:
                        act = act_raw
                    act = np.clip(np.tanh(act), -0.99, 0.99)
                    act = (act + 1.0) / 2.0
                    act = act.astype(np.float32)
                actions[agent] = act

            step_result = env.step(actions)
            obs, rewards, terms, truncs = step_result[0], step_result[1], step_result[2], step_result[3]
            episode_return += sum(rewards.values())

            all_done = all(terms.values()) or all(truncs.values()) if (terms or truncs) else False
            if all_done:
                break

        total_returns.append(episode_return)

    return float(np.mean(total_returns))


def train_agent(
    env: Any,
    trainer: IPPOTrainer,
    num_steps: int,
    eval_interval: int = 5000,
    eval_episodes: int = 10,
    logger: Optional[TrainingLogger] = None,
    seed: int = 42,
    final_eval_seeds: Optional[List[int]] = None,
) -> TrainingLogger:
    if logger is None:
        logger = TrainingLogger()

    from autocore.algos.buffers import RolloutBuffer

    total_steps = 0
    episode_count = 0
    next_eval_step = eval_interval
    eval_tick = 0

    buffer = RolloutBuffer(num_agents=len(env.possible_agents))
    first_agent = env.possible_agents[0]
    obs_shape = env.observation_space(first_agent).shape

    while total_steps < num_steps:
        result = env.reset(seed=seed + episode_count)
        if isinstance(result, tuple):
            obs, _ = result
        else:
            obs = result
        buffer.reset()
        episode_return = 0.0
        episode_steps = 0

        for _ in range(200):
            actions: Dict[str, Any] = {}
            log_probs: Dict[str, float] = {}
            values: Dict[str, float] = {}

            for i, agent in enumerate(env.agents):
                obs_a = obs[agent]
                if obs_a is None:
                    obs_a = np.zeros(obs_shape)
                act_raw, lp, val = trainer.get_action(obs_a, deterministic=False)
                if trainer.discrete_action:
                    act = int(act_raw.item()) if hasattr(act_raw, 'item') else int(act_raw)
                else:
                    if act_raw.ndim > 0:
                        act = np.squeeze(act_raw)
                    else:
                        act = act_raw
                    act = np.clip(np.tanh(act), -0.99, 0.99)
                    act = (act + 1.0) / 2.0
                    act = act.astype(np.float32)
                actions[agent] = act
                try:
                    log_probs[agent] = float(np.squeeze(lp)[()]) if lp is not None else 0.0
                except Exception:
                    log_probs[agent] = 0.0
                try:
                    values[agent] = float(np.squeeze(val)[()]) if val is not None else 0.0
                except Exception:
                    values[agent] = 0.0

            step_result = env.step(actions)
            next_obs, rewards, terms, truncs = step_result[0], step_result[1], step_result[2], step_result[3]

            for i, agent in enumerate(env.agents):
                r = rewards.get(agent, 0.0)
                done = terms.get(agent, False) or truncs.get(agent, False)
                ob = obs.get(agent, next(iter(obs.values())))
                buffer.add(i, ob, actions[agent], log_probs[agent], r, values[agent], float(done))
                episode_return += r

            obs = next_obs
            total_steps += 1
            episode_steps += 1

            if all(truncs.values()) if truncs else (episode_steps >= 100):
                break

        for i, agent in enumerate(env.possible_agents):
            if len(buffer.obs[i]) > 0:
                last_obs = obs.get(agent, next(iter(obs.values())))
                if last_obs is None:
                    last_obs = np.zeros(obs_shape)
                last_val = trainer.policy.get_value(
                    torch.as_tensor(last_obs, dtype=torch.float32, device=trainer.device)
                ).item()
                buffer.compute_gae(i, last_val, trainer.config.gamma, trainer.config.gae_lambda)

        losses = trainer.update(buffer, len(env.possible_agents))
        logger.log(total_steps, episode_return=episode_return, **losses)

        if total_steps >= next_eval_step:
            eval_seed = seed * 100 + eval_tick * 7
            eval_tick += 1
            eval_return = evaluate_agent(env, trainer, eval_episodes, eval_seed)
            logger.log(total_steps, eval_return=eval_return)
            next_eval_step += eval_interval

        episode_count += 1

    if total_steps > 0:
        last_log_at_total = any(
            m['step'] == total_steps and 'eval_return' in m
            for m in logger.metrics
        )
        if not last_log_at_total:
            eval_seeds = final_eval_seeds or [seed * 100 + 777]
            eval_returns = []
            for es in eval_seeds:
                eval_returns.append(evaluate_agent(env, trainer, eval_episodes, es))
            logger.log(total_steps, eval_return=float(np.mean(eval_returns)))

    return logger
