from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd


def aggregate_results(raw_dir: str) -> pd.DataFrame:
    raw_path = Path(raw_dir)
    results: List[Dict[str, Any]] = []

    for f in raw_path.glob("*.json"):
        with open(f, "r", encoding="utf-8") as fp:
            data = json.load(fp)
            results.append(data)

    if not results:
        return pd.DataFrame()

    df = pd.DataFrame(results)
    return df


def compute_statistics(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    group_cols = ["env_id", "method", "provider"]

    if not all(col in df.columns for col in group_cols):
        missing = [col for col in group_cols if col not in df.columns]
        raise KeyError(f"Required columns missing from DataFrame: {missing}")

    agg = (
        df.groupby(group_cols)
        .agg(
            final_return_mean=("final_return", "mean"),
            final_return_std=("final_return", "std"),
            final_return_count=("final_return", "count"),
            wall_time_mean=("wall_time", "mean"),
            status_completed=("status", lambda x: (x == "completed").sum()),
        )
        .reset_index()
    )

    agg["stderr"] = agg["final_return_std"] / np.sqrt(
        agg["final_return_count"].replace(0, 1)
    )

    return agg
