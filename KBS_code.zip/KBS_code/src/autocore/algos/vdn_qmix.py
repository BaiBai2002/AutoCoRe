"""Value-decomposition learners (VDN and QMIX) for cooperative MARL.

The paper's deployment audit is run under IPPO and a centralised-critic MAPPO
variant; both are policy-gradient methods. This module adds the third learner
family the manuscript's limitations section flags as untested: a *value
decomposition* learner, in which per-agent action-values are mixed into a team
action-value by a monotonic function. It is the natural third family because the
audit's remaining question — whether the search budget is repaid — has so far only
been asked of on-policy methods.

Two mixers are provided:

* ``vdn``  — the team value is the sum of the agent values (Sunehag et al., 2017);
* ``qmix`` — a hypernetwork produces non-negative mixing weights conditioned on a
  global state, giving a monotonic but *non-linear* mixture (Rashid et al., 2018).

Design notes specific to this audit:

* Actions are discrete, so the learner is restricted to the environments whose
  action spaces are discrete (MPE ``simple_spread_v3`` qualifies).
* The *team* reward is the sum over agents of the per-agent reward, matching the
  evaluator's own definition of the return (``raw_total += sum(rew.values())``) and
  the paper's convention ``R(s,a) = sum_i r_i``. With a shared task reward and the
  per-agent shaping term this makes the effective team-level shaping coefficient
  ``N*lambda``, exactly as in the policy-gradient audits.
* The mixer is conditioned on the **joint observation** rather than a privileged
  world state. That keeps the learner environment-agnostic and is the standard
  fallback when a global state is unavailable; it is noted in the paper so the
  reader can weigh it.
* Exploration is epsilon-greedy with a linear anneal, and the target network is
  hard-synced, both standard for this family.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class QMixConfig:
    lr: float = 5e-4
    hidden_dim: int = 128
    num_layers: int = 2
    gamma: float = 0.99
    mixer: str = "qmix"                 # "qmix" | "vdn"
    hypernet_dim: int = 64
    embed_dim: int = 64
    buffer_size: int = 300_000
    batch_size: int = 256
    warmup_collects: int = 3
    updates_per_collect: int = 128
    target_update_interval: int = 200   # in gradient steps
    epsilon_start: float = 1.0
    epsilon_finish: float = 0.05
    epsilon_anneal_frac: float = 0.6    # of total collects
    grad_clip: float = 10.0
    double_q: bool = True
    device: str = "cuda"
    replay_seed: int = 0


def _mlp(in_dim: int, out_dim: int, hidden: int, layers: int) -> nn.Sequential:
    mods: list[nn.Module] = []
    d = in_dim
    for _ in range(max(1, layers)):
        mods += [nn.Linear(d, hidden), nn.ReLU()]
        d = hidden
    mods.append(nn.Linear(d, out_dim))
    return nn.Sequential(*mods)


class AgentQNet(nn.Module):
    """Per-agent action-value head over a local observation."""

    def __init__(self, obs_dim: int, act_dim: int, hidden: int, layers: int) -> None:
        super().__init__()
        self.net = _mlp(obs_dim, act_dim, hidden, layers)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.net(obs)


class QMixer(nn.Module):
    """Monotonic mixing of agent values into a team value.

    ``vdn`` returns the sum. ``qmix`` builds the mixture with weights produced by a
    hypernetwork and passed through ``abs``, which is what guarantees
    ``d Q_tot / d Q_i >= 0`` -- the monotonicity that makes a decentralised greedy
    action selection consistent with the centralised one.
    """

    def __init__(self, num_agents: int, state_dim: int, config: QMixConfig) -> None:
        super().__init__()
        self.num_agents = int(num_agents)
        self.mode = config.mixer
        if self.mode == "vdn":
            return
        h = config.hypernet_dim
        e = config.embed_dim
        self.hyper_w1 = nn.Sequential(nn.Linear(state_dim, h), nn.ReLU(),
                                      nn.Linear(h, self.num_agents * e))
        self.hyper_b1 = nn.Linear(state_dim, e)
        self.hyper_w2 = nn.Sequential(nn.Linear(state_dim, h), nn.ReLU(),
                                      nn.Linear(h, e))
        self.hyper_b2 = nn.Sequential(nn.Linear(state_dim, h), nn.ReLU(),
                                      nn.Linear(h, 1))

    def forward(self, agent_qs: torch.Tensor, state: torch.Tensor) -> torch.Tensor:
        if self.mode == "vdn":
            return agent_qs.sum(dim=1, keepdim=True)
        b = agent_qs.shape[0]
        e = self.hyper_b1.out_features
        q = agent_qs.view(b, 1, self.num_agents)
        w1 = torch.abs(self.hyper_w1(state)).view(b, self.num_agents, e)
        b1 = self.hyper_b1(state).view(b, 1, e)
        hidden = F.elu(torch.bmm(q, w1) + b1)
        w2 = torch.abs(self.hyper_w2(state)).view(b, e, 1)
        b2 = self.hyper_b2(state).view(b, 1, 1)
        return (torch.bmm(hidden, w2) + b2).view(b, 1)


class ReplayBuffer:
    """Fixed-capacity ring buffer of team transitions."""

    def __init__(self, capacity: int, num_agents: int, obs_dim: int,
                 state_dim: int, seed: int = 0) -> None:
        self.capacity = int(capacity)
        self.n = int(num_agents)
        self.o = int(obs_dim)
        self.s = int(state_dim)
        self.obs = np.zeros((self.capacity, self.n, self.o), dtype=np.float32)
        self.next_obs = np.zeros((self.capacity, self.n, self.o), dtype=np.float32)
        self.state = np.zeros((self.capacity, self.s), dtype=np.float32)
        self.next_state = np.zeros((self.capacity, self.s), dtype=np.float32)
        self.actions = np.zeros((self.capacity, self.n), dtype=np.int64)
        self.rewards = np.zeros(self.capacity, dtype=np.float32)
        self.dones = np.zeros(self.capacity, dtype=np.float32)
        self.idx = 0
        self.size = 0
        self.rng = np.random.default_rng(seed)

    def push(self, obs: np.ndarray, state: np.ndarray, actions: np.ndarray,
             reward: float, next_obs: np.ndarray, next_state: np.ndarray,
             done: float) -> None:
        i = self.idx
        self.obs[i] = obs
        self.state[i] = state
        self.actions[i] = actions
        self.rewards[i] = reward
        self.next_obs[i] = next_obs
        self.next_state[i] = next_state
        self.dones[i] = done
        self.idx = (i + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int) -> dict[str, np.ndarray]:
        idx = self.rng.integers(0, self.size, size=batch_size)
        return {"obs": self.obs[idx], "state": self.state[idx],
                "actions": self.actions[idx], "rewards": self.rewards[idx],
                "next_obs": self.next_obs[idx], "next_state": self.next_state[idx],
                "dones": self.dones[idx]}


def joint_state(obs: np.ndarray) -> np.ndarray:
    """Mixer conditioning vector: the joint observation, flattened.

    Used instead of a privileged world state so that the learner does not depend on
    environment internals; the choice is stated in the paper.
    """
    return np.asarray(obs, dtype=np.float32).reshape(obs.shape[0], -1)


class QMixAgent:
    """Epsilon-greedy value-decomposition learner over discrete actions."""

    def __init__(self, num_agents: int, obs_dim: int, act_dim: int, state_dim: int,
                 config: QMixConfig) -> None:
        self.config = config
        self.device = torch.device(config.device if torch.cuda.is_available() else "cpu")
        self.num_agents = int(num_agents)
        self.obs_dim = int(obs_dim)
        self.act_dim = int(act_dim)
        self.state_dim = int(state_dim)
        self.online = AgentQNet(self.obs_dim, self.act_dim, config.hidden_dim,
                                config.num_layers).to(self.device)
        self.target = AgentQNet(self.obs_dim, self.act_dim, config.hidden_dim,
                                config.num_layers).to(self.device)
        self.mixer = QMixer(self.num_agents, self.state_dim, config).to(self.device)
        self.target_mixer = QMixer(self.num_agents, self.state_dim, config).to(self.device)
        self.target.load_state_dict(self.online.state_dict())
        self.target_mixer.load_state_dict(self.mixer.state_dict())
        params = list(self.online.parameters()) + list(self.mixer.parameters())
        self.optim = torch.optim.Adam(params, lr=config.lr)
        self.grad_steps = 0
        self.rng = np.random.default_rng(config.replay_seed + 7)

    # ------------------------------------------------------------------ acting
    def greedy(self, obs: np.ndarray) -> np.ndarray:
        """Argmax action per agent. Accepts (n_envs, N, obs_dim)."""
        with torch.no_grad():
            t = torch.as_tensor(np.asarray(obs, dtype=np.float32), device=self.device)
            q = self.online(t)                       # (n_envs, N, A)
            return torch.argmax(q, dim=-1).cpu().numpy().astype(np.float32)

    def act(self, obs: np.ndarray, epsilon: float = 0.0) -> np.ndarray:
        acts = self.greedy(obs)
        if epsilon > 0.0:
            mask = self.rng.random(size=acts.shape) < epsilon
            if mask.any():
                acts[mask] = self.rng.integers(0, self.act_dim, size=int(mask.sum()))
        return acts

    def epsilon(self, collect_idx: int, total_collects: int) -> float:
        c = self.config
        horizon = max(1, int(c.epsilon_anneal_frac * total_collects))
        frac = min(1.0, collect_idx / horizon)
        return float(c.epsilon_start + frac * (c.epsilon_finish - c.epsilon_start))

    # ------------------------------------------------------------------ learning
    def update(self, buffer: ReplayBuffer) -> dict[str, float]:
        c = self.config
        b = buffer.sample(c.batch_size)
        dev = self.device
        obs = torch.as_tensor(b["obs"], device=dev)
        nobs = torch.as_tensor(b["next_obs"], device=dev)
        state = torch.as_tensor(b["state"], device=dev)
        nstate = torch.as_tensor(b["next_state"], device=dev)
        acts = torch.as_tensor(b["actions"], device=dev)
        rew = torch.as_tensor(b["rewards"], device=dev).view(-1, 1)
        done = torch.as_tensor(b["dones"], device=dev).view(-1, 1)

        q = self.online(obs)                                   # (B,N,A)
        chosen = q.gather(-1, acts.unsqueeze(-1)).squeeze(-1)   # (B,N)
        q_tot = self.mixer(chosen, state)                       # (B,1)

        with torch.no_grad():
            nq = self.target(nobs)
            if c.double_q:
                nq_online = self.online(nobs)
                best = torch.argmax(nq_online, dim=-1, keepdim=True)
                n_chosen = nq.gather(-1, best).squeeze(-1)
            else:
                n_chosen = nq.max(dim=-1).values
            q_next = self.target_mixer(n_chosen, nstate)
            target = rew + c.gamma * (1.0 - done) * q_next

        loss = F.mse_loss(q_tot, target)
        self.optim.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(list(self.online.parameters()) + list(self.mixer.parameters()),
                                 c.grad_clip)
        self.optim.step()
        self.grad_steps += 1
        if self.grad_steps % c.target_update_interval == 0:
            self.target.load_state_dict(self.online.state_dict())
            self.target_mixer.load_state_dict(self.mixer.state_dict())
        return {"td_loss": float(loss.detach()), "mean_q": float(q_tot.mean().detach())}

    # ------------------------------------------------------------------ io
    def state_dict(self) -> dict:
        return {"config": self.config.__dict__, "online": self.online.state_dict(),
                "mixer": self.mixer.state_dict(),
                "num_agents": self.num_agents, "obs_dim": self.obs_dim,
                "act_dim": self.act_dim, "state_dim": self.state_dim}

    def load_state_dict(self, state: dict) -> None:
        self.online.load_state_dict(state["online"])
        self.mixer.load_state_dict(state["mixer"])
        self.target.load_state_dict(self.online.state_dict())
        self.target_mixer.load_state_dict(self.mixer.state_dict())
