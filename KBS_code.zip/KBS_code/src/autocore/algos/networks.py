import torch
import torch.nn as nn
import numpy as np


class MLPActor(nn.Module):
    """Actor network with continuous action output."""

    def __init__(self, obs_dim: int, act_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, act_dim),
        )
        self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, obs):
        mean = self.net(obs)
        std = torch.exp(self.log_std.clamp(-20, 2))
        return mean, std


class MLPCritic(nn.Module):
    """Value function critic."""

    def __init__(self, obs_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, obs):
        return self.net(obs).squeeze(-1)


class SharedActorCritic(nn.Module):
    """Shared-parameter actor-critic for IPPO."""

    def __init__(self, obs_dim: int, act_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
        )
        self.actor_head = nn.Linear(hidden_dim, act_dim)
        self.critic_head = nn.Linear(hidden_dim, 1)
        self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, obs):
        features = self.shared(obs)
        act_mean = self.actor_head(features)
        value = self.critic_head(features).squeeze(-1)
        act_std = torch.exp(self.log_std.clamp(-20, 2))
        return act_mean, act_std, value

    def get_value(self, obs):
        features = self.shared(obs)
        return self.critic_head(features).squeeze(-1)

    def get_action(self, obs, deterministic=False):
        features = self.shared(obs)
        act_mean = self.actor_head(features)
        act_std = torch.exp(self.log_std.clamp(-20, 2))
        if deterministic:
            return act_mean, None, act_mean
        dist = torch.distributions.Normal(act_mean, act_std)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(-1)
        return action, log_prob, act_mean


class SharedActorCriticDiscrete(nn.Module):
    """Shared-parameter actor-critic for discrete actions (speaker agents)."""

    def __init__(self, obs_dim: int, act_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
        )
        self.actor_head = nn.Linear(hidden_dim, act_dim)
        self.critic_head = nn.Linear(hidden_dim, 1)

    def forward(self, obs):
        features = self.shared(obs)
        logits = self.actor_head(features)
        value = self.critic_head(features).squeeze(-1)
        return logits, value

    def get_value(self, obs):
        features = self.shared(obs)
        return self.critic_head(features).squeeze(-1)

    def get_action(self, obs, deterministic=False):
        features = self.shared(obs)
        logits = self.actor_head(features)
        dist = torch.distributions.Categorical(logits=logits)
        if deterministic:
            return torch.argmax(logits, dim=-1), None, logits
        action = dist.sample()
        log_prob = dist.log_prob(action)
        return action, log_prob, logits
