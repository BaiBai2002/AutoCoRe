import torch
import numpy as np
from collections import deque


class RolloutBuffer:
    """Stores rollouts from multiple parallel agents."""

    def __init__(self, num_agents: int, max_size: int = 4096):
        self.num_agents = num_agents
        self.max_size = max_size
        self.reset()

    def reset(self):
        self.obs = [[] for _ in range(self.num_agents)]
        self.actions = [[] for _ in range(self.num_agents)]
        self.log_probs = [[] for _ in range(self.num_agents)]
        self.rewards = [[] for _ in range(self.num_agents)]
        self.values = [[] for _ in range(self.num_agents)]
        self.dones = [[] for _ in range(self.num_agents)]
        self.advantages = [[] for _ in range(self.num_agents)]
        self.returns = [[] for _ in range(self.num_agents)]

    def add(self, agent_idx, obs, action, log_prob, reward, value, done):
        self.obs[agent_idx].append(obs)
        self.actions[agent_idx].append(action)
        self.log_probs[agent_idx].append(log_prob)
        self.rewards[agent_idx].append(reward)
        self.values[agent_idx].append(value)
        self.dones[agent_idx].append(done)

    def compute_gae(self, agent_idx, last_value, gamma, gae_lambda):
        advantages = []
        gae = 0.0
        rewards = self.rewards[agent_idx]
        values = self.values[agent_idx] + [last_value]
        dones = self.dones[agent_idx]
        for t in reversed(range(len(rewards))):
            delta = rewards[t] + gamma * values[t + 1] * (1 - dones[t]) - values[t]
            gae = delta + gamma * gae_lambda * (1 - dones[t]) * gae
            advantages.insert(0, gae)
        self.advantages[agent_idx] = advantages
        self.returns[agent_idx] = [adv + val for adv, val in zip(advantages, values[:-1])]

    def get_training_data(self, agent_idx):
        data = {
            'obs': np.array(self.obs[agent_idx], dtype=np.float32),
            'actions': np.array(self.actions[agent_idx], dtype=np.float32),
            'log_probs': np.array(self.log_probs[agent_idx], dtype=np.float32),
            'advantages': np.array(self.advantages[agent_idx], dtype=np.float32),
            'returns': np.array(self.returns[agent_idx], dtype=np.float32),
        }
        return data
