import torch
import torch.nn as nn
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Dict, List
import time

from autocore.algos.buffers import RolloutBuffer
from autocore.algos.networks import SharedActorCritic, SharedActorCriticDiscrete


@dataclass
class IPPOConfig:
    lr: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.2
    entropy_coef: float = 0.01
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    hidden_dim: int = 128
    num_minibatches: int = 4
    update_epochs: int = 4
    batch_size: int = 256
    use_shared_parameters: bool = True
    device: str = "cpu"


class IPPOTrainer:
    """Independent PPO with shared parameters for cooperative MARL."""

    def __init__(
        self,
        obs_dim: int,
        act_dim: int,
        config: IPPOConfig,
        discrete_action: bool = False,
    ):
        self.config = config
        self.device = torch.device(config.device)
        self.discrete_action = discrete_action

        if discrete_action:
            self.policy = SharedActorCriticDiscrete(
                obs_dim, act_dim, config.hidden_dim
            ).to(self.device)
        else:
            self.policy = SharedActorCritic(
                obs_dim, act_dim, config.hidden_dim
            ).to(self.device)

        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=config.lr)
        self.entropy_coef = config.entropy_coef

    def get_action(self, obs, deterministic=False):
        obs_tensor = torch.as_tensor(obs, dtype=torch.float32, device=self.device)
        if obs_tensor.dim() == 1:
            obs_tensor = obs_tensor.unsqueeze(0)

        with torch.no_grad():
            if self.discrete_action:
                action, log_prob, logits = self.policy.get_action(
                    obs_tensor, deterministic
                )
                value = self.policy.get_value(obs_tensor)
                return (
                    action.cpu().numpy(),
                    log_prob.cpu().numpy() if log_prob is not None else None,
                    value.cpu().numpy(),
                )
            else:
                action, log_prob, mean = self.policy.get_action(
                    obs_tensor, deterministic
                )
                value = self.policy.get_value(obs_tensor)
                return (
                    action.cpu().numpy(),
                    log_prob.cpu().numpy() if log_prob is not None else None,
                    value.cpu().numpy(),
                )

    def update(self, buffer: RolloutBuffer, num_agents: int):
        all_obs = []
        all_actions = []
        all_log_probs = []
        all_advantages = []
        all_returns = []

        for a in range(num_agents):
            data = buffer.get_training_data(a)
            if len(data['obs']) == 0:
                continue
            all_obs.append(data['obs'])
            all_actions.append(data['actions'])
            all_log_probs.append(data['log_probs'])
            all_advantages.append(data['advantages'])
            all_returns.append(data['returns'])

        if len(all_obs) == 0:
            return {'policy_loss': 0.0, 'value_loss': 0.0, 'entropy': 0.0}

        all_obs = np.concatenate(all_obs, axis=0)
        all_actions = np.concatenate(all_actions, axis=0)
        all_log_probs = np.concatenate(all_log_probs, axis=0)
        all_advantages = np.concatenate(all_advantages, axis=0)
        all_returns = np.concatenate(all_returns, axis=0)

        all_advantages = (all_advantages - all_advantages.mean()) / (
            all_advantages.std() + 1e-8
        )

        total_samples = len(all_obs)
        batch_size = min(self.config.batch_size, total_samples)

        losses = []
        for epoch in range(self.config.update_epochs):
            indices = np.random.permutation(total_samples)
            for start in range(0, total_samples, batch_size):
                batch_idx = indices[start : start + batch_size]

                obs_b = torch.as_tensor(
                    all_obs[batch_idx], dtype=torch.float32, device=self.device
                )
                act_b = torch.as_tensor(
                    all_actions[batch_idx], dtype=torch.float32, device=self.device
                )
                logp_b = torch.as_tensor(
                    all_log_probs[batch_idx], dtype=torch.float32, device=self.device
                )
                adv_b = torch.as_tensor(
                    all_advantages[batch_idx], dtype=torch.float32, device=self.device
                )
                ret_b = torch.as_tensor(
                    all_returns[batch_idx], dtype=torch.float32, device=self.device
                )

                if self.discrete_action:
                    logits, values = self.policy(obs_b)
                    act_b = act_b.long()
                    dist = torch.distributions.Categorical(logits=logits)
                    new_log_probs = dist.log_prob(act_b)
                    entropy = dist.entropy().mean()
                else:
                    act_mean, act_std, values = self.policy(obs_b)
                    dist = torch.distributions.Normal(act_mean, act_std)
                    new_log_probs = dist.log_prob(act_b).sum(-1)
                    entropy = dist.entropy().sum(-1).mean()

                ratio = torch.exp(new_log_probs - logp_b)
                surr1 = ratio * adv_b
                surr2 = (
                    torch.clamp(
                        ratio,
                        1.0 - self.config.clip_epsilon,
                        1.0 + self.config.clip_epsilon,
                    )
                    * adv_b
                )
                policy_loss = -torch.min(surr1, surr2).mean()

                value_loss = nn.MSELoss()(values, ret_b)

                loss = (
                    policy_loss
                    + self.config.value_coef * value_loss
                    - self.config.entropy_coef * entropy
                )

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(
                    self.policy.parameters(), self.config.max_grad_norm
                )
                self.optimizer.step()

                losses.append(
                    {
                        'policy_loss': policy_loss.item(),
                        'value_loss': value_loss.item(),
                        'entropy': entropy.item(),
                        'total_loss': loss.item(),
                    }
                )

        avg_losses = {k: np.mean([l[k] for l in losses]) for k in losses[0]}
        return avg_losses

    def save(self, path: str):
        torch.save(
            {
                'policy_state_dict': self.policy.state_dict(),
                'optimizer_state_dict': self.optimizer.state_dict(),
                'config': self.config,
            },
            path,
        )

    def load(self, path: str):
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)
        self.policy.load_state_dict(checkpoint['policy_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
