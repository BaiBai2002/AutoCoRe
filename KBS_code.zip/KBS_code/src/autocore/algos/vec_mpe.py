"""Vectorized MPE environment layer with per-role agent grouping.

The existing training path forwarded one observation at a time through the
policy, which made throughput unusable and coupled each update to a single
episode. This module runs several ``parallel_env`` instances together and
exposes the whole batch as arrays, so the policy is evaluated once per
timestep for every environment and every agent.

Observations are zero-padded to a common width so heterogeneous agents
(Simple Push, Simple Speaker Listener) share one storage layout; each role
slices back to its own width before entering its network. Rewards are never
rescaled or clipped by this layer.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np
from gymnasium import spaces

from autocore.envs.pettingzoo_mpe import make_mpe_env

StateDict = dict[str, Any]


@dataclass
class RoleSpec:
    name: str
    agent_names: list[str]
    obs_dim: int
    act_dim: int
    discrete: bool


@dataclass
class StepOutcome:
    obs: np.ndarray
    next_obs: np.ndarray
    rewards: np.ndarray
    terminated: np.ndarray
    truncated: np.ndarray
    dones: np.ndarray
    reset_envs: list[int] = field(default_factory=list)


def state_from_world(world: Any) -> StateDict:
    return {
        "agent_positions": [np.asarray(a.state.p_pos, dtype=np.float64).tolist() for a in world.agents],
        "landmark_positions": [np.asarray(l.state.p_pos, dtype=np.float64).tolist() for l in world.landmarks],
        "agent_velocities": [np.asarray(a.state.p_vel, dtype=np.float64).tolist() for a in world.agents],
    }


class VecMPE:
    """``num_envs`` independent MPE parallel environments stepped in lockstep."""

    def __init__(
        self,
        env_id: str,
        num_envs: int = 8,
        max_cycles: int = 80,
        base_seed: int = 0,
        potential_fn: Optional[Callable[[StateDict], float]] = None,
        shaping_lambda: float = 0.0,
        gamma: float = 0.99,
        reward_scale: float = 1.0,
        num_agents: Optional[int] = None,
    ) -> None:
        self.env_id = env_id
        self.num_envs = int(num_envs)
        self.max_cycles = int(max_cycles)
        self.base_seed = int(base_seed)
        self.potential_fn = potential_fn
        self.shaping_lambda = float(shaping_lambda)
        self.gamma = float(gamma)
        self.reward_scale = float(reward_scale)

        self.envs = [make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)
                     for _ in range(self.num_envs)]
        probe = self.envs[0]
        self.agent_names: list[str] = list(probe.possible_agents)
        self.num_agents = len(self.agent_names)
        self._agent_index = {a: i for i, a in enumerate(self.agent_names)}
        self._episode_count = [0] * self.num_envs
        self._prev_phi: list[Optional[float]] = [None] * self.num_envs

        self.obs_dims: list[int] = []
        self.roles: dict[str, RoleSpec] = {}
        self.agent_role: dict[str, str] = {}
        grouped: dict[tuple[int, int, bool], list[str]] = {}
        for a in self.agent_names:
            odim = int(np.prod(probe.observation_space(a).shape))
            asp = probe.action_space(a)
            discrete = isinstance(asp, spaces.Discrete)
            adim = int(asp.n) if discrete else int(np.prod(asp.shape))
            self.obs_dims.append(odim)
            grouped.setdefault((odim, adim, discrete), []).append(a)
        for k, key in enumerate(sorted(grouped)):
            odim, adim, discrete = key
            names = grouped[key]
            role = RoleSpec(name=f"role{k}", agent_names=names, obs_dim=odim,
                            act_dim=adim, discrete=discrete)
            self.roles[role.name] = role
            for a in names:
                self.agent_role[a] = role.name

        self.obs_dim = max(self.obs_dims)
        self.act_dim = max(r.act_dim for r in self.roles.values())

    @property
    def agent_index(self) -> dict[str, int]:
        return self._agent_index

    # ------------------------------------------------------------------ state
    def _world(self, i: int) -> Any:
        return self.envs[i].aec_env.world

    def states(self) -> list[StateDict]:
        return [state_from_world(self._world(i)) for i in range(self.num_envs)]

    def phi(self, i: int) -> float:
        if self.potential_fn is None:
            return 0.0
        return float(self.potential_fn(state_from_world(self._world(i))))

    def _pack_obs(self, raw: dict[str, Any]) -> np.ndarray:
        row = np.zeros((self.num_agents, self.obs_dim), dtype=np.float32)
        for a in self.agent_names:
            if a in raw and raw[a] is not None:
                v = np.asarray(raw[a], dtype=np.float32).reshape(-1)
                row[self._agent_index[a], : v.shape[0]] = v
        return row

    # ------------------------------------------------------------------ reset
    def reset(self, seeds: Optional[list[int]] = None) -> np.ndarray:
        if seeds is None:
            seeds = [self.base_seed + i for i in range(self.num_envs)]
        obs_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        for i, env in enumerate(self.envs):
            self._episode_count[i] = 0
            res = env.reset(seed=int(seeds[i]))
            raw = res[0] if isinstance(res, tuple) else res
            obs_batch[i] = self._pack_obs(raw)
            self._prev_phi[i] = 0.0 if self.potential_fn is None else self.phi(i)
        return obs_batch

    def _reset_one(self, i: int) -> np.ndarray:
        self._episode_count[i] += 1
        seed = self.base_seed + i + self._episode_count[i] * 100003
        res = self.envs[i].reset(seed=seed)
        raw = res[0] if isinstance(res, tuple) else res
        self._prev_phi[i] = 0.0 if self.potential_fn is None else self.phi(i)
        return self._pack_obs(raw)

    # ------------------------------------------------------------------ step
    def step(self, actions: np.ndarray) -> StepOutcome:
        obs_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        next_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        rewards = np.zeros((self.num_envs, self.num_agents), dtype=np.float32)
        terminated = np.zeros(self.num_envs, dtype=np.float32)
        truncated = np.zeros(self.num_envs, dtype=np.float32)
        dones = np.zeros(self.num_envs, dtype=np.float32)
        reset_envs: list[int] = []

        for i, env in enumerate(self.envs):
            act_dict: dict[str, Any] = {}
            for a in env.agents:
                j = self._agent_index[a]
                role = self.roles[self.agent_role[a]]
                raw = actions[i, j]
                if role.discrete:
                    act_dict[a] = int(np.clip(int(round(float(raw))), 0, role.act_dim - 1))
                else:
                    act_dict[a] = np.asarray(raw, dtype=np.float32)
            res = env.step(act_dict)
            next_obs, rew, term, trunc = res[0], res[1], res[2], res[3]

            term_all = bool(np.all(list(term.values()))) if term else False
            trunc_all = bool(np.all(list(trunc.values()))) if trunc else False

            if self.potential_fn is not None:
                curr_phi = self.phi(i)
                prev_phi = self._prev_phi[i] if self._prev_phi[i] is not None else 0.0
                if term_all:
                    shaping = self.shaping_lambda * (0.0 - prev_phi)
                    self._prev_phi[i] = 0.0
                else:
                    shaping = self.shaping_lambda * (self.gamma * curr_phi - prev_phi)
                    self._prev_phi[i] = curr_phi
            else:
                shaping = 0.0

            for a in self.agent_names:
                if a in rew:
                    rewards[i, self._agent_index[a]] = self.reward_scale * float(rew[a]) + shaping

            terminated[i] = 1.0 if term_all else 0.0
            truncated[i] = 1.0 if (trunc_all and not term_all) else 0.0
            done = term_all or trunc_all
            dones[i] = 1.0 if done else 0.0

            next_batch[i] = self._pack_obs(next_obs)
            if done:
                obs_batch[i] = self._reset_one(i)
                reset_envs.append(i)
            else:
                obs_batch[i] = next_batch[i]

        return StepOutcome(obs=obs_batch, next_obs=next_batch, rewards=rewards,
                           terminated=terminated, truncated=truncated, dones=dones,
                           reset_envs=reset_envs)

    def close(self) -> None:
        for env in self.envs:
            try:
                env.close()
            except Exception:
                pass


class MpeEvaluator:
    """Deterministic, single-environment evaluation of a role-aware policy."""

    def __init__(self, env_id: str, max_cycles: int = 80,
                 potential_fn: Optional[Callable[[StateDict], float]] = None,
                 shaping_lambda: float = 0.0, gamma: float = 0.99,
                 reward_scale: float = 1.0, num_agents: Optional[int] = None) -> None:
        self.env = make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)
        self.agent_names = list(self.env.possible_agents)
        self.agent_index = {a: i for i, a in enumerate(self.agent_names)}
        self.obs_dims = [int(np.prod(self.env.observation_space(a).shape)) for a in self.agent_names]
        self.act_dims = [int(self.env.action_space(a).n) for a in self.agent_names]
        self.obs_dim = max(self.obs_dims)
        self.max_cycles = max_cycles
        self.potential_fn = potential_fn
        self.shaping_lambda = shaping_lambda
        self.gamma = gamma
        self.reward_scale = float(reward_scale)

    def _pack(self, raw: dict[str, Any]) -> np.ndarray:
        ob = np.zeros((1, len(self.agent_names), self.obs_dim), dtype=np.float32)
        for a in self.agent_names:
            if a in raw and raw[a] is not None:
                v = np.asarray(raw[a], dtype=np.float32).reshape(-1)
                ob[0, self.agent_index[a], : v.shape[0]] = v
        return ob

    def run(self, act_fn: Callable[[np.ndarray], np.ndarray], seeds: list[int]) -> dict[str, float]:
        """Evaluate a policy and report raw and shaped returns separately.

        The shaping term is an additive, policy-invariant offset at the level of
        expected returns; adding it to the *reported* score makes any coefficient
        comparable by construction and therefore hides whether the policy itself
        improved. The primary quantity is therefore the raw task return.
        """
        raw_returns: list[float] = []
        shaped_returns: list[float] = []
        lengths: list[int] = []
        for s in seeds:
            res = self.env.reset(seed=int(s))
            raw = res[0] if isinstance(res, tuple) else res
            ob = self._pack(raw)
            prev_phi = 0.0 if self.potential_fn is None else float(self.potential_fn(state_from_world(self.env.aec_env.world)))
            raw_total, shape_total, steps = 0.0, 0.0, 0
            while steps < self.max_cycles:
                acts = act_fn(ob)
                act_dict = {}
                for a in self.env.agents:
                    i = self.agent_index[a]
                    act_dict[a] = int(np.clip(int(round(float(acts[0, i]))), 0, self.act_dims[i] - 1))
                res = self.env.step(act_dict)
                next_obs, rew, term, trunc = res[0], res[1], res[2], res[3]
                term_all = bool(np.all(list(term.values()))) if term else False
                if self.potential_fn is not None:
                    curr_phi = float(self.potential_fn(state_from_world(self.env.aec_env.world)))
                    shape_total += self.shaping_lambda * (
                        (0.0 - prev_phi) if term_all else (self.gamma * curr_phi - prev_phi))
                raw_total += self.reward_scale * float(sum(rew.values()))
                steps += 1
                if term_all or (trunc and all(trunc.values())):
                    break
                ob = self._pack(next_obs)
                if self.potential_fn is not None:
                    prev_phi = float(self.potential_fn(state_from_world(self.env.aec_env.world)))
            raw_returns.append(raw_total)
            shaped_returns.append(raw_total + shape_total)
            lengths.append(steps)
        arr = np.asarray(raw_returns, dtype=np.float64)
        arr_shaped = np.asarray(shaped_returns, dtype=np.float64)
        return {"mean_return": float(arr.mean()), "std_return": float(arr.std()),
                "mean_raw_return": float(arr.mean()), "std_raw_return": float(arr.std()),
                "mean_shaped_return": float(arr_shaped.mean()),
                "std_shaped_return": float(arr_shaped.std()),
                "mean_length": float(np.mean(lengths)), "n": len(seeds)}

    def close(self) -> None:
        self.env.close()
