"""Heterogeneous agent policy support.
Detects different agent types and creates per-type networks.
When `max_obs_dim` != agent's actual obs_dim, pads with zeros.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Optional
import numpy as np
import torch
from gymnasium import spaces

from autocore.algos.networks import SharedActorCritic, SharedActorCriticDiscrete
from autocore.algos.ippo import IPPOConfig, IPPOTrainer


@dataclass
class AgentTypeInfo:
    obs_dim: int
    act_dim: int
    act_type: str
    agent_names: list[str]


def detect_agent_types(env: Any) -> dict[str, AgentTypeInfo]:
    """Group agents by (obs_dim, act_dim, act_type) tuples."""
    type_map: dict[tuple, AgentTypeInfo] = {}
    for name in env.possible_agents:
        obs_s = env.observation_space(name)
        act_s = env.action_space(name)
        od = int(np.prod(obs_s.shape))
        at = "discrete" if isinstance(act_s, spaces.Discrete) else "continuous"
        ad = int(act_s.n) if at == "discrete" else int(np.prod(act_s.shape))
        key = (od, ad, at)
        if key not in type_map:
            type_map[key] = AgentTypeInfo(obs_dim=od, act_dim=ad, act_type=at, agent_names=[])
        type_map[key].agent_names.append(name)
    return {k.agent_names[0]: k for k in type_map.values()} if len(type_map) > 1 else {}


class HeterogeneousTrainer:
    """Manages multiple per-type trainers for heterogeneous environments."""
    def __init__(self, env: Any, config: IPPOConfig):
        self.type_map = detect_agent_types(env)
        self.trainers: dict[str, IPPOTrainer] = {}
        self.agent_to_type: dict[str, str] = {}
        max_obs_dim = 0

        if self.type_map:
            for rep_name, tinfo in self.type_map.items():
                tcfg = IPPOConfig(**{k: v for k, v in config.__dict__.items() if k != 'device'})
                tcfg.device = config.device
                discrete = tinfo.act_type == "discrete"
                tcfg.hidden_dim = min(tcfg.hidden_dim, max(tinfo.obs_dim * 8, 64))
                self.trainers[rep_name] = IPPOTrainer(tinfo.obs_dim, tinfo.act_dim, tcfg, discrete)
                for an in tinfo.agent_names:
                    self.agent_to_type[an] = rep_name
                max_obs_dim = max(max_obs_dim, tinfo.obs_dim)
            self.is_heterogeneous = True
            self.max_obs_dim = max_obs_dim
        else:
            a0 = env.possible_agents[0]
            od = int(np.prod(env.observation_space(a0).shape))
            discrete = isinstance(env.action_space(a0), spaces.Discrete)
            ad = int(env.action_space(a0).n) if discrete else int(np.prod(env.action_space(a0).shape))
            tcfg = IPPOConfig(**{k: v for k, v in config.__dict__.items() if k != 'device'})
            tcfg.device = config.device
            self.trainers[a0] = IPPOTrainer(od, ad, tcfg, discrete)
            for an in env.possible_agents:
                self.agent_to_type[an] = a0
            self.is_heterogeneous = False
            self.max_obs_dim = 0

    def get_action(self, obs, agent_name, deterministic=False):
        trainer = self.trainers[self.agent_to_type[agent_name]]
        return trainer.get_action(obs, deterministic)

    def update(self, buffers: dict[str, Any], agents_per_type: dict[str, int]):
        losses = {}
        for rep_name, trainer in self.trainers.items():
            buf = buffers.get(rep_name)
            if buf is None or len(buf.obs[0]) == 0:
                continue
            n = agents_per_type.get(rep_name, 1)
            l = trainer.update(buf, n)
            losses.update({f"{rep_name}_{k}": v for k, v in l.items()})
        return losses or {'policy_loss': 0.0, 'value_loss': 0.0, 'entropy': 0.0}

    @property
    def discrete_action(self):
        return any(t.discrete_action for t in self.trainers.values())

    @property
    def device(self):
        return next(iter(self.trainers.values())).device

    def get_trainer_for(self, agent_name: str) -> IPPOTrainer:
        return self.trainers[self.agent_to_type[agent_name]]
