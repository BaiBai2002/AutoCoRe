"""Batched PPO for cooperative MARL with per-role shared parameters.

Unlike the previous per-agent, per-step implementation, this trainer evaluates
the policy once per environment step for all agents of a role, keeps rollouts
spanning many episodes, and applies generalized advantage estimation with an
explicit distinction between true termination and time-limit truncation.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
import torch.nn as nn

from autocore.algos.vec_mpe import RoleSpec


@dataclass
class MARLPPOConfig:
    lr: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.2
    entropy_coef: float = 0.01
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    hidden_dim: int = 128
    num_layers: int = 2
    update_epochs: int = 4
    num_minibatches: int = 4
    normalize_advantage: bool = True
    target_kl: float | None = None
    device: str = "cuda"
    centralized_critic: bool = False


class RolePolicy(nn.Module):
    """Actor-critic for one role.

    Actor and critic use separate bodies. Sharing a single trunk lets the
    squared-error value objective (targets here are of order 1e2) dominate the
    shared features and corrupt the policy representation.

    When ``global_obs_dim`` is given the critic is conditioned on the
    concatenated observations of all agents instead of the local one, which is
    the centralized-critic variant used by MAPPO. The actor always remains
    local, so the policy stays decentralised at execution time.
    """

    def __init__(self, obs_dim: int, act_dim: int, hidden_dim: int = 128,
                 num_layers: int = 2, discrete: bool = True,
                 global_obs_dim: int | None = None) -> None:
        super().__init__()
        self.discrete = discrete
        self.global_obs_dim = global_obs_dim

        def body(in_dim: int) -> nn.Sequential:
            layers: list[nn.Module] = []
            last = in_dim
            for _ in range(max(1, num_layers)):
                layers += [nn.Linear(last, hidden_dim), nn.Tanh()]
                last = hidden_dim
            return nn.Sequential(*layers)

        self.actor_body = body(obs_dim)
        self.critic_body = body(global_obs_dim if global_obs_dim else obs_dim)
        self.actor_head = nn.Linear(hidden_dim, act_dim)
        self.critic_head = nn.Linear(hidden_dim, 1)
        if not discrete:
            self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, obs: torch.Tensor,
                global_obs: torch.Tensor | None = None
                ) -> tuple[torch.Tensor, torch.Tensor]:
        out = self.actor_head(self.actor_body(obs))
        critic_in = global_obs if self.global_obs_dim else obs
        value = self.critic_head(self.critic_body(critic_in)).squeeze(-1)
        return out, value

    def distribution(self, out: torch.Tensor) -> torch.distributions.Distribution:
        if self.discrete:
            return torch.distributions.Categorical(logits=out)
        std = torch.exp(self.log_std.clamp(-20.0, 2.0))
        return torch.distributions.Normal(out, std)

    def log_prob(self, out: torch.Tensor, actions: torch.Tensor) -> torch.Tensor:
        dist = self.distribution(out)
        if self.discrete:
            return dist.log_prob(actions.long())
        return dist.log_prob(actions).sum(-1)

    def entropy(self, out: torch.Tensor) -> torch.Tensor:
        dist = self.distribution(out)
        ent = dist.entropy()
        return ent if self.discrete else ent.sum(-1)


@dataclass
class Rollout:
    """Storage for one on-policy batch, shaped (T, num_envs, num_agents, ...)."""

    obs: np.ndarray
    actions: np.ndarray
    log_probs: np.ndarray
    rewards: np.ndarray
    values: np.ndarray
    next_values: np.ndarray
    terminated: np.ndarray
    dones: np.ndarray

    @property
    def horizon(self) -> int:
        return int(self.obs.shape[0])


class MARLPPO:
    def __init__(self, roles: dict[str, RoleSpec], agent_index: dict[str, int],
                 num_agents: int, obs_dim: int, config: MARLPPOConfig | None = None) -> None:
        self.config = config or MARLPPOConfig()
        self.device = torch.device(self.config.device if torch.cuda.is_available() else "cpu")
        self.roles = roles
        self.agent_index = agent_index
        self.num_agents = num_agents
        self.obs_dim = obs_dim
        self.global_obs_dim = (num_agents * obs_dim) if self.config.centralized_critic else None

        self.policies: dict[str, RolePolicy] = {}
        self.optimizers: dict[str, torch.optim.Adam] = {}
        for name, role in roles.items():
            policy = RolePolicy(role.obs_dim, role.act_dim, self.config.hidden_dim,
                                self.config.num_layers, role.discrete,
                                global_obs_dim=self.global_obs_dim).to(self.device)
            self.policies[name] = policy
            self.optimizers[name] = torch.optim.Adam(policy.parameters(), lr=self.config.lr)

    def _global_tensor(self, obs_batch: np.ndarray) -> torch.Tensor | None:
        """Concatenated observations of all agents, shared by every critic."""
        if self.global_obs_dim is None:
            return None
        flat = obs_batch.reshape(obs_batch.shape[0], self.global_obs_dim)
        return torch.as_tensor(flat, dtype=torch.float32, device=self.device)

    @staticmethod
    def _expand_global(global_tensor: torch.Tensor | None, k: int) -> torch.Tensor | None:
        """Align the per-environment global state with the per-agent batch order."""
        if global_tensor is None:
            return None
        return global_tensor.repeat_interleave(k, dim=0)

    def parameters(self):
        for p in self.policies.values():
            yield from p.parameters()

    # --------------------------------------------------------------- inference
    def _role_slice(self, role: RoleSpec) -> list[int]:
        return [self.agent_index[a] for a in role.agent_names]

    def act(self, obs_batch: np.ndarray, deterministic: bool = False
            ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        n_envs = obs_batch.shape[0]
        actions = np.zeros((n_envs, self.num_agents), dtype=np.float32)
        log_probs = np.zeros((n_envs, self.num_agents), dtype=np.float32)
        values = np.zeros((n_envs, self.num_agents), dtype=np.float32)

        with torch.no_grad():
            g = self._global_tensor(obs_batch)
            for name, role in self.roles.items():
                idx = self._role_slice(role)
                sub = obs_batch[:, idx, : role.obs_dim]
                flat = torch.as_tensor(sub.reshape(-1, role.obs_dim), dtype=torch.float32,
                                       device=self.device)
                out, value = self.policies[name](flat, self._expand_global(g, len(idx)))
                if deterministic:
                    act = torch.argmax(out, dim=-1) if role.discrete else out
                    lp = torch.zeros_like(act, dtype=torch.float32)
                else:
                    dist = self.policies[name].distribution(out)
                    act = dist.sample()
                    lp = self.policies[name].log_prob(out, act)
                k = len(idx)
                actions[:, idx] = act.reshape(n_envs, k).cpu().numpy()
                log_probs[:, idx] = lp.reshape(n_envs, k).cpu().numpy()
                values[:, idx] = value.reshape(n_envs, k).cpu().numpy()
        return actions, log_probs, values

    def value_of(self, obs_batch: np.ndarray) -> np.ndarray:
        n_envs = obs_batch.shape[0]
        values = np.zeros((n_envs, self.num_agents), dtype=np.float32)
        with torch.no_grad():
            g = self._global_tensor(obs_batch)
            for name, role in self.roles.items():
                idx = self._role_slice(role)
                sub = obs_batch[:, idx, : role.obs_dim]
                flat = torch.as_tensor(sub.reshape(-1, role.obs_dim), dtype=torch.float32,
                                       device=self.device)
                _, value = self.policies[name](flat, self._expand_global(g, len(idx)))
                values[:, idx] = value.reshape(n_envs, len(idx)).cpu().numpy()
        return values

    # ------------------------------------------------------------------ update
    def _compute_gae(self, rollout: Rollout, role: RoleSpec) -> tuple[np.ndarray, np.ndarray]:
        index = self._role_slice(role)
        T = rollout.horizon
        cfg = self.config
        adv = np.zeros((T, rollout.obs.shape[1], len(index)), dtype=np.float32)
        ret = np.zeros_like(adv)
        gae = np.zeros((rollout.obs.shape[1], len(index)), dtype=np.float32)
        for t in reversed(range(T)):
            nonterminal = 1.0 - rollout.terminated[t][:, index]
            carry = 1.0 - rollout.dones[t][:, index]
            delta = (rollout.rewards[t][:, index]
                     + cfg.gamma * rollout.next_values[t][:, index] * nonterminal
                     - rollout.values[t][:, index])
            gae = delta + cfg.gamma * cfg.gae_lambda * carry * gae
            adv[t] = gae
        ret = adv + rollout.values[:, :, index]
        return adv.reshape(-1), ret.reshape(-1)

    def update(self, rollout: Rollout) -> dict[str, float]:
        cfg = self.config
        stats: dict[str, list[float]] = {"policy_loss": [], "value_loss": [], "entropy": [],
                                         "approx_kl": [], "clip_fraction": [], "grad_norm": []}
        for name, role in self.roles.items():
            index = self._role_slice(role)
            policy = self.policies[name]
            opt = self.optimizers[name]

            obs = rollout.obs[:, :, index, : role.obs_dim].reshape(-1, role.obs_dim)
            actions = rollout.actions[:, :, index].reshape(-1)
            old_logp = rollout.log_probs[:, :, index].reshape(-1)
            adv, ret = self._compute_gae(rollout, role)

            global_obs = None
            if self.global_obs_dim is not None:
                T, n_envs = rollout.obs.shape[0], rollout.obs.shape[1]
                gall = rollout.obs.reshape(T, n_envs, self.global_obs_dim)
                global_obs = np.repeat(gall[:, :, None, :], len(index), axis=2).reshape(
                    -1, self.global_obs_dim)

            if cfg.normalize_advantage and adv.size > 1:
                adv = (adv - adv.mean()) / (adv.std() + 1e-8)

            obs_t = torch.as_tensor(obs, dtype=torch.float32, device=self.device)
            act_t = torch.as_tensor(actions, dtype=torch.float32, device=self.device)
            oldlp_t = torch.as_tensor(old_logp, dtype=torch.float32, device=self.device)
            adv_t = torch.as_tensor(adv, dtype=torch.float32, device=self.device)
            ret_t = torch.as_tensor(ret, dtype=torch.float32, device=self.device)
            gobs_t = (torch.as_tensor(global_obs, dtype=torch.float32, device=self.device)
                      if global_obs is not None else None)

            n = obs_t.shape[0]
            batch = max(1, n // max(1, cfg.num_minibatches))
            stop = False
            for _epoch in range(cfg.update_epochs):
                perm = torch.randperm(n, device=self.device)
                for start in range(0, n, batch):
                    mb = perm[start:start + batch]
                    out, value = policy(obs_t[mb],
                                        gobs_t[mb] if gobs_t is not None else None)
                    new_logp = policy.log_prob(out, act_t[mb])
                    entropy = policy.entropy(out).mean()

                    log_ratio = new_logp - oldlp_t[mb]
                    ratio = torch.exp(log_ratio)
                    surr1 = ratio * adv_t[mb]
                    surr2 = torch.clamp(ratio, 1.0 - cfg.clip_epsilon, 1.0 + cfg.clip_epsilon) * adv_t[mb]
                    policy_loss = -torch.min(surr1, surr2).mean()
                    value_loss = nn.functional.mse_loss(value, ret_t[mb])
                    loss = policy_loss + cfg.value_coef * value_loss - cfg.entropy_coef * entropy

                    opt.zero_grad()
                    loss.backward()
                    grad_norm = nn.utils.clip_grad_norm_(policy.parameters(), cfg.max_grad_norm)
                    opt.step()

                    with torch.no_grad():
                        approx_kl = ((ratio - 1.0) - log_ratio).mean()
                        clip_frac = (torch.abs(ratio - 1.0) > cfg.clip_epsilon).float().mean()
                        grad_norm_f = float(grad_norm.detach()) if isinstance(grad_norm, torch.Tensor) else float(grad_norm)
                    stats["policy_loss"].append(float(policy_loss.detach()))
                    stats["value_loss"].append(float(value_loss.detach()))
                    stats["entropy"].append(float(entropy.detach()))
                    stats["approx_kl"].append(float(approx_kl))
                    stats["clip_fraction"].append(float(clip_frac))
                    stats["grad_norm"].append(grad_norm_f)
                if cfg.target_kl is not None and np.mean(stats["approx_kl"][-1:]) > 1.5 * cfg.target_kl:
                    stop = True
                    break
            if stop:
                break
        return {k: float(np.mean(v)) if v else 0.0 for k, v in stats.items()}

    def state_dict(self) -> dict[str, Any]:
        return {name: p.state_dict() for name, p in self.policies.items()}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        for name, sd in state.items():
            self.policies[name].load_state_dict(sd)
