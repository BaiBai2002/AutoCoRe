from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class LambdaSchedule:
    name: str
    values: list[float]
    current_step: int = 0
    total_steps: int = 0
    lambda0: float = 0.1
    lambda_min: float = 0.01

    def get_lambda(self, step: int) -> float:
        if not self.values:
            return 0.0
        if len(self.values) == 1:
            return self.values[0]
        idx = min(step, len(self.values) - 1)
        return self.values[idx]


def fixed_lambda(value: float = 0.1) -> LambdaSchedule:
    return LambdaSchedule(
        name="fixed",
        values=[value],
        lambda0=value,
        lambda_min=value,
    )


def calibrated_lambda(
    selected_lambda_value: float,
    fallback: float = 0.1,
) -> LambdaSchedule:
    return LambdaSchedule(
        name="calibrated",
        values=[selected_lambda_value],
        lambda0=selected_lambda_value,
        lambda_min=fallback,
    )


def selected_lambda(
    candidates: list[tuple[float, float]],
    default: float = 0.1,
) -> LambdaSchedule:
    if not candidates:
        value = default
    else:
        value = max(candidates, key=lambda x: x[1])[0]

    return LambdaSchedule(
        name="selected",
        values=[value],
        lambda0=value,
        lambda_min=default,
    )


def annealed_lambda(
    lambda0: float = 0.5,
    lambda_min: float = 0.01,
    decay_steps: int = 100_000,
    total_steps: int | None = None,
) -> LambdaSchedule:
    effective_total = total_steps if total_steps is not None else decay_steps
    clamped_total = max(decay_steps, effective_total)

    pre_values: list[float] = []
    samples_per_decay = max(1, decay_steps // 100)
    for step in range(0, decay_steps + 1, samples_per_decay):
        progress = min(1.0, step / max(decay_steps, 1))
        lam = lambda_min + 0.5 * (lambda0 - lambda_min) * (1.0 + math.cos(math.pi * progress))
        pre_values.append(lam)

    final_value = pre_values[-1] if pre_values else lambda_min

    values: list[float] = []
    for step in range(clamped_total):
        if step < decay_steps:
            frac = step / samples_per_decay
            low_idx = int(frac)
            high_idx = min(low_idx + 1, len(pre_values) - 1)
            if low_idx == high_idx:
                values.append(pre_values[low_idx])
            else:
                t = frac - low_idx
                values.append(pre_values[low_idx] * (1.0 - t) + pre_values[high_idx] * t)
        else:
            values.append(final_value)

    return LambdaSchedule(
        name="annealed",
        values=values,
        total_steps=clamped_total,
        lambda0=lambda0,
        lambda_min=lambda_min,
    )
