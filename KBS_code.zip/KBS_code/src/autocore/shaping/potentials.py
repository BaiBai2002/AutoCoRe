from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

import numpy as np

if TYPE_CHECKING:
    from autocore.dsl.compiler import CompilerOutput


@dataclass
class ShapingConfig:
    gamma: float = 0.99
    shaping_lambda: float = 0.1
    potential_clip: tuple[float, float] = (-1.0, 1.0)

    def __post_init__(self) -> None:
        if not 0.0 < self.gamma <= 1.0:
            raise ValueError(f"gamma must be in (0, 1], got {self.gamma}")
        if not 0.0 <= self.shaping_lambda:
            raise ValueError(f"shaping_lambda must be non-negative, got {self.shaping_lambda}")
        if self.potential_clip[0] >= self.potential_clip[1]:
            raise ValueError(
                f"potential_clip min must be less than max, got {self.potential_clip}"
            )


DISTANCE_POTENTIAL_TYPES = {"negative_normalized_sum_min_distance", "negative_mean_distance"}


class PotentialFunction:
    def __init__(
        self,
        compiled_output: CompilerOutput,
        config: Optional[ShapingConfig] = None,
    ) -> None:
        self.compiled = compiled_output
        self.config = config or ShapingConfig()
        self._prev_potential: Optional[float] = None

    @staticmethod
    def get_effective_clip(potential_type: str) -> tuple[float, float]:
        if potential_type in DISTANCE_POTENTIAL_TYPES:
            return (-10.0, 10.0)
        return (-1.0, 1.0)

    def compute_potential(self, state: dict[str, Any]) -> float:
        clipped: list[float] = []
        pot_types = self.compiled.meta.get("pot_types", [])

        for i, subgoal_fn in enumerate(self.compiled.subgoal_functions):
            raw = float(subgoal_fn(state))
            pot_type = pot_types[i] if i < len(pot_types) else ""
            clip_min, clip_max = self.get_effective_clip(pot_type)
            clipped.append(max(clip_min, min(clip_max, raw)))

        if not clipped:
            return 0.0

        weights = self.compiled.meta.get("weights", [1.0] * len(clipped))
        total = sum(w * v for w, v in zip(weights, clipped))

        total_clip_min = -10.0
        total_clip_max = 10.0
        effective_clips = [
            self.get_effective_clip(pot_types[i] if i < len(pot_types) else "")
            for i in range(len(clipped))
        ]
        if effective_clips:
            total_clip_min = min(c[0] for c in effective_clips)
            total_clip_max = max(c[1] for c in effective_clips)

        return float(max(total_clip_min, min(total_clip_max, total)))

    def compute_shaping_reward(
        self,
        curr_state: dict[str, Any],
        prev_state: Optional[dict[str, Any]] = None,
    ) -> float:
        curr_pot = self.compute_potential(curr_state)

        if prev_state is None:
            shaping = 0.0
        else:
            prev_pot = self.compute_potential(prev_state)
            shaping = self.config.gamma * curr_pot - prev_pot

        return self.config.shaping_lambda * shaping

    @property
    def prev_potential(self) -> Optional[float]:
        return self._prev_potential

    @prev_potential.setter
    def prev_potential(self, value: Optional[float]) -> None:
        self._prev_potential = value

    def reset(self) -> None:
        self._prev_potential = None


def compute_potential(
    compiled_output: CompilerOutput,
    state: dict[str, Any],
    config: Optional[ShapingConfig] = None,
) -> float:
    fn = PotentialFunction(compiled_output, config)
    return fn.compute_potential(state)
