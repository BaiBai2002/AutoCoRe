from __future__ import annotations

import copy
from typing import Any, Optional

from autocore.shaping.potentials import PotentialFunction, ShapingConfig


class RewardShapingWrapper:
    def __init__(
        self,
        env: Any,
        potential_function: PotentialFunction,
        config: Optional[ShapingConfig] = None,
    ) -> None:
        self.env = env
        self.potential_fn = potential_function
        self.config = config or potential_function.config

        if hasattr(env, "possible_agents"):
            self._agent_names: list[str] = list(env.possible_agents)
        elif hasattr(env, "agents"):
            self._agent_names = list(env.agents)
        else:
            self._agent_names = []

        self._prev_state: Optional[dict[str, Any]] = None

    @property
    def agents(self) -> list[str]:
        if hasattr(self.env, "agents"):
            return self.env.agents
        return self._agent_names

    @property
    def possible_agents(self) -> list[str]:
        if hasattr(self.env, "possible_agents"):
            return self.env.possible_agents
        return self._agent_names

    @property
    def unwrapped(self) -> Any:
        env = self.env
        while isinstance(env, RewardShapingWrapper):
            env = env.env
        return getattr(env, "unwrapped", env)

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict[str, Any]] = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        result = self.env.reset(seed=seed, options=options)
        if isinstance(result, tuple) and len(result) == 2:
            obs, infos = result
        else:
            obs = result
            infos = {}

        self._prev_state = self._extract_state()
        return obs, infos

    def step(
        self,
        actions: dict[str, Any],
    ) -> tuple[
        dict[str, Any],
        dict[str, float],
        dict[str, bool],
        dict[str, bool],
        dict[str, Any],
    ]:
        step_result = self.env.step(actions)

        if len(step_result) == 5:
            obs, rewards, terminations, truncations, infos = step_result
        else:
            obs, rewards, terminations, truncations = step_result
            infos = {}

        curr_state = self._extract_state()

        shaping = 0.0
        if self._prev_state is not None:
            shaping = self.potential_fn.compute_shaping_reward(curr_state, self._prev_state)

        shaped_rewards: dict[str, float] = {}
        for agent in self._agent_names:
            if agent in rewards:
                shaped_rewards[agent] = float(rewards[agent]) + shaping
        for agent in rewards:
            if agent not in shaped_rewards:
                shaped_rewards[agent] = float(rewards[agent]) + shaping

        self._prev_state = curr_state
        return obs, shaped_rewards, terminations, truncations, infos

    def _extract_state(self) -> dict[str, Any]:
        raw_env = self.env
        while isinstance(raw_env, RewardShapingWrapper):
            raw_env = raw_env.env

        state: dict[str, Any] = {
            "agent_positions": [],
            "landmark_positions": [],
            "agent_velocities": [],
        }

        try:
            world = None
            for attr in ("world", "unwrapped", "aec_env"):
                candidate = getattr(raw_env, attr, None)
                if candidate is None:
                    continue
                if hasattr(candidate, "world"):
                    world = candidate.world
                    break
                elif hasattr(candidate, "agents") and hasattr(candidate, "landmarks"):
                    world = candidate
                    break

            if world is not None:
                try:
                    agents = getattr(world, "agents", [])
                    if agents:
                        for agent in agents:
                            pos = getattr(agent.state, "p_pos", None)
                            vel = getattr(agent.state, "p_vel", None)
                            if pos is not None:
                                state["agent_positions"].append(
                                    pos.tolist() if hasattr(pos, "tolist") else list(pos)
                                )
                            if vel is not None:
                                state["agent_velocities"].append(
                                    vel.tolist() if hasattr(vel, "tolist") else list(vel)
                                )
                except Exception:
                    pass
                try:
                    landmarks = getattr(world, "landmarks", [])
                    if landmarks:
                        for landmark in landmarks:
                            pos = getattr(landmark.state, "p_pos", None)
                            if pos is not None:
                                state["landmark_positions"].append(
                                    pos.tolist() if hasattr(pos, "tolist") else list(pos)
                                )
                except Exception:
                    pass
        except Exception:
            pass

        return state

    def close(self) -> None:
        if hasattr(self.env, "close"):
            self.env.close()

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self.env, name)
