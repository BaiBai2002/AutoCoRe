from __future__ import annotations

from typing import Any, Optional, Union


def make_mpe_env(
    env_id: str,
    max_cycles: int = 100,
    render_mode: Optional[str] = None,
    num_agents: Optional[int] = None,
) -> Any:
    try:
        from pettingzoo.mpe import (
            simple_adversary_v3,
            simple_crypto_v3,
            simple_push_v3,
            simple_reference_v3,
            simple_speaker_listener_v4,
            simple_spread_v3,
        )
    except ImportError:
        try:
            from mpe2 import (
                simple_adversary_v3,
                simple_crypto_v3,
                simple_push_v3,
                simple_reference_v3,
                simple_speaker_listener_v4,
                simple_spread_v3,
            )
        except ImportError as e:
            raise ImportError(
                "MPE environments are required. Install one of: "
                "pip install pettingzoo[mpe]  (pettingzoo < 1.27) or "
                "pip install mpe2  (pettingzoo >= 1.27)"
            ) from e

    clean_id = env_id.replace("mpe/", "")

    env_map: dict[str, Any] = {
        "simple_adversary_v3": simple_adversary_v3,
        "simple_crypto_v3": simple_crypto_v3,
        "simple_push_v3": simple_push_v3,
        "simple_spread_v3": simple_spread_v3,
        "simple_reference_v3": simple_reference_v3,
        "simple_speaker_listener_v4": simple_speaker_listener_v4,
    }

    if clean_id not in env_map:
        raise ValueError(
            f"Unknown environment: '{env_id}'. "
            f"Available: {sorted(env_map.keys())}"
        )

    env_class = env_map[clean_id]
    kwargs: dict[str, Any] = {"max_cycles": max_cycles, "render_mode": render_mode}
    if num_agents is not None and clean_id == "simple_spread_v3":
        kwargs["N"] = int(num_agents)
    return env_class.parallel_env(**kwargs)


class MPEEnvWrapper:
    def __init__(self, env: Any) -> None:
        self.env = env

    @property
    def agents(self) -> list[str]:
        return self.env.agents

    @property
    def possible_agents(self) -> list[str]:
        if hasattr(self.env, "possible_agents"):
            return self.env.possible_agents
        return self.env.agents

    @property
    def unwrapped(self) -> Any:
        return getattr(self.env, "unwrapped", self.env)

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict[str, Any]] = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        result = self.env.reset(seed=seed, options=options)
        if isinstance(result, tuple) and len(result) == 2:
            obs, infos = result
        else:
            obs = result
            infos = {}
        return obs, infos

    def step(
        self,
        actions: dict[str, Any],
    ) -> tuple[
        dict[str, Any],
        dict[str, float],
        dict[str, bool],
        dict[str, bool],
        dict[str, Any],
    ]:
        step_result = self.env.step(actions)

        if len(step_result) == 5:
            obs, rewards, terminations, truncations, infos = step_result
        else:
            obs, rewards, terminations, truncations = step_result
            infos = {}

        return obs, rewards, terminations, truncations, infos

    def get_global_state(self) -> dict[str, Any]:
        state: dict[str, Any] = {
            "agent_positions": [],
            "landmark_positions": [],
            "agent_velocities": [],
        }

        raw_env = self.unwrapped
        try:
            world = None
            for attr in ("world", "aec_env"):
                candidate = getattr(raw_env, attr, None)
                if candidate is not None:
                    if hasattr(candidate, "world"):
                        world = candidate.world
                        break
                    elif hasattr(candidate, "agents") and hasattr(candidate, "landmarks"):
                        world = candidate
                        break

            if world is not None:
                for agent in world.agents:
                    pos = getattr(agent.state, "p_pos", None)
                    vel = getattr(agent.state, "p_vel", None)
                    if pos is not None:
                        state["agent_positions"].append(
                            pos.tolist() if hasattr(pos, "tolist") else list(pos)
                        )
                    if vel is not None:
                        state["agent_velocities"].append(
                            vel.tolist() if hasattr(vel, "tolist") else list(vel)
                        )
                for landmark in world.landmarks:
                    pos = getattr(landmark.state, "p_pos", None)
                    if pos is not None:
                        state["landmark_positions"].append(
                            pos.tolist() if hasattr(pos, "tolist") else list(pos)
                        )
        except Exception:
            pass

        return state

    def close(self) -> None:
        if hasattr(self.env, "close"):
            self.env.close()

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self.env, name)
