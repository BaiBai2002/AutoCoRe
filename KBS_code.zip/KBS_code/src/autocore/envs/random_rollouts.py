from __future__ import annotations

from typing import Any, Optional, Union

import numpy as np

from autocore.envs.pettingzoo_mpe import MPEEnvWrapper, make_mpe_env


class RandomRolloutSampler:
    def __init__(
        self,
        env: Any,
        num_rollouts: int = 10,
        rollout_length: int = 50,
        seed: Optional[int] = None,
    ) -> None:
        self._raw_env = env
        self.num_rollouts = num_rollouts
        self.rollout_length = rollout_length
        self._rng = np.random.RandomState(seed)

        wrapper = MPEEnvWrapper(env)
        self._agent_names = list(wrapper.agents)
        self._action_spaces: dict[str, Any] = {}

        for agent in self._agent_names:
            try:
                self._action_spaces[agent] = env.action_space(agent)
            except (AttributeError, TypeError):
                pass

    @property
    def env(self) -> Any:
        return self._raw_env

    def sample_states(self) -> list[dict[str, Any]]:
        states: list[dict[str, Any]] = []
        wrapper = MPEEnvWrapper(self._raw_env)

        for _ in range(self.num_rollouts):
            wrapper.reset()
            for _ in range(self.rollout_length):
                actions = self._random_actions()
                wrapper.step(actions)
                states.append(wrapper.get_global_state())

        return states

    def sample_trajectories(
        self,
        num_trajectories: int = 5,
    ) -> list[list[dict[str, Any]]]:
        trajectories: list[list[dict[str, Any]]] = []

        for _ in range(num_trajectories):
            wrapper = MPEEnvWrapper(self._raw_env)
            wrapper.reset()
            traj: list[dict[str, Any]] = []

            for _ in range(self.rollout_length):
                actions = self._random_actions()
                wrapper.step(actions)
                traj.append(wrapper.get_global_state())

            trajectories.append(traj)

        return trajectories

    def _random_actions(self) -> dict[str, Any]:
        actions: dict[str, Any] = {}
        for agent in self._agent_names:
            if agent in self._action_spaces:
                space = self._action_spaces[agent]
                actions[agent] = space.sample()
            else:
                actions[agent] = self._rng.uniform(-1.0, 1.0, size=5)
        return actions
