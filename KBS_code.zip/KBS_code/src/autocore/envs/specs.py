from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Union

from autocore.utils.io import load_yaml


@dataclass
class EnvSpec:
    env_id: str
    pettingzoo_id: str
    task_description: str
    observation_space_summary: str
    action_space_summary: str
    available_state_variables: list[str] = field(default_factory=list)
    success_metric: str = ""
    default_episode_length: int = 100
    reward_description: str = ""
    num_agents: int = 3
    num_landmarks: int = 3
    max_cycles: int = 100

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EnvSpec:
        return cls(
            env_id=str(data.get("env_id", "")),
            pettingzoo_id=str(data.get("pettingzoo_id", "")),
            task_description=str(data.get("task_description", "")),
            observation_space_summary=str(data.get("observation_space_summary", "")),
            action_space_summary=str(data.get("action_space_summary", "")),
            available_state_variables=list(data.get("available_state_variables", [])),
            success_metric=str(data.get("success_metric", "")),
            default_episode_length=int(data.get("default_episode_length", 100)),
            reward_description=str(data.get("reward_description", "")),
            num_agents=int(data.get("num_agents", 3)),
            num_landmarks=int(data.get("num_landmarks", 3)),
            max_cycles=int(data.get("max_cycles", 100)),
        )


def load_env_specs(
    config_path: Union[str, Path],
) -> dict[str, EnvSpec]:
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Environment config file not found: {config_path}")

    raw = load_yaml(config_path)
    environments = raw.get("environments", raw)

    env_specs: dict[str, EnvSpec] = {}
    for env_name, env_data in environments.items():
        if not isinstance(env_data, dict):
            continue
        env_specs[env_name] = EnvSpec.from_dict(env_data)

    if not env_specs:
        raise ValueError(f"No valid environment specifications found in {config_path}")

    return env_specs


def load_shaping_config(config_path: Union[str, Path]) -> dict[str, Any]:
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Environment config file not found: {config_path}")

    raw = load_yaml(config_path)
    return raw.get("shaping", {})


def load_env_config(
    config_path: Union[str, Path],
) -> tuple[dict[str, EnvSpec], dict[str, Any]]:
    specs = load_env_specs(config_path)
    config_path = Path(config_path)
    raw = load_yaml(config_path)
    shaping_cfg = raw.get("shaping", {})
    return specs, shaping_cfg
