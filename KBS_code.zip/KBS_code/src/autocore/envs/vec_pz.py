"""Vectorised wrapper for any PettingZoo parallel environment.

``VecMPE`` is specialised to MPE: it reads the environment's particle world to
build a state dictionary for the potential. The second benchmark family used in
this work (PettingZoo SISL) has no such world object, so this module builds the
state from the *joint observation* instead. That keeps the shaping machinery
environment-agnostic: a potential is simply a function of the observations the
agents already receive, which is available for every parallel environment.

Everything else -- role grouping, auto-reset, terminated/truncated handling,
potential-based shaping and the deterministic evaluator -- follows the same
contract as ``VecMPE`` so the training entry point can treat them uniformly.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable, Optional

import numpy as np
from gymnasium import spaces

StateDict = dict[str, Any]

SISL_ENVS = {"pursuit_v5", "multiwalker_v9"}
BUTTERFLY_ENVS = {"pistonball_v6", "cooperative_pong_v6", "knights_archers_zombies_v11"}
PZ_ENV_IDS = SISL_ENVS | BUTTERFLY_ENVS


def make_pz_env(env_id: str, max_cycles: int = 100, **kwargs: Any):
    """Instantiate a PettingZoo parallel environment by family."""
    if env_id in SISL_ENVS:
        module = importlib.import_module("pettingzoo.sisl")
    elif env_id in BUTTERFLY_ENVS:
        module = importlib.import_module("pettingzoo.butterfly")
    else:
        raise ValueError(f"unknown PettingZoo environment {env_id!r}")
    ctor = getattr(module, env_id)
    return ctor.parallel_env(max_cycles=max_cycles, **kwargs)


def state_from_obs(raw: dict[str, Any], agent_names: list[str]) -> StateDict:
    """Joint-observation state: the only quantity every parallel env provides."""
    rows = []
    for a in agent_names:
        v = raw.get(a)
        if v is None:
            continue
        rows.append(np.asarray(v, dtype=np.float64).ravel())
    if not rows:
        return {"obs": np.zeros((0, 1)), "mean_obs": np.zeros(1), "channels": 1}
    mat = np.stack(rows)
    return {"obs": mat, "mean_obs": mat.mean(axis=0), "max_obs": mat.max(axis=0),
            "channels": 1}


@dataclass
class RoleSpec:
    name: str
    agent_names: list[str]
    obs_dim: int
    act_dim: int
    discrete: bool


@dataclass
class StepOutcome:
    obs: np.ndarray
    next_obs: np.ndarray
    rewards: np.ndarray
    terminated: np.ndarray
    truncated: np.ndarray
    dones: np.ndarray


class VecPZ:
    """``num_envs`` independent PettingZoo parallel environments in lockstep."""

    def __init__(
        self,
        env_id: str,
        num_envs: int = 8,
        max_cycles: int = 100,
        base_seed: int = 0,
        potential_fn: Optional[Callable[[StateDict], float]] = None,
        shaping_lambda: float = 0.0,
        gamma: float = 0.99,
        reward_scale: float = 1.0,
        **env_kwargs: Any,
    ) -> None:
        self.env_id = env_id
        self.num_envs = int(num_envs)
        self.max_cycles = int(max_cycles)
        self.base_seed = int(base_seed)
        self.potential_fn = potential_fn
        self.shaping_lambda = float(shaping_lambda)
        self.gamma = float(gamma)
        self.reward_scale = float(reward_scale)

        self.envs = [make_pz_env(env_id, max_cycles=max_cycles, **env_kwargs)
                     for _ in range(self.num_envs)]
        probe = self.envs[0]
        self.agent_names: list[str] = list(probe.possible_agents)
        self.num_agents = len(self.agent_names)
        self._agent_index = {a: i for i, a in enumerate(self.agent_names)}
        self._episode_count = [0] * self.num_envs
        self._prev_phi: list[Optional[float]] = [None] * self.num_envs

        self.obs_dims: list[int] = []
        self.roles: dict[str, RoleSpec] = {}
        self.agent_role: dict[str, str] = {}
        grouped: dict[tuple[int, int, bool], list[str]] = {}
        for a in self.agent_names:
            odim = int(np.prod(probe.observation_space(a).shape))
            asp = probe.action_space(a)
            discrete = isinstance(asp, spaces.Discrete) or isinstance(asp, spaces.MultiDiscrete)
            adim = int(asp.n) if isinstance(asp, spaces.Discrete) else int(np.prod(asp.shape))
            self.obs_dims.append(odim)
            grouped.setdefault((odim, adim, discrete), []).append(a)
        for k, key in enumerate(sorted(grouped)):
            odim, adim, discrete = key
            names = grouped[key]
            role = RoleSpec(name=f"role{k}", agent_names=names, obs_dim=odim,
                            act_dim=adim, discrete=discrete)
            self.roles[role.name] = role
            for a in names:
                self.agent_role[a] = role.name

        self.obs_dim = max(self.obs_dims)
        self.act_dim = max(r.act_dim for r in self.roles.values())
        self._raw: list[dict[str, Any]] = [{} for _ in range(self.num_envs)]

    @property
    def agent_index(self) -> dict[str, int]:
        return self._agent_index

    def _state(self, i: int) -> StateDict:
        return state_from_obs(self._raw[i], self.agent_names)

    def states(self) -> list[StateDict]:
        return [self._state(i) for i in range(self.num_envs)]

    def phi(self, i: int) -> float:
        if self.potential_fn is None:
            return 0.0
        return float(self.potential_fn(self._state(i)))

    def _pack_obs(self, raw: dict[str, Any]) -> np.ndarray:
        row = np.zeros((self.num_agents, self.obs_dim), dtype=np.float32)
        for a in self.agent_names:
            v = raw.get(a)
            if v is not None:
                flat = np.asarray(v, dtype=np.float32).reshape(-1)
                row[self._agent_index[a], : flat.shape[0]] = flat
        return row

    def reset(self, seeds: Optional[list[int]] = None) -> np.ndarray:
        if seeds is None:
            seeds = [self.base_seed + i for i in range(self.num_envs)]
        obs_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        for i, env in enumerate(self.envs):
            self._episode_count[i] = 0
            res = env.reset(seed=int(seeds[i]))
            raw = res[0] if isinstance(res, tuple) else res
            self._raw[i] = raw
            obs_batch[i] = self._pack_obs(raw)
            self._prev_phi[i] = 0.0 if self.potential_fn is None else self.phi(i)
        return obs_batch

    def _reset_one(self, i: int) -> np.ndarray:
        self._episode_count[i] += 1
        seed = self.base_seed + i + self._episode_count[i] * 100003
        res = self.envs[i].reset(seed=seed)
        raw = res[0] if isinstance(res, tuple) else res
        self._raw[i] = raw
        self._prev_phi[i] = 0.0 if self.potential_fn is None else self.phi(i)
        return self._pack_obs(raw)

    def step(self, actions: np.ndarray) -> StepOutcome:
        obs_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        next_batch = np.zeros((self.num_envs, self.num_agents, self.obs_dim), dtype=np.float32)
        rewards = np.zeros((self.num_envs, self.num_agents), dtype=np.float32)
        terminated = np.zeros(self.num_envs, dtype=np.float32)
        truncated = np.zeros(self.num_envs, dtype=np.float32)
        dones = np.zeros(self.num_envs, dtype=np.float32)

        for i, env in enumerate(self.envs):
            if not env.agents:
                obs_batch[i] = self._reset_one(i)
                continue
            obs_batch[i] = self._pack_obs(self._raw[i])
            step_actions = {}
            for a in env.agents:
                slot = self._agent_index[a]
                role = self.roles[self.agent_role[a]]
                if role.discrete:
                    step_actions[a] = int(actions[i, slot])
                else:
                    step_actions[a] = np.asarray(actions[i, slot], dtype=np.float32)

            res = env.step(step_actions)
            raw, rew, term, trunc, _ = res
            self._raw[i] = raw

            phi_next = 0.0 if self.potential_fn is None else self.phi(i)
            phi_prev = self._prev_phi[i] if self._prev_phi[i] is not None else 0.0
            shape = self.shaping_lambda * (self.gamma * phi_next - phi_prev)
            self._prev_phi[i] = phi_next

            for a in env.agents:
                slot = self._agent_index[a]
                rewards[i, slot] = self.reward_scale * float(rew.get(a, 0.0)) + shape
                next_batch[i, slot] = 0.0

            next_batch[i] = self._pack_obs(raw)
            any_term = any(bool(term.get(a, False)) for a in env.agents)
            any_trunc = any(bool(trunc.get(a, False)) for a in env.agents)
            terminated[i] = 1.0 if any_term else 0.0
            truncated[i] = 1.0 if (any_trunc and not any_term) else 0.0
            dones[i] = 1.0 if (any_term or any_trunc) else 0.0

        return StepOutcome(obs=obs_batch, next_obs=next_batch, rewards=rewards,
                           terminated=terminated, truncated=truncated, dones=dones)

    def close(self) -> None:
        for env in self.envs:
            try:
                env.close()
            except Exception:
                pass


class PzEvaluator:
    """Deterministic single-environment evaluator reporting raw and shaped returns."""

    def __init__(self, env_id: str, max_cycles: int = 100, gamma: float = 0.99,
                 potential_fn: Optional[Callable[[StateDict], float]] = None,
                 shaping_lambda: float = 0.0, reward_scale: float = 1.0,
                 **env_kwargs: Any) -> None:
        self.env_id = env_id
        self.max_cycles = int(max_cycles)
        self.gamma = float(gamma)
        self.potential_fn = potential_fn
        self.shaping_lambda = float(shaping_lambda)
        self.reward_scale = float(reward_scale)
        probe = make_pz_env(env_id, max_cycles=max_cycles, **env_kwargs)
        self.agent_names = list(probe.possible_agents)
        self.agent_index = {a: i for i, a in enumerate(self.agent_names)}
        self.obs_dims = [int(np.prod(probe.observation_space(a).shape))
                         for a in self.agent_names]
        self.act_dims = []
        for a in self.agent_names:
            asp = probe.action_space(a)
            if isinstance(asp, spaces.Discrete):
                self.act_dims.append(int(asp.n))
            else:
                self.act_dims.append(1)
        self.obs_dim = max(self.obs_dims)
        self.num_agents = len(self.agent_names)
        probe.close()
        self._env_kwargs = env_kwargs

    def _pack(self, raw: dict[str, Any]) -> np.ndarray:
        row = np.zeros((1, self.num_agents, self.obs_dim), dtype=np.float32)
        for a in self.agent_names:
            v = raw.get(a)
            if v is not None:
                flat = np.asarray(v, dtype=np.float32).reshape(-1)
                row[0, self.agent_index[a], : flat.shape[0]] = flat
        return row

    def run(self, act_fn: Callable[[np.ndarray], np.ndarray],
            seeds: list[int]) -> dict[str, float]:
        raw_returns, shaped_returns, lengths = [], [], []
        completed_early = 0
        for seed in seeds:
            env = make_pz_env(self.env_id, max_cycles=self.max_cycles, **self._env_kwargs)
            res = env.reset(seed=int(seed))
            raw = res[0] if isinstance(res, tuple) else res
            ob = self._pack(raw)
            phi_prev = 0.0 if self.potential_fn is None else float(
                self.potential_fn(state_from_obs(raw, self.agent_names)))
            raw_total = shape_total = 0.0
            steps = 0
            while steps < self.max_cycles and env.agents:
                acts = act_fn(ob)
                step_actions = {}
                for a in env.agents:
                    i = self.agent_index[a]
                    asp = env.action_space(a)
                    if isinstance(asp, spaces.Discrete):
                        step_actions[a] = int(np.clip(
                            int(round(float(acts[0, i]))), 0, self.act_dims[i] - 1))
                    else:
                        step_actions[a] = np.asarray(asp.sample() * 0, dtype=np.float32)
                res = env.step(step_actions)
                raw_next, rew, term, trunc, _ = res
                term_all = bool(all(bool(term.get(a, False)) for a in env.agents))
                if self.potential_fn is not None:
                    curr_phi = float(self.potential_fn(
                        state_from_obs(raw_next, self.agent_names)))
                    shape_total += self.shaping_lambda * (
                        (0.0 - phi_prev) if term_all else (self.gamma * curr_phi - phi_prev))
                    phi_prev = curr_phi
                raw_total += self.reward_scale * float(sum(rew.get(a, 0.0) for a in env.agents))
                steps += 1
                if term_all or (trunc and all(bool(trunc.get(a, False)) for a in env.agents)):
                    break
                ob = self._pack(raw_next)
            raw_returns.append(raw_total)
            shaped_returns.append(raw_total + shape_total)
            lengths.append(steps)
            # An episode that ends before the step limit ended because the prey
            # were all captured; with a random policy this never happens, so the
            # rate is a non-degenerate task-level metric.
            if steps < self.max_cycles:
                completed_early += 1
            env.close()

        arr = np.asarray(raw_returns, dtype=np.float64)
        arr_shaped = np.asarray(shaped_returns, dtype=np.float64)
        return {"mean_return": float(arr.mean()), "std_return": float(arr.std()),
                "mean_raw_return": float(arr.mean()), "std_raw_return": float(arr.std()),
                "mean_shaped_return": float(arr_shaped.mean()),
                "std_shaped_return": float(arr_shaped.std()),
                "mean_length": float(np.mean(lengths)),
                "success_rate": float(completed_early) / max(1, len(seeds)),
                "n": len(seeds)}

    def close(self) -> None:
        return None
