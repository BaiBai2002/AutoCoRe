from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest

from autocore.llm.cache import LLMCache, _API_KEY_PATTERN


class TestLLMCacheNoSecrets:
    def test_api_key_pattern_detects_long_alpha_strings(self):
        assert _API_KEY_PATTERN.search("sk-abc123def456ghi789jkl012mno345pq")
        assert _API_KEY_PATTERN.search("abcdefghijklmnopqrstuvwxyz123456")

    def test_api_key_pattern_ignores_short_strings(self):
        assert not _API_KEY_PATTERN.search("short")
        assert not _API_KEY_PATTERN.search("key")

    def test_redact_api_keys_removes_from_string_values(self):
        cache = LLMCache.__new__(LLMCache)
        data = {"api_key": "sk-abc123def456ghi789jkl012mno345pq67890", "name": "test"}
        redacted = cache._redact_api_keys(data)
        assert redacted["api_key"] == "[REDACTED_API_KEY]"
        assert redacted["name"] == "test"

    def test_redact_api_keys_handles_nested_dict(self):
        cache = LLMCache.__new__(LLMCache)
        data = {
            "config": {
                "auth": {
                    "token": "abcdefghijklmnopqrstuvwxyz1234567890",
                },
                "endpoint": "https://api.example.com",
            }
        }
        redacted = cache._redact_api_keys(data)
        assert redacted["config"]["auth"]["token"] == "[REDACTED_API_KEY]"
        assert redacted["config"]["endpoint"] == "https://api.example.com"

    def test_redact_api_keys_handles_list(self):
        cache = LLMCache.__new__(LLMCache)
        data = {"items": [
            {"key": "sk-abcdefghijklmnopqrstuvwxyz1234567890"},
            {"name": "item2"},
        ]}
        redacted = cache._redact_api_keys(data)
        assert redacted["items"][0]["key"] == "[REDACTED_API_KEY]"
        assert redacted["items"][1]["name"] == "item2"

    def test_cache_put_redacts_before_saving(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            key = "test_provider|test_model|abc123|def456|v1"
            response = {
                "api_key": "sk-abcdefghijklmnopqrstuvwxyz1234567890",
                "result": "success",
                "token": "anotherlongtoken1234567890abcdefghijklmn",
            }
            cache.put(key, response)

            cache2 = LLMCache(cache_dir=tmpdir)
            retrieved = cache2.get(key)
            assert retrieved is not None
            assert retrieved["api_key"] == "[REDACTED_API_KEY]"
            assert retrieved["result"] == "success"
            assert retrieved["token"] == "[REDACTED_API_KEY]"

    def test_cache_does_not_contain_raw_api_keys(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            key = LLMCache.make_key("deepseek", "deepseek-chat", "hash1", "hash2", "v1")
            fake_api_key = "sk-" + "A" * 40

            response = {
                "auth_header": f"Bearer {fake_api_key}",
                "content": "Some generated DSL content",
            }
            cache.put(key, response)

            cache_files = list(Path(tmpdir).glob("*.json"))
            for cf in cache_files:
                with open(cf, "r", encoding="utf-8") as f:
                    raw_content = f.read()
                    assert fake_api_key not in raw_content, (
                        f"Raw API key found in cache file {cf.name}"
                    )

    def test_cache_does_not_redact_normal_content(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            key = LLMCache.make_key("glm", "glm-4", "hash1", "hash2", "v1")

            response = {
                "dsl_content": json.dumps({
                    "task_name": "test",
                    "subgoals": [{"name": "sg1", "rationale": "This is a valid rationale with exactly 32 chars!"}],
                }),
            }
            cache.put(key, response)

            cache2 = LLMCache(cache_dir=tmpdir)
            retrieved = cache2.get(key)
            assert retrieved is not None
            assert retrieved["dsl_content"] == response["dsl_content"]

    def test_cache_index_does_not_leak_secrets(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            key = LLMCache.make_key("provider", "model", "h1", "h2", "v1")
            fake_key = "sk-" + "Z" * 40
            cache.put(key, {"api_secret": fake_key})

            index_path = Path(tmpdir) / "cache_index.json"
            with open(index_path, "r", encoding="utf-8") as f:
                index_raw = f.read()
                assert fake_key not in index_raw

    def test_clear_removes_all_cached_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            for i in range(3):
                cache.put(f"key_{i}", {"data": f"value_{i}"})
            assert cache.size == 3
            count = cache.clear()
            assert count == 3
            assert cache.size == 0

    def test_invalidate_removes_single_entry(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            cache.put("key1", {"data": "v1"})
            cache.put("key2", {"data": "v2"})
            assert cache.size == 2

            result = cache.invalidate("key1")
            assert result is True
            assert cache.size == 1
            assert cache.get("key1") is None
            assert cache.get("key2") is not None

    def test_invalidate_nonexistent_key(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            result = cache.invalidate("nonexistent")
            assert result is False

    def test_has_key_detects_existing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            cache.put("mykey", {"data": "value"})
            assert cache.has_key("mykey") is True
            assert cache.has_key("nonexistent") is False

    def test_hash_content_produces_stable_hash(self):
        h1 = LLMCache.hash_content("test_content")
        h2 = LLMCache.hash_content("test_content")
        assert h1 == h2
        assert len(h1) == 16

    def test_make_key_consistent(self):
        k1 = LLMCache.make_key("p", "m", "h1", "h2", "v1")
        k2 = LLMCache.make_key("p", "m", "h1", "h2", "v1")
        assert k1 == k2

    def test_cache_get_missing_key_returns_none(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            assert cache.get("missing_key") is None


class TestCacheDoesNotCorruptDslIdentifiers:
    """Regression: a >=32-char lowercase DSL identifier (e.g. a potential type)
    was being redacted, silently corrupting cached LLM output so that a cache
    hit differed from the run that produced it."""

    def test_long_lowercase_identifier_is_not_redacted(self):
        cache = LLMCache.__new__(LLMCache)
        dsl = {"potential": {"type": "negative_normalized_sum_min_distance"}}
        redacted = cache._redact_api_keys(dsl)
        assert redacted["potential"]["type"] == "negative_normalized_sum_min_distance"

    def test_credentials_are_still_redacted(self):
        cache = LLMCache.__new__(LLMCache)
        assert cache._redact_api_keys(
            {"token": "sk-abcdefghijklmnopqrstuvwxyz1234567890"}
        )["token"] == "[REDACTED_API_KEY]"
        assert cache._redact_api_keys(
            {"token": "sk-" + "A" * 40}
        )["token"] == "[REDACTED_API_KEY]"

    def test_dsl_content_round_trips_through_cache(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cache = LLMCache(cache_dir=tmpdir)
            key = LLMCache.make_key("deepseek", "deepseek-chat", "h1", "h2", "v1")
            content = json.dumps(
                {"subgoals": [{"potential": {"type": "negative_normalized_sum_min_distance"}}]}
            )
            cache.put(key, {"content": content, "model": "deepseek-chat"})
            got = LLMCache(cache_dir=tmpdir).get(key)
            assert got["content"] == content
