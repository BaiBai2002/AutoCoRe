from __future__ import annotations

import pytest

from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.verifier.static_checks import StaticValidator, ValidationReport


class TestVerifierUnboundVariables:
    def test_detects_unbound_variable_references(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()

        env_spec_with_restricted_vars = dict(mock_env_spec)
        env_spec_with_restricted_vars["available_state_variables"] = ["agent_positions"]

        dsl = {
            "task_name": "t", "version": "1.0", "description": "d",
            "subgoals": [{
                "name": "sg", "scope": "global", "weight": 1.0,
                "predicate": {
                    "type": "min_distance_landmark_coverage",
                    "args": {"agent_key": "agent_positions", "landmark_key": "nonexistent.landmarks"},
                },
                "potential": {"type": "negative_normalized_sum_min_distance"},
                "rationale": "test",
            }],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        sv = StaticValidator(pl, potl, env_spec_with_restricted_vars)
        report = sv.validate(dsl)
        assert report.checks.get("variable_bindings") is False

    def test_known_variables_pass_validation(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(valid_dsl_dict)
        assert report.checks.get("variable_bindings") is True

    def test_unknown_predicate_type_flagged(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["predicate"]["type"] = "completely_unknown_type"
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("predicate_whitelist") is False

    def test_unknown_potential_type_flagged(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["potential"]["type"] = "completely_unknown_potential"
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("potential_whitelist") is False


class TestVerifierWeightValidation:
    def test_non_finite_weight_flagged(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = float("inf")
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("weights_valid") is False

    def test_negative_weight_flagged(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = -5.0
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert not report.passed

    def test_dominating_subgoal_flagged(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = {
            "task_name": "t", "version": "1.0", "description": "d",
            "subgoals": [
                {
                    "name": "dominating", "scope": "global", "weight": 10.0,
                    "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                    "potential": {"type": "negative_normalized_sum_min_distance"},
                    "rationale": "r1",
                },
                {
                    "name": "minor", "scope": "global", "weight": 0.1,
                    "predicate": {"type": "pairwise_agent_distance", "args": {"agent_key": "agent_positions", "aggregation": "mean"}},
                    "potential": {"type": "negative_mean_distance"},
                    "rationale": "r2",
                },
            ],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("no_domination") is False


class TestVerifierSafetyChecks:
    def test_arbitrary_code_detected(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = {
            "task_name": "t", "version": "1.0", "description": "d",
            "subgoals": [{
                "name": "sg",
                "scope": "global",
                "weight": 1.0,
                "predicate": {"type": "exec(something)", "args": {}},
                "potential": {"type": "negative_mean_distance"},
                "rationale": "import os; rm -rf /",
            }],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        dsl["description"] = "import os"
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("no_arbitrary_code") is False

    def test_urls_detected(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = {
            "task_name": "t", "version": "1.0", "description": "http://malicious.site",
            "subgoals": [{
                "name": "sg",
                "scope": "global",
                "weight": 1.0,
                "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                "potential": {"type": "negative_normalized_sum_min_distance"},
                "rationale": "good rationale",
            }],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("no_urls_or_commands") is False

    def test_shell_commands_detected(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = {
            "task_name": "t", "version": "1.0", "description": "rm -rf /tmp",
            "subgoals": [{
                "name": "sg",
                "scope": "global",
                "weight": 1.0,
                "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                "potential": {"type": "negative_normalized_sum_min_distance"},
                "rationale": "good rationale",
            }],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("no_urls_or_commands") is False


class TestValidationReportMerge:
    def test_merge_two_reports(self):
        r1 = ValidationReport(passed=True, errors=["e1"], warnings=["w1"], checks={"a": True})
        r2 = ValidationReport(passed=False, errors=["e2"], warnings=["w2"], checks={"a": False, "b": True})
        merged = r1.merge(r2)
        assert merged.passed is False
        assert merged.errors == ["e1", "e2"]
        assert merged.warnings == ["w1", "w2"]
        assert merged.checks == {"a": False, "b": True}

    def test_ok_creates_passing_report(self):
        report = ValidationReport.ok({"check1": True, "check2": True})
        assert report.passed is True
        assert report.errors == []
        assert report.checks == {"check1": True, "check2": True}

    def test_to_dict_serializable(self):
        report = ValidationReport(passed=True, errors=["e"], warnings=["w"], checks={"c": True})
        d = report.to_dict()
        assert d == {"passed": True, "errors": ["e"], "warnings": ["w"], "checks": {"c": True}}

    def test_merge_handles_empty_reports(self):
        r1 = ValidationReport.ok({"a": True})
        r2 = ValidationReport.ok({"b": True})
        merged = r1.merge(r2)
        assert merged.passed is True
        assert merged.errors == []


class TestVerifierRationale:
    def test_missing_rationale_flagged(self, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        dsl = {
            "task_name": "t", "version": "1.0", "description": "d",
            "subgoals": [{
                "name": "sg",
                "scope": "global",
                "weight": 1.0,
                "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                "potential": {"type": "negative_normalized_sum_min_distance"},
                "rationale": "",
            }],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(dsl)
        assert report.checks.get("rationale_present") is False

    def test_rationale_present_passes(self, valid_dsl_dict, mock_env_spec):
        pl = PredicateLibrary()
        potl = PotentialLibrary()
        sv = StaticValidator(pl, potl, mock_env_spec)
        report = sv.validate(valid_dsl_dict)
        assert report.checks.get("rationale_present") is True
