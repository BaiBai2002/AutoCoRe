from __future__ import annotations

import numpy as np
import pytest
import torch

from autocore.algos.ippo import IPPOTrainer, IPPOConfig
from autocore.algos.networks import SharedActorCritic, SharedActorCriticDiscrete


def _get_all_params_flat(model: torch.nn.Module) -> np.ndarray:
    arrays = []
    for p in model.parameters():
        arrays.append(p.data.cpu().numpy().ravel())
    return np.concatenate(arrays) if arrays else np.array([])


def _l2_distance(params_a: np.ndarray, params_b: np.ndarray) -> float:
    return float(np.linalg.norm(params_a - params_b))


class TestL2DistanceBeforeAfterTraining:
    def test_continuous_l2_increases_after_sgd_step(self):
        config = IPPOConfig(lr=3e-4, hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(8, 3, config, discrete_action=False)

        params_before = _get_all_params_flat(trainer.policy)

        obs_t = torch.randn(16, 8)
        trainer.policy.train()
        act_mean, act_std, values = trainer.policy(obs_t)
        loss = act_mean.pow(2).sum() + act_std.pow(2).sum() + values.mean()
        loss.backward()
        trainer.optimizer.step()
        trainer.optimizer.zero_grad()

        params_after = _get_all_params_flat(trainer.policy)
        dist = _l2_distance(params_before, params_after)
        assert dist > 1e-6, f"L2 distance should be positive after SGD step, got {dist}"

    def test_discrete_l2_increases_after_sgd_step(self):
        config = IPPOConfig(lr=3e-4, hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(8, 5, config, discrete_action=True)

        params_before = _get_all_params_flat(trainer.policy)

        obs_t = torch.randn(16, 8)
        trainer.policy.train()
        logits, values = trainer.policy(obs_t)
        loss = logits.pow(2).sum() + values.mean()
        loss.backward()
        trainer.optimizer.step()
        trainer.optimizer.zero_grad()

        params_after = _get_all_params_flat(trainer.policy)
        dist = _l2_distance(params_before, params_after)
        assert dist > 1e-6, f"Discrete L2 distance should be positive after SGD step, got {dist}"

    def test_multiple_rl_updates_produce_larger_l2(self):
        config = IPPOConfig(lr=1e-3, hidden_dim=16, device="cpu",
                            update_epochs=4, batch_size=16,
                            gamma=0.99, gae_lambda=0.95)
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)

        params_before = _get_all_params_flat(trainer.policy)

        obs = torch.randn(64, 4)
        acts = torch.randn(64, 2)
        log_probs = torch.zeros(64)
        advantages = torch.randn(64)
        returns = torch.randn(64)

        for _ in range(3):
            trainer.policy.train()
            act_mean, act_std, values = trainer.policy(obs)
            dist = torch.distributions.Normal(act_mean, act_std)
            new_log_probs = dist.log_prob(acts).sum(-1)
            ratio = torch.exp(new_log_probs - log_probs)
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 0.8, 1.2) * advantages
            policy_loss = -torch.min(surr1, surr2).mean()
            value_loss = torch.nn.functional.mse_loss(values, returns)
            entropy = dist.entropy().sum(-1).mean()
            loss = policy_loss + 0.5 * value_loss - 0.01 * entropy
            trainer.optimizer.zero_grad()
            loss.backward()
            trainer.optimizer.step()

        params_after = _get_all_params_flat(trainer.policy)
        dist = _l2_distance(params_before, params_after)
        assert dist > 0.01, f"Multiple RL updates should produce L2 > 0.01, got {dist}"
