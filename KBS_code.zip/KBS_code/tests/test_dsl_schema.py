from __future__ import annotations

import pytest
import jsonschema

from autocore.dsl.schema import DSL_SCHEMA_JSON, DSLSchema
from autocore.dsl.parser import validate_schema_raw, DSLParseError


class TestDSLSchemaValidation:
    def test_valid_dsl_passes_schema_validation(self, valid_dsl_dict):
        result = validate_schema_raw(valid_dsl_dict)
        assert result == valid_dsl_dict

    def test_valid_dsl_has_all_required_fields(self, valid_dsl_dict):
        required_fields = ["task_name", "version", "description", "subgoals", "expected_effects"]
        for field in required_fields:
            assert field in valid_dsl_dict, f"Missing required field: {field}"

    def test_subgoal_has_all_required_fields(self, valid_dsl_dict):
        required_fields = ["name", "scope", "weight", "predicate", "potential", "rationale"]
        for sg in valid_dsl_dict["subgoals"]:
            for field in required_fields:
                assert field in sg, f"Subgoal missing required field: {field}"


class TestDSLSchemaRejectsInvalid:
    def test_rejects_missing_task_name(self):
        dsl = {
            "version": "1.0",
            "description": "test",
            "subgoals": [],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_missing_subgoals(self):
        dsl = {
            "task_name": "test",
            "version": "1.0",
            "description": "test",
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_empty_subgoals(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"] = []
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_wrong_type_for_weight(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = "heavy"
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_weight_below_minimum(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = 0.05
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_weight_above_maximum(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = 15.0
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_too_many_subgoals(self, dsl_dict_too_many_subgoals):
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl_dict_too_many_subgoals)

    def test_rejects_invalid_scope(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["scope"] = "invalid_scope_value"
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_missing_predicate_type(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["predicate"] = {"args": {}}
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_missing_rationale(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        del dsl["subgoals"][0]["rationale"]
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_empty_rationale(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["rationale"] = ""
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_extra_properties(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["injected_field"] = "malicious"
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_rejects_missing_expected_effects(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["expected_effects"] = {}
        with pytest.raises(jsonschema.ValidationError):
            DSLSchema.validate(dsl)

    def test_validate_schema_raw_accepts_string(self, valid_dsl_dict):
        import json
        raw = json.dumps(valid_dsl_dict)
        result = validate_schema_raw(raw)
        assert result == valid_dsl_dict

    def test_validate_schema_raw_rejects_invalid_json(self):
        with pytest.raises(DSLParseError, match="Failed to parse DSL as valid JSON"):
            validate_schema_raw("{invalid json")

    def test_validate_schema_raw_rejects_wrong_type(self):
        with pytest.raises(DSLParseError):
            validate_schema_raw(42)


class TestDSLSchemaEdgeCases:
    def test_minimum_subgoal_count_is_one(self, dsl_dict_single_subgoal):
        result = validate_schema_raw(dsl_dict_single_subgoal)
        assert len(result["subgoals"]) == 1

    def test_maximum_subgoal_count_is_five(self, valid_dsl_dict):
        assert len(valid_dsl_dict["subgoals"]) == 2
        assert len(valid_dsl_dict["subgoals"]) <= 5

    def test_weight_at_boundary_minimum(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = 0.1
        result = validate_schema_raw(dsl)
        assert result["subgoals"][0]["weight"] == 0.1

    def test_weight_at_boundary_maximum(self, valid_dsl_dict):
        dsl = dict(valid_dsl_dict)
        dsl["subgoals"][0]["weight"] = 10.0
        result = validate_schema_raw(dsl)
        assert result["subgoals"][0]["weight"] == 10.0
