from __future__ import annotations

import copy
import math
import pytest

from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.dsl.expanded_predicates import register_expanded_predicates
from autocore.verifier.conservative_repair import ConservativeRepair, ConservativeRepairResult


@pytest.fixture
def pred_lib():
    return register_expanded_predicates(PredicateLibrary())


@pytest.fixture
def pot_lib():
    return PotentialLibrary()


@pytest.fixture
def env_spec():
    return {
        "env_id": "simple_spread_v3",
        "available_state_variables": [
            "agent_positions", "agent_velocities", "landmark_positions",
            "agent_count", "landmark_count",
        ],
        "repair": {"max_domination_ratio": 10.0},
    }


@pytest.fixture
def valid_candidate():
    return {
        "task_name": "test_task",
        "version": "1.0.0",
        "description": "A valid test DSL",
        "subgoals": [
            {
                "name": "cover_landmarks",
                "scope": "global",
                "weight": 1.0,
                "predicate": {
                    "type": "min_distance_landmark_coverage",
                    "args": {
                        "agent_key": "agent_positions",
                        "landmark_key": "landmark_positions",
                    },
                },
                "potential": {
                    "type": "negative_normalized_sum_min_distance",
                },
                "rationale": "Cover all landmarks efficiently",
            },
        ],
        "expected_effects": {
            "sample_efficiency": "high",
            "final_return": "improved",
            "interpretability": "clear",
        },
    }


class TestRepairPreservesSemantics:
    def test_valid_candidate_unchanged_by_repair(self, pred_lib, pot_lib, env_spec, valid_candidate):
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(valid_candidate)
        assert result.changes_made == [], f"Repair modified valid candidate: {result.changes_made}"
        repaired = result.repaired_candidate
        assert repaired["task_name"] == valid_candidate["task_name"]
        assert repaired["subgoals"][0]["name"] == valid_candidate["subgoals"][0]["name"]
        assert repaired["subgoals"][0]["predicate"]["type"] == valid_candidate["subgoals"][0]["predicate"]["type"]
        assert repaired["subgoals"][0]["rationale"] == valid_candidate["subgoals"][0]["rationale"]
        assert repaired["subgoals"][0]["weight"] == valid_candidate["subgoals"][0]["weight"]

    def test_missing_json_fields_added_without_semantic_change(self, pred_lib, pot_lib, env_spec):
        candidate = {
            "task_name": "incomplete",
            "subgoals": [],
        }
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert repaired["task_name"] == "incomplete", "Task name should not change"
        assert "version" in repaired
        assert "description" in repaired
        assert "expected_effects" in repaired
        assert "subgoals" in repaired

    def test_nan_weights_fixed_without_affecting_other_fields(self, pred_lib, pot_lib, env_spec, valid_candidate):
        candidate = copy.deepcopy(valid_candidate)
        candidate["subgoals"][0]["weight"] = float("nan")
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert repaired["subgoals"][0]["name"] == valid_candidate["subgoals"][0]["name"]
        assert repaired["subgoals"][0]["rationale"] == valid_candidate["subgoals"][0]["rationale"]
        assert repaired["subgoals"][0]["predicate"]["type"] == valid_candidate["subgoals"][0]["predicate"]["type"]
        w = repaired["subgoals"][0]["weight"]
        assert isinstance(w, (int, float)) and math.isfinite(w), f"NaN weight should be fixed, got {w}"
        assert 0.01 <= w <= 10.0, f"Weight should be in valid range, got {w}"

    def test_inf_weight_clamped_without_side_effects(self, pred_lib, pot_lib, env_spec, valid_candidate):
        candidate = copy.deepcopy(valid_candidate)
        candidate["subgoals"][0]["weight"] = float("inf")
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert repaired["subgoals"][0]["predicate"]["type"] == valid_candidate["subgoals"][0]["predicate"]["type"]
        assert repaired["subgoals"][0]["potential"]["type"] == valid_candidate["subgoals"][0]["potential"]["type"]
        w = repaired["subgoals"][0]["weight"]
        assert math.isfinite(w), f"Inf weight should be finite, got {w}"

    def test_unknown_predicate_renamed_but_rest_preserved(self, pred_lib, pot_lib, env_spec, valid_candidate):
        candidate = copy.deepcopy(valid_candidate)
        candidate["subgoals"][0]["predicate"]["type"] = "min_distance_landmark_coverage"
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert repaired["task_name"] == valid_candidate["task_name"]
        assert repaired["description"] == valid_candidate["description"]
        assert repaired["subgoals"][0]["rationale"] == valid_candidate["subgoals"][0]["rationale"]
        assert repaired["subgoals"][0]["weight"] == valid_candidate["subgoals"][0]["weight"]
        assert repaired["subgoals"][0]["name"] == valid_candidate["subgoals"][0]["name"]

    def test_multiple_subgoals_preserved_after_repair(self, pred_lib, pot_lib, env_spec):
        candidate = {
            "task_name": "multi_sg",
            "version": "1.0.0",
            "description": "Multi subgoal test",
            "subgoals": [
                {
                    "name": "sg_a",
                    "scope": "global",
                    "weight": 1.0,
                    "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                    "potential": {"type": "negative_normalized_sum_min_distance"},
                    "rationale": "First subgoal",
                },
                {
                    "name": "sg_b",
                    "scope": "global",
                    "weight": float("inf"),
                    "predicate": {"type": "pairwise_agent_distance", "args": {"agent_key": "agent_positions", "aggregation": "mean"}},
                    "potential": {"type": "negative_mean_distance"},
                    "rationale": "Second subgoal with bad weight",
                },
            ],
            "expected_effects": {"sample_efficiency": "high", "final_return": "good", "interpretability": "clear"},
        }
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert len(repaired["subgoals"]) == 2
        assert repaired["subgoals"][0]["name"] == "sg_a"
        assert repaired["subgoals"][0]["rationale"] == "First subgoal"
        assert repaired["subgoals"][0]["weight"] == 1.0
        assert repaired["subgoals"][1]["name"] == "sg_b"
        assert repaired["subgoals"][1]["rationale"] == "Second subgoal with bad weight"
        assert math.isfinite(repaired["subgoals"][1]["weight"]), "Inf weight should be fixed"

    def test_original_candidate_stored_and_unmodified(self, pred_lib, pot_lib, env_spec, valid_candidate):
        candidate = copy.deepcopy(valid_candidate)
        candidate["subgoals"][0]["weight"] = float("nan")
        original_copy = copy.deepcopy(candidate)

        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)

        assert result.original_candidate is not None
        assert result.original_candidate["subgoals"][0]["name"] == original_copy["subgoals"][0]["name"]

        repaired = result.repaired_candidate
        assert repaired["subgoals"][0]["rationale"] == valid_candidate["subgoals"][0]["rationale"]
        w = repaired["subgoals"][0]["weight"]
        assert math.isfinite(w), f"NaN weight should be repaired, got {w}"

    def test_empty_subgoals_preserves_structure(self, pred_lib, pot_lib, env_spec):
        candidate = {
            "task_name": "empty_sg",
            "version": "1.0.0",
            "description": "No subgoals",
            "subgoals": [],
            "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"},
        }
        repair = ConservativeRepair(pred_lib, pot_lib, env_spec)
        result = repair.repair(candidate)
        repaired = result.repaired_candidate
        assert repaired["task_name"] == "empty_sg"
        assert repaired["subgoals"] == []
        assert repaired["description"] == "No subgoals"
