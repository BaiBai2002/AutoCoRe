from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pytest

from autocore.dsl.compiler import CompilerOutput, compile_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.shaping.potentials import PotentialFunction, ShapingConfig


@pytest.fixture
def valid_dsl_dict() -> dict[str, Any]:
    return {
        "task_name": "test_task",
        "version": "1.0.0",
        "description": "A test DSL for cooperative landmark coverage",
        "subgoals": [
            {
                "name": "cover_landmarks",
                "scope": "global",
                "weight": 2.0,
                "predicate": {
                    "type": "min_distance_landmark_coverage",
                    "args": {
                        "agent_key": "agent_positions",
                        "landmark_key": "landmark_positions",
                    },
                },
                "potential": {
                    "type": "negative_normalized_sum_min_distance",
                    "threshold": 10.0,
                },
                "rationale": "Agents should minimize distance to landmarks.",
            },
            {
                "name": "avoid_collisions",
                "scope": "global",
                "weight": 1.0,
                "predicate": {
                    "type": "collision_count_or_margin",
                    "args": {
                        "agent_key": "agent_positions",
                        "collision_threshold": 0.5,
                        "mode": "margin",
                    },
                },
                "potential": {
                    "type": "collision_margin_bonus",
                    "threshold": 0.0,
                },
                "rationale": "Maintain safe inter-agent distances.",
            },
        ],
        "expected_effects": {
            "sample_efficiency": "Faster convergence",
            "final_return": "Higher coverage",
            "interpretability": "Clear subgoal decomposition",
        },
    }


@pytest.fixture
def mock_state() -> dict[str, Any]:
    np.random.seed(42)
    return {
        "agent_positions": np.random.uniform(-2.0, 2.0, (3, 2)).astype(np.float64),
        "agent_velocities": np.random.uniform(-1.0, 1.0, (3, 2)).astype(np.float64),
        "landmark_positions": np.random.uniform(-2.0, 2.0, (3, 2)).astype(np.float64),
        "agent_count": 3,
        "landmark_count": 3,
    }


@pytest.fixture
def mock_state_far_apart() -> dict[str, Any]:
    return {
        "agent_positions": np.array([[10.0, 10.0], [10.0, 9.0], [9.0, 10.0]], dtype=np.float64),
        "agent_velocities": np.zeros((3, 2), dtype=np.float64),
        "landmark_positions": np.array([[-10.0, -10.0], [-9.0, -10.0], [-10.0, -9.0]], dtype=np.float64),
        "agent_count": 3,
        "landmark_count": 3,
    }


@pytest.fixture
def mock_state_near_landmarks() -> dict[str, Any]:
    return {
        "agent_positions": np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0]], dtype=np.float64),
        "agent_velocities": np.zeros((3, 2), dtype=np.float64),
        "landmark_positions": np.array([[0.1, 0.1], [1.1, 0.1], [0.1, 1.1]], dtype=np.float64),
        "agent_count": 3,
        "landmark_count": 3,
    }


@pytest.fixture
def mock_collision_state() -> dict[str, Any]:
    return {
        "agent_positions": np.array([[0.0, 0.0], [0.01, 0.01], [1.0, 1.0]], dtype=np.float64),
        "agent_velocities": np.zeros((3, 2), dtype=np.float64),
        "landmark_positions": np.array([[5.0, 5.0], [6.0, 5.0], [5.0, 6.0]], dtype=np.float64),
        "agent_count": 3,
        "landmark_count": 3,
    }


@pytest.fixture
def predicate_library() -> PredicateLibrary:
    return PredicateLibrary()


@pytest.fixture
def potential_library() -> PotentialLibrary:
    return PotentialLibrary()


@pytest.fixture
def shaping_config() -> ShapingConfig:
    return ShapingConfig(gamma=0.99, shaping_lambda=0.1, potential_clip=(-1.0, 1.0))


@pytest.fixture
def compiler_output(valid_dsl_dict, predicate_library, potential_library) -> CompilerOutput:
    return compile_dsl(valid_dsl_dict, predicate_library, potential_library)


@pytest.fixture
def potential_function(compiler_output, shaping_config) -> PotentialFunction:
    return PotentialFunction(compiler_output, shaping_config)


@pytest.fixture
def mock_env_spec() -> dict[str, Any]:
    return {
        "env_id": "simple_spread_v3",
        "task_description": "N agents spread to cover N landmarks",
        "num_agents": 3,
        "num_landmarks": 3,
        "reward_description": "Negative sum of min distances from landmarks to agents",
        "available_state_variables": [
            "agent_positions",
            "agent_velocities",
            "landmark_positions",
            "agent_count",
            "landmark_count",
        ],
        "repair": {"max_domination_ratio": 10.0},
    }


@pytest.fixture
def temp_dir() -> str:
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_experiment_df() -> pd.DataFrame:
    return pd.DataFrame({
        "env_id": ["simple_spread_v3"] * 6 + ["simple_reference_v3"] * 6,
        "method": ["autocore", "base"] * 6,
        "final_return": [45.2, 30.1, 47.8, 28.3, 44.0, 31.5,
                         38.7, 25.0, 40.1, 24.2, 39.5, 26.8],
        "wall_time": [1200.0, 800.0, 1250.0, 780.0, 1180.0, 820.0,
                      1500.0, 900.0, 1480.0, 920.0, 1520.0, 880.0],
    })


@pytest.fixture
def dsl_dict_invalid_missing_fields() -> dict[str, Any]:
    return {
        "task_name": "test",
        "version": "1.0",
    }


@pytest.fixture
def dsl_dict_too_many_subgoals(valid_dsl_dict) -> dict[str, Any]:
    d = dict(valid_dsl_dict)
    d["subgoals"] = [
        {
            "name": f"sg_{i}",
            "scope": "global",
            "weight": 1.0,
            "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_normalized_sum_min_distance"},
            "rationale": f"Rationale for subgoal {i}",
        }
        for i in range(6)
    ]
    return d


@pytest.fixture
def dsl_dict_single_subgoal() -> dict[str, Any]:
    return {
        "task_name": "single_sg",
        "version": "1.0.0",
        "description": "Single subgoal DSL",
        "subgoals": [
            {
                "name": "cover",
                "scope": "global",
                "weight": 1.0,
                "predicate": {
                    "type": "mean_distance_to_nearest_landmark",
                    "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"},
                },
                "potential": {"type": "negative_mean_distance"},
                "rationale": "Cover landmarks",
            }
        ],
        "expected_effects": {
            "sample_efficiency": "Good",
            "final_return": "Good",
            "interpretability": "Simple",
        },
    }


@pytest.fixture
def dsl_dict_weighted_multi() -> dict[str, Any]:
    return {
        "task_name": "weighted_multi",
        "version": "1.0.0",
        "description": "Multi subgoal with varied weights",
        "subgoals": [
            {
                "name": "primary",
                "scope": "global",
                "weight": 5.0,
                "predicate": {
                    "type": "min_distance_landmark_coverage",
                    "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"},
                },
                "potential": {"type": "negative_normalized_sum_min_distance", "threshold": 10.0},
                "rationale": "Primary goal",
            },
            {
                "name": "secondary",
                "scope": "global",
                "weight": 1.0,
                "predicate": {
                    "type": "pairwise_agent_distance",
                    "args": {"agent_key": "agent_positions", "aggregation": "mean"},
                },
                "potential": {"type": "negative_mean_distance"},
                "rationale": "Secondary goal",
            },
            {
                "name": "tertiary",
                "scope": "agent_local",
                "weight": 0.5,
                "predicate": {
                    "type": "coverage_entropy_or_balance",
                    "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"},
                },
                "potential": {"type": "balanced_coverage", "threshold": 1.0},
                "rationale": "Balance coverage",
            },
        ],
        "expected_effects": {
            "sample_efficiency": "Good",
            "final_return": "Good",
            "interpretability": "Multi-faceted",
        },
    }


@pytest.fixture
def dsl_dict_all_predicate_types() -> dict[str, Any]:
    def _args_for(ptype: str) -> dict[str, Any]:
        if ptype == "pairwise_agent_distance":
            return {"agent_key": "agent_positions", "aggregation": "mean"}
        return {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}

    predicate_types = [
        "min_distance_landmark_coverage",
        "mean_distance_to_nearest_landmark",
        "max_uncovered_landmark_distance",
        "pairwise_agent_distance",
        "agent_target_assignment_distance",
    ]
    subgoals = []
    for i, ptype in enumerate(predicate_types):
        subgoals.append({
            "name": f"sg_{ptype}",
            "scope": "global" if i < 3 else "agent_local",
            "weight": 1.0,
            "predicate": {
                "type": ptype,
                "args": _args_for(ptype),
            },
            "potential": {"type": "negative_mean_distance"},
            "rationale": f"Testing predicate {ptype}",
        })
    return {
        "task_name": "all_predicates",
        "version": "1.0.0",
        "description": "Test all predicate types",
        "subgoals": subgoals,
        "expected_effects": {
            "sample_efficiency": "Test",
            "final_return": "Test",
            "interpretability": "Test",
        },
    }
