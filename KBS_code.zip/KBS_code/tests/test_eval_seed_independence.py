from __future__ import annotations

import numpy as np
import pytest

from autocore.algos.ippo import IPPOTrainer, IPPOConfig
from autocore.experiments.train import evaluate_agent


class MockEvalEnv:
    def __init__(self, n_agents: int = 2, obs_dim: int = 4):
        self.possible_agents = [f"agent_{i}" for i in range(n_agents)]
        self.agents = list(self.possible_agents)
        self._step_count = 0
        self.obs_dim = obs_dim
        self.unwrapped = self

        class ObsSpace:
            def __init__(self, dim):
                self.shape = (dim,)

        class ActSpace:
            def __init__(self):
                self.shape = (2,)

        self._obs_space = ObsSpace(obs_dim)
        self._act_space = ActSpace()

    def observation_space(self, agent):
        return self._obs_space

    def action_space(self, agent):
        return self._act_space

    def reset(self, seed=None, options=None):
        self._step_count = 0
        if seed is not None:
            np.random.seed(seed)
        obs = {agent: np.random.randn(self.obs_dim).astype(np.float32) for agent in self.agents}
        return obs, {}

    def step(self, actions):
        self._step_count += 1
        obs = {agent: np.random.randn(self.obs_dim).astype(np.float32) for agent in self.agents}
        rewards = {agent: float(np.random.randn() * 0.1) for agent in self.agents}
        terminations = {agent: False for agent in self.agents}
        truncations = {agent: self._step_count >= 30 for agent in self.agents}
        return obs, rewards, terminations, truncations, {}

    def close(self):
        pass


class TestEvalSeedIndependence:
    def test_different_seeds_produce_varying_returns(self):
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)

        returns = []
        for seed in [42, 123, 456, 789]:
            env = MockEvalEnv(n_agents=2, obs_dim=4)
            ret = evaluate_agent(env, trainer, num_episodes=15, seed=seed)
            returns.append(ret)
            env.close()

        assert len(set(round(r, 6) for r in returns)) >= 2, \
            f"Expected varying returns across seeds, got {returns}"

    def test_seed_zero_produces_numeric_result(self):
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)

        env = MockEvalEnv(n_agents=2, obs_dim=4)
        ret = evaluate_agent(env, trainer, num_episodes=5, seed=0)
        env.close()

        assert isinstance(ret, float)
        assert np.isfinite(ret), f"Return should be finite, got {ret}"

    def test_large_seed_does_not_crash(self):
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)

        for seed in [9999, 12345, 99999]:
            env = MockEvalEnv(n_agents=2, obs_dim=4)
            ret = evaluate_agent(env, trainer, num_episodes=3, seed=seed)
            env.close()
            assert isinstance(ret, float)
            assert np.isfinite(ret), f"Return for seed={seed} should be finite, got {ret}"
