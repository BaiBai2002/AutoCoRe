"""Tests for the selection module."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np

from autocore.selection.proxy_scores import (
    CandidateScore, compute_validity_score, compute_diversity_score,
    compute_progress_alignment_score, compute_reward_dominance_score,
    compute_non_interference_score, compute_interpretability_score,
    compute_composite_score,
)
from autocore.selection.candidate_selector import CandidateSelector, select_lambda


class TestValidityScore:
    def test_perfect_validity(self):
        s = compute_validity_score([True]*11, [True]*6, 0)
        assert s == 1.0, f"Expected 1.0, got {s}"

    def test_all_failed(self):
        s = compute_validity_score([False]*11, [False]*6, 3)
        assert s == 0.0, f"Expected 0.0, got {s}"

    def test_repair_penalty(self):
        s0 = compute_validity_score([True]*11, [True]*6, 0)
        s3 = compute_validity_score([True]*11, [True]*6, 3)
        assert s3 < s0, f"Repair penalty should lower score: {s3} vs {s0}"


class TestDiversityScore:
    def test_constant_potential(self):
        s = compute_diversity_score([1.0, 1.0, 1.0, 1.0, 1.0])
        assert s == 0.0, f"Constant should have 0 diversity, got {s}"

    def test_diverse_potential(self):
        s = compute_diversity_score([-1.0, -0.5, 0.0, 0.5, 1.0])
        assert s > 0.5, f"Diverse should have high score, got {s}"

    def test_single_value(self):
        s = compute_diversity_score([1.0])
        assert s == 0.0, f"Single value should be 0, got {s}"


class TestProgressAlignment:
    def test_positive_correlation(self):
        delta = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
        rewards = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
        s = compute_progress_alignment_score(delta, rewards)
        assert s > 0.7, f"Positive corr should be high: {s}"

    def test_negative_correlation(self):
        delta = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]
        rewards = [0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1]
        s = compute_progress_alignment_score(delta, rewards)
        assert s < 0.5, f"Negative corr should be low: {s}"

    def test_too_short(self):
        s = compute_progress_alignment_score([0.1, 0.2], [0.1, 0.2])
        assert s == 0.5, f"Short should return default 0.5, got {s}"


class TestRewardDominance:
    def test_safe_ratio(self):
        s = compute_reward_dominance_score([0.1]*100, [1.0]*100)
        assert s == 1.0, f"0.1 ratio should be perfect: {s}"

    def test_too_high_ratio(self):
        s = compute_reward_dominance_score([2.0]*100, [1.0]*100)
        assert s == 0.0, f"2.0 ratio should be 0: {s}"

    def test_zero_env_reward(self):
        s = compute_reward_dominance_score([0.05]*100, [0.0]*100)
        assert s == 1.0, f"Zero env reward with low shaping should be safe: {s}"


class TestNonInterference:
    def test_no_violations(self):
        pairs = [(1.0, 1.0, 0.0, 0.0), (5.0, 5.0, 1.0, 1.0), (3.0, 3.0, 2.0, 2.0),
                 (4.0, 4.0, 1.0, 1.0), (2.0, 2.0, 0.5, 0.5)]
        s = compute_non_interference_score(pairs)
        assert s == 1.0, f"No violations: {s}"

    def test_all_violations(self):
        pairs = [(5.0, 1.0, 1.0, 5.0), (4.0, 0.0, 2.0, 10.0), (3.0, -1.0, 0.0, 8.0),
                 (6.0, 2.0, 1.0, 7.0), (7.0, 3.0, 0.0, 9.0)]
        s = compute_non_interference_score(pairs)
        assert s == 0.0, f"All violations: {s}"

    def test_too_short(self):
        s = compute_non_interference_score([(1.0, 1.0, 0.0, 0.0)])
        assert s == 0.5, f"Too short should default to 0.5: {s}"


class TestInterpretability:
    def test_well_structured_dsl(self):
        dsl = {"subgoals": [
            {"name": "a", "predicate": {"type": "t1"}, "potential": {"type": "p1"}, "rationale": "good reason here"},
            {"name": "b", "predicate": {"type": "t2"}, "potential": {"type": "p2"}, "rationale": "another reason"},
            {"name": "c", "predicate": {"type": "t3"}, "potential": {"type": "p3"}, "rationale": "third reason"},
        ]}
        s = compute_interpretability_score(dsl)
        assert s > 0.7, f"Well structured: {s}"

    def test_empty_dsl(self):
        s = compute_interpretability_score({"subgoals": []})
        assert s == 0.0, f"Empty: {s}"

    def test_duplicates(self):
        dsl = {"subgoals": [
            {"name": "a", "predicate": {"type": "t1"}, "potential": {"type": "p1"}, "rationale": "x"},
            {"name": "b", "predicate": {"type": "t1"}, "potential": {"type": "p1"}, "rationale": "x"},
        ]}
        s = compute_interpretability_score(dsl)
        assert s < 0.8, f"Duplicates should lower score: {s}"


class TestCompositeScore:
    def test_perfect_candidate(self):
        score = CandidateScore(
            validity_score=1.0, progress_alignment_score=1.0,
            reward_dominance_score=1.0, non_interference_score=1.0,
            diversity_score=1.0, interpretability_score=1.0,
        )
        c = compute_composite_score(score)
        assert abs(c - 1.0) < 0.01, f"Perfect should be 1.0: {c}"

    def test_invalid_candidate(self):
        score = CandidateScore(
            validity_score=0.0, progress_alignment_score=0.8,
            reward_dominance_score=0.8, non_interference_score=0.8,
            diversity_score=0.8, interpretability_score=0.8,
        )
        c = compute_composite_score(score)
        assert c <= 0.61, f"Invalid should be low: {c}"


class TestCandidateSelector:
    def test_select_best_from_valid(self):
        selector = CandidateSelector()
        s1 = CandidateScore(); s1.is_valid = True; s1.composite_score = 0.8
        s2 = CandidateScore(); s2.is_valid = True; s2.composite_score = 0.6
        s3 = CandidateScore(); s3.is_valid = True; s3.composite_score = 0.9
        candidates = [({"name": "a"}, s1), ({"name": "b"}, s2), ({"name": "c"}, s3)]
        best_dsl, best_score, all_c = selector.select_best(candidates)
        assert best_dsl["name"] == "c", f"Should select highest score: {best_dsl}"

    def test_no_valid_candidates(self):
        selector = CandidateSelector()
        s1 = CandidateScore(); s1.is_valid = False; s1.composite_score = 0.5
        s2 = CandidateScore(); s2.is_valid = False; s2.composite_score = 0.3
        candidates = [({"name": "a"}, s1), ({"name": "b"}, s2)]
        best_dsl, _, _ = selector.select_best(candidates)
        assert best_dsl["name"] == "a", f"Should select best invalid: {best_dsl}"


class TestLambdaSelection:
    def test_safe_lambda(self):
        def evaluator(lam, rewards):
            return lam * 0.5  # ratio = lam * 0.5
        env_rew = [1.0] * 100
        lam, reason = select_lambda(
            ({"task_name": "test"}, CandidateScore()),
            [0.025, 0.05, 0.1, 0.2, 0.4],
            evaluator, env_rew, (0.05, 0.50))
        assert 0.01 <= lam <= 0.5, f"Should select reasonable lambda: {lam}"

    def test_returns_default_on_all_unsafe(self):
        def evaluator(lam, rewards):
            return 5.0  # always too high
        env_rew = [1.0] * 100
        lam, _ = select_lambda(
            ({"task_name": "test"}, CandidateScore()),
            [0.1, 0.2], evaluator, env_rew)
        assert lam in [0.1, 0.2], f"Should return one of the inputs: {lam}"
