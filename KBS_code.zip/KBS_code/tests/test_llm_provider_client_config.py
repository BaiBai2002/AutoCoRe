from __future__ import annotations

import pytest

from autocore.llm.client import LLMAuthError, LLMClient
from autocore.llm.providers import ProviderConfig


def _provider(api_key: str | None) -> ProviderConfig:
    return ProviderConfig(
        name="dummy",
        display_name="Dummy",
        api_key_env="DUMMY_API_KEY_ENV_NOT_SET",
        base_url_env="DUMMY_BASE_URL_ENV_NOT_SET",
        model_env="DUMMY_MODEL_ENV_NOT_SET",
        default_model="dummy-model",
        default_base_url="https://example.invalid/v1",
        _api_key=api_key,
        _base_url="https://example.invalid/v1",
        _model="dummy-model",
    )


class TestProviderClientConfig:
    """Regression for the generator bug: ProviderConfig.to_dict() drops api_key."""

    def test_to_dict_omits_api_key(self):
        d = _provider("dummy-key").to_dict()
        assert "api_key" not in d

    def test_client_from_to_dict_raises_auth_error(self):
        with pytest.raises(LLMAuthError):
            LLMClient(_provider("dummy-key").to_dict())

    def test_generator_style_config_includes_key_and_constructs(self):
        provider = _provider("dummy-key")
        config = provider.to_dict()
        config["api_key"] = provider.api_key
        client = LLMClient(config)
        assert client.provider_name == "dummy"
        assert client.model == "dummy-model"
        client.close()
