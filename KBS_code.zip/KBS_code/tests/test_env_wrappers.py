from __future__ import annotations

import copy
from typing import Any

import numpy as np
import pytest

from autocore.shaping.wrappers import RewardShapingWrapper
from autocore.shaping.potentials import PotentialFunction, ShapingConfig


class MockEnv:
    def __init__(self, n_agents: int = 3, n_landmarks: int = 3):
        self.possible_agents = [f"agent_{i}" for i in range(n_agents)]
        self.agents = list(self.possible_agents)
        self.n_agents = n_agents
        self.n_landmarks = n_landmarks
        self._step_count = 0
        self.unwrapped = self

        np.random.seed(42)
        self._agent_positions = np.random.uniform(-2.0, 2.0, (n_agents, 2)).astype(np.float64)
        self._landmark_positions = np.random.uniform(-2.0, 2.0, (n_landmarks, 2)).astype(np.float64)
        self._agent_velocities = np.zeros((n_agents, 2), dtype=np.float64)

        class Landmark:
            def __init__(self, pos):
                self.state = type("State", (), {"p_pos": pos.copy(), "p_vel": np.zeros(2)})()

        class Agent:
            def __init__(self, pos):
                self.state = type("State", (), {"p_pos": pos.copy(), "p_vel": np.zeros(2)})()

        self._world = type("World", (), {
            "agents": [Agent(self._agent_positions[i]) for i in range(n_agents)],
            "landmarks": [Landmark(self._landmark_positions[i]) for i in range(n_landmarks)],
        })()

    @property
    def world(self):
        return self._world

    def reset(self, seed=None, options=None):
        self._step_count = 0
        np.random.seed(seed if seed is not None else 42)
        self._agent_positions = np.random.uniform(-2.0, 2.0, (self.n_agents, 2)).astype(np.float64)
        self._agent_velocities = np.zeros((self.n_agents, 2), dtype=np.float64)
        for i, agent in enumerate(self._world.agents):
            agent.state.p_pos = self._agent_positions[i].copy()
            agent.state.p_vel = self._agent_velocities[i].copy()
        obs = {agent: np.zeros(10, dtype=np.float64) for agent in self.agents}
        return obs, {}

    def step(self, actions):
        self._step_count += 1
        for i, agent in enumerate(self._world.agents):
            self._agent_positions[i] += np.random.uniform(-0.1, 0.1, 2)
            agent.state.p_pos = self._agent_positions[i].copy()

        obs = {agent: np.zeros(10, dtype=np.float64) for agent in self.agents}
        rewards = {agent: -0.1 for agent in self.agents}
        terminations = {agent: False for agent in self.agents}
        truncations = {agent: self._step_count >= 100 for agent in self.agents}
        return obs, rewards, terminations, truncations, {}

    def close(self):
        pass


class MockEnvNoWorld:
    def __init__(self, n_agents: int = 2):
        self.possible_agents = [f"agent_{i}" for i in range(n_agents)]
        self.agents = list(self.possible_agents)
        self._step_count = 0
        self.unwrapped = self

    def reset(self, seed=None, options=None):
        self._step_count = 0
        obs = {agent: np.zeros(5, dtype=np.float64) for agent in self.agents}
        return obs, {}

    def step(self, actions):
        self._step_count += 1
        obs = {agent: np.zeros(5, dtype=np.float64) for agent in self.agents}
        rewards = {agent: 0.0 for agent in self.agents}
        terminations = {agent: False for agent in self.agents}
        truncations = {agent: self._step_count >= 50 for agent in self.agents}
        return obs, rewards, terminations, truncations, {}

    def close(self):
        pass


class TestRewardShapingWrapper:
    def test_wrap_mock_env_with_world(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        assert wrapper.agents == env.agents

    def test_reset_returns_obs_and_infos(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        obs, infos = wrapper.reset()
        assert isinstance(obs, dict)
        assert isinstance(infos, dict)

    def test_step_returns_shaped_rewards(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        wrapper.reset()
        obs, rewards, terms, truncs, infos = wrapper.step({a: np.zeros(2) for a in env.agents})
        assert isinstance(rewards, dict)
        for agent in env.agents:
            assert agent in rewards
            assert isinstance(rewards[agent], float)

    def test_shaped_reward_differs_from_base(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        wrapper.reset()

        base_rewards = {-0.1 for _ in env.agents}
        obs, rewards, _, _, _ = wrapper.step({a: np.zeros(2) for a in env.agents})

        is_different = False
        for reward in rewards.values():
            if reward != -0.1:
                is_different = True
                break
        assert is_different, "Shaped reward should differ from base reward"

    def test_wrapper_unwrapped_property(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        unwrapped = wrapper.unwrapped
        assert unwrapped is env

    def test_wrapper_close(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        wrapper.close()

    def test_wrapper_delegates_unknown_attr(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        assert wrapper.possible_agents == env.possible_agents

    def test_extract_state_from_world(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        state = wrapper._extract_state()
        assert "agent_positions" in state
        assert "landmark_positions" in state
        assert "agent_velocities" in state
        assert len(state["agent_positions"]) == 3
        assert len(state["landmark_positions"]) == 3

    def test_env_without_world(self, potential_function):
        env = MockEnvNoWorld(n_agents=2)
        wrapper = RewardShapingWrapper(env, potential_function)
        obs, infos = wrapper.reset()
        assert isinstance(obs, dict)
        obs, rewards, _, _, _ = wrapper.step({a: 0 for a in env.agents})
        assert isinstance(rewards, dict)

    def test_shaping_consistent_across_episodes(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)

        wrapper.reset()
        _, rewards1, _, _, _ = wrapper.step({a: np.zeros(2) for a in env.agents})

        wrapper.reset(seed=42)
        _, rewards2, _, _, _ = wrapper.step({a: np.zeros(2) for a in env.agents})

        for agent in env.agents:
            assert abs(rewards1[agent] - rewards2[agent]) < 1e-6

    def test_multiple_steps_accumulate_shaping(self, potential_function):
        env = MockEnv(n_agents=3, n_landmarks=3)
        wrapper = RewardShapingWrapper(env, potential_function)
        wrapper.reset()

        all_rewards = []
        for _ in range(10):
            _, rewards, terms, truncs, _ = wrapper.step({a: np.zeros(2) for a in env.agents})
            all_rewards.append(rewards)
            if any(truncs.values()):
                break

        assert len(all_rewards) > 0
