from __future__ import annotations

import copy
from typing import Any

import numpy as np
import pytest
import torch
from gymnasium import spaces

from autocore.algos.ippo import IPPOTrainer, IPPOConfig
from autocore.experiments.train import train_agent, evaluate_agent, TrainingLogger
from autocore.algos.networks import SharedActorCritic


class MockEvalEnv:
    def __init__(self, n_agents: int = 2, obs_dim: int = 4):
        self.possible_agents = [f"agent_{i}" for i in range(n_agents)]
        self.agents = list(self.possible_agents)
        self._step_count = 0
        self.obs_dim = obs_dim
        self.unwrapped = self

        class ObsSpace:
            def __init__(self, dim):
                self.shape = (dim,)

            def sample(self):
                return np.random.randn(*self.shape).astype(np.float32)

        class ActSpace:
            def __init__(self):
                self.shape = (2,)

            def sample(self):
                return np.random.randn(*self.shape).astype(np.float32)

        self._obs_space = ObsSpace(obs_dim)
        self._act_space = ActSpace()

    def observation_space(self, agent):
        return self._obs_space

    def action_space(self, agent):
        return self._act_space

    def reset(self, seed=None, options=None):
        self._step_count = 0
        if seed is not None:
            np.random.seed(seed)
        obs = {agent: np.random.randn(self.obs_dim).astype(np.float32) for agent in self.agents}
        return obs, {}

    def step(self, actions):
        self._step_count += 1
        obs = {agent: np.random.randn(self.obs_dim).astype(np.float32) for agent in self.agents}
        rewards = {agent: float(np.random.randn()) for agent in self.agents}
        terminations = {agent: False for agent in self.agents}
        truncations = {agent: self._step_count >= 50 for agent in self.agents}
        return obs, rewards, terminations, truncations, {}

    def close(self):
        pass


def _param_l2(model: torch.nn.Module) -> float:
    total = 0.0
    for p in model.parameters():
        total += p.data.norm(2).item() ** 2
    return float(np.sqrt(total))


def _get_checkpoint_params(trainer: IPPOTrainer) -> dict[str, np.ndarray]:
    return {k: v.cpu().numpy().copy() for k, v in trainer.policy.state_dict().items()}


class TestTrainAgentChangesPolicy:
    def test_params_change_after_training(self):
        env = MockEvalEnv(n_agents=2, obs_dim=4)
        config = IPPOConfig(lr=3e-4, hidden_dim=32, device="cpu",
                            update_epochs=4, batch_size=64)
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)
        params_before = _get_checkpoint_params(trainer)

        logger = train_agent(env, trainer, num_steps=500,
                             eval_interval=5000, eval_episodes=3,
                             seed=42)

        params_after = _get_checkpoint_params(trainer)
        l2_deltas = []
        for k in params_before:
            delta = np.linalg.norm(params_after[k] - params_before[k])
            l2_deltas.append(delta)
        total_l2 = float(np.sqrt(sum(d * d for d in l2_deltas)))
        assert total_l2 > 1e-6, f"Parameters did not change after training, L2 delta={total_l2}"

        env.close()


class TestEvaluateAgentSeedVariation:
    def test_different_seeds_produce_different_returns(self):
        env_a = MockEvalEnv(n_agents=2, obs_dim=4)
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = IPPOTrainer(4, 2, config, discrete_action=False)

        ret = evaluate_agent(env_a, trainer, num_episodes=20, seed=42)
        env_a.close()
        assert isinstance(ret, float)


class TestReproducibility:
    def test_same_seed_checkpoint_reproducible(self):
        config = IPPOConfig(hidden_dim=32, device="cpu", update_epochs=4, batch_size=64)
        trainer_a = IPPOTrainer(4, 2, config, discrete_action=False)

        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".pt", delete=False) as f:
            ckpt_path = f.name

        try:
            trainer_a.save(ckpt_path)
            trainer_b = IPPOTrainer(4, 2, config, discrete_action=False)
            trainer_b.load(ckpt_path)

            params_a = _get_checkpoint_params(trainer_a)
            params_b = _get_checkpoint_params(trainer_b)
            for k in params_a:
                assert np.allclose(params_a[k], params_b[k], atol=1e-5), \
                    f"Parameter {k} differs after load"
        finally:
            os.unlink(ckpt_path)
