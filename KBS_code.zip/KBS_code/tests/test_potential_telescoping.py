from __future__ import annotations

import math

import numpy as np
import pytest

from autocore.shaping.potentials import PotentialFunction, ShapingConfig, compute_potential


class TestTelescopingReward:
    def test_shaping_reward_matches_telescoping_formula(self, potential_function, mock_state, mock_state_far_apart):
        gamma = potential_function.config.gamma
        lamb = potential_function.config.shaping_lambda

        curr_pot = potential_function.compute_potential(mock_state)
        shaping = potential_function.compute_shaping_reward(mock_state, mock_state_far_apart)

        prev_pot = potential_function.compute_potential(mock_state_far_apart)
        expected = lamb * (gamma * curr_pot - prev_pot)

        assert math.isclose(shaping, expected, rel_tol=1e-9)

    def test_shaping_reward_zero_when_no_prev_state(self, potential_function, mock_state):
        shaping = potential_function.compute_shaping_reward(mock_state, None)
        assert shaping == 0.0

    def test_shaping_reward_zero_when_potentials_equal(
        self, compiler_output, shaping_config, mock_state
    ):
        pf = PotentialFunction(compiler_output, shaping_config)
        shaping = pf.compute_shaping_reward(mock_state, mock_state)
        curr_pot = pf.compute_potential(mock_state)
        gamma = shaping_config.gamma
        lamb = shaping_config.shaping_lambda
        expected = lamb * (gamma * curr_pot - curr_pot)
        assert math.isclose(shaping, expected, rel_tol=1e-9)

    def test_shaping_reward_scales_with_lambda(
        self, compiler_output, mock_state, mock_state_far_apart
    ):
        config1 = ShapingConfig(gamma=0.99, shaping_lambda=0.1)
        config2 = ShapingConfig(gamma=0.99, shaping_lambda=0.5)

        pf1 = PotentialFunction(compiler_output, config1)
        pf2 = PotentialFunction(compiler_output, config2)

        s1 = pf1.compute_shaping_reward(mock_state, mock_state_far_apart)
        s2 = pf2.compute_shaping_reward(mock_state, mock_state_far_apart)

        assert math.isclose(s2 / s1, 5.0, rel_tol=1e-9)

    def test_shaping_reward_scales_with_gamma(self, compiler_output, mock_state, mock_state_far_apart):
        config = ShapingConfig(gamma=0.5, shaping_lambda=1.0)
        pf = PotentialFunction(compiler_output, config)

        curr_pot = pf.compute_potential(mock_state)
        prev_pot = pf.compute_potential(mock_state_far_apart)
        shaping = pf.compute_shaping_reward(mock_state, mock_state_far_apart)

        expected = 1.0 * (0.5 * curr_pot - prev_pot)
        assert math.isclose(shaping, expected, rel_tol=1e-9)

    def test_reset_clears_prev_potential(self, potential_function, mock_state):
        potential_function._prev_potential = 5.0
        potential_function.reset()
        assert potential_function.prev_potential is None

    def test_prev_potential_property_get_set(self, potential_function):
        potential_function.prev_potential = 3.14
        assert potential_function.prev_potential == 3.14
        potential_function.prev_potential = None
        assert potential_function.prev_potential is None


class TestPotentialFunction:
    def test_compute_potential_clips_to_range(self, compiler_output, mock_state_far_apart):
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig
        config = ShapingConfig(gamma=0.99, shaping_lambda=0.1, potential_clip=(-0.5, 0.5))
        pf = PotentialFunction(compiler_output, config)
        val = pf.compute_potential(mock_state_far_apart)
        # effective clip for distance potentials is (-10, 10), so val should be within that
        clip_min, clip_max = PotentialFunction.get_effective_clip("negative_normalized_sum_min_distance")
        assert clip_min <= val <= clip_max, f"{val} should be in [{clip_min}, {clip_max}]"

    def test_compute_potential_finite_for_all_states(self, potential_function, mock_state, mock_state_far_apart, mock_state_near_landmarks, mock_collision_state):
        for state in [mock_state, mock_state_far_apart, mock_state_near_landmarks, mock_collision_state]:
            val = potential_function.compute_potential(state)
            assert math.isfinite(val)

    def test_shaping_config_rejects_invalid_gamma(self):
        with pytest.raises(ValueError):
            ShapingConfig(gamma=0.0)
        with pytest.raises(ValueError):
            ShapingConfig(gamma=-0.1)
        with pytest.raises(ValueError):
            ShapingConfig(gamma=1.5)

    def test_shaping_config_rejects_negative_lambda(self):
        with pytest.raises(ValueError):
            ShapingConfig(shaping_lambda=-0.1)

    def test_shaping_config_rejects_invalid_clip_range(self):
        with pytest.raises(ValueError):
            ShapingConfig(potential_clip=(1.0, -1.0))
        with pytest.raises(ValueError):
            ShapingConfig(potential_clip=(0.5, 0.5))

    def test_shaping_config_valid(self):
        config = ShapingConfig(gamma=0.99, shaping_lambda=0.1, potential_clip=(-1.0, 1.0))
        assert config.gamma == 0.99
        assert config.shaping_lambda == 0.1
        assert config.potential_clip == (-1.0, 1.0)

    def test_compute_potential_helper_function(self, compiler_output, shaping_config, mock_state):
        val = compute_potential(compiler_output, mock_state, shaping_config)
        assert math.isfinite(val)


class TestPotentialNearVsFar:
    def test_near_landmarks_lower_potential_magnitude(
        self, potential_function, mock_state_near_landmarks, mock_state_far_apart
    ):
        near_val = abs(potential_function.compute_potential(mock_state_near_landmarks))
        far_val = abs(potential_function.compute_potential(mock_state_far_apart))
        assert far_val > near_val, (
            f"Expected far state ({far_val:.4f}) to have larger magnitude "
            f"than near state ({near_val:.4f})"
        )

    def test_shaping_encourages_moving_toward_landmarks(
        self, potential_function, mock_state_far_apart, mock_state_near_landmarks
    ):
        far_pot = potential_function.compute_potential(mock_state_far_apart)
        near_pot = potential_function.compute_potential(mock_state_near_landmarks)
        shaping = potential_function.compute_shaping_reward(mock_state_near_landmarks, mock_state_far_apart)
        gamma = potential_function.config.gamma
        lamb = potential_function.config.shaping_lambda
        expected = lamb * (gamma * near_pot - far_pot)
        assert math.isclose(shaping, expected, rel_tol=1e-9)
