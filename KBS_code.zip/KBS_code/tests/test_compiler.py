from __future__ import annotations

import math

import numpy as np
import pytest

from autocore.dsl.compiler import CompilerOutput, compile_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary


class TestCompilerFinitePotentials:
    def test_total_potential_returns_finite_value(self, compiler_output, mock_state):
        val = compiler_output.total_potential(mock_state)
        assert isinstance(val, float)
        assert math.isfinite(val)

    def test_total_potential_finite_across_states(
        self, compiler_output, mock_state, mock_state_far_apart, mock_state_near_landmarks
    ):
        for state in [mock_state, mock_state_far_apart, mock_state_near_landmarks]:
            val = compiler_output.total_potential(state)
            assert math.isfinite(val), f"Non-finite potential in state"

    def test_total_potential_differs_across_states(
        self, compiler_output, mock_state_far_apart, mock_state_near_landmarks
    ):
        val_far = compiler_output.total_potential(mock_state_far_apart)
        val_near = compiler_output.total_potential(mock_state_near_landmarks)
        assert abs(val_far - val_near) > 0.0, "Potential should differ between states"

    def test_subgoal_functions_return_finite_values(self, compiler_output, mock_state):
        for i, fn in enumerate(compiler_output.subgoal_functions):
            val = fn(mock_state)
            assert math.isfinite(float(val)), f"Subgoal {i} returned non-finite value: {val}"


class TestCompilerPredicateTypes:
    def test_min_distance_landmark_coverage(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_normalized_sum_min_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_mean_distance_to_nearest_landmark(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "mean_distance_to_nearest_landmark", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_max_uncovered_landmark_distance(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "max_uncovered_landmark_distance", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_pairwise_agent_distance(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "pairwise_agent_distance", "args": {"agent_key": "agent_positions", "aggregation": "mean"}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_collision_count_or_margin_margin_mode(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "collision_count_or_margin", "args": {"agent_key": "agent_positions", "mode": "margin", "collision_threshold": 0.5}},
            "potential": {"type": "collision_margin_bonus"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_collision_count_or_margin_count_mode(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "collision_count_or_margin", "args": {"agent_key": "agent_positions", "mode": "count", "collision_threshold": 0.5}},
            "potential": {"type": "collision_margin_bonus"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_coverage_entropy_or_balance(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "coverage_entropy_or_balance", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "balanced_coverage", "threshold": 1.0},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)

    def test_agent_target_assignment_distance(self, predicate_library, potential_library, mock_state):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "agent_target_assignment_distance", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl, predicate_library, potential_library)
        val = out.total_potential(mock_state)
        assert math.isfinite(val)


class TestCompilerWeightedSum:
    def test_weighted_sum_uses_weights_from_meta(self, compiler_output):
        meta = compiler_output.meta
        assert "weights" in meta
        assert len(meta["weights"]) == len(compiler_output.subgoal_functions)

    def test_higher_weight_has_larger_contribution(self, predicate_library, potential_library, mock_state_near_landmarks):
        dsl_base = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg1", "scope": "global", "weight": 1.0,
            "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "negative_normalized_sum_min_distance"},
            "rationale": "r1",
        }, {
            "name": "sg2", "scope": "global", "weight": 10.0,
            "predicate": {"type": "pairwise_agent_distance", "args": {"agent_key": "agent_positions", "aggregation": "mean"}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "r2",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        out = compile_dsl(dsl_base, predicate_library, potential_library)
        val = out.total_potential(mock_state_near_landmarks)
        assert math.isfinite(val)
        assert out.meta["weights"] == [1.0, 10.0]

    def test_all_predicate_types_compile(self, dsl_dict_all_predicate_types, predicate_library, potential_library, mock_state):
        out = compile_dsl(dsl_dict_all_predicate_types, predicate_library, potential_library)
        assert len(out.subgoal_functions) == 5
        val = out.total_potential(mock_state)
        assert math.isfinite(val)


class TestCompilerErrors:
    def test_raises_on_unknown_predicate_type(self, predicate_library, potential_library):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "nonexistent_predicate", "args": {}},
            "potential": {"type": "negative_mean_distance"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        with pytest.raises(ValueError, match="Unknown predicate type"):
            compile_dsl(dsl, predicate_library, potential_library)

    def test_raises_on_unknown_potential_type(self, predicate_library, potential_library):
        dsl = {"task_name": "t", "version": "1.0", "description": "d", "subgoals": [{
            "name": "sg", "scope": "global", "weight": 1.0,
            "predicate": {"type": "min_distance_landmark_coverage", "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
            "potential": {"type": "nonexistent_potential"},
            "rationale": "test",
        }], "expected_effects": {"sample_efficiency": "x", "final_return": "y", "interpretability": "z"}}
        with pytest.raises(ValueError, match="Unknown potential type"):
            compile_dsl(dsl, predicate_library, potential_library)


class TestPotentialLibraryTypes:
    def test_negative_normalized_sum_min_distance(self, potential_library, mock_state):
        from autocore.dsl.predicates import PredicateLibrary
        pl = PredicateLibrary()
        pred_fn = pl.build("min_distance_landmark_coverage", {"agent_key": "agent_positions", "landmark_key": "landmark_positions"})
        pot_fn = potential_library.build("negative_normalized_sum_min_distance", pred_fn, clip=None, threshold=10.0)
        val = pot_fn(mock_state)
        assert math.isfinite(val)
        assert val <= 0.0

    def test_collision_margin_bonus(self, potential_library, mock_collision_state):
        from autocore.dsl.predicates import PredicateLibrary
        pl = PredicateLibrary()
        pred_fn = pl.build("collision_count_or_margin", {"agent_key": "agent_positions", "mode": "margin", "collision_threshold": 0.5})
        pot_fn = potential_library.build("collision_margin_bonus", pred_fn, clip=None, threshold=0.0)
        val = pot_fn(mock_collision_state)
        assert math.isfinite(val)

    def test_negative_mean_distance(self, potential_library, mock_state):
        from autocore.dsl.predicates import PredicateLibrary
        pl = PredicateLibrary()
        pred_fn = pl.build("mean_distance_to_nearest_landmark", {"agent_key": "agent_positions", "landmark_key": "landmark_positions"})
        pot_fn = potential_library.build("negative_mean_distance", pred_fn, clip=None, threshold=None)
        val = pot_fn(mock_state)
        assert math.isfinite(val)
        assert val <= 0.0

    def test_balanced_coverage(self, potential_library, mock_state):
        from autocore.dsl.predicates import PredicateLibrary
        pl = PredicateLibrary()
        pred_fn = pl.build("coverage_entropy_or_balance", {"agent_key": "agent_positions", "landmark_key": "landmark_positions"})
        pot_fn = potential_library.build("balanced_coverage", pred_fn, clip=None, threshold=1.0)
        val = pot_fn(mock_state)
        assert math.isfinite(val)
        assert 0.0 <= val <= 1.0
