from __future__ import annotations

import numpy as np
import pytest
from gymnasium import spaces

from autocore.algos.ippo import IPPOTrainer, IPPOConfig
from autocore.algos.heterogeneous import HeterogeneousTrainer, detect_agent_types
from autocore.algos.buffers import RolloutBuffer


class MockHeteroEnv:
    def __init__(self):
        self.possible_agents = ["agent_0", "agent_1"]
        self.agents = list(self.possible_agents)
        self._step_count = 0
        self.unwrapped = self

        class ObsSpaceA:
            shape = (6,)

        class ObsSpaceB:
            shape = (10,)

        class ActSpaceCont:
            shape = (2,)

        class ActSpaceDisc:
            n = 3
            shape = (1,)

        self._obs_spaces = {
            "agent_0": ObsSpaceA(),
            "agent_1": ObsSpaceB(),
        }
        self._act_spaces = {
            "agent_0": ActSpaceCont(),
            "agent_1": ActSpaceDisc(),
        }

    def observation_space(self, agent):
        return self._obs_spaces[agent]

    def action_space(self, agent):
        return self._act_spaces[agent]

    def reset(self, seed=None, options=None):
        self._step_count = 0
        if seed is not None:
            np.random.seed(seed)
        obs = {
            "agent_0": np.random.randn(6).astype(np.float32),
            "agent_1": np.random.randn(10).astype(np.float32),
        }
        return obs, {}

    def step(self, actions):
        self._step_count += 1
        obs = {
            "agent_0": np.random.randn(6).astype(np.float32),
            "agent_1": np.random.randn(10).astype(np.float32),
        }
        rewards = {a: float(np.random.randn() * 0.05) for a in self.agents}
        terminations = {a: False for a in self.agents}
        truncations = {a: self._step_count >= 30 for a in self.agents}
        return obs, rewards, terminations, truncations, {}

    def close(self):
        pass


class TestHeterogeneousEvalConsistency:
    def test_detect_agent_types_returns_correct_groups(self):
        env = MockHeteroEnv()
        type_map = detect_agent_types(env)
        assert len(type_map) == 2, f"Expected 2 agent types, got {len(type_map)}"
        type_names = list(type_map.keys())
        assert "agent_0" in type_names
        assert "agent_1" in type_names
        env.close()

    def test_hetero_trainer_created_with_per_type_networks(self):
        env = MockHeteroEnv()
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = HeterogeneousTrainer(env, config)
        assert trainer.is_heterogeneous is True
        assert len(trainer.trainers) == 2
        assert "agent_0" in trainer.trainers
        assert "agent_1" in trainer.trainers
        env.close()

    def test_hetero_get_action_returns_valid_outputs(self):
        env = MockHeteroEnv()
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = HeterogeneousTrainer(env, config)

        obs_a = np.random.randn(6).astype(np.float32)
        act_a, lp_a, val_a = trainer.get_action(obs_a, "agent_0")
        assert act_a is not None

        obs_b = np.random.randn(10).astype(np.float32)
        act_b, lp_b, val_b = trainer.get_action(obs_b, "agent_1")
        assert act_b is not None
        env.close()

    def test_hetero_training_loop_runs_without_error(self):
        env = MockHeteroEnv()
        config = IPPOConfig(lr=3e-4, hidden_dim=32, device="cpu",
                            update_epochs=2, batch_size=16)
        trainer = HeterogeneousTrainer(env, config)

        type_map = trainer.type_map
        buffers = {t: RolloutBuffer(num_agents=len(type_map[t].agent_names)) for t in type_map}

        for ep in range(3):
            result = env.reset(seed=42 + ep)
            obs, _ = result if isinstance(result, tuple) else (result, {})
            for b in buffers.values():
                b.reset()

            for _ in range(20):
                acts = {}
                for ag in env.agents:
                    ar, lp, v = trainer.get_action(obs.get(ag), ag)
                    t_name = trainer.agent_to_type[ag]
                    idx = type_map[t_name].agent_names.index(ag)
                    if trainer.trainers[t_name].discrete_action:
                        act = int(ar.item()) if hasattr(ar, 'item') else int(ar)
                    else:
                        act = np.squeeze(ar).astype(np.float32)
                    acts[ag] = act
                    buf = buffers[t_name]
                    try:
                        lp_val = float(np.squeeze(lp)[()]) if lp is not None else 0.0
                    except Exception:
                        lp_val = 0.0
                    try:
                        v_val = float(np.squeeze(v)[()]) if v is not None else 0.0
                    except Exception:
                        v_val = 0.0
                    buf.add(idx, obs.get(ag), acts[ag], lp_val, 0.0, v_val, 0.0)

                step_result = env.step(acts)
                obs = step_result[0]

            for t_name in type_map:
                buf = buffers[t_name]
                for ci in range(len(type_map[t_name].agent_names)):
                    if len(buf.obs[ci]) > 0:
                        buf.compute_gae(ci, 0.0, 0.99, 0.95)

            agents_per = {t: len(type_map[t].agent_names) for t in type_map}
            losses = trainer.update(buffers, agents_per)
            assert "policy_loss" in losses or any("policy_loss" in k for k in losses)

        env.close()

    def test_hetero_eval_with_both_agent_types(self):
        env = MockHeteroEnv()
        config = IPPOConfig(hidden_dim=32, device="cpu")
        trainer = HeterogeneousTrainer(env, config)

        returns = []
        for ep in range(5):
            result = env.reset(seed=42 + ep)
            obs, _ = result if isinstance(result, tuple) else (result, {})
            ep_r = 0.0
            for _ in range(30):
                acts = {}
                for ag in env.agents:
                    ar, _, _ = trainer.get_action(obs.get(ag), ag, deterministic=True)
                    t_name = trainer.agent_to_type[ag]
                    if trainer.trainers[t_name].discrete_action:
                        act = int(ar.item()) if hasattr(ar, 'item') else int(ar)
                    else:
                        act = np.squeeze(ar).astype(np.float32)
                    acts[ag] = act
                step_result = env.step(acts)
                obs, rewards, terms, truncs = step_result[0], step_result[1], step_result[2], step_result[3]
                ep_r += sum(rewards.values())
                all_done = all(terms.values()) or all(truncs.values())
                if all_done:
                    break
            returns.append(ep_r)

        assert len(returns) == 5
        assert all(np.isfinite(r) for r in returns)
        env.close()
