# CONFIRM_V3B_PROTOCOL — per-draw independent training blocks for the grounded contrasts

Frozen: 2026-10-10, **before any `confv3b_*` draw existed**; no amendment after the first summary.
Companion to `CONFIRM_V3_PROTOCOL.md` (does not replace or extend it; V3 is not extended to
significance).

## 0. Why this batch exists (the structure V3 did not fix)

Self-audited structure of the two earlier batches (from the runners, before seeing any V3B number):

- **E1** (`confv2_*`): each draw serves its own candidate pool (different temperatures per draw) and
  its own random-valid pool, but **all draws share one training-seed block** (probe 200–202, finals
  100–104), and the re-emitted candidate makes several draws share a trained model. Its dependence is
  disclosed and its caveat is stated.
- **V3** (`confv3_*`): candidate pools are the same five as E1's r0–r4 (cache-served), and **all five
  draws again share one training-seed block** (probe 300–302, finals 110–114). So within V3 the five
  draws differ **only** in the candidate/reference pools; their realised training outcomes repeat
  whenever a draw deploys the same candidate (visible as repeated per-draw values). The five
  differences are therefore **not five independent training units**.

V3B is the batch that closes this: **every draw gets its own probe and final seed block**, on top of
its own candidate pool.

## 1. Design (pre-registered)

| element | value |
| --- | --- |
| providers | `deepseek_v4_flash` and `gpt_6_astra` |
| tags | `confv3b_r0..r4` (DeepSeek), `confv3bgpt_r0..r4` (GPT-6 Astra) — five draws each |
| candidate pools | `--rep-offset 0..4` → the published r0–r4 pools (generation held fixed, cache-served; each draw a different pool) |
| **per-draw training blocks** | draw $i$ (0-based): probe seeds $300{+}3i, 301{+}3i, 302{+}3i$; final seeds $120{+}5i \ldots 124{+}5i$ |
| interface / pools | grounded (`--llm-v2`), $K_{\text{llm}}{=}12$, $K_{\text{raw}}{=}6$, $K_{\text{rand}}{=}12$ — unchanged |
| steps / env / learner | probe 50K, finals 300K; `simple_spread_v3`, IPPO, $N{=}3$ — unchanged |
| decision rule | the frozen deploy-or-abstain rule — unchanged |
| runner | `scripts/run_confirm_v3b.ps1` (idempotent, self-healing; log `artifacts/llm_proposal/confirm_v3b.log`) |

With per-draw seed blocks and per-draw pools, **the five draws are independent pipeline replicates**
(in the sampling sense: independent candidate pools, independent probe and final training, independent
reference draws). The only element shared with E1/V3 is the candidate-pool *procedure*, which is held
fixed by design.

## 2. Contrasts and analysis (frozen)

Same two primaries as V3: H1 DeepSeek, H2 GPT-6 Astra, `llm − rand` at the draw level; TOST $\pm20$
for `llm − hand`. Analysis suite unchanged (draw-level bootstrap; small-sample $t$; exact sign-flip
$p$; Holm over the two primaries only).

**Disclosed limitation, written before the run:** with five draws, an exact two-sided sign-flip test
has minimum attainable $p = 2/2^5 = 0.0625$, so the two-sided test cannot reach $0.05$ at this $n$.
The batch is therefore powered to *estimate* the contrast and its interval, not to certify a
two-sided significance claim; this is stated in the paper rather than worked around (no draw
extension to significance, no one-sided switch after the fact).

## 3. Interpretation rules (pre-registered)

- Run to completion (five draws per family); no interim changes, no dropped draw, no extension.
- **If H1/H2 hold** (bootstrap interval excludes zero): the paper states the contrast is reproduced
  under per-draw independent training blocks.
- **If they do not hold**: the paper states the contrast is **not confirmed** under either fresh
  batch, and the E1 separation remains a reported property of the E1 design; both negative outcomes
  are reported in full.
- The $\pm20$ hand-design equivalence is restated on this batch whichever way it falls.
- V3 and V3B are reported **separately** (they share candidate pools; pooling them would
  double-count); the paper's per-batch tables show both.

## 4. What this batch is not

Not an extension of V3, not a new method, not a new task, and not tuned: the pipeline, prompt, $K$
and rule are byte-identical to the published configuration; only the seed blocks differ.