# CONFIRM_V3_PROTOCOL — fresh-training confirmation of the grounded proposer contrasts

Frozen: 2026-10-09, **before any `confv3_*` draw existed**. Authors must not amend this file after
the first `confv3_*` summary lands; deviations go to `PROTOCOL_DEVIATIONS.tsv`.

## 1. Why this batch exists (the estimand it separates)

The published E1 confirmation (parts 36–37) pools **ten draws** per capable family, but the draws
share two sources of dependence: (a) within a family the proposer re-emits the **same deployed
candidate** in most draws, and (b) a re-emitted candidate trained on the **same final seeds** yields
the **same realised outcome**. The E1 estimate therefore mainly measures *candidate/reference
sampling* variation, not training variation. This was disclosed as a caveat; a KBS-level reviewer
will (correctly) ask for the missing estimand:

> Holding the candidate-generation procedure fixed, does the contrast survive **fresh probe and
> final-training randomness**?

CONFIRM_V3 estimates exactly that: **(i) the candidate draws are identical to the published
`confv2_r0..r4` / `confv2gpt_6_astra_r0..r4` draws** (served from the released cache — the
generation procedure is held fixed, no re-tuning), and **(ii) the probe and final training are
re-run with seeds never used before**. Nothing else changes.

## 2. Design (pre-registered)

| element | value |
| --- | --- |
| providers | `deepseek_v4_flash` (primary, was confirmatory in E1) and `gpt_6_astra` (was suggestive) |
| tags | `confv3_r0..r4` (DeepSeek), `confv3gpt_r0..r4` (GPT-6 Astra) — **five fresh draws each** |
| candidate draws | `--rep-offset 0..4` → the same candidate pools and the same random-valid pools as the published draws r0–r4 (cache hits; `gen_random_pool` is deterministic in the offset) |
| interface | grounded (`--llm-v2`), $K_{\text{llm}}{=}12$, $K_{\text{raw}}{=}6$, $K_{\text{rand}}{=}12$ — unchanged |
| **fresh probe seeds** | **300, 301, 302** (never used in any previous run) |
| **fresh final seeds** | **110, 111, 112, 113, 114** (never used in any previous run) |
| steps | probe 50K, finals 300K — unchanged |
| environment / learner | `simple_spread_v3`, IPPO, $N{=}3$ — unchanged |
| decision rule | the frozen deploy-or-abstain rule — unchanged |
| runner | `scripts/run_confirm_v3.ps1` (idempotent, self-healing; log `artifacts/llm_proposal/confirm_v3.log`) |

Because probe/final seeds are fresh, every arm in this batch (LLM, raw, random-valid, hand,
unshaped) is re-trained; the hand design's interval becomes **non-degenerate** here, which is the
second reason for the batch.

## 3. Contrasts and analysis (frozen; same suite as E1)

Two primary contrasts, one per model family:

- **H1 (DeepSeek):** grounded LLM $-$ random valid $> 0$ at the draw level.
- **H2 (GPT-6 Astra):** grounded LLM $-$ random valid $> 0$ at the draw level.

Analysis in this order, at the draw level (the draw is the unit; five clusters per family):

1. draw-level percentile bootstrap 95% CI (10,000 resamples);
2. small-sample $t$ interval and exact sign-flip $p$ (`--small-sample`), Holm-corrected across the
   two primaries only;
3. TOST $\pm20$ equivalence for LLM $-$ hand (the pre-stated bound of the paper).

Secondary (exploratory, reported with draw-level intervals only): LLM $-$ hand point contrast, the
raw-arm contrast, deployment/abstention events.

## 4. Interpretation rules (pre-registered, before any result is seen)

- The batch is run to completion (five draws per family); no interim peeking that changes anything,
  no extension to significance, no draw dropped.
- **If H1/H2 hold under fresh training randomness** (bootstrap CI excludes zero), the E1 verdict is
  *strengthened*: the paper states that the contrast survives fresh training randomness, and the
  dependence caveat narrows accordingly.
- **If H1/H2 do not hold**, the paper **narrows** the corresponding claim to the E1 estimand
  (candidate/reference sampling) and says so explicitly in the abstract-relevant sections; the
  negative outcome is reported in full.
- The \(\pm20\) equivalence verdict is re-stated on the fresh-training hand interval; if it fails,
  the equivalence claim is narrowed to the E1 estimand in the same way.
- Every number is regenerated from run records by `scripts/analyze_llm_proposal.py --small-sample`.

## 5. What this batch is not

It is **not** a new candidate-generation replication (the generation calls are held fixed and
cached, by design, to isolate the training-randomness estimand), not a model scan, and not a new
environment. Those are separate, later protocols (recorded in `NEXT_ACTION.md`).