# CONFIRM_PROTOCOL.md — pre-registered confirmation batch (E1)

Frozen: 2026-10-06, **before** any confirmatory draw is generated. Any change after this file is
written is a deviation and must be logged in the deviation table at the bottom.

The purpose of this batch is not to obtain a significant result. It is to make the paper's central
positive claim **robust under a small-sample analysis**, or to learn that it is not. Selecting draws,
models, tasks, thresholds or analysis variants by outcome is forbidden; every draw generated under
this protocol is analysed and reported.

## 1. Background and why the batch is needed

The current evidence is 4 draws (DeepSeek grounded) and 4 draws (GPT-6 Astra grounded) on
`simple_spread_v3`, N=3 IPPO. A reviewer recomputed the per-draw paired differences against random
valid and showed that the *draw-level percentile bootstrap* interval excludes zero while a
small-sample **t** interval does not:

| configuration | per-draw paired diff (LLM - random valid) | percentile cluster 95% CI | t 95% CI | exact sign-flip p |
| --- | --- | --- | --- | --- |
| DeepSeek grounded, K=12 | -2.95, +19.45, +48.24, +57.57 | [+8.25, +52.90] | [-13.4, +74.5] | 0.25 |
| GPT-6 Astra grounded, K=12 | +1.22, +48.76, +28.46, +17.66 | [+8.03, +40.98] | [-7.7, +55.7] | 0.125 |

With four draws the percentile bootstrap can under-cover, so the significance claim is
method-dependent. The existing four draws per family are therefore reclassified as **exploratory**.

## 2. Hypotheses (two primary, all else exploratory)

- **H1**: for DeepSeek under the grounded interface at K=12, the mean per-draw held-out raw-return
  gain over the random-valid arm is > 0.
- **H2**: the same for GPT-6 Astra.

Primary endpoint: the paired difference (LLM arm - random-valid arm) of the final raw return on the
five held-out seeds, **averaged within a draw**, so the draw is the independent unit.

Everything else (GLM, Gemini, Claude, the union, the ablation, the effort sweep, the second task,
N=5, MAPPO, SITL) is **exploratory** and is reported as such.

## 3. Required sample size (precision rationale, computed from the exploratory draws only)

Exploratory per-draw paired diffs for DeepSeek: -2.95, +19.45, +48.24, +57.57 (SD ~ 27; mean ~ +30.6).
A two-sided one-sample t test at alpha = 0.05 with 80% power needs n ~ (2.80 * 27 / 30.6)^2 ~ 6.1. We
therefore target **10 draws per family** (6 additional, added to the 4 exploratory ones, which are
kept and re-reported in the confirmatory table with their exploratory status flagged). Ten draws give
9 degrees of freedom, at which the t multiplier is 2.26 rather than 3.18 at n=4.

## 4. Frozen configuration (identical for every confirmatory draw)

| item | value |
| --- | --- |
| environment | `simple_spread_v3` |
| learner / team | IPPO, N = 3 |
| models | `deepseek_v4_flash` and `gpt_6_astra` |
| interface | grounded (`--llm-v2`), whitelist = the environment's allowed predicates/potentials |
| pool sizes | `--k-llm 12 --k-raw 6 --k-rand 12` |
| coefficient | `rho* = 0.2`, `lambda* = rho* E|R| / E|dPhi|`, applied per agent as `lambda*/N` |
| probe | 50 K steps, seeds 200, 201, 202 |
| finals | 300 K steps, seeds 100, 101, 102, 103, 104 |
| decision rule | frozen: rank by the raw-return probe; deploy iff the paired probe mean >= 0, else abstain |
| draw indices | `--rep-offset 4,5,6,7,8,9` (disjoint from the exploratory 0-3) |
| prompt template | v3 (unchanged) |
| code version | the commit at which this file is written; recorded in `EXPERIMENT_REGISTRY.tsv` |

No prompt, K, threshold, model alias, training length, task, seed window or analysis variant may be
changed once the first confirmatory draw exists.

## 5. Analysis (frozen; run once, after all draws exist)

1. Per-draw paired differences; report every draw point.
2. Report, side by side and never selectively: the draw-level percentile cluster bootstrap 95% CI,
   the small-sample t 95% CI, and the exact sign-flip p-value (with its exchangeability caveat).
3. Holm correction across the two primary hypotheses (H1, H2).
4. Leave-one-draw-out sensitivity.
5. Abstentions and failures are reported on the same footing; a refused deployment is a result, not a
   missing value.

## 6. Stopping and interpretation rules (frozen)

- The batch runs to its pre-set size. No interim significance check decides whether to continue.
- If both primaries survive the t analysis and Holm, the claim is stated as confirmatory.
- If they survive the bootstrap but not the t, the paper reports **both** and states the evidence as
  suggestive rather than confirmatory, and the abstract and highlights are downgraded accordingly.
- If they fail both, the interface claim is withdrawn to "grounding changes what is reachable" and the
  paper is repositioned as a measurement study.
- No additional draws are added to "reach significance".

## 7. Deviation log

| date | deviation | reason | before/after new data |
| --- | --- | --- | --- |
| — | none yet | — | — |
