"""Does a short training probe rank candidate configurations the same way the
full training budget does?

This is the question the selection stage of an automated shaping pipeline
depends on. Instead of fitting any offline proxy, it is measured directly by
reusing the evaluation curves already produced by the shaping experiments: every
configuration in those runs was evaluated every 10% of its budget, so the ranking
at an early checkpoint can be compared with the ranking at the full budget.

Reported per early budget fraction: Spearman rank correlation between the early
and final rankings, plus the regret of selecting by the early ranking against
selecting the best configuration with hindsight.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    denom = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / denom) if denom > 0 else float("nan")


def load_configs(tags: list[str]) -> dict[str, dict[int, list]]:
    """config label -> seed -> curve [(step, raw_return, sd), ...]"""
    out: dict[str, dict[int, list]] = {}
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        for r in raw:
            if r.get("status") != "completed":
                continue
            label = f"{tag}:{r['arm']}"
            out.setdefault(label, {})[r["seed"]] = r["curve"]
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", default="main,sweep")
    ap.add_argument("--fractions", default="0.1,0.2,0.3,0.5")
    args = ap.parse_args()

    configs = load_configs([t for t in args.tags.split(",") if t])
    if not configs:
        raise SystemExit("no completed runs found")

    lengths = [len(c) for per_seed in configs.values() for c in per_seed.values()]
    n_points = min(lengths)
    print(f"configurations: {len(configs)}  evaluation points per curve (min): {n_points}")
    print("(each unit below is one configuration; values are averaged over its seeds)\n")

    final = {k: float(np.mean([c[-1][1] for c in v.values()])) for k, v in configs.items()}
    labels = sorted(configs, key=lambda k: -final[k])
    print(f"{'rank':>4s} {'configuration':<28s} {'final':>9s}")
    for i, k in enumerate(labels):
        print(f"{i + 1:>4d} {k:<28s} {final[k]:>9.2f}")

    fractions = [float(f) for f in args.fractions.split(",")]
    print(f"\n{'early budget':>13s} {'Spearman':>9s} {'pick':<28s} {'picked':>9s} "
          f"{'oracle':>9s} {'regret':>8s}")
    rows = []
    for frac in fractions:
        idx = max(0, int(round(frac * (n_points - 1))))
        early = {k: float(np.mean([c[idx][1] for c in v.values()]))
                 for k, v in configs.items()}
        keys = labels
        e = np.asarray([early[k] for k in keys])
        fv = np.asarray([final[k] for k in keys])
        rho = spearman(e, fv)
        pick = keys[int(np.argmax(e))]
        best = keys[int(np.argmax(fv))]
        regret = final[best] - final[pick]
        rows.append({"fraction": frac, "eval_index": idx, "spearman": rho,
                     "picked": pick, "picked_return": final[pick],
                     "oracle": best, "oracle_return": final[best], "regret": regret,
                     "n_configs": len(keys)})
        print(f"{frac:>13.0%} {rho:>9.3f} {pick:<28s} {final[pick]:>9.2f} "
              f"{final[best]:>9.2f} {regret:>+8.2f}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "selection_fidelity.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"configs": labels, "final": final, "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
