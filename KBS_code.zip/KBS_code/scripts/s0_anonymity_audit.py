"""S0-7: double-anonymous audit for the IEEE TAI submission (main + supplement)."""
from __future__ import annotations

import glob
import os
import re

PAPER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "paper")
os.chdir(PAPER)

TERMS = [
    "github", "gitlab", "zenodo", "bitbucket", "http://", "https://", "www.",
    "acknowledg", "funding", "grant no", "our prior", "our conference",
    "our earlier paper", "autocore", "ictai", "anonymous authors",
    "double-blind", "we previously",
]

FILES = sorted(glob.glob("sections/*.tex")) + ["main.tex", "supplement.tex"]

print("=" * 90)
print("source scan (author-identifying / non-anonymous strings)")
print("=" * 90)
hits = 0
for f in FILES:
    if not os.path.exists(f):
        continue
    txt = open(f, encoding="utf-8").read()
    for term in TERMS:
        for m in re.finditer(re.escape(term), txt, re.I):
            a = max(0, m.start() - 70)
            b = min(len(txt), m.end() + 70)
            snippet = txt[a:b].replace("\n", " ")
            print(f"  {f:<24s} [{term}]  ...{snippet}...")
            hits += 1
print(f"  -> {hits} hit(s)")

print()
print("=" * 90)
print("PDF metadata (pdftrailer) — check for author/tool leakage")
print("=" * 90)
for pdf in ("main.pdf", "supplement.pdf"):
    if not os.path.exists(pdf):
        continue
    raw = open(pdf, "rb").read()
    for key in (b"/Author", b"/Title", b"/Creator", b"/Producer", b"/Subject"):
        for m in re.finditer(re.escape(key) + rb"\s*\(([^)]{0,200})\)", raw):
            print(f"  {pdf} {key.decode()}: {m.group(1)[:160]!r}")
    # XMP packet
    for m in re.finditer(rb"<dc:creator>.*?</dc:creator>", raw, re.S):
        print(f"  {pdf} XMP dc:creator: {m.group(0)[:160]!r}")
print("  (a PDF with no /Author and an anonymous title is the requirement)")
