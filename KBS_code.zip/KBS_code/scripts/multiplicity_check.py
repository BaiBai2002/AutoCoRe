"""Does the one positive result survive a multiplicity correction?

The paper reports several settings and does not select on significance. This script
is the honest sensitivity check: it recomputes the rich-pool pipeline's paired
budget-matched gain at the Bonferroni-adjusted level (alpha / 7, one per reported
setting) so the reader can see how fragile the single positive result is.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from plot_budget_flip import OUTDIR, bootstrap_ci, per_seed_values, prefix  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default=os.path.join(OUTDIR, "bps_n3_rho020_summary.json"),
                    help="deployment summary with a budget-matched baseline")
    ap.add_argument("--bm-steps", type=int, default=None,
                    help="override the budget-matched baseline budget (e.g. the "
                         "stricter 490000 charge) and recompute the intervals")
    args = ap.parse_args()

    with open(args.summary, encoding="utf-8") as f:
        s = json.load(f)
    seeds = [int(x) for x in s["final_seeds"]]
    bm = s["budget_matched_baseline"]
    bm_steps = args.bm_steps or bm["steps"]
    # Prefer the step-specific key; the bare ``base_bm`` name is a legacy alias
    # that may hold a run trained to a *different* budget.
    bm_key = prefix(s, f"base_bm{bm_steps}")
    if not os.path.exists(os.path.join(OUTDIR, f"{bm_key}_s{seeds[0]}.json")):
        bm_key = prefix(s, "base_bm")

    bmv = per_seed_values(bm_key, seeds)
    if not bmv:
        raise SystemExit(f"no budget-matched runs at {bm_steps} steps")
    diffs = []
    for d in s["decisions"]:
        if not d.get("gate_choice"):
            continue
        v = per_seed_values(prefix(s, d["gate_choice"]["key"]), seeds)
        for sd in seeds:
            if sd in v and sd in bmv:
                diffs.append(v[sd] - bmv[sd])
    diffs = np.asarray(diffs, dtype=float)
    print(f"{os.path.basename(args.summary)}: {diffs.size} paired seed-replicates, "
          f"budget-matched baseline at {bm_steps} steps "
          f"({bm_steps / s['final_steps']:.2f}x)\n")
    for label, alpha in (("uncorrected", 0.05), ("Bonferroni (x7)", 0.05 / 7)):
        m, lo, hi = bootstrap_ci(diffs, alpha=alpha)
        excl = "yes" if (lo > 0 or hi < 0) else "no"
        print(f"{label:<18s} mean {m:+8.2f}  {100 * (1 - alpha):5.1f}% CI "
              f"[{lo:+.2f}, {hi:+.2f}]  excludes 0: {excl}")


if __name__ == "__main__":
    main()
