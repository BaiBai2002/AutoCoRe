"""Formal evaluation of budgeted potential shaping with conservative gating.

The pipeline under test is:

    calibrate -> propose candidates -> short paired probe -> gate -> final training

and it is compared against unshaped training and against non-adaptive baselines
at a strictly matched total interaction budget. Random sources are separated
into disjoint roles so that the deployment decision is never informed by the
held-out evaluation:

* ``pipeline_seed``      candidate generation and probe-seed choice
* ``probe seeds``        short paired probes, drawn from a development pool
* ``final seeds``        held-out training seeds, disjoint from probe seeds
* ``evaluation seeds``   fixed inside the trainer, shared by every arm

A *pipeline replicate* is one independent run of the whole pipeline; five of
them are reported separately rather than treating many final seeds of a single
selected candidate as replicates.

Every executed run is cached to disk by a content hash, and every arm is
charged for the interactions it actually consumes, so the budget ledger can be
recomputed from the logs.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.selection.landscape_search import (
    FeatureBank, LinearPotential, one_hot_directions, sample_directions,
)
from autocore.selection.magnitude_calibration import (
    collect_reference_states, estimate_scales,
)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
TRAIN = os.path.join(PROJECT_ROOT, "scripts", "stage0_train.py")

NUM_ENVS = 16
HORIZON = 80

# Appended to every run id. This is the mechanism that keeps runs produced under
# a different calibration target (or any other global setting that the run id
# does not otherwise encode) in separate cache slots, so protocol rule P6 holds
# when a setting is ablated.
RUN_TAG = ""


def realized_steps(steps: int) -> int:
    """Actual steps a stage0_train run with this nominal budget will execute.

    The trainer performs ``steps // (num_envs * horizon)`` policy updates and
    reports the product, so the realised count is a multiple of the rollout
    size and is generally smaller than the nominal budget.
    """
    unit = NUM_ENVS * HORIZON
    return max(1, int(steps) // unit) * unit


def weight_key(w: np.ndarray) -> str:
    payload = ",".join(f"{v:.6f}" for v in np.asarray(w, dtype=float).reshape(-1))
    return hashlib.md5(payload.encode()).hexdigest()[:12]


def prefix_of(env: str, algo: str, num_agents: int | None, kind: str, key: str) -> str:
    n = "na" if num_agents is None else str(num_agents)
    tag = f"_{RUN_TAG}" if RUN_TAG else ""
    return f"{env.replace('/', '-')}_{algo}_N{n}_{kind}_{key}{tag}"


def run_id(env: str, algo: str, num_agents: int | None, kind: str,
           key: str, seed: int) -> str:
    return f"{prefix_of(env, algo, num_agents, kind, key)}_s{seed}"


def cache_valid(rec: dict, env: str, algo: str, num_agents: int | None,
                steps: int, max_cycles: int) -> bool:
    """Is a cached record reusable for this exact configuration? (P6)

    A cached run may only be reused if it was produced by *the same
    configuration*. Two omissions here each caused a silent error in this study:
    the step count was not checked (an 11.5K smoke run was served as a 300K
    baseline) and the learner was not checked on the legacy path (a MAPPO job
    reused IPPO probe scores). The run id does not encode the horizon either, so
    it is checked too. This is the single place that decides cache reuse, and it
    is what the P0 property test exercises.
    """
    try:
        if int(rec.get("steps", -1)) != realized_steps(steps):
            return False
        if (rec.get("env") != env or rec.get("algo") != algo
                or rec.get("num_agents") != num_agents
                or int(rec.get("max_cycles", -1)) != int(max_cycles)):
            return False
        return "final_return" in rec
    except Exception:
        return False


def train(env: str, algo: str, num_agents: int | None, steps: int, seed: int,
          weights: np.ndarray | None, rid: str, rho_target: float,
          reward_scale: float = 1.0, lam: float | None = None,
          hidden: int = 512, dsl: str | None = None,
          max_cycles: int = 80, legacy_rid: str | None = None) -> float | None:
    out = os.path.join(OUTDIR, f"{rid}.json")
    # A run id must encode everything that changes the result. Probe and screen
    # ids historically omitted the environment, so two families shared a cache
    # slot and silently overwrote each other. New ids are namespaced by
    # environment; ``legacy_rid`` is consulted only as a read-only fallback so
    # that pre-existing per-family caches are still honoured.
    lookup = [out]
    # ``legacy_rid`` is a read-only fallback for pre-existing caches written
    # before run ids were namespaced by environment. It must never be consulted
    # for a *tagged* run: a tag exists precisely because the configuration (in
    # practice the calibration target, hence lambda) differs from the untagged
    # one, and the recorded step count does not detect that difference. Letting a
    # tagged run read the legacy slot would silently reuse probe scores measured
    # at another coefficient.
    if legacy_rid and not RUN_TAG:
        lookup.append(os.path.join(OUTDIR, f"{legacy_rid}.json"))
    for path in lookup:
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                cached = json.load(f)
            # A cached run may only be reused if it was produced by *the same
            # configuration*. Two omissions here each caused a silent error: the
            # step count was not checked (an 11.5K smoke run was served as a 300K
            # baseline) and the learner was not checked on the legacy path (a
            # MAPPO job reused IPPO probe scores). The run id does not encode the
            # horizon either, so it is checked too.
            if not cache_valid(cached, env, algo, num_agents, steps, max_cycles):
                continue
            return float(cached["final_return"])
        except Exception:
            continue
    cmd = [sys.executable, "-u", TRAIN, "--env", env, "--steps", str(steps),
           "--eval-every", str(max(steps // 8, 5000)), "--seed", str(seed),
           "--hidden", str(hidden), "--entropy", "0.003", "--epochs", "8",
           "--minibatches", "8", "--algo", algo, "--out", out, "--tag", rid,
           "--rho-target", str(rho_target), "--max-cycles", str(max_cycles)]
    if num_agents is not None:
        cmd += ["--num-agents", str(num_agents)]
    if dsl:
        cmd += ["--dsl", dsl]
        if lam is not None:
            cmd += [f"--lam={lam:.6f}"]
    elif weights is not None:
        cmd += ["--feature-weights=" + ",".join(f"{w:.8f}" for w in weights)]
        if lam is not None:
            cmd += [f"--lam={lam:.6f}"]
    if reward_scale != 1.0:
        cmd += ["--reward-scale", str(reward_scale)]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    if proc.returncode != 0 or not os.path.exists(out):
        sys.stderr.write(f"run failed {rid}: {(proc.stderr or '')[-200:]}\n")
        return None
    try:
        with open(out, encoding="utf-8") as f:
            return float(json.load(f)["final_return"])
    except Exception:
        return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--algo", default="ippo")
    ap.add_argument("--num-agents", type=int, default=None)
    ap.add_argument("--random-candidates", type=int, default=6)
    ap.add_argument("--sparse-prob", type=float, default=0.4)
    ap.add_argument("--probe-steps", type=int, default=50_000)
    ap.add_argument("--probe-pool", default="200,201,202,203,204")
    ap.add_argument("--probe-draws", type=int, default=3)
    ap.add_argument("--final-steps", type=int, default=300_000)
    ap.add_argument("--final-seeds", default="100,101,102,103,104,105,106,107,108,109")
    ap.add_argument("--replicates", type=int, default=3)
    ap.add_argument("--rho-target", type=float, default=0.2)
    ap.add_argument("--z", type=float, default=0.5)
    ap.add_argument("--bm-steps", type=int, default=0,
                    help="also train an unshaped baseline for this many steps per seed, "
                         "to match the pipeline's total interaction budget")
    ap.add_argument("--bm-auto", action="store_true",
                    help="derive bm-steps from the realised search overhead")
    ap.add_argument("--pool-filter", default="all", choices=["all", "axis"],
                    help="restrict the candidate pool (axis = single primitives only)")
    ap.add_argument("--schedule", default="flat", choices=["flat", "halving"],
                    help="flat = probe every candidate equally; halving = cheap screen then deepen")
    ap.add_argument("--screen-steps", type=int, default=15_000)
    ap.add_argument("--screen-keep", type=float, default=0.3)
    ap.add_argument("--screen-seed", type=int, default=210)
    ap.add_argument("--bm-scope", default="per-replicate", choices=["per-replicate", "total"],
                    help="amortise the search cost over pipeline replicates, or charge all of it once")
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--aligned-axis", default="agent_target_assignment_distance",
                    help="axis direction used as the task-aligned reference; falls back to "
                         "the first axis for families without that feature (e.g. SISL)")
    ap.add_argument("--dsl", default=None,
                    help="hand-designed DSL potential to final-train alongside the pool")
    ap.add_argument("--final-all-pool", action="store_true",
                    help="final-train EVERY candidate in the pool on the held-out seeds, "
                         "not only the deployed ones; removes the selection bias in the "
                         "probe-fidelity analysis and widens the oracle")
    ap.add_argument("--tag", default="bps")
    ap.add_argument("--run-tag", default="",
                    help="suffix appended to every run id; use it when ablating a "
                         "global setting (e.g. --rho-target) so caches stay separate (P6)")
    ap.add_argument("--pipeline-seed-offset", type=int, default=0,
                    help="shift the replicate seeds. The pool primitives, task, "
                         "hyper-parameters and held-out seeds stay frozen, but a "
                         "non-zero offset redraws the random candidate directions, "
                         "the probe-seed draws and the replicate labels. This is the "
                         "mechanism used for the P6 independent confirmation, so the "
                         "confirmatory chain shares no pipeline randomness with the "
                         "exploratory one.")
    args = ap.parse_args()

    global RUN_TAG
    RUN_TAG = args.run_tag
    # NOTE (P6-class collision, found 2026-09-28): ``--tag`` names only the *summary* file; it is
    # NOT part of the run ids, so two runs that differ in ``--tag`` but share an empty ``--run-tag``
    # write to the *same* cached probe/final records and silently overwrite each other. This bit us
    # when attempting a controlled probe-budget sweep (see workplan/decision_log.md D34). We warn
    # loudly instead of failing, so that the historically documented commands keep working.
    if not RUN_TAG and args.tag not in ("", "bps"):
        print("WARNING: --tag names the summary but does NOT namespace run ids. Cached "
              "probe/final records are SHARED with every other run that has an empty --run-tag, "
              "so runs that differ only in a global setting (e.g. the probe budget) will overwrite "
              "each other (P6-class collision). Pass --run-tag <name> to isolate this run.",
              flush=True)

    os.makedirs(OUTDIR, exist_ok=True)
    probe_pool = [int(s) for s in args.probe_pool.split(",")]
    final_seeds = [int(s) for s in args.final_seeds.split(",")]
    assert not (set(probe_pool) & set(final_seeds)), "probe and final seeds must be disjoint"

    from autocore.envs.vec_pz import PZ_ENV_IDS
    pz_family = args.env in PZ_ENV_IDS
    if pz_family:
        from autocore.selection.obs_features import build_obs_bank
        bank = build_obs_bank(args.env, max_cycles=args.max_cycles, n_episodes=6,
                              seed=args.seed)
    else:
        states = collect_reference_states(args.env, max_cycles=args.max_cycles,
                                          n_episodes=6, seed=args.seed,
                                          num_agents=args.num_agents)
        bank = FeatureBank().fit(states)
    axis = one_hot_directions(bank)
    axis_names = list(axis)
    aligned_name = args.aligned_axis if args.aligned_axis in axis else axis_names[0]
    print(f"family={'pz' if pz_family else 'mpe'}  bank dim={bank.dim}  "
          f"axis candidates={len(axis)}  aligned axis={aligned_name}")

    replicates: list[dict] = []
    for p in range(args.replicates):
        ps = args.pipeline_seed_offset + p
        rng = np.random.default_rng(10_000 + ps)
        pool = [{"name": f"axis:{n}", "weights": w} for n, w in axis.items()]
        if args.pool_filter == "all":
            for i, w in enumerate(sample_directions(args.random_candidates, bank.dim, rng,
                                                    sparse_prob=args.sparse_prob)):
                pool.append({"name": f"r{p}:{i}", "weights": w})
        probe_seeds = sorted(rng.choice(probe_pool, size=args.probe_draws,
                                        replace=False).tolist())
        replicates.append({"pipeline_seed": ps, "pool": pool,
                           "probe_seeds": [int(s) for s in probe_seeds]})

    unique: dict[str, dict] = {}
    for r in replicates:
        for c in r["pool"]:
            unique.setdefault(weight_key(c["weights"]), {"name": c["name"],
                                                         "weights": c["weights"]})
    print(f"replicates={len(replicates)}  distinct candidates={len(unique)}")

    def run_jobs(jobs, steps, label):
        cache: dict[str, dict[int, float]] = {}

        def task(job):
            rid, seed, w, key, legacy = job
            return key, seed, train(args.env, args.algo, args.num_agents, steps, seed, w,
                                    rid, args.rho_target, max_cycles=args.max_cycles,
                                    legacy_rid=legacy)

        with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
            for key, seed, val in pool.map(task, jobs):
                if val is not None:
                    cache.setdefault(key, {})[seed] = val
        print(f"  {label}: {len(jobs)} runs x {steps} steps", flush=True)
        return cache

    all_probe_seeds = sorted(set(sum([r["probe_seeds"] for r in replicates], [])))
    base_probe = run_jobs(
        [(prefix_of(args.env, args.algo, args.num_agents, "probe", "base") + f"_s{s}",
          s, None, "base", f"probe_base_s{s}") for s in all_probe_seeds],
        args.probe_steps, "baseline probes").get("base", {})
    if not base_probe:
        raise SystemExit("no baseline probe succeeded")

    kept: dict[int, list[str]] = {}
    screen_total = 0
    if args.schedule == "halving":
        screen_jobs = [(prefix_of(args.env, args.algo, args.num_agents, "screen", k)
                        + f"_s{args.screen_seed}", args.screen_seed,
                        unique[k]["weights"], k, f"screen_{k}_s{args.screen_seed}")
                       for k in unique]
        screen = run_jobs(screen_jobs, args.screen_steps, "stage-1 screening")
        screen_total = len(screen_jobs) * args.screen_steps
        for r in replicates:
            pool_keys = [weight_key(c["weights"]) for c in r["pool"]]
            ranked = sorted(pool_keys,
                            key=lambda k: -screen.get(k, {}).get(args.screen_seed, -np.inf))
            n_keep = max(2, int(np.ceil(args.screen_keep * len(pool_keys))))
            kept[r["pipeline_seed"]] = ranked[:n_keep]
        print(f"  stage 1 keeps {sum(len(v) for v in kept.values())} candidate-replicate "
              f"pairs ({args.screen_keep:.0%} of each pool)", flush=True)
    else:
        for r in replicates:
            kept[r["pipeline_seed"]] = [weight_key(c["weights"]) for c in r["pool"]]

    stage2_jobs = []
    for r in replicates:
        for key in kept[r["pipeline_seed"]]:
            for s in r["probe_seeds"]:
                stage2_jobs.append((prefix_of(args.env, args.algo, args.num_agents, "probe", key)
                                    + f"_s{s}", s, unique[key]["weights"], key,
                                    f"probe_{key}_s{s}"))
    stage2_jobs = list({j[0]: j for j in stage2_jobs}.values())
    stage2 = run_jobs(stage2_jobs, args.probe_steps, "stage-2 probes")
    probe_cache: dict[str, dict[int, float]] = {"base": base_probe}
    for k, v in stage2.items():
        probe_cache.setdefault(k, {}).update(v)
    search_total = screen_total + len(stage2_jobs) * args.probe_steps
    print(f"  search cost: screening {screen_total} + probes "
          f"{len(stage2_jobs) * args.probe_steps} = {search_total} interactions", flush=True)

    decisions = []
    for r in replicates:
        base = probe_cache["base"]
        scored = []
        for key in kept[r["pipeline_seed"]]:
            c = unique[key]
            got = probe_cache.get(key, {})
            seeds = [s for s in r["probe_seeds"] if s in got and s in base]
            if len(seeds) < 2:
                continue
            d = np.asarray([got[s] - base[s] for s in seeds], dtype=float)
            lcb = float(d.mean() - args.z * d.std(ddof=1) / np.sqrt(len(seeds)))
            w = c["weights"]
            scored.append({"key": key, "name": c["name"],
                           "weights": w.tolist() if hasattr(w, "tolist") else list(w),
                           "probe_mean_gain": float(d.mean()), "probe_lcb": lcb,
                           "n": len(seeds)})
        scored.sort(key=lambda x: -x["probe_lcb"])
        top = scored[0] if scored else None
        chosen = top if top and top["probe_lcb"] > 0 else None
        rng = np.random.default_rng(50_000 + r["pipeline_seed"])
        else_key = weight_key(r["pool"][int(rng.integers(0, len(r["pool"])))]["weights"])
        reco = {"key": else_key, "name": unique[else_key]["name"],
                "weights": unique[else_key]["weights"].tolist()
                if hasattr(unique[else_key]["weights"], "tolist")
                else list(unique[else_key]["weights"])}
        decisions.append({"replicate": r["pipeline_seed"],
                          "probe_seeds": r["probe_seeds"],
                          "kept": kept[r["pipeline_seed"]],
                          "top_by_probe": top,
                          "gate_deployed": chosen is not None,
                          "gate_choice": chosen,
                          "random_choice": reco,
                          "probe_table": scored})

    for d in decisions:
        nm = d["gate_choice"]["name"] if d["gate_choice"] else "FALLBACK(base)"
        rn = d["random_choice"]["name"] if d["random_choice"] else "-"
        print(f"  replicate {d['replicate']}: gate -> {nm:<34s} random-k -> {rn}")

    aligned_key = weight_key(axis[aligned_name])
    need: dict[str, dict] = {}
    for d in decisions:
        if d["gate_choice"]:
            need[d["gate_choice"]["key"]] = {"name": d["gate_choice"]["name"],
                                             "weights": d["gate_choice"]["weights"]}
        if d["random_choice"]:
            need[d["random_choice"]["key"]] = {"name": d["random_choice"]["name"],
                                               "weights": d["random_choice"]["weights"]}
    need[aligned_key] = {"name": f"task_aligned({aligned_name})",
                         "weights": axis[aligned_name].tolist()}
    if args.final_all_pool:
        before = len(need)
        for k, c in unique.items():
            need.setdefault(k, {"name": c["name"], "weights": c["weights"]})
        print(f"final-all-pool: expanded final-training set from {before} to {len(need)} "
              f"configurations (removes selection bias in the fidelity analysis)")
    print(f"final-training {len(need)} distinct configurations "
          f"+ baseline on {len(final_seeds)} held-out seeds")

    base_prefix = prefix_of(args.env, args.algo, args.num_agents, "final", "base")
    dsl_specs = {"hand_designed_semantic_dsl": args.dsl} if args.dsl else {}
    final_jobs: list[tuple] = []
    for s in final_seeds:
        rid = run_id(args.env, args.algo, args.num_agents, "final", "base", s)
        final_jobs.append((rid, s, None, base_prefix, 1.0, None))
    for key, c in need.items():
        w = np.asarray(c["weights"], dtype=float)
        pfx = prefix_of(args.env, args.algo, args.num_agents, "final", key)
        for s in final_seeds:
            final_jobs.append((run_id(args.env, args.algo, args.num_agents, "final", key, s),
                               s, w, pfx, 1.0, None))
    for name, path in dsl_specs.items():
        pfx = prefix_of(args.env, args.algo, args.num_agents, "final", name)
        for s in final_seeds:
            final_jobs.append((run_id(args.env, args.algo, args.num_agents, "final", name, s),
                               s, None, pfx, 1.0, path))

    finals: dict[str, dict[int, float]] = {}

    def do_final(job):
        rid, seed, w, pfx, scale, dsl = job
        val = train(args.env, args.algo, args.num_agents, args.final_steps, seed, w,
                    rid, args.rho_target, reward_scale=scale, dsl=dsl,
                    max_cycles=args.max_cycles)
        return pfx, seed, val

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for pfx, seed, val in pool.map(do_final, final_jobs):
            if val is not None:
                finals.setdefault(pfx, {})[seed] = val

    base_by_seed = {s: v for s, v in finals.get(base_prefix, {}).items()}
    if not base_by_seed:
        raise SystemExit("baseline final runs missing")

    def mean_of(pfx):
        vals = [v for s, v in finals.get(pfx, {}).items() if s in base_by_seed]
        return float(np.mean(vals)) if vals else None

    base_mean = float(np.mean(list(base_by_seed.values())))
    per_config = {}
    for key, c in need.items():
        pfx = prefix_of(args.env, args.algo, args.num_agents, "final", key)
        m = mean_of(pfx)
        if m is not None:
            per_config[key] = {"name": c["name"], "mean": m, "gain": m - base_mean}
    for name in dsl_specs:
        m = mean_of(prefix_of(args.env, args.algo, args.num_agents, "final", name))
        if m is not None:
            per_config[f"dsl::{name}"] = {"name": f"hand-designed DSL ({name})",
                                          "mean": m, "gain": m - base_mean}
    bm_info = None
    if args.bm_steps > 0 or args.bm_auto:
        final_total = args.final_steps * len(final_seeds)
        amort = (search_total / max(1, args.replicates)
                 if args.bm_scope == "per-replicate" else float(search_total))
        bm_steps = (int(round(args.final_steps * (1.0 + amort / final_total)))
                    if args.bm_auto else args.bm_steps)
        bm_key = f"base_bm{bm_steps}"
        bm_pfx = prefix_of(args.env, args.algo, args.num_agents, "final", bm_key)
        bm_jobs = [(run_id(args.env, args.algo, args.num_agents, "final", bm_key, s), s)
                   for s in final_seeds]

        def do_bm(job):
            rid, seed = job
            # Older summaries stored the budget-matched baseline under the bare
            # key ``base_bm`` (without the step suffix). Fall back to it so the
            # already-trained runs are reused instead of retrained.
            legacy = prefix_of(args.env, args.algo, args.num_agents, "final", "base_bm") + f"_s{seed}"
            val = train(args.env, args.algo, args.num_agents, bm_steps, seed,
                        None, rid, args.rho_target, max_cycles=args.max_cycles,
                        legacy_rid=legacy)
            return seed, val

        bm_vals = []
        with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
            for seed, val in pool.map(do_bm, bm_jobs):
                if val is not None:
                    bm_vals.append(val)
                    # Persist per-seed values so the paired budget-matched
                    # comparison can be recomputed from the summary alone.
                    finals.setdefault(bm_pfx, {})[seed] = val
        if bm_vals:
            bm_mean = float(np.mean(bm_vals))
            bm_info = {"steps": bm_steps, "mean": bm_mean, "scope": args.bm_scope,
                       "search_overhead_interactions": search_total,
                       "amortised_overhead_interactions": amort,
                       "budget_ratio_vs_unshaped": (amort + final_total) / final_total,
                       "auto": bool(args.bm_auto), "pool_filter": args.pool_filter}
            print(f"\nbudget-matched baseline ({args.bm_scope} amortisation of search): "
                  f"{bm_steps} steps/seed -> mean {bm_mean:.2f} "
                  f"(unshaped total is {bm_info['budget_ratio_vs_unshaped']:.2f}x the plain baseline)")

    oracle_key = max(per_config, key=lambda k: per_config[k]["mean"]) if per_config else None
    oracle_gain = per_config[oracle_key]["gain"] if oracle_key else float("nan")

    print("\ncost ledger (interactions):")
    print(f"  screening {screen_total}; stage-2 probes {len(stage2_jobs)} runs x "
          f"{args.probe_steps} steps; final {len(final_jobs)} runs x {args.final_steps} steps")
    print(f"  total search overhead = {search_total} interactions")

    print("\nper-replicate outcome (deployed configuration, held-out final seeds):")
    print(f"{'rep':>4s} {'decision':<34s} {'final mean':>11s} {'gain vs base':>13s} "
          f"{'gain vs bm-base':>16s} {'regret vs oracle':>17s}")
    rows = []
    for d in decisions:
        if d["gate_choice"]:
            name = d["gate_choice"]["name"]
            m = per_config.get(d["gate_choice"]["key"], {}).get("mean")
        else:
            name, m = "FALLBACK(base)", base_mean
        if m is None:
            continue
        rows.append({"replicate": d["replicate"], "arm": "bps_gate", "deployed": name,
                     "final_mean": m, "gain_vs_base": m - base_mean,
                     "gain_vs_budget_matched": (m - bm_info["mean"]) if bm_info else None,
                     "regret_vs_oracle": oracle_gain - (m - base_mean),
                     "deployed_flag": d["gate_deployed"]})
        r = rows[-1]
        bm_gain = r["gain_vs_budget_matched"]
        bm_col = f"{bm_gain:>+16.2f}" if bm_gain is not None else f"{'-':>16s}"
        print(f"{d['replicate']:>4d} {name:<34s} {m:>11.2f} {r['gain_vs_base']:>+13.2f} "
              f"{bm_col} {r['regret_vs_oracle']:>+17.2f}")
        if d["random_choice"]:
            rk = d["random_choice"]["key"]
            m2 = per_config.get(rk, {}).get("mean")
            if m2 is not None:
                rows.append({"replicate": d["replicate"], "arm": "random_k",
                             "deployed": d["random_choice"]["name"], "final_mean": m2,
                             "gain_vs_base": m2 - base_mean,
                             "regret_vs_oracle": oracle_gain - (m2 - base_mean),
                             "deployed_flag": True})

    print(f"\nbaseline mean = {base_mean:.2f}; oracle among final-trained configs = "
          f"{per_config.get(oracle_key, {}).get('name')} (gain {oracle_gain:+.2f})")
    print("configurations final-trained:")
    for k, v in sorted(per_config.items(), key=lambda kv: -kv[1]["mean"]):
        print(f"  {v['name']:<34s} {v['mean']:>9.2f}  gain {v['gain']:>+9.2f}")

    summary = {"env": args.env, "algo": args.algo, "num_agents": args.num_agents,
               "max_cycles": args.max_cycles,
               "rho_target": args.rho_target, "run_tag": args.run_tag, "z": args.z,
               "probe_steps": args.probe_steps, "probe_pool": probe_pool,
               "probe_draws": args.probe_draws, "final_steps": args.final_steps,
               "final_seeds": final_seeds, "replicates": args.replicates,
               "probe_executions": len(stage2_jobs), "final_executions": len(final_jobs),
               "search_overhead_interactions": search_total,
               "screen_interactions": screen_total, "schedule": args.schedule,
               "pool_filter": args.pool_filter,
               "decisions": decisions, "per_config": per_config,
               "base_mean": base_mean, "oracle_key": oracle_key,
               "oracle_gain": oracle_gain, "rows": rows, "budget_matched_baseline": bm_info,
               "finals": {k: {str(s): v for s, v in d.items()} for k, d in finals.items()}}
    out = os.path.join(OUTDIR, f"{args.tag}_summary.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
