# Rule-consistency pass: re-runs every draw whose stored decision disagrees with the frozen
# deployment rule (max probe mean). Runs after the follow-up queue so it never contends for the GPU,
# and repeats until the audit reports no disagreement.
#
# Usage:  powershell -NoProfile -File scripts/rerun_rule_disagreements.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/rule_rerun.log"

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

# ---- wait for the follow-up queue to finish first
Write-Log "waiting for the follow-up queue to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/followup.log" -Pattern "FOLLOWUP_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}
Write-Log "follow-up done; checking rule consistency"

# ---- reproduce each tag's ORIGINAL configuration (raw global runs use the gate-only pool, K=6)
function Get-Extra([string]$Tag) {
    if ($Tag -like "confglm*") {
        # original GLM runs were raw-interface: gate only, K=6, random arm matched at K=6
        return @("--provider", "glm_5_2", "--k-llm", "6", "--k-raw", "6", "--k-rand", "6")
    }
    $p = "deepseek_v4_flash"
    if ($Tag -like "*gpt_6_astra*") { $p = "gpt_6_astra" }
    elseif ($Tag -like "*gemini_31_pro*") { $p = "gemini_31_pro" }
    elseif ($Tag -like "*claude_sonnet_46*") { $p = "claude_sonnet_46" }
    elseif ($Tag -like "*grok_47*") { $p = "grok_47" }
    elseif ($Tag -like "confv2glm*") { $p = "glm_5_2" }
    return @("--provider", $p, "--llm-v2", "--k-llm", "12", "--k-raw", "6", "--k-rand", "12")
}

for ($round = 1; $round -le 5; $round++) {
    $out = & python scripts/audit_experiment_integrity.py 2>&1
    $line = $out | Select-String -Pattern "^RERUN_TAGS="
    if (-not $line) { Write-Log "round ${round}: audit produced no RERUN_TAGS line"; break }
    $tags = ($line -replace "^.*RERUN_TAGS=", "").Trim()
    if ([string]::IsNullOrWhiteSpace($tags)) { Write-Log "round ${round}: consistent, done"; break }
    Write-Log "round ${round}: re-running -> $tags"
    foreach ($t in ($tags -split ",")) {
        if ([string]::IsNullOrWhiteSpace($t)) { continue }
        $ro = "0"
        if ($t -match "_r(\d+)$") { $ro = $matches[1] }
        Write-Log "re-run: $t (rep-offset $ro)"
        Remove-Item "artifacts/llm_proposal/${t}_summary.json" -Force -ErrorAction SilentlyContinue
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + (Get-Extra $t) + @(
            "--replicates", "1", "--rep-offset", $ro, "--probe-steps", "50000",
            "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $t)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
    }
}

Write-Log "RULE_RERUN_DONE"
