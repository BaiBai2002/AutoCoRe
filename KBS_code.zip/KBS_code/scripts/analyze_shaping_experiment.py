"""Paired statistics for the shaping experiment.

Reads the raw per-seed records produced by ``stage1_shaping_experiment.py`` and
reports, for every arm, the paired difference against the base arm together
with a bootstrap interval and a standardized effect size. With few seeds the
interval is wide by construction; the point of reporting it is to keep the
claim proportional to the evidence rather than to manufacture significance.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")


def bootstrap_ci(values: np.ndarray, n_boot: int = 20000, alpha: float = 0.05,
                 seed: int = 0) -> tuple[float, float]:
    if values.size < 2:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, values.size, size=(n_boot, values.size))
    means = values[idx].mean(axis=1)
    return float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


def cohen_dz(diffs: np.ndarray) -> float:
    if diffs.size < 2 or diffs.std(ddof=1) == 0:
        return float("nan")
    return float(diffs.mean() / diffs.std(ddof=1))


ARM_ALIASES = {"cov_legacy": "pot_legacy", "cov_cal": "pot_cal"}


def canonical_arm(name: str) -> str:
    return ARM_ALIASES.get(name, name)


def spearman_rank(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    denom = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / denom) if denom > 0 else float("nan")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="main")
    ap.add_argument("--tags", default=None,
                    help="comma-separated tags to pool before analysis")
    args = ap.parse_args()

    tags = [t for t in (args.tags.split(",") if args.tags else [args.tag]) if t]
    raw: list[dict] = []
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            raw.extend(json.load(f))
    ok = [r for r in raw if r.get("status") == "completed"]

    by_arm: dict[str, dict[int, dict]] = {}
    for r in ok:
        by_arm.setdefault(canonical_arm(r["arm"]), {})[r["seed"]] = r

    if "base" not in by_arm:
        raise SystemExit("no base arm found")
    base = by_arm["base"]
    common_seeds = sorted(set.intersection(*[set(v) for v in by_arm.values()]))

    lines = [
        f"# Shaping experiment — {args.tag}",
        "",
        f"seeds used for paired contrasts: {common_seeds} (n = {len(common_seeds)}); "
        "environment: " + ok[0].get("env", "?"),
        "returns are negative; higher (closer to zero) is better.",
        "",
        "| arm | mean | sd | mean AUC | paired delta vs base | 95% CI | Cohen's dz | seeds improved |",
        "|---|---|---|---|---|---|---|---|",
    ]
    rows = []
    for arm, per_seed in by_arm.items():
        seeds = [s for s in common_seeds if s in per_seed]
        finals = np.asarray([per_seed[s]["final_return"] for s in seeds])
        aucs = np.asarray([np.trapezoid([c[1] for c in per_seed[s]["curve"]],
                                        [c[0] for c in per_seed[s]["curve"]])
                           / (per_seed[s]["curve"][-1][0] - per_seed[s]["curve"][0][0])
                           for s in seeds])
        diffs = np.asarray([per_seed[s]["final_return"] - base[s]["final_return"] for s in seeds])
        lo, hi = bootstrap_ci(diffs)
        improved = int(np.sum(diffs > 0))
        rows.append({"arm": arm, "n": len(seeds), "mean_final": float(finals.mean()),
                     "sd_final": float(finals.std(ddof=1)) if len(finals) > 1 else 0.0,
                     "mean_auc": float(aucs.mean()), "paired_delta": float(diffs.mean()),
                     "ci_lo": lo, "ci_hi": hi, "cohen_dz": cohen_dz(diffs),
                     "seeds_improved": f"{improved}/{len(seeds)}"})
        lines.append(
            f"| {arm} | {finals.mean():.2f} | "
            f"{finals.std(ddof=1) if len(finals) > 1 else 0.0:.2f} | {aucs.mean():.2f} | "
            f"{diffs.mean():+.2f} | [{lo:+.2f}, {hi:+.2f}] | {cohen_dz(diffs):+.2f} | "
            f"{improved}/{len(seeds)} |")

    lines += [
        "",
        "## Seed heterogeneity",
        "",
    ]
    base_vals = np.asarray([base[s]["final_return"] for s in common_seeds], dtype=float)
    pairs_arm: list[str] = []
    pairs_base: list[float] = []
    pairs_delta: list[float] = []
    for arm, per_seed in by_arm.items():
        if arm == "base":
            continue
        for s in common_seeds:
            if s in per_seed:
                pairs_arm.append(arm)
                pairs_base.append(base[s]["final_return"])
                pairs_delta.append(per_seed[s]["final_return"] - base[s]["final_return"])
    pb = np.asarray(pairs_base, dtype=float)
    pd = np.asarray(pairs_delta, dtype=float)
    lines.append(f"- base across seeds: mean {base_vals.mean():.2f}, "
                 f"sd {base_vals.std(ddof=1):.2f}, range "
                 f"[{base_vals.min():.2f}, {base_vals.max():.2f}]")
    if pb.size > 3 and pb.std() > 0 and pd.std() > 0:
        pear = float(np.corrcoef(pb, pd)[0, 1])
        spear = spearman_rank(pb, pd)
        lines.append(f"- correlation between the unshaped return of a seed and the "
                     f"shaping gain on that same seed: Pearson {pear:+.3f}, "
                     f"Spearman {spear:+.3f} (n = {pb.size} arm-seed pairs)")
        lines.append("- a strongly negative value means shaping mainly rescues seeds "
                     "on which unshaped training fails, i.e. it acts as variance "
                     "reduction rather than as a uniform improvement")
    lines.append("")
    lines.append("- the seed-to-seed spread of the unshaped baseline is comparable to "
                 "the effect being measured, so claims about which configuration is "
                 "better must not be based on a few seeds")

    lines += [
        "",
        "## Reading of the contrasts",
        "",
        "- `legacy` uses the coefficient grid of the original pipeline; its dominance is "
        "two to three orders of magnitude below any level that can affect learning, so it "
        "is expected to be indistinguishable from base.",
        "- `cal` places the coefficient at the analytically calibrated value for a target "
        "episode-level dominance.",
        "- `randctl` replaces the task potential with a task-uninformative random field of "
        "matched dynamic range and uses the same calibrated coefficient, isolating the "
        "contribution of task information from the contribution of signal magnitude.",
        "- `rescale` multiplies the original reward by the same factor the shaping would "
        "add, with no shaping, isolating magnitude from structured temporal credit.",
        "",
        "Interpretation must respect the seed count above: the intervals are wide at this "
        "sample size and the confirmatory analysis requires more independent training seeds.",
    ]

    name = args.tags.replace(",", "+") if args.tags else args.tag
    out = os.path.join(OUTDIR, f"{name}_analysis.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(OUTDIR, f"{name}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "seeds": common_seeds}, f, indent=2)
    print("\n".join(lines))
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
