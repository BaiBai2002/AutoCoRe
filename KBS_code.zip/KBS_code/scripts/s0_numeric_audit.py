"""S0 numeric reconciliation: independently recompute the derived quantities the
manuscript quotes, from the raw artifacts, and print the convention each uses.

Checks (GPT revision plan 2026-09-27, items C1-C5):
  C1  shortfall "4-67x" vs "median 89x [42,126]"
  C2  search cost 6.25M / 1.25M vs budget-matched baseline 425K
  C3  shortfall "4-67x" vs grid-reachable dominance "0.099%-0.57%"
  C4  dose peaks vs lambda* ratio
  C5  kaz in/out of grid vs "every audited setting" wording
"""
from __future__ import annotations

import json
import os
import statistics
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
D = os.path.join(ROOT, "artifacts", "diagnostics")
G = os.path.join(ROOT, "artifacts", "bps_gate")


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    feas = load(os.path.join(D, "lambda_feasibility.json"))
    grid = feas["grid"]
    lam_max = max(grid)
    print("=" * 100)
    print(f"grid = {grid}   lambda_max = {lam_max}   rho_target = {feas['rho_target']}")

    # agent count per env, from the environment-space report if present
    n_agents = {}
    p = os.path.join(D, "env_spaces.json")
    if os.path.exists(p):
        for r in load(p):
            if r.get("num_agents") is not None:
                n_agents[r.get("env_name")] = r["num_agents"]
    print(f"num_agents from env_spaces.json = {n_agents}")

    print("\n--- C1/C3: per-pair scales, shortfalls, grid-reachable dominance ---")
    hdr = (f"{'env':<28s}{'potential':<22s}{'E|R|':>9s}{'E|dPhi|':>9s}"
           f"{'lambda*':>9s}{'raw':>8s}{'N':>3s}{'applied':>9s}"
           f"{'rho_lo':>12s}{'rho_hi':>12s}")
    print(hdr)
    rows = []
    for r in feas["rows"]:
        env = r["env_id"]
        raw = r["lambda_star"] / lam_max
        n = n_agents.get(env)
        applied = (r["lambda_star"] / (n * lam_max)) if n else None
        rows.append(dict(r, raw=raw, n=n, applied=applied))
        print(f"{env:<28s}{r['potential']:<22s}{r['mean_abs_return']:9.2f}"
              f"{r['mean_abs_delta_phi']:9.4f}{r['lambda_star']:9.3f}{raw:8.1f}"
              f"{(n if n else 0):3d}{(applied if applied else float('nan')):9.2f}"
              f"{r['rho_lo_on_grid']:12.6f}{r['rho_hi_on_grid']:12.6f}")

    infeas = [r for r in rows if not r["feasible"]]
    print(f"\ninfeasible pairs: {len(infeas)} of {len(rows)}")
    raw_short = [r["raw"] for r in infeas]
    print(f"  RAW shortfall (lambda*/lambda_max, no N)      : "
          f"min {min(raw_short):.1f}  max {max(raw_short):.1f}  median {statistics.median(raw_short):.1f}")
    ap = [r["applied"] for r in infeas if r["applied"]]
    if ap:
        print(f"  APPLIED shortfall (/N)                       : "
              f"min {min(ap):.1f}  max {max(ap):.1f}  median {statistics.median(ap):.1f}")
    rlo = [r["rho_lo_on_grid"] for r in infeas]
    rhi = [r["rho_hi_on_grid"] for r in infeas]
    print(f"  rho_lo on grid (no N)                        : {min(rlo):.6f} .. {max(rhi) and max(rlo):.6f}")
    print(f"  rho_hi on grid (no N)                        : min {min(rhi):.6f}  max {max(rhi):.6f}")
    rhi_n = [r["rho_hi_on_grid"] * r["n"] for r in infeas if r["n"]]
    print(f"  rho_hi on grid * N (team-effective)          : min {min(rhi_n):.6f}  max {max(rhi_n):.6f}")

    print("\n--- C3 cross-check: rho_target / raw_shortfall == rho_hi ? ---")
    for r in infeas[:3]:
        print(f"  {r['env_id']:<26s}{r['potential']:<20s}"
              f" rho*/raw = {0.2 / r['raw']:.8f}   reported rho_hi = {r['rho_hi_on_grid']:.8f}")

    print("\n--- C1 cross-check: uncertainty artifact ---")
    p = os.path.join(D, "lambda_uncertainty.json")
    if os.path.exists(p):
        u = load(p)
        for k in ("rho_target", "grid_ceiling", "n_pairs", "median_shortfall",
                  "median_shortfall_lo", "median_shortfall_hi",
                  "hier_median_lo", "hier_median_hi"):
            if k in u:
                print(f"  {k} = {u[k]}")
        if "rows" in u:
            sh = [r.get("shortfall_vs_ceiling", r.get("shortfall")) for r in u["rows"]]
            sh = [s for s in sh if isinstance(s, (int, float))]
            if sh:
                print(f"  recomputed median of row shortfalls = {statistics.median(sh):.1f} "
                      f"(n={len(sh)}); sorted = {sorted(round(s, 1) for s in sh)}")

    print("\n--- C4: dose-response peaks vs lambda* ---")
    p = os.path.join(D, "dose_response_merged.json")
    if os.path.exists(p):
        dr = load(p)
        print(f"  grid_ceiling = {dr.get('grid_ceiling')}")
        base = {r.get("lambda"): r for r in dr.get("rows", []) if r.get("lambda") is not None}
        for lam in sorted(base):
            r = base[lam]
            keys = {k: v for k, v in r.items() if k not in ("lambda", "seeds", "per_seed")}
            print(f"    lambda={lam}: {keys}")

    print("\n--- C4b: per-potential sweep (feasibility_dose_response) ---")
    for name in ("feasibility_dose_response.json", "feasibility_dose_response_ext.json"):
        p = os.path.join(D, name)
        if not os.path.exists(p):
            continue
        fd = load(p)
        print(f"  {name}: env={fd.get('env')} N={fd.get('num_agents')} "
              f"grid_ceiling={fd.get('grid_ceiling')} base_mean={fd.get('base_mean')}")
        best = None
        for r in fd.get("rows", []):
            lam = r.get("lambda", r.get("shaping_lambda"))
            d = r.get("delta", r.get("paired_delta"))
            lo, hi = r.get("ci_lo"), r.get("ci_hi")
            sig = (lo is not None and hi is not None and (lo > 0 or hi < 0))
            print(f"    lambda={lam}: delta={d} [{lo},{hi}] sig={sig}")
            if d is not None and (best is None or d > best[1]):
                best = (lam, d)
        print(f"    -> argmax delta at lambda={best[0]} (delta={best[1]})")

    print("\n--- C2: budget ledger ---")
    for name in ("bps_n3_rho020_summary.json", "bps_confirm_summary.json"):
        p = os.path.join(G, name)
        if not os.path.exists(p):
            continue
        s = load(p)
        print(f"  {name}:")
        for k in ("env", "num_agents", "probe_steps", "probe_pool", "probe_draws",
                  "final_steps", "final_seeds", "replicates", "probe_executions",
                  "final_executions", "search_overhead_interactions",
                  "screen_interactions", "schedule"):
            if k in s:
                v = s[k]
                v = f"{v} (n={len(v)})" if isinstance(v, list) and len(v) > 6 else v
                print(f"    {k} = {v}")
        if "decisions" in s:
            d0 = s["decisions"][0]
            print(f"    decisions[0] keys = {list(d0.keys())}")
            for k, v in d0.items():
                if "budget" in k or "bm" in k or "baseline" in k or "steps" in k:
                    print(f"      {k} = {v}")


if __name__ == "__main__":
    main()
