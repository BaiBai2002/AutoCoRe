"""Text of the three documentation files shipped inside the code bundle.

Kept as a separate module so the long prose does not drown the packaging logic in
``make_code_bundle.py``. English is used throughout: the bundle addresses the journal and
its reviewers.
"""
from __future__ import annotations

README = r"""# Code and environment bundle

This bundle accompanies the manuscript *Grounding the proposer: a knowledge-based
decision procedure for potential-based reward shaping in cooperative multi-agent
reinforcement learning* (submitted to Knowledge-Based Systems). It contains the
complete code layer of the study: the pipeline source, every experiment, analysis and
figure script, all configurations, the environment specifications of the two tasks, the
test suite, and the lightweight transparency artefacts the manuscript names (the claim
ledger, the protocol-deviation table, the three pre-registration protocols and the
decision-record schema).

## What is in this bundle

    src/autocore/        the pipeline library: DSL compiler and verifier, shaping
                         potentials (PBRS), probe/deployment selection, IPPO/MAPPO/QMIX
                         learners, provider clients, evaluation
    scripts/             every script that runs an experiment, a diagnostic, an audit,
                         a figure or an analysis quoted in the manuscript
    configs/             environment specifications (configs/env_specs/), the PBRS DSL
                         programs (configs/dsl/), the study configurations and the
                         provider definitions (credentials are referenced by
                         environment-variable name only; no key material is present)
    tests/               the unit/integration test suite of the pipeline
    ledgers/             CLAIM_LEDGER.tsv (claim to evidence map), PROTOCOL_DEVIATIONS.tsv,
                         the pre-registration protocols (CONFIRM_*.md) and
                         decision_record.schema.json
    REPRODUCE.md         script-to-table/figure map: which command regenerates which
                         artefact of the manuscript
    ENVIRONMENT.md       exact environment: interpreter, libraries, benchmarks, install
    SHA256SUMS.txt       SHA-256 of every member of this archive

## What is deliberately NOT in this bundle

The data layer: per-run records, probe and final-training logs, response caches and the
aggregated result files. Those are released as the supplementary *data* bundle, so that
this archive stays a code-and-environment submission. The manuscript states the split
explicitly in its data-availability note. `REPRODUCE.md` marks, for each script, whether
it consumes run records (re-analysis, executable immediately if the data bundle is
present) or produces them (re-running an experiment; needs the environment of
`ENVIRONMENT.md`, a GPU, and provider credentials).

## Quick start (code layer)

    python -m venv .venv && . .venv/bin/activate     # or conda; see ENVIRONMENT.md
    pip install -e .
    pip install -r requirements.txt
    pytest tests/ -q                                  # the pipeline's own test suite

Analysis scripts assume the run records of the data bundle are present under
`artifacts/`; they fail loudly rather than silently substituting anything when a record
is missing. Experiment scripts regenerate records from scratch and are subject to the
budgets documented in the manuscript.

## Credentials

No key material ships. `configs/providers.yaml` names the environment variable for each
provider; copy `.env.example`, fill in your own keys, and export them before running any
experiment script. The cache guard in `tests/test_llm_cache_no_secrets.py` enforces that
no call record can store a key.
"""

ENVIRONMENT = r"""# Environment

## Interpreter and core libraries

The study was run with CPython 3.12 on Linux (CUDA GPUs for training; CPU suffices for
every analysis and figure script). Exact pins of the third-party stack:

    torch>=2.0.0        numpy>=1.24.0      pandas>=2.0.0      scipy>=1.10.0
    matplotlib>=3.7.0   seaborn>=0.12.0    scikit-learn>=1.2.0
    pettingzoo>=1.24.0  gymnasium>=0.29.0  pyyaml>=6.0        requests>=2.28.0
    jsonschema>=4.17.0  python-dotenv>=1.0.0  tqdm>=4.65.0    pytest>=7.4.0

Install:

    pip install -e ".[dev]"      # the package, from pyproject.toml
    pip install -r requirements.txt

## Benchmarks

Two benchmark families are used, with their environment specifications shipped in
`configs/env_specs/`:

* Multi-Agent Particle Environments (MPE), via PettingZoo: `simple_spread_v3` (the main
  task), `simple_push_v3` (the second task), `simple_reference_v3`;
* PettingZoo SISL and Butterfly suites: `pursuit_v5` (SISL) and
  `knights_archers_zombies_v11` / butterfly environments (feasibility study).

Each specification fixes the agent count, observation and action spaces, the allowed
state variables, the implementable predicate/potential whitelist (the PBRS DSL surface),
the task-progress metrics, the success metric, the reference coefficient grid and the
target dominance. They are the knowledge contract the manuscript's framework is built
around, and they are what makes the candidate space reproducible.

## Learning stack

Cooperative learners are IPPO and MAPPO (implemented in `src/autocore/algos/`), plus QMIX
for the value-decomposition audit. Training hyper-parameters, budgets and seeds are in
the experiment scripts and the configuration files; the manuscript records the same
numbers in its protocol section.

## Determinism

Run records store the full configuration of each run (environment, learner, agent count,
horizon, budget, probe/final seeds, coefficient). Re-running a stored configuration with
the same seeds reproduces its record; the integrity audit re-derives every reported
per-arm statistic from the records. The reference bank (state samples used for
coefficient calibration) is generated by a fixed procedure and validated by the test
suite.
"""

REPRODUCE = r"""# Reproduction guide

Every number, table and figure in the manuscript is regenerated from the study's run
records by the scripts in this bundle; nothing is entered by hand. This file maps each
artefact to the exact command. Scripts marked **[records]** consume the per-run records
that ship in the supplementary data bundle (placed under `artifacts/`); scripts marked
**[run]** produce records (full training; needs GPUs, credentials, and the budgets the
manuscript reports).

## 0. Integrity guards (run first)

    python scripts/audit_experiment_integrity.py     # [records] every reported per-arm
                                                     # statistic re-derived from records
    python scripts/verify_claims.py                  # [records] every quoted number is
                                                     # present in its artefact
    python scripts/check_protocol_consistency.py     # [records] P1-P7 on a shaping study
    pytest tests/ -q                                 # the pipeline's own test suite

## 1. Feasibility screen and the coefficient sweep

    python scripts/calibrate_lambda.py               # [records] Table (feasibility)
    python scripts/plot_feasibility.py               # Figure (feasibility, panels a-b)
    python scripts/feasibility_dose_response.py      # [run] the dose sweep itself
    python scripts/analyze_dose_response.py          # [records] merge + paired statistics
    python scripts/plot_dose_response.py             # Figure (dose response)

## 2. The proposer study (the manuscript's main experiment)

    python scripts/llm_proposal_experiment.py \      # [run] one pipeline replicate:
      --provider deepseek_v4_flash --llm-v2 \        #   grounded interface, K=12
      --k-llm 12 --k-raw 6 --k-rand 12 --rep-offset 0 \
      --replicates 1 --probe-steps 50000 --probe-seeds 200,201,202 \
      --final-steps 300000 --final-seeds 100,101,102,103,104 --tag confv2_r0

    python scripts/analyze_llm_proposal.py \         # [records] draw-level bootstrap,
      --tags confv2_r0,confv2_r1 --pairs --cluster \ #   small-sample t, sign-flip p,
      --small-sample --tost 20                       #   TOST +/-20
    python scripts/plot_proposer_study.py            # Figures: arms sweep, decision view,
                                                     # estimand blocks, appendix matrix
    python scripts/analyze_decision_utility.py --all # Appendix: deployment risk and
                                                     # abstention accounting
    python scripts/decision_record.py --tag confv2_r0  # one runnable decision record

The pre-registered confirmation batches were launched by the PowerShell runners
(`run_confirm_v3.ps1`, `run_confirm_v3b.ps1`, `run_gpt_ladder.ps1`, ...), whose
pre-registration is frozen in `ledgers/` and must not be amended.

## 3. Reporting criterion, gate calibration and deployment audits

    python scripts/shaped_criterion_audit.py         # [records] shaped-vs-raw bias
    python scripts/kappa_interval.py                 # [records] the kappa crossing
    python scripts/protocol_reporting_gap.py         # [records] sign disagreement
    python scripts/plot_shaped_screen.py             # Figure (screening collapse)
    python scripts/bps_gate_experiment.py ...        # [run] gate-calibration study
    python scripts/analyze_bps_gate.py --summaries artifacts/bps_gate/<summary>.json
    python scripts/gate_calibration_test.py          # [records] nominal vs realised risk
    python scripts/gate_calibration_fix.py           # [records] error-coverage trade-off
    python scripts/plot_gate_and_fidelity.py         # Figure (gate and fidelity)
    python scripts/strong_controls.py --summary artifacts/bps_gate/<summary>.json
    python scripts/ablate_deploy_coefficient.py      # [records] rho* ablation
    python scripts/plot_rho_ablation.py ; python scripts/plot_budget_flip.py
    python scripts/plot_deployment_rule.py

## 4. Framework and graphical abstract

    python scripts/fig_proposer_framework.py --layout B   # Figure 1
    python scripts/fig1_method.py                          # Figure 2
    python scripts/fig_graphical_abstract.py               # graphical abstract (2.5:1)

## 5. Pre-registration and claim records

`ledgers/CONFIRM_PROTOCOL.md`, `CONFIRM_V3_PROTOCOL.md` and `CONFIRM_V3B_PROTOCOL.md`
are the frozen analysis plans of the confirmation batches (each was written before its
first draw existed); `ledgers/CLAIM_LEDGER.tsv` maps every claim in the manuscript to its
evidence and status; `ledgers/PROTOCOL_DEVIATIONS.tsv` records every deviation with its
reason; `ledgers/decision_record.schema.json` is the schema of the runnable decision
records emitted by `scripts/decision_record.py`.

## 6. Rebuilding the manuscript

Not in this bundle. The manuscript sources typeset the document; the figures it includes
are regenerated by the scripts in section 4 (and the `plot_*.py` scripts elsewhere in
this guide).

## 7. What is deliberately not reproducible from records alone

Re-training: any setting outside the audited configurations, and the budget-matched
baseline for a different charging convention. Those require re-running training. Every
number actually reported is recomputed from the stored records by the scripts above.
"""