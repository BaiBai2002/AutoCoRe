"""Phase 0 — Evaluation Audit: diagnose and fix eval_returns constant issue.

Checks 1-14 as specified in the experiment requirements.

Usage: python scripts/debug_evaluation_pipeline.py
"""
import json, sys, os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
import torch
from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.algos.ippo import IPPOTrainer, IPPOConfig
from autocore.shaping.wrappers import RewardShapingWrapper
from autocore.shaping.potentials import PotentialFunction, ShapingConfig
from autocore.dsl.compiler import compile_dsl
from autocore.dsl.predicates import PredicateLibrary, PotentialLibrary
from autocore.dsl.expanded_predicates import register_expanded_predicates
from autocore.shaping.potentials import PotentialFunction, ShapingConfig
from autocore.experiments.train import train_agent, evaluate_agent, TrainingLogger
from gymnasium import spaces

ENV_ID = "simple_spread_v3"
SEED = 42
STEPS = 500

print("=" * 70)
print("EVALUATION AUDIT")
print("=" * 70)

# Setup
pred_lib = register_expanded_predicates(PredicateLibrary())
pot_lib = PotentialLibrary()

simple_dsl = {
    "task_name": ENV_ID, "version": "1.0", "description": "Test",
    "subgoals": [{
        "name": "approach", "scope": "global", "weight": 1.0,
        "predicate": {"type": "mean_distance_to_nearest_landmark",
                       "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
        "potential": {"type": "negative_mean_distance", "clip": [-1.0, 0.0]},
        "rationale": "Minimize distance"
    }]
}

env = make_mpe_env(ENV_ID, max_cycles=100)
a0 = env.possible_agents[0]
obs_shape = env.observation_space(a0).shape
od = int(np.prod(obs_shape))
discrete = isinstance(env.action_space(a0), spaces.Discrete)
ad = env.action_space(a0).n if discrete else 5

# ======================================
# CHECK 1: Policy parameters change after training
# ======================================
print("\n[1] Policy parameter change after training:")
trainer = IPPOTrainer(od, ad, IPPOConfig(lr=3e-4, hidden_dim=128, device='cuda'), discrete)
params_before = {k: v.clone().detach() for k, v in trainer.policy.state_dict().items()}
logger = train_agent(env, trainer, num_steps=STEPS, eval_interval=STEPS, eval_episodes=3, seed=SEED)
params_after = {k: v.clone().detach() for k, v in trainer.policy.state_dict().items()}
l2_diffs = []
for k in params_before:
    diff = (params_after[k] - params_before[k]).norm().item()
    l2_diffs.append(diff)
total_l2 = np.sqrt(sum(d**2 for d in l2_diffs))
print(f"  L2 distance before/after: {total_l2:.4f}")
print(f"  PASS: {total_l2 > 0}")

# ======================================
# CHECK 2: evaluate_agent uses current policy
# ======================================
print("\n[2] evaluate_agent uses current policy:")
eval_ret = evaluate_agent(env, trainer, num_episodes=3, seed=99, max_steps_per_episode=100)
print(f"  eval return: {eval_ret:.2f}")
print(f"  PASS: {isinstance(eval_ret, float) and not np.isnan(eval_ret)}")

# ======================================
# CHECK 3: eval resets correctly per episode
# ======================================
print("\n[3] Eval reset per episode:")
rets = []
for ep in range(5):
    ret = evaluate_agent(env, trainer, num_episodes=1, seed=999+ep, max_steps_per_episode=50)
    rets.append(ret)
all_same = all(abs(r - rets[0]) < 1e-6 for r in rets)
print(f"  5 episode returns: {[f'{r:.1f}' for r in rets]}")
print(f"  All same? {all_same}")
print(f"  PASS: {not all_same} (different seeds should have some variance)")

# ======================================
# CHECK 4: deterministic=True vs False behavior
# ======================================
print("\n[4] deterministic=True vs False:")
det_ret = evaluate_agent(env, trainer, num_episodes=5, seed=42, max_steps_per_episode=100)
print(f"  deterministic: {det_ret:.2f}")
# Stochastic (sample 1 action non-deterministically to check it doesn't crash)
r = env.reset(seed=42)
obs = r[0] if isinstance(r, tuple) else r
for a in env.agents:
    act_raw, _, _ = trainer.get_action(obs[a], deterministic=False)
    print(f"  {a}: stochastic action OK")
env.close()
print(f"  PASS: deterministic eval returned valid float")

# ======================================
# CHECK 5: different eval seeds → different initial states
# ======================================
print("\n[5] Different eval seeds:")
for s in [42, 123, 456]:
    r = env.reset(seed=s)
    obs = r[0] if isinstance(r, tuple) else r
sum_obs_42 = np.sum([np.sum(obs[a]) for a in env.agents[:2]])
for s in [123, 456]:
    r = env.reset(seed=s)
    obs2 = r[0] if isinstance(r, tuple) else r
    sum2 = np.sum([np.sum(obs2[a]) for a in env.agents[:2]])
    print(f"  seed={s}: obs sum = {sum2:.4f} (seed=42: {sum_obs_42:.4f}, diff={abs(sum2-sum_obs_42):.4f})")

# ======================================
# CHECK 6: same seed same checkpoint → reproducible
# ======================================
print("\n[6] Reproducibility:")
ret1 = evaluate_agent(env, trainer, num_episodes=3, seed=42, max_steps_per_episode=50)
ret2 = evaluate_agent(env, trainer, num_episodes=3, seed=42, max_steps_per_episode=50)
print(f"  run1={ret1:.2f}, run2={ret2:.2f}, diff={abs(ret1-ret2):.6f}")
print(f"  PASS: {abs(ret1-ret2) < 1e-4}")

# ======================================
# CHECK 7: different checkpoints → different returns
# ======================================
print("\n[7] Different checkpoints:")
# Train a bit more
ret_after = evaluate_agent(env, trainer, num_episodes=3, seed=42, max_steps_per_episode=50)
print(f"  eval at step 0: {eval_ret:.2f}")
print(f"  eval at step {STEPS}: {ret_after:.2f}")
print(f"  PASS: {abs(ret_after - eval_ret) > 1e-3} (different returns expected)")

# ======================================
# CHECK 8: logger not reusing old values
# ======================================
print("\n[8] Logger values check:")
df = logger.get_dataframe()
if 'eval_return' in df.columns:
    ev = df['eval_return'].dropna().values
    print(f"  eval_returns: {[f'{x:.0f}' for x in ev]}")
    all_const = len(ev) > 1 and all(abs(x - ev[0]) < 1e-4 for x in ev)
    print(f"  All constant? {all_const}")
    print(f"  PASS: {not all_const or len(ev) <= 1}")
else:
    print(f"  No eval_return column found (columns: {list(df.columns)[:10]})")
    print(f"  ISSUE: eval_return missing from logger!")

# ======================================
# CHECK 9: train/eval action decoding consistency
# ======================================
print("\n[9] Action decoding consistency:")
# Use same obs and check
r = env.reset(seed=999)
obs = r[0] if isinstance(r, tuple) else r
for a in env.agents:
    train_act, _, _ = trainer.get_action(obs[a], deterministic=False)
    eval_act, _, _ = trainer.get_action(obs[a], deterministic=True)
    print(f"  {a}: train_act={train_act}, eval_act={eval_act}")

# ======================================
# CHECK 10: simple_push heterogeneous check
# ======================================
print("\n[10] Simple Push heterogeneous:")
try:
    penv = make_mpe_env("simple_push_v3", max_cycles=10)
    agents = penv.possible_agents
    for a in agents:
        print(f"  {a}: obs={penv.observation_space(a).shape} act={penv.action_space(a)}")
    penv.close()
    print(f"  PASS: 2 agent types detected")
except Exception as e:
    print(f"  ERROR: {e}")

# ======================================
# CHECK 11: simple_reference action space
# ======================================
print("\n[11] Simple Reference action space:")
try:
    renv = make_mpe_env("simple_reference_v3", max_cycles=10)
    ref0 = renv.possible_agents[0]
    print(f"  obs={renv.observation_space(ref0).shape} act={renv.action_space(ref0)}")
    print(f"  discrete? {isinstance(renv.action_space(ref0), spaces.Discrete)}")
    r = renv.reset(seed=42)
    obs = r[0] if isinstance(r, tuple) else r
    print(f"  actual obs dim: {np.prod(obs[ref0].shape)}")
    renv.close()
    print(f"  PASS")
except Exception as e:
    print(f"  ERROR: {e}")

# ======================================
# CHECK 12: episode termination types
# ======================================
print("\n[12] Episode termination types:")
r = env.reset(seed=42)
obs = r[0] if isinstance(r, tuple) else r
trunc_count = 0
term_count = 0
for _ in range(10):
    acts = {a: env.action_space(a).sample() for a in env.agents}
    step_result = env.step(acts)
    _, _, terms, truncs = step_result[0], step_result[1], step_result[2], step_result[3]
    if any(terms.values()): term_count += 1
    if any(truncs.values()): trunc_count += 1
print(f"  terminations in 10 steps: {term_count}, truncations: {trunc_count}")

# ======================================
# CHECK 13: parallel rewards correct
# ======================================
print("\n[13] Parallel rewards:")
r = env.reset(seed=42)
obs = r[0] if isinstance(r, tuple) else r
for step in range(3):
    acts = {a: env.action_space(a).sample() for a in env.agents}
    step_result = env.step(acts)
    _, rewards, _, _ = step_result[0], step_result[1], step_result[2], step_result[3]
    print(f"  step {step}: rewards={rewards}, sum={sum(rewards.values()):.3f}")

# ======================================
# CHECK 14: team return vs agent sum
# ======================================
print("\n[14] Team return vs agent sum:")
ret1 = evaluate_agent(env, trainer, num_episodes=1, seed=42, max_steps_per_episode=100)
print(f"  evaluate_agent return: {ret1:.2f}")

env.close()
print(f"\n{'='*70}")
print("EVALUATION AUDIT COMPLETE")
print(f"{'='*70}")
