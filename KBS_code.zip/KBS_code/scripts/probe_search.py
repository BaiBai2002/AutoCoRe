"""Probe-based search over shaping landscapes.

Every candidate potential is (i) calibrated analytically to the same target
episode-level dominance, so the comparison is at fixed magnitude, and (ii)
evaluated by a short paired probe against unshaped training on the same seeds.
The candidate with the best mean paired improvement is then trained at the full
budget. Selection uses the mean rather than a risk measure because the payoff
is already an option-like function of the seed, so averaging computes the net
value of the insurance the shaping provides.

All budgets are accounted for explicitly so that the search cost is comparable
to the alternatives it is measured against.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.selection.landscape_search import (
    FeatureBank, LinearPotential, one_hot_directions, sample_directions,
)
from autocore.selection.magnitude_calibration import (
    collect_reference_states, estimate_scales,
)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "search")
TRAIN = os.path.join(PROJECT_ROOT, "scripts", "stage0_train.py")


def cmd_for(env: str, steps: int, seed: int, out: str, tag: str,
            weights: np.ndarray | None, algo: str, num_agents: int | None,
            rho_target: float, hidden: int = 512) -> list[str]:
    cmd = [sys.executable, "-u", TRAIN, "--env", env, "--steps", str(steps),
           "--eval-every", str(max(steps // 4, 5000)), "--seed", str(seed),
           "--hidden", str(hidden), "--entropy", "0.003", "--epochs", "8",
           "--minibatches", "8", "--algo", algo, "--out", out, "--tag", tag,
           "--rho-target", str(rho_target)]
    if num_agents is not None:
        cmd += ["--num-agents", str(num_agents)]
    if weights is not None:
        cmd += ["--feature-weights=" + ",".join(f"{w:.8f}" for w in weights)]
    return cmd


def run(cmd: list[str]) -> tuple[bool, str]:
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    if proc.returncode != 0:
        return False, (proc.stdout or "")[-300:] + (proc.stderr or "")[-300:]
    return True, ""


def load_final(path: str) -> float | None:
    try:
        with open(path, encoding="utf-8") as f:
            return float(json.load(f)["final_return"])
    except Exception:
        return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--algo", default="ippo")
    ap.add_argument("--num-agents", type=int, default=None)
    ap.add_argument("--probe-steps", type=int, default=50_000)
    ap.add_argument("--probe-seeds", default="0,1")
    ap.add_argument("--final-steps", type=int, default=300_000)
    ap.add_argument("--final-seeds", default="0,1,2,3,4,5,6,7")
    ap.add_argument("--random-candidates", type=int, default=12)
    ap.add_argument("--sparse-prob", type=float, default=0.4)
    ap.add_argument("--rho-target", type=float, default=0.2)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tag", default="search")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    probe_seeds = [int(s) for s in args.probe_seeds.split(",")]
    final_seeds = [int(s) for s in args.final_seeds.split(",")]
    rng = np.random.default_rng(args.seed)

    states = collect_reference_states(args.env, max_cycles=80, n_episodes=6,
                                      seed=args.seed, num_agents=args.num_agents)
    bank = FeatureBank().fit(states)
    print(f"feature bank: dim={bank.dim} {bank.names}")

    candidates: list[dict] = []
    for name, w in one_hot_directions(bank).items():
        candidates.append({"name": f"axis:{name}", "weights": w})
    for i, w in enumerate(sample_directions(args.random_candidates, bank.dim, rng,
                                            sparse_prob=args.sparse_prob)):
        candidates.append({"name": f"rand:{i}", "weights": w})

    probe_cost = len(probe_seeds) * args.probe_steps * (len(candidates) + 1)
    final_cost = len(final_seeds) * args.final_steps
    print(f"candidates={len(candidates)}  search budget={probe_cost} interactions "
          f"(incl. baseline probes)  + final budget={final_cost} "
          f"-> total={probe_cost + final_cost}")

    jobs: list[tuple[str, str, int, np.ndarray | None]] = []
    for s in probe_seeds:
        jobs.append(("base", f"{args.tag}_probe_base_s{s}",
                     s, None))
    for c in candidates:
        for s in probe_seeds:
            jobs.append((c["name"], f"{args.tag}_probe_{c['name'].replace(':', '-')}_s{s}",
                         s, c["weights"]))

    def probe_task(job):
        name, tag, seed, weights = job
        out = os.path.join(OUTDIR, f"{tag}.json")
        if os.path.exists(out):
            return name, seed, load_final(out)
        ok, err = run(cmd_for(args.env, args.probe_steps, seed, out, tag, weights,
                              args.algo, args.num_agents, args.rho_target))
        if not ok:
            print(f"  probe FAILED {tag}: {err[:200]}", flush=True)
            return name, seed, None
        return name, seed, load_final(out)

    print("running probes...", flush=True)
    probe_results: dict[str, dict[int, float]] = {}
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for name, seed, value in pool.map(probe_task, jobs):
            if value is not None:
                probe_results.setdefault(name, {})[seed] = value
    print(f"  probes done: {len(probe_results)} candidates with results", flush=True)

    base_probe = probe_results.get("base", {})
    shared = [s for s in probe_seeds if s in base_probe]
    scores = []
    for c in candidates:
        got = probe_results.get(c["name"], {})
        seeds = [s for s in shared if s in got]
        if len(seeds) < 2:
            continue
        diffs = np.asarray([got[s] - base_probe[s] for s in seeds], dtype=float)
        scores.append({"name": c["name"], "weights": c["weights"].tolist(),
                       "n_seeds": len(seeds), "probe_mean_gain": float(diffs.mean()),
                       "probe_sd": float(diffs.std(ddof=1)) if len(diffs) > 1 else 0.0,
                       "seeds": seeds})
    scores.sort(key=lambda r: -r["probe_mean_gain"])
    print("\nprobe ranking (mean paired improvement over unshaped):")
    for r in scores:
        print(f"  {r['name']:<42s} {r['probe_mean_gain']:+9.2f} "
              f"(sd {r['probe_sd']:6.2f}, n={r['n_seeds']})")

    if not scores:
        raise SystemExit("no candidate produced a usable probe")
    winner = scores[0]
    deployed = winner if winner["probe_mean_gain"] > 0 else None
    print(f"\nselected: {winner['name'] if deployed else 'no shaping (gate closed)'}")

    finals: list[dict] = []
    if deployed is not None:
        w = np.asarray(deployed["weights"], dtype=float)
        tasks = []
        for s in final_seeds:
            tasks.append((s, os.path.join(OUTDIR, f"{args.tag}_final_{deployed['name'].replace(':', '-')}_s{s}.json")))

        def final_task(t):
            s, out = t
            if os.path.exists(out):
                return load_final(out)
            ok, err = run(cmd_for(args.env, args.final_steps, s, out,
                                  f"{args.tag}_final_{deployed['name'].replace(':', '-')}_s{s}",
                                  w, args.algo, args.num_agents, args.rho_target))
            if not ok:
                print(f"  final FAILED seed={s}: {err[:200]}", flush=True)
                return None
            return load_final(out)

        print("running final training of the selected candidate...", flush=True)
        with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
            for value in pool.map(final_task, tasks):
                if value is not None:
                    finals.append(value)

    summary = {"env": args.env, "algo": args.algo, "num_agents": args.num_agents,
               "rho_target": args.rho_target,
               "probe_steps": args.probe_steps, "probe_seeds": probe_seeds,
               "final_steps": args.final_steps, "final_seeds": final_seeds,
               "search_budget_interactions": probe_cost,
               "final_budget_interactions": final_cost,
               "total_budget_interactions": probe_cost + final_cost,
               "bank": bank.describe(), "probe_scores": scores,
               "selected": deployed["name"] if deployed else None,
               "selected_weights": deployed["weights"] if deployed else None,
               "final_returns": finals,
               "final_mean": float(np.mean(finals)) if finals else None,
               "baseline_probe_returns": base_probe}
    out = os.path.join(OUTDIR, f"{args.tag}_summary.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"\nselected final mean = {summary['final_mean']}")
    print("wrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
