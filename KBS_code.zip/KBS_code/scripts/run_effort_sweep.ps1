# Study E: inference-time reasoning effort as a controlled variable.
#
# Motivation: the "capability-dependent" finding in the proposer study is confounded by the fact
# that different models run at different default thinking levels. Here we hold the *model* fixed and
# vary only the reasoning-effort hint (probed to be honoured by GPT-6 Astra and Claude Sonnet 4.6),
# under the grounded interface, at matched training budget.
#
# Runs after the rule-consistency pass so it never contends for the GPU.
#
# Usage:  powershell -NoProfile -File scripts/run_effort_sweep.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/effort_sweep.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "waiting for the rule-consistency pass to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/rule_rerun.log" -Pattern "RULE_RERUN_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}
Write-Log "starting effort sweep"

foreach ($model in @("gpt_6_astra", "claude_sonnet_46")) {
    foreach ($level in @("def", "low", "high")) {
        for ($r = 0; $r -lt 2; $r++) {
            $extra = @("--provider", $model, "--llm-v2", "--k-llm", "12", "--k-raw", "6",
                "--k-rand", "12", "--rep-offset", "$r")
            if ($level -ne "def") { $extra += @("--effort", $level) }
            Run-Draw -Tag "confeff_${model}_${level}_r$r" -Extra $extra
        }
    }
}

Write-Log "EFFORT_SWEEP_DONE"
