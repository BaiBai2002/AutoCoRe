"""Figure 1 for the KBS manuscript: the framework and the decision it supports.

Two candidate layouts are rendered so the better one can be chosen at final size
(``--layout both`` writes ``fig_proposer_framework_A/B``; ``--layout A|B`` writes the
paper file ``fig_proposer_framework.pdf`` from the chosen layout):

  A -- three columns (candidate source | budget-matched audit | the decision), the
       published arrangement, with the small-type issues repaired (no rotated label,
       the repair loop labelled in clear space).
  B -- four stages left-to-right (knowledge contract -> candidate construction ->
       compile/calibrate/probe -> frozen decision) over a full-width audit band
       (candidate IDs -> probe RNG -> final RNG -> decision record -> held-out
       evaluation), the arrangement a reader can follow in one sweep.

Colour is semantic only (blue = knowledge source, grey = audit, green/red = the two
decision outcomes, amber = the repair loop). Vector output, Type 42 fonts.
"""
from __future__ import annotations

import os
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGDIR = os.path.join(ROOT, "paper", "figures")

W = 6.42            # matches the 0.98\textwidth embedding width of the Elsevier 5p layout,
                    # so the rendered point sizes are the printed point sizes (reviewer item:
                    # embedded text was ~6.7 pt when rendered at 7.16 in and scaled down)

INK, EDGE, GREY = "#1a1a1a", "#7d7d7d", "#f2f2f2"
BLU, BLU_E = "#e8eff7", "#1f4e79"
GRN, GRN_E = "#e9f3ea", "#2e7d32"
RED, RED_E = "#fbeeee", "#b3261e"
RUL, RUL_E = "#fbf6e6", "#b5651d"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman No9 L", "Liberation Serif",
                   "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.dpi": 200,
})

FS, FS_T, FS_S = 7.1, 8.0, 6.8


def box(ax, x, y, w, h, text, *, fs=FS, fc=GREY, ec=EDGE, bold=False,
        color=INK, ls="-", lw=0.7):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.015,rounding_size=0.045",
        linewidth=lw, edgecolor=ec, facecolor=fc, linestyle=ls))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            color=color, linespacing=1.30,
            fontweight=("bold" if bold else "normal"))


def arrow(ax, p, q, *, ls="-", color=INK, rad=0.0, lw=0.9, ms=8):
    ax.add_patch(FancyArrowPatch(
        p, q, arrowstyle="-|>", mutation_scale=ms, linewidth=lw, linestyle=ls,
        color=color, connectionstyle=f"arc3,rad={rad}", shrinkA=1.0, shrinkB=1.0,
        zorder=2))


def layout_a(ax, H):
    """Three columns -- the published arrangement, small-type issues repaired."""
    c1x, c1w = 0.06, 1.92
    c2x, c2w = 2.30, 2.55
    c3x, c3w = 5.10, 2.00
    xc = c1x + c1w + 0.13
    top = H - 0.32

    for x, w, t in ((c1x, c1w, "(a)  candidate source"),
                    (c2x, c2w, "(b)  budget-matched audit"),
                    (c3x, c3w, "(c)  the decision")):
        ax.text(x + w / 2, H - 0.05, t, ha="center", va="top",
                fontsize=FS_T, fontweight="bold", color=INK)

    src = [("language-model proposal", "raw or grounded interface"),
           ("random valid composition", "same grammar, matched $K$"),
           ("hand-designed potential", "task-aware human prior")]
    bh = 0.42
    y = top
    cy = []
    for t1, t2 in src:
        box(ax, c1x, y - bh, c1w, bh, t1 + "\n" + t2, fs=FS, fc=BLU, ec=BLU_E)
        cy.append(y - bh / 2)
        y -= (bh + 0.07)

    # collector on the right of the sources -> matched pool -> audit
    ax.plot([xc, xc], [cy[0], cy[-1]], color=EDGE, lw=0.8, zorder=1)
    for c in cy:
        ax.plot([c1x + c1w, xc], [c, c], color=EDGE, lw=0.8, zorder=1)
    arrow(ax, (xc, cy[0]), (c2x, cy[0]), color=BLU_E, lw=1.0)
    ax.text((xc + c2x) / 2, cy[0] + 0.055, "$K$", fontsize=FS_S, color=EDGE,
            ha="center", va="bottom")

    stages = [
        ("1  feasibility screen", r"$\lambda^\star=\rho^\star\,\mathbb{E}|R|/\mathbb{E}|\Delta\Phi|$"),
        ("2  applicability gate", "keep implementable primitives only"),
        ("3  probe", "raw return, budget-matched"),
        ("4  frozen rule", r"deploy iff paired probe mean $\geq 0$"),
    ]
    sh = 0.42
    y = top
    st = []
    for t1, t2 in stages:
        fc, ec = (RUL, RUL_E) if t1.startswith("1") else (GREY, EDGE)
        box(ax, c2x, y - sh, c2w, sh, t1 + "\n" + t2, fs=FS, fc=fc, ec=ec)
        st.append(y - sh / 2)
        y -= (sh + 0.07)
    for a, b in zip(st[:-1], st[1:]):
        arrow(ax, (c2x + c2w / 2, a - sh / 2), (c2x + c2w / 2, b + sh / 2))

    # verify-and-repair: stage 2 returns a rejected proposal to the proposer;
    # labelled in clear space below the top source box
    arrow(ax, (c2x, st[1]), (c1x + c1w, cy[0]), ls="--", color=RUL_E,
          rad=-0.22, lw=0.8, ms=7)
    ax.text((c1x + c1w + c2x) / 2 + 0.04, cy[0] - 0.16,
            "verify-and-repair", fontsize=FS_S, color=RUL_E, ha="center",
            va="top")

    dh = 0.48
    box(ax, c3x, top - dh, c3w, dh, "DEPLOY the shaping term", fs=FS, bold=True,
        fc=GRN, ec=GRN_E, color=GRN_E)
    dep = top - dh / 2
    box(ax, c3x, top - 2 * dh - 0.10, c3w, dh, "ABSTAIN (do not shape)",
        fs=FS, bold=True, fc=RED, ec=RED_E, color=RED_E)
    ab = top - 2 * dh - 0.10 - dh / 2

    box(ax, c3x, 0.16, c3w, 0.92,
        "the decision depends on\n"
        r"$\lambda$   shaping coefficient" "\n"
        r"$\rho^\star$   target dominance" "\n"
        "which return is reported\n"
        "search budget $S$",
        fs=FS_S, fc="white", ec=EDGE, ls=":")

    arrow(ax, (c2x + c2w, st[3]), (c3x, dep), color=GRN_E, lw=1.0)
    arrow(ax, (c2x + c2w, st[3]), (c3x, ab), color=RED_E, rad=-0.20, lw=1.0)


def layout_b(ax, H):
    """Four stages left to right over a full-width audit band (rendered at the embedding width,
    so every printed size stays at or above ~7 pt)."""
    bw = (W - 0.26 - 3 * 0.14) / 4.0
    gap = 0.14
    xs = [0.13 + i * (bw + gap) for i in range(4)]
    top = H - 0.14
    hb = 0.98

    stages = [
        ("(1)  knowledge contract",
         "typed DSL of the environment's\nimplementable predicates and\npotentials; PBRS convention\n$\lambda^\star=\\rho^\\star E|R|/E|\\Delta\\Phi|$",
         GREY, EDGE, False),
        ("(2)  candidate construction",
         "human  ·  random valid\nLLM raw  ·  LLM grounded\n(one whitelist per interface);\nduplicates removed, $K{=}12$",
         BLU, BLU_E, False),
        ("(3)  compile · calibrate · probe",
         "static & implementation checks;\nscale diagnostic at a reference\npolicy; raw-return probe\n(50K steps $\\times$ 3 seeds)",
         GREY, EDGE, False),
        ("(4)  frozen decision",
         "rank by the probe; deploy the\nbest candidate iff its paired\nprobe mean $\\geq 0$ — else\nABSTAIN (rule frozen before finals)",
         "white", EDGE, False),
    ]
    for x, (t, body, fc, ec, _) in zip(xs, stages):
        ax.add_patch(FancyBboxPatch((x, top - hb), bw, hb,
                                    boxstyle="round,pad=0.015,rounding_size=0.045",
                                    linewidth=0.8, edgecolor=ec, facecolor=fc, zorder=2))
        ax.text(x + bw / 2, top - 0.10, t, ha="center", va="top", fontsize=7.8,
                fontweight="bold", color=INK, zorder=3)
        ax.text(x + bw / 2, top - 0.235, body, ha="center", va="top", fontsize=7.0,
                color=INK, linespacing=1.28, zorder=3)

    for a, b_ in zip(xs[:-1], xs[1:]):
        arrow(ax, (a + bw, top - hb / 2), (b_, top - hb / 2))

    # optional repair bypass routed below the stage row, in clear space
    yb = top - hb - 0.17
    ax.add_patch(FancyArrowPatch((xs[2] + bw / 2, top - hb), (xs[2] + bw / 2, yb),
                                 arrowstyle="-", linewidth=0.8, linestyle=(0, (3, 2)),
                                 color=RUL_E, zorder=1))
    ax.add_patch(FancyArrowPatch((xs[2] + bw / 2, yb), (xs[1] + bw / 2, yb),
                                 arrowstyle="-|>", mutation_scale=7, linewidth=0.8,
                                 linestyle=(0, (3, 2)), color=RUL_E, zorder=1))
    ax.add_patch(FancyArrowPatch((xs[1] + bw / 2, yb), (xs[1] + bw / 2, top - hb),
                                 arrowstyle="-|>", mutation_scale=7, linewidth=0.8,
                                 linestyle=(0, (3, 2)), color=RUL_E, zorder=1))
    ax.text((xs[1] + xs[2]) / 2 + bw / 2, yb + 0.10,
            "verify-and-repair:\noptional; the rule never changes",
            fontsize=6.8, color=RUL_E, ha="center", va="bottom", linespacing=1.25)

    # decision chips inside stage 4
    ax.add_patch(FancyBboxPatch((xs[3] + 0.10, top - hb + 0.055), 0.56, 0.20,
                                boxstyle="round,pad=0.008,rounding_size=0.03",
                                linewidth=0.7, edgecolor=GRN_E, facecolor=GRN, zorder=3))
    ax.text(xs[3] + 0.38, top - hb + 0.155, "DEPLOY", ha="center", va="center",
            fontsize=7.0, fontweight="bold", color=GRN_E, zorder=4)
    ax.add_patch(FancyBboxPatch((xs[3] + 0.74, top - hb + 0.055), 0.56, 0.20,
                                boxstyle="round,pad=0.008,rounding_size=0.03",
                                linewidth=0.7, edgecolor=RED_E, facecolor=RED, zorder=3))
    ax.text(xs[3] + 1.02, top - hb + 0.155, "ABSTAIN", ha="center", va="center",
            fontsize=7.0, fontweight="bold", color=RED_E, zorder=4)

    # ---- bottom band: the audit trail behind every deployed decision ----
    band_y, band_h = 0.62, 0.86
    ax.add_patch(FancyBboxPatch((0.13, band_y), W - 0.26, band_h,
                                boxstyle="round,pad=0.012,rounding_size=0.04",
                                linewidth=0.8, edgecolor=EDGE, facecolor="white",
                                linestyle=(0, (4, 2)), zorder=1))
    ax.text(0.13 + (W - 0.26) / 2, band_y + band_h - 0.065,
            "the released audit trail behind every decision", ha="center", va="top",
            fontsize=7.3, fontweight="bold", color=INK)
    cells = [
        ("candidate IDs", "dsl + arm + draw"),
        ("probe block", "RNG seeds, 50K steps"),
        ("final block", "RNG seeds, 300K steps"),
        ("decision record", "reason, coefficient, cost"),
        ("held-out evaluation", "20 fixed episodes, read-only"),
    ]
    cw = (W - 0.26 - 0.20) / 5.0
    for i, (t, b_) in enumerate(cells):
        cx = 0.23 + i * cw
        if i:
            ax.plot([cx - 0.04, cx - 0.04], [band_y + 0.10, band_y + band_h - 0.16],
                    color="#c9d2da", lw=0.7, ls=(0, (2, 2)), zorder=2)
        ax.text(cx + 0.06, band_y + band_h - 0.20, t, ha="left", va="top",
                fontsize=7.0, fontweight="bold", color=INK)
        ax.text(cx + 0.06, band_y + band_h - 0.335, b_, ha="left", va="top",
                fontsize=6.6, color=EDGE, linespacing=1.25)
    ax.text(W / 2, band_y - 0.075,
            "the evaluation is read-only: its result never feeds back into the frozen rule",
            ha="center", va="top", fontsize=6.8, color=EDGE, style="italic")


def main(layout: str) -> int:
    os.makedirs(FIGDIR, exist_ok=True)
    if layout in ("A", "B", "both"):
        for tag in ("A", "B") if layout == "both" else (layout,):
            H = 2.95 if tag == "A" else 3.02
            fig, ax = plt.subplots(figsize=(W, H))
            ax.set_xlim(0, W)
            ax.set_ylim(0, H)
            ax.axis("off")
            fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
            (layout_a if tag == "A" else layout_b)(ax, H)
            name = "fig_proposer_framework" if layout != "both" else f"fig_proposer_framework_{tag}"
            pdf = os.path.join(FIGDIR, f"{name}.pdf")
            fig.savefig(pdf, format="pdf")
            fig.savefig(os.path.join(FIGDIR, f"{name}.png"), dpi=200)
            plt.close(fig)
            print("wrote", pdf)
    return 0


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else "--layout"
    val = sys.argv[2] if len(sys.argv) > 2 else "both"
    if arg == "--layout" and val in ("A", "B", "both"):
        raise SystemExit(main(val))
    print("usage: python scripts/fig_proposer_framework.py --layout A|B|both")
    raise SystemExit(2)