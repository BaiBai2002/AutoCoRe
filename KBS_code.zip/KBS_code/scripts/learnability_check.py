"""Operational learnability / measurability check.

The protocol requires a task to be *learnably measurable* before any feasibility or
deployment verdict on it is interpreted: the unshaped baseline must (a) beat a
task-agnostic random policy by more than its own seed-to-seed dispersion, and (b)
improve with budget. The check is computable from the per-run logs, because every
training run already evaluates a no-op policy and a random policy inside the
evaluator; those reference returns are stored in each run's JSON.

This turns a qualitative precondition into a measured verdict with intervals, and it
is what separates the settings that carry evidence from the ones that do not (the
`kaz` setting fails it; this script reports which others do).

Reads ``artifacts/bps_gate/*_final_base_s*.json`` (full budget) and
``*_probe_base_s*.json`` (probe budget). Writes
``artifacts/diagnostics/learnability.json``.
"""
from __future__ import annotations

import argparse
import glob
import json
import os

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "learnability.json")


def load(pattern: str) -> dict[str, dict[int, dict]]:
    """Group run records by environment, then by seed."""
    by_env: dict[str, dict[int, dict]] = {}
    for p in sorted(glob.glob(os.path.join(OUTDIR, pattern))):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        env = d.get("env")
        if not env or "final_return" not in d:
            continue
        by_env.setdefault(env, {})[int(d["seed"])] = d
    return by_env


def paired_ci(diffs: np.ndarray, n_boot: int = 20000, seed: int = 0,
              alpha: float = 0.05) -> tuple[float, float, float]:
    if diffs.size == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, diffs.size, size=(n_boot, diffs.size))
    means = diffs[idx].mean(axis=1)
    lo, hi = np.percentile(means, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(diffs.mean()), float(lo), float(hi)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-boot", type=int, default=20000)
    ap.add_argument("--rho-target", type=float, default=0.2)
    args = ap.parse_args()

    final = load("*_final_base_s*.json")
    probe = load("*_probe_base_s*.json")

    # E|R| per environment, from the feasibility table (measured on the reference
    # policy), so the resolution test uses the same scale as the feasibility verdict.
    abs_r: dict[str, float] = {}
    feas_path = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "lambda_feasibility.json")
    if os.path.exists(feas_path):
        with open(feas_path, encoding="utf-8") as f:
            for row in json.load(f)["rows"]:
                abs_r.setdefault(row["env_id"], float(row["mean_abs_return"]))
    rho_target = args.rho_target

    rows = []
    print(f"{'env':<30s} {'n':>3s} {'trained':>10s} {'random':>10s} {'noop':>10s} "
          f"{'tr-random':>26s} {'budget trend':>14s}  verdict")
    for env in sorted(final):
        recs = final[env]
        seeds = sorted(recs)
        fin, rnd, nop = [], [], []
        for s in seeds:
            d = recs[s]
            if "random_return" in d and "noop_return" in d:
                fin.append(d["final_return"]); rnd.append(d["random_return"]); nop.append(d["noop_return"])
        if not fin:
            continue
        fin_a, rnd_a, nop_a = map(np.asarray, (fin, rnd, nop))
        d_rand = fin_a - rnd_a
        m, lo, hi = paired_ci(d_rand, args.n_boot)
        # Budget trend: unshaped baseline at the probe budget vs the final budget.
        trend = float("nan")
        precs = probe.get(env, {})
        if precs:
            pv = [v["final_return"] for v in precs.values()]
            trend = float(fin_a.mean() - np.mean(pv))

        beats_random = lo > 0                      # interval excludes zero, positive
        improves = (trend > 0) if np.isfinite(trend) else False
        # Scale-relative margin, so a task with a tiny return scale cannot pass on noise.
        rel = float(m / max(abs(rnd_a.mean()), 1e-9))
        verdict = ("measurable" if (beats_random and improves) else
                   "measurable (budget trend untested)" if beats_random else
                   "NOT measurable")

        # Resolution test. The learnability test above asks whether *any* signal is
        # present; it does not ask whether the signal the method is meant to inject
        # (rho* E|R|) is large enough to be seen above the noise of the very
        # comparison being reported. A setting can pass learnability and still be
        # uninformative about gains, which is what happens when the target signal is
        # smaller than the across-seed standard error of the baseline.
        se = float(fin_a.std(ddof=1) / np.sqrt(fin_a.size)) if fin_a.size > 1 else float("nan")
        signal = (rho_target * abs_r[env]) if env in abs_r else None
        resolved = (signal is not None and np.isfinite(se) and signal > se)
        rows.append({
            "env": env, "n": int(fin_a.size),
            "trained_mean": float(fin_a.mean()), "random_mean": float(rnd_a.mean()),
            "noop_mean": float(nop_a.mean()),
            "trained_minus_random": m, "trained_minus_random_lo": lo,
            "trained_minus_random_hi": hi,
            "relative_margin": rel,
            "budget_trend_final_minus_probe": trend,
            "beats_random_ci_excludes_zero": bool(beats_random),
            "baseline_se_across_seeds": se,
            "target_signal_rho_times_absR": signal,
            "signal_exceeds_baseline_se": bool(resolved) if signal is not None else None,
            "verdict": verdict,
        })
        print(f"{env:<30s} {fin_a.size:>3d} {fin_a.mean():>10.2f} {rnd_a.mean():>10.2f} "
              f"{nop_a.mean():>10.2f} {m:>+9.2f} [{lo:+7.2f},{hi:+7.2f}] "
              f"{trend:>+14.2f}  {verdict}")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
