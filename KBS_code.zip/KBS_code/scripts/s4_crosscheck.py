"""S4: independent cross-recomputation of the manuscript's headline numbers.

Purpose: confirm that every load-bearing number in the paper can be rebuilt *from raw logs by
a second, independent code path* --- not merely that the string appears in an artifact (which
`verify_claims.py` already checks).

Independence is obtained by
  * reading the per-seed / per-configuration values out of the stored summaries directly,
  * recomputing the pooled paired mean and a **percentile** bootstrap interval (the original
    analyses report stratified bootstrap intervals),
  * using a different RNG seed and a different resampling routine,
and then comparing against the value quoted in the manuscript within a stated tolerance.
Every comparison prints RECOMPUTED / QUOTED / Δ / verdict, and the script exits non-zero if any
number fails to reproduce.
"""
from __future__ import annotations

import glob
import json
import os
import re
import statistics
import sys

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
D = os.path.join(ROOT, "artifacts", "diagnostics")
G = os.path.join(ROOT, "artifacts", "bps_gate")
SECTIONS = os.path.join(ROOT, "paper", "sections")

TOL = {"mean": 0.75, "ci": 3.0, "scale": 0.05}


def load(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def paired_interval(pairs: list[float], n_boot: int = 20000, seed: int = 7) -> tuple[float, float, float]:
    """Percentile bootstrap over per-seed paired differences (independent of the original)."""
    a = np.asarray(pairs, dtype=float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, a.size, size=(n_boot, a.size))
    means = a[idx].mean(axis=1)
    return float(a.mean()), float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def pooled_pairs(summary: dict, base_match: str) -> list[float]:
    """Pooled per-seed paired differences of each replicate's *own* deployed candidate
    against the baseline whose key contains `base_match` (the paper's estimator)."""
    keys = list(summary.get("finals", {}))
    base_key = next((k for k in keys if base_match in k), None)
    if base_key is None:
        return []
    base = summary["finals"][base_key]
    if not isinstance(base, dict):
        return []
    out = []
    for d in summary.get("decisions", []):
        gc = d.get("gate_choice")
        if not isinstance(gc, dict) or not d.get("gate_deployed"):
            continue
        k = next((kk for kk in keys if gc.get("key") and gc["key"] in kk), None)
        if k is None or not isinstance(summary["finals"][k], dict):
            continue
        arm = summary["finals"][k]
        for sd in sorted(set(arm) & set(base)):
            out.append(float(arm[sd]) - float(base[sd]))
    return out


def check(name: str, recomputed: float, quoted: float, tol: float) -> bool:
    good = abs(recomputed - quoted) <= tol
    print(f"  [{'ok ' if good else 'FAIL'}] {name:<44s} recomputed {recomputed:>10.3f}   "
          f"quoted {quoted:>10.3f}   Δ {recomputed - quoted:+.3f}  (tol {tol})")
    return good


def tex() -> str:
    return "".join(open(f, encoding="utf-8").read()
                   for f in sorted(glob.glob(os.path.join(SECTIONS, "*.tex"))))


def main() -> int:
    ok = True
    t = tex()

    print("=" * 96)
    print("S4 — independent cross-recomputation")
    print("=" * 96)

    # ---- 1. Table II: lambda*, applied shortfall, team-reachable dominance ---------------
    print("\n1. Table II (feasibility): lambda* and the applied shortfall")
    feas = load(os.path.join(D, "lambda_feasibility.json"))
    lam_max = max(feas["grid"])
    n_agents = {"simple_spread_v3": 3, "simple_reference_v3": 2,
                "simple_push_v3": 2, "simple_speaker_listener_v4": 2,
                "pursuit_v5": 8, "knights_archers_zombies_v11": 4}
    rows = []
    for r in feas["rows"]:
        lam_star = 0.2 * r["mean_abs_return"] / r["mean_abs_delta_phi"]
        n = n_agents[r["env_id"]]
        rows.append((r["env_id"], r["potential"], lam_star, lam_star / (n * lam_max)))
    infeas = [x for x in rows if x[2] > lam_max]
    lo = min(x[3] for x in infeas)
    hi = max(x[3] for x in infeas)
    ok &= check("applied shortfall, lower", lo, 4.4, 0.2)
    ok &= check("applied shortfall, upper", hi, 101.0, 1.0)
    # quoted in the manuscript?
    for needle in ("4.4$--$101\\times", "0.20$--$4.6\\%"):
        present = needle in t
        print(f"  [{'ok ' if present else 'FAIL'}] quoted in the manuscript: {needle}")
        ok &= present

    # ---- 2. Deployment audit: paired gains vs unshaped and vs budget-matched --------------
    print("\n2. Deployment audit (rich pool, N=3): paired gain of the deployed candidate")
    s = load(os.path.join(G, "bps_n3_rho020_summary.json"))
    for match, quoted, label in (("_final_base", 38.70, "vs unshaped"),
                                 ("base_bm", 25.74, "vs budget-matched")):
        pairs = pooled_pairs(s, match)
        if pairs:
            m, lo_, hi_ = paired_interval(pairs)
            ok &= check(f"deployed gain {label} ({len(pairs)} seed-rows)", m, quoted, TOL["mean"])
        else:
            print(f"  [skip] no '{match}' baseline in the summary")

    # ---- 3. Pre-registered confirmation ----------------------------------------------------
    print("\n3. Pre-registered confirmation")
    c = load(os.path.join(G, "bps_confirm_summary.json"))
    for match, quoted, label, tol in (("base_bm", 29.39, "vs budget-matched", TOL["mean"]),):
        pairs = pooled_pairs(c, match)
        if pairs:
            m, lo_, hi_ = paired_interval(pairs)
            ok &= check(f"confirmatory gain {label} ({len(pairs)} seed-rows)", m, quoted, tol)
            ok &= check("its 95% lower end", lo_, 14.88, TOL["ci"])
            ok &= check("its 95% upper end", hi_, 43.67, TOL["ci"])
        else:
            print(f"  [skip] no '{match}' baseline in the confirmatory summary")

    # ---- 4. Dose response: the grid ceiling is inert ----------------------------------------
    print("\n4. Dose response: paired change at the grid ceiling")
    dr = load(os.path.join(D, "dose_response_merged.json"))
    for lam, pot, quoted in ((0.4, "spread_coverage", 0.1), (0.4, "spread_assignment", 8.5)):
        rows = [r for r in dr["rows"] if abs(r.get("lambda", -1) - lam) < 1e-9
                and r.get("potential") == pot]
        if rows:
            ok &= check(f"delta raw at lambda={lam} ({pot.split('_')[1]})", float(rows[0]["delta"]),
                        quoted, TOL["mean"])

    # ---- 5. Every quoted headline number is present in the manuscript -----------------------
    print("\n5. Manuscript containment of the headline numbers")
    for needle in ("+25.74", "+29.39", "+38.70", "+54.27", "$+109.9$", "$+89.6$",
                   "1{,}822", "13.5", "+0.85$ to $-0.85"):
        present = needle in t
        print(f"  [{'ok ' if present else 'FAIL'}] {needle}")
        ok &= present

    print("\n" + "=" * 96)
    print("S4 verdict:", "CROSS-CHECK PASSES" if ok else "DISCREPANCY — inspect the FAIL rows")
    print("=" * 96)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
