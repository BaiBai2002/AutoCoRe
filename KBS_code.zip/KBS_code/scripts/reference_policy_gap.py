"""How much does the feasibility verdict depend on the reference policy?

The calibration ``lambda* = rho* E|R| / E|dPhi|`` is measured under a task-agnostic
*uniform random* reference policy. The natural objection is that such a policy is
unrepresentative: on a sparse task it earns almost nothing, so E|R| is
underestimated and the verdict can be optimistic. This script quantifies the
sensitivity by recomputing the calibration under reference policies of increasing
quality --- the uniform random policy, and policies trained on the *unshaped* task
for a short and a longer budget --- holding the potential, the horizon, the episode
count and the seed fixed.

The per-episode telescoping total is ``gamma**H Phi(s_H) - Phi(s_0)`` for that
episode, as in Eq. (telescope), and actions for the uniform reference are drawn from
an explicitly seeded generator (P7).

Usage:
    python scripts/reference_policy_gap.py --env knights_archers_zombies_v11 \
        --max-cycles 100 --budgets 0,30000,100000
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Callable

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "reference_policy_gap.json")


def env_facts(env_id: str, max_cycles: int):
    from autocore.envs.vec_pz import make_pz_env
    env = make_pz_env(env_id, max_cycles=max_cycles)
    names = list(env.possible_agents)
    obs_dim = int(np.prod(env.observation_space(names[0]).shape))
    act_dims = {a: int(env.action_space(a).n) for a in names}
    env.close()
    return names, obs_dim, act_dims


def build_potential(env_id: str, max_cycles: int, seed: int):
    from autocore.selection.landscape_search import LinearPotential
    from autocore.selection.obs_features import build_obs_bank
    bank = build_obs_bank(env_id, max_cycles=max_cycles, n_episodes=6, seed=seed)
    rng = np.random.default_rng(seed)
    return LinearPotential(bank, list(rng.normal(size=bank.dim))), bank


def rollout_scales(env_id: str, potential_fn, policy: Callable[[dict], dict],
                   max_cycles: int, n_episodes: int, seed: int, gamma: float = 0.99):
    """E|R| and E|dPhi| for one reference policy, accumulated per episode."""
    from autocore.envs.vec_pz import make_pz_env, state_from_obs

    env = make_pz_env(env_id, max_cycles=max_cycles)
    names = list(env.possible_agents)
    rets, dphis, phis = [], [], []
    for ep in range(n_episodes):
        res = env.reset(seed=seed * 1000 + ep)
        raw = res[0] if isinstance(res, tuple) else res
        phi0 = float(potential_fn(state_from_obs(raw, names)))
        phis.append(phi0)
        disc, phi_last = 0.0, phi0
        for t in range(max_cycles):
            if not getattr(env, "agents", []):
                break
            acts = policy(raw)
            out = env.step(acts)
            obs, rew = out[0], out[1]
            disc += (gamma ** t) * float(sum(rew.values()))
            phi_last = float(potential_fn(state_from_obs(obs, names)))
            phis.append(phi_last)
            raw = obs
        rets.append(abs(disc))
        dphis.append(abs((gamma ** max_cycles) * phi_last - phi0))
    env.close()
    return (float(np.mean(rets)), float(np.mean(dphis)), float(np.mean(np.abs(phis))))


def random_policy(act_dims: dict, rng: np.random.Generator):
    def policy(raw: dict) -> dict:
        return {a: int(rng.integers(0, act_dims[a])) for a in raw}
    return policy


def train_unshaped(env_id: str, max_cycles: int, steps: int, seed: int,
                   num_envs: int = 16, horizon: int = 80):
    """Shared-parameter IPPO on the *unshaped* task; returns (agent, obs_dim, names)."""
    import torch
    from autocore.algos.ppo_role import MARLPPO, MARLPPOConfig, Rollout
    from autocore.envs.vec_pz import VecPZ

    torch.manual_seed(seed)
    np.random.seed(seed)
    env = VecPZ(env_id, num_envs=num_envs, max_cycles=max_cycles,
                base_seed=seed * 1000, potential_fn=None, shaping_lambda=0.0, gamma=0.99)
    cfg = MARLPPOConfig(lr=3e-4, hidden_dim=512, num_layers=2, update_epochs=8,
                        num_minibatches=8, entropy_coef=0.003, value_coef=0.5,
                        max_grad_norm=0.5, device="cuda")
    agent = MARLPPO(env.roles, env.agent_index, env.num_agents, env.obs_dim, cfg)
    obs = env.reset()
    names = list(env.agent_names)
    obs_dim = env.obs_dim
    for _ in range(max(1, steps // (num_envs * horizon))):
        rollout, obs = _rollout(env, agent, horizon, obs)
        agent.update(rollout)
    env.close()
    return agent, obs_dim, names


def _rollout(env: Any, agent: Any, horizon: int, current_obs: np.ndarray):
    from autocore.algos.ppo_role import Rollout
    n_envs, n_agents = env.num_envs, env.num_agents
    obs = np.zeros((horizon, n_envs, n_agents, env.obs_dim), dtype=np.float32)
    actions = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    log_probs = np.zeros_like(actions)
    rewards = np.zeros_like(actions)
    values = np.zeros_like(actions)
    next_values = np.zeros_like(actions)
    terminated = np.zeros_like(actions)
    dones = np.zeros_like(actions)
    for t in range(horizon):
        act, lp, val = agent.act(current_obs, deterministic=False)
        out = env.step(act)
        obs[t], actions[t], log_probs[t], values[t] = current_obs, act, lp, val
        next_values[t] = agent.value_of(out.next_obs)
        rewards[t] = out.rewards
        terminated[t] = out.terminated[:, None]
        dones[t] = out.dones[:, None]
        current_obs = out.obs
    return Rollout(obs=obs, actions=actions, log_probs=log_probs, rewards=rewards,
                   values=values, next_values=next_values, terminated=terminated,
                   dones=dones), current_obs


def greedy_policy(agent: Any, obs_dim: int, names: list[str]):
    """Pack raw per-agent observations exactly as ``VecPZ`` does and act greedily."""
    index = {a: i for i, a in enumerate(names)}

    def policy(raw: dict) -> dict:
        row = np.zeros((len(names), obs_dim), dtype=np.float32)
        for a in names:
            v = raw.get(a)
            if v is not None:
                flat = np.asarray(v, dtype=np.float32).reshape(-1)
                row[index[a], : flat.shape[0]] = flat
        act, _, _ = agent.act(row[None], deterministic=True)
        return {a: int(round(float(act[0, index[a]]))) for a in raw}

    return policy


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="knights_archers_zombies_v11")
    ap.add_argument("--max-cycles", type=int, default=100)
    ap.add_argument("--budgets", default="0,30000,100000")
    ap.add_argument("--episodes", type=int, default=40)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--rho-target", type=float, default=0.2)
    args = ap.parse_args()

    pot, bank = build_potential(args.env, args.max_cycles, args.seed)
    names, obs_dim, act_dims = env_facts(args.env, args.max_cycles)
    print(f"{args.env}: potential = fixed direction over {bank.dim} obs features "
          f"{bank.names}; {len(names)} agents; act dims {sorted(set(act_dims.values()))}")

    rows = []
    for budget in [int(b) for b in args.budgets.split(",")]:
        if budget == 0:
            policy = random_policy(act_dims, np.random.default_rng(args.seed))
            label = "uniform random"
        else:
            print(f"  training an unshaped reference policy for {budget} steps ...", flush=True)
            agent, a_obs_dim, a_names = train_unshaped(
                args.env, args.max_cycles, budget, args.seed)
            policy = greedy_policy(agent, a_obs_dim, a_names)
            label = f"trained {budget} steps"
        m_r, m_dphi, m_phi = rollout_scales(
            args.env, pot, policy, args.max_cycles, args.episodes, args.seed)
        lam = args.rho_target * m_r / max(m_dphi, 1e-12)
        rows.append({"budget": budget, "label": label, "mean_abs_return": m_r,
                     "mean_abs_delta_phi": m_dphi, "mean_abs_phi": m_phi,
                     "lambda_star": lam, "in_grid": bool(lam <= 0.4)})
        print(f"  {label:<24s} E|R|={m_r:10.3f}  E|dPhi|={m_dphi:8.4f}  "
              f"lambda*={lam:8.3f}  in-grid={lam <= 0.4}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"env": args.env, "max_cycles": args.max_cycles,
                   "episodes": args.episodes, "seed": args.seed,
                   "rho_target": args.rho_target, "grid_ceiling": 0.4, "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
