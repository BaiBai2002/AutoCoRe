import os, re, subprocess, glob, json
import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PDF = os.path.join(ROOT, "paper", "main_final.pdf")
OUT = os.path.join(ROOT, "audit", "_t3_bands")
os.makedirs(OUT, exist_ok=True)
for f in glob.glob(os.path.join(OUT, "*.png")):
    os.remove(f)

DPI = 150
subprocess.run(["pdftoppm", "-r", str(DPI), "-png", PDF, os.path.join(OUT, "pg")], check=False)

xml = subprocess.run(["pdftotext", "-bbox", PDF, "-"], capture_output=True, text=True, encoding="utf-8").stdout
pages_xml = re.split(r"<page\b", xml)[1:]


def words_on_page(i):
    p = pages_xml[i]
    ws = re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)</word>', p)
    return [(float(a), float(b), float(c), float(d), t) for a, b, c, d, t in ws]


def bands(dark, x0, x1, gap_tol=8):
    sub = dark[:, x0:x1]
    rows = sub.any(axis=1)
    H = len(rows)
    out = []
    y = 0
    while y < H:
        if rows[y]:
            start = y
            y2 = y
            gap = 0
            while y2 < H:
                if rows[y2]:
                    gap = 0
                else:
                    gap += 1
                    if gap > gap_tol:
                        break
                y2 += 1
            end = y2 - gap
            out.append((start / DPI, end / DPI))
            y = y2
        else:
            y += 1
    return out


report = {}
widths = []
for i in range(len(pages_xml)):
    m = re.search(r'width="([\d.]+)" height="([\d.]+)"', pages_xml[i])
    Wp, Hp = float(m.group(1)), float(m.group(2))
    img = sorted(glob.glob(os.path.join(OUT, "pg-*.png")))
    p = img[i]
    a = np.asarray(Image.open(p).convert("L"))
    H, W = a.shape
    dark = a < 128
    x0L, x1L = int(0.68 * DPI), int(4.20 * DPI)
    x0R, x1R = int(4.30 * DPI), int(7.85 * DPI)
    bl = bands(dark, x0L, x1L)
    br = bands(dark, x0R, x1R)
    ws = words_on_page(i)
    rec = {"page": i + 1, "left_bands": [], "right_bands": []}
    for (s, e) in bl:
        wl = [t for t in ws if float(t[0]) < Wp / 2.0 and s * 72.0 <= float(t[1]) and float(t[3]) <= e * 72.0]
        rec["left_bands"].append({"y0": round(s, 2), "y1": round(e, 2), "h": round(e - s, 2), "nwords": len(wl)})
    for (s, e) in br:
        wl = [t for t in ws if float(t[0]) >= Wp / 2.0 and s * 72.0 <= float(t[1]) and float(t[3]) <= e * 72.0]
        rec["right_bands"].append({"y0": round(s, 2), "y1": round(e, 2), "h": round(e - s, 2), "nwords": len(wl)})
    report[str(i + 1)] = rec
    widths.append(round(Wp, 1))

json.dump(report, open(os.path.join(ROOT, "audit", "_t3_floatbands.json"), "w"), indent=2)

for k in sorted(report, key=int):
    r = report[k]
    print("== page", k, "== (col w pt %.1f)" % widths[int(k) - 1])
    for side in ("left_bands", "right_bands"):
        s = "L" if side == "left_bands" else "R"
        for b in r[side]:
            tag = "FIG?" if b["nwords"] == 0 else ""
            print("   %s  y=%5.2f-%5.2f  h=%4.2f  words=%4d %s" % (s, b["y0"], b["y1"], b["h"], b["nwords"], tag))
