"""G4 experiment: at a *fixed total budget*, does adaptive (successive-halving) probing
beat a flat probe allocation at selecting a deployable reward-shaping candidate?

G4 of the 2026-09-30 manual.  The manual's promotion bar (Route B) is that a rule must beat
fixed-probe / mean>0 / argmax and the same-budget no-shaping baseline on held-out data.  This
script isolates the *one* decision an allocation rule makes --- how to split a fixed probe
budget --- and holds everything else equal.

Design (one task, IPPO, horizon 80):

* Fixed total budget ``B`` per replicate; probe budget ``P`` and final budget ``F = B - P`` are
  identical in both arms.  The no-shaping baseline is trained to the same ``B``.
* FLAT: probe ``n`` candidates for ``p`` steps each; deploy the probe-argmax at ``F``.
* HALVING: probe all ``n`` for ``p/2`` (stage 1), keep the top ``k``, probe those for the
  remaining probe budget (stage 2), deploy the stage-2 probe-argmax at ``F``.
  Stage 1 (``n*p/2``) + stage 2 (``k * (P - n*p/2)/k``) = ``P`` exactly, so both arms cost the
  same and differ only in *shape*.

Endpoint: the deployed candidate's held-out raw return minus the no-shaping baseline at the same
``B`` (paired over held-out seeds, aggregated over pipeline replicates).  Negative results are kept.

Run ids encode the step count and are namespaced, so two budgets never share a cache slot (D34).
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bps_gate_experiment as H  # noqa: E402

ENV = "simple_spread_v3"
ALGO = "ippo"
N = 3
MC = 80
PROBE_SEED = 200
RHO = 0.2
OUT = os.path.join(H.PROJECT_ROOT, "artifacts", "diagnostics", "g4_allocation.json")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--budget", type=int, default=180_000)
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--probe-steps", type=int, default=5_120)
    ap.add_argument("--keep", type=int, default=6)
    ap.add_argument("--replicates", type=int, default=3)
    ap.add_argument("--final-seeds", default="100,101,102")
    ap.add_argument("--workers", type=int, default=12)
    ap.add_argument("--run-tag", default="g4")
    args = ap.parse_args()

    H.RUN_TAG = args.run_tag
    B = args.budget
    p = args.probe_steps
    n = args.n
    k = min(args.keep, n)
    P = n * p
    F = B - P
    assert F > 0, f"budget {B} too small for probe budget {P}"
    s1 = p // 2
    stage2_budget = P - n * s1
    s2 = max(s1, stage2_budget // k)
    final_seeds = [int(x) for x in args.final_seeds.split(",")]
    print(f"B={B} P={P} F={F} | flat {n}x{p} | halving {n}x{s1} -> keep {k} x {s2} "
          f"(stage2 budget {k * s2})", flush=True)

    states = H.collect_reference_states(ENV, max_cycles=MC, n_episodes=6, seed=0, num_agents=N)
    bank = H.FeatureBank().fit(states)

    def rid(kind: str, key: str, steps: int, seed: int) -> str:
        return H.run_id(ENV, ALGO, N, kind, f"{kind[0]}{steps}_{key}", seed)

    def train(steps: int, seed: int, w, key: str, kind: str):
        return H.train(ENV, ALGO, N, steps, seed, w, rid(kind, key, steps, seed), RHO, max_cycles=MC)

    reps = []
    for r in range(args.replicates):
        ps = r
        rng = np.random.default_rng(10_000 + ps)
        cands = H.sample_directions(n, bank.dim, rng, sparse_prob=0.4)
        keys = [H.weight_key(np.asarray(w, dtype=float)) for w in cands]
        reps.append({"ps": ps, "cands": cands, "keys": keys})

    # ---- probes: shared baseline probes + candidate probes (stage 1) ----------------------
    probe_vals: dict[tuple[int, str], float] = {}

    def do_probe(job):
        steps, seed, w, key = job
        v = H.train(ENV, ALGO, N, steps, seed, w, rid("probe", key, steps, seed), RHO, max_cycles=MC)
        return steps, key, v

    jobs = [(steps, PROBE_SEED, None, "base") for steps in {p, s1, s2}]
    for rep in reps:
        for key, w in zip(rep["keys"], rep["cands"]):
            for steps in {p, s1}:
                jobs.append((steps, PROBE_SEED, w, key))

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for steps, key, v in pool.map(do_probe, jobs):
            if v is not None:
                probe_vals[(steps, key)] = v

    def base(steps: int):
        return probe_vals.get((steps, "base"))

    # ---- resolve selections per replicate, collect stage-2 probes --------------------------
    stage2_jobs = []
    for rep in reps:
        g1 = {}
        for key in rep["keys"]:
            if (s1, key) in probe_vals and base(s1) is not None:
                g1[key] = probe_vals[(s1, key)] - base(s1)
        surv = sorted(g1, key=lambda kk: -g1[kk])[:k]
        rep["survivors"] = surv
        for key in surv:
            w = rep["cands"][rep["keys"].index(key)]
            stage2_jobs.append((s2, PROBE_SEED, w, key))
        # flat selection
        g0 = {}
        for key in rep["keys"]:
            if (p, key) in probe_vals and base(p) is not None:
                g0[key] = probe_vals[(p, key)] - base(p)
        rep["flat_sel"] = max(g0, key=lambda kk: g0[kk]) if g0 else None
        rep["stage1_gain"] = g1

    def do_probe2(job):
        steps, seed, w, key = job
        v = H.train(ENV, ALGO, N, steps, seed, w, rid("probe", key, steps, seed), RHO, max_cycles=MC)
        return steps, key, v

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for steps, key, v in pool.map(do_probe2, stage2_jobs):
            if v is not None:
                probe_vals[(steps, key)] = v

    for rep in reps:
        g2 = {}
        for key in rep["survivors"]:
            if (s2, key) in probe_vals and base(s2) is not None:
                g2[key] = probe_vals[(s2, key)] - base(s2)
        rep["stage2_gain"] = g2
        rep["halv_sel"] = max(g2, key=lambda kk: g2[kk]) if g2 else None

    # ---- finals: baseline at B, and each arm's selection at F ------------------------------
    final_jobs = []
    for seed in final_seeds:
        final_jobs.append(("base", B, seed, None))
    for rep in reps:
        for arm, sel in (("flat", rep["flat_sel"]), ("halv", rep["halv_sel"])):
            if sel is None:
                continue
            w = rep["cands"][rep["keys"].index(sel)]
            tag = f"{arm}-{rep['ps']}"
            for seed in final_seeds:
                final_jobs.append((tag, F, seed, w))

    finals: dict[tuple[str, int], dict[int, float]] = {}

    def do_final(job):
        arm, steps, seed, w = job
        v = H.train(ENV, ALGO, N, steps, seed, w, rid("final", arm, steps, seed), RHO, max_cycles=MC)
        return arm, steps, seed, v

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for arm, steps, seed, v in pool.map(do_final, final_jobs):
            if v is not None:
                finals.setdefault((arm, steps), {})[seed] = v

    def mean_of(prefix: str, steps: int, per_rep: bool = False):
        per: dict[str, list[float]] = {}
        for (arm, st), d in finals.items():
            if st != steps:
                continue
            if prefix == "base":
                match = arm == "base"
            else:
                match = arm.startswith(prefix + "-")
            if match:
                per.setdefault(arm, []).extend(d.values())
        if per_rep:
            return {a: float(np.mean(v)) for a, v in per.items()}
        vals = [x for v in per.values() for x in v]
        return float(np.mean(vals)) if vals else None

    base_mean = mean_of("base", B)
    flat_mean = mean_of("flat", F)
    halv_mean = mean_of("halv", F)

    res = {"env": ENV, "algo": ALGO, "N": N, "B": B, "P": P, "F": F,
           "flat": {"n": n, "probe_steps": p},
           "halving": {"n": n, "keep": k, "stage1": s1, "stage2": s2},
           "final_seeds": final_seeds, "replicates": args.replicates,
           "baseline_mean_at_B": base_mean,
           "flat_mean": flat_mean, "halving_mean": halv_mean,
           "flat_delta": (flat_mean - base_mean) if (flat_mean is not None and base_mean is not None) else None,
           "halving_delta": (halv_mean - base_mean) if (halv_mean is not None and base_mean is not None) else None,
           "per_replicate_mean": {"flat": mean_of("flat", F, per_rep=True),
                                  "halving": mean_of("halv", F, per_rep=True)},
           "selection": [{"pipeline_seed": rep["ps"], "flat_sel": rep["flat_sel"],
                          "halv_sel": rep["halv_sel"], "survivors": rep["survivors"]}
                         for rep in reps]}

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2)

    print("\n=== G4 fixed-total-budget allocation ===")
    print(f"no-shaping baseline at B={B}: {base_mean}")
    print(f"FLAT    {n}x{p}: mean {flat_mean}  delta {res['flat_delta']}")
    print(f"HALVING {n}x{s1}->{k}x{s2}: mean {halv_mean}  delta {res['halving_delta']}")
    print("wrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
