# E1 — pre-registered confirmation batch. Frozen protocol: research_upgrade/kbs_upgrade/CONFIRM_PROTOCOL.md
#
# Six additional grounded draws per capable family (rep-offset 4..9), so each family reaches ten
# draws and the small-sample t analysis has nine degrees of freedom. The configuration is frozen
# before the first draw exists; nothing here may be tuned afterwards.
#
# This batch is NOT a search for a significant result. Every draw generated here is analysed and
# reported, and the protocol states in advance what happens if the effect does not survive.
#
# Usage:  powershell -NoProfile -File scripts/run_confirm_e1.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/e1_confirm.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "E1 confirmation batch starting; frozen config = grounded, K=12, N=3 IPPO, spread"
Write-Log "protocol: research_upgrade/kbs_upgrade/CONFIRM_PROTOCOL.md"

foreach ($r in 4, 5, 6, 7, 8, 9) {
    Run-Draw -Tag "confv2_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}
foreach ($r in 4, 5, 6, 7, 8, 9) {
    Run-Draw -Tag "confv2gpt_6_astra_r$r" -Extra @("--provider", "gpt_6_astra", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}

Write-Log "E1_CONFIRM_DONE"
