#!/bin/bash
set -e
echo "=== AutoCoRe Full Reproduction ==="
bash scripts/setup_env.sh
bash scripts/smoke_test.sh
bash scripts/run_pilot.sh
echo "Reproduction complete. See artifacts/ for results."
