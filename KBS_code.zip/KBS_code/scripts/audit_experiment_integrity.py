"""Integrity audit of the LLM-proposal experiment summaries.

Checks, for every stored summary under artifacts/llm_proposal/:

  C1  the deployed candidate is the one the *frozen rule* selects (max probe mean among
      non-negative candidates); reports every disagreement with the LCB-ranked variant
  C2  every reported per-arm gain recomputes from the raw `finals` and `base_final_by_seed`
  C3  probe seeds and held-out seeds are disjoint
  C4  summaries that share a configuration agree on their baseline curve (no cross-tag drift)
  C5  the metric is the last evaluation, i.e. len(curve) == ceil(steps/eval_every), never a max

Nothing is recomputed from anything but the stored run records, so a failure here means a
stored number is not reproducible from the runs that produced it.

Run: python scripts/audit_experiment_integrity.py
"""
from __future__ import annotations

import glob
import json
import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ARMS = ("llm", "llm_raw", "rand", "hand")


def safe(k: str) -> str:
    return k.replace("::", "_").replace(":", "_")


def main() -> None:
    files = sorted(glob.glob(os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal",
                                           "conf*_summary.json")))
    if not files:
        raise SystemExit("no summaries found")
    fails = 0
    c1_disagree = 0
    c1_cases = []
    base_by_cfg: dict[tuple, dict] = {}

    for path in files:
        tag = os.path.basename(path).replace("_summary.json", "")
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        probe_seeds = set(str(s) for s in d.get("probe_seeds", []))
        final_seeds = [str(s) for s in d.get("final_seeds", [])]
        base = d.get("base_final_by_seed", {})
        finals = d.get("finals", {})

        # C3
        if probe_seeds & set(final_seeds):
            print(f"[C3 FAIL] {tag}: probe and held-out seeds overlap")
            fails += 1

        for arm in ARMS:
            dec = d.get("decisions", {}).get(arm)
            if not dec:
                continue
            table = dec.get("probe_table", [])
            dep = dec.get("deployed")
            if not table:
                continue

            # C1: frozen rule = argmax probe mean among candidates with mean >= 0
            feasible = [t for t in table if t["probe_mean_gain"] >= 0]
            rule = max(feasible, key=lambda t: t["probe_mean_gain"]) if feasible else None
            lcb = max(table, key=lambda t: t["probe_lcb"])
            if dep is not None:
                if rule is None:
                    print(f"[C1 FAIL] {tag}/{arm}: deployed despite no non-negative candidate")
                    fails += 1
                elif dep["key"] != rule["key"]:
                    c1_disagree += 1
                    c1_cases.append((tag, arm, dep["name"], rule["name"],
                                     round(dep["probe_mean_gain"], 2),
                                     round(rule["probe_mean_gain"], 2)))
            else:
                if rule is not None:
                    print(f"[C1 FAIL] {tag}/{arm}: abstained but a non-negative candidate exists")
                    fails += 1

            # C2: recompute the arm gain
            e = d.get("per_arm", {}).get(arm, {})
            if dep is not None and "deployed_mean_gain" in e:
                vals = [finals[f"final_{safe(dep['key'])}_s{s}"] - base[s]
                        for s in final_seeds
                        if f"final_{safe(dep['key'])}_s{s}" in finals and s in base]
                if not vals:
                    print(f"[C2 FAIL] {tag}/{arm}: no stored finals for the deployed candidate")
                    fails += 1
                else:
                    rec = sum(vals) / len(vals)
                    if abs(rec - e["deployed_mean_gain"]) > 1e-6:
                        print(f"[C2 FAIL] {tag}/{arm}: reported {e['deployed_mean_gain']:.4f} "
                              f"vs recomputed {rec:.4f}")
                        fails += 1
                    if len(vals) != len(final_seeds):
                        print(f"[C2 WARN] {tag}/{arm}: {len(vals)}/{len(final_seeds)} held-out seeds")
        # C4
        cfg = (d.get("env"), d.get("N"), d.get("final_steps"),
               tuple(d.get("final_seeds", [])))
        if base:
            prev = base_by_cfg.get(cfg)
            if prev is not None and prev != base:
                print(f"[C4 FAIL] {tag}: baseline differs from another tag with the same config")
                fails += 1
            base_by_cfg.setdefault(cfg, base)

    # C5: independent check on a sample of underlying run records
    runs = sorted(glob.glob(os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal", "runs",
                                         "*.json")))
    checked = 0
    for rp in runs[:400]:
        try:
            with open(rp, encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            print(f"[C5 FAIL] unreadable run record: {os.path.basename(rp)}")
            fails += 1
            continue
        curve = rec.get("curve") or []
        if curve and rec.get("final_return") is not None:
            last = curve[-1][1]
            if abs(float(rec["final_return"]) - float(last)) > 1e-6:
                print(f"[C5 FAIL] {os.path.basename(rp)}: final_return != last curve value")
                fails += 1
            mx = max(c[1] for c in curve)
            if float(rec["final_return"]) > float(mx) + 1e-9:
                print(f"[C5 FAIL] {os.path.basename(rp)}: final_return exceeds curve max")
                fails += 1
            checked += 1

    if checked == 0:
        # A vacuous pass. With no run records the C5 recomputation checks nothing, so a green
        # audit would be misleading rather than reassuring. This is the exact failure mode a
        # reviewer hits when the released bundle omits artifacts/llm_proposal/runs/.
        print("[C5 FAIL] no run records found: the audit would pass vacuously; "
              "ship artifacts/llm_proposal/runs/ with the bundle")
        fails += 1

    print(f"\nsummaries audited : {len(files)}")
    print(f"run records checked: {checked}")
    print(f"C1 rule disagreements (LCB-ranked vs frozen rule): {c1_disagree}")
    for t in c1_cases:
        print(f"    {t[0]}/{t[1]}: deployed {t[2][:32]} (mean {t[4]}) "
              f"vs rule {t[3][:32]} (mean {t[5]})")
    rerun = sorted({t[0] for t in c1_cases})
    print("RERUN_TAGS=" + ",".join(rerun))
    print(f"HARD FAILURES: {fails}")
    if fails or (rerun and "--strict-c1" in sys.argv):
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
