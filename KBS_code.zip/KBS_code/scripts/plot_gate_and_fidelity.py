"""Two diagnostic figures.

``fig_gate_calibration``: the nominal error target of the conservative gate versus the
error rate actually observed when the gate opens (log-log, with the identity line).
``fig_probe_fidelity``: the probe score against the held-out paired gain for every
candidate of the rich pool, with the rank correlation and its bootstrap interval. Each
figure answers one question, and both use the shared style so that the two read as one
document.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import FAMILY, OUTCOME, apply_style, grid, legend_outside, save  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")


def gate_figure() -> None:
    with open(os.path.join(DIAG, "gate_calibration.json"), encoding="utf-8") as f:
        rows = json.load(f)
    rows = [r for r in rows if np.isfinite(r.get("p_harmful_given_open", np.nan))
            and r["nominal_alpha"] > 0]
    if not rows:
        print("no gate calibration rows")
        return
    apply_style()
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.42, 2.95))
    nom = np.asarray([r["nominal_alpha"] for r in rows])
    emp = np.asarray([r["p_harmful_given_open"] for r in rows])
    ns = np.asarray([r["n"] for r in rows])
    zs = np.asarray([r["z"] for r in rows])
    lims = [min(nom.min(), emp[emp > 0].min()) * 0.35, 1.2]

    ax.plot(lims, lims, ls="--", lw=1.0, color=OUTCOME["neutral"],
            label="calibrated ($y=x$)", zorder=1)
    # probe-count categories: orange/purple/blue, never red (red means "harmful here")
    for n_val, marker, color in ((3, "^", FAMILY["butterfly"]),
                                 (5, "o", FAMILY["mpe"]),
                                 (8, "s", FAMILY["sisl"])):
        m = ns == n_val
        if m.any():
            ax.scatter(nom[m], np.maximum(emp[m], 1e-3), marker=marker, s=24,
                       color=color, label=f"probe seeds $={n_val}$", zorder=3,
                       linewidths=0.0)
    worst = int(np.argmax(emp / nom))
    ax.annotate(f"$z={zs[worst]:g}$, $n={ns[worst]}$\n"
                f"{emp[worst] / nom[worst]:.0f}$\\times$ nominal",
                xy=(nom[worst], emp[worst]), xytext=(0, -26),
                textcoords="offset points", fontsize=6.2,
                color=OUTCOME["negative"], ha="left", va="top",
                arrowprops=dict(arrowstyle="-", lw=0.6, color=OUTCOME["negative"],
                                shrinkA=0, shrinkB=2))
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlim(*lims)
    ax.set_ylim(1e-3, 1.4)
    ax.set_xlabel("nominal violation rate $e^{-z}$")
    ax.set_ylabel("observed $P(\\mathrm{harm}\\mid\\mathrm{open})$")
    ax.set_title("the gate is a filter, not a guarantee", loc="left")
    grid(ax)
    legend_outside(ax, ncol=2, y=-0.30)
    fig.subplots_adjust(left=0.17, right=0.98, top=0.90, bottom=0.31)
    save(fig, "fig_gate_calibration")


def fidelity_figure() -> None:
    with open(os.path.join(DIAG, "heldout_fidelity.json"), encoding="utf-8") as f:
        rows = json.load(f)
    rows = [r for r in rows if r.get("n_candidates", 0) >= 20 and r.get("points")]
    if not rows:
        print("no rich-pool fidelity rows")
        return
    r = max(rows, key=lambda r: r["n_candidates"])
    x = np.asarray([p["probe_gain"] for p in r["points"]], dtype=float)
    y = np.asarray([p["heldout_gain"] for p in r["points"]], dtype=float)

    apply_style()
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.42, 2.95))
    ax.axhline(0, lw=0.7, color=OUTCOME["muted"])
    ax.axvline(0, lw=0.7, color=OUTCOME["muted"])
    ax.scatter(x, y, s=20, color=FAMILY["mpe"], alpha=0.85, zorder=3,
               linewidths=0.0, label="candidate")
    slope, intercept = np.polyfit(x, y, 1)
    xs = np.linspace(x.min(), x.max(), 50)
    ax.plot(xs, slope * xs + intercept, lw=1.2, color=FAMILY["sisl"],
            label=f"OLS (slope ${slope:.2f}$)", zorder=4)
    lo, hi = r["spearman_ci"]
    # placed bottom-right: the data occupy a rising band, leaving that corner empty
    ax.annotate(f"$n={r['n_candidates']}$\nSpearman ${r['spearman']:+.3f}$\n"
                f"95% CI $[{lo:+.3f},{hi:+.3f}]$",
                xy=(0.97, 0.04), xycoords="axes fraction", va="bottom", ha="right",
                fontsize=6.2,
                bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="0.8", lw=0.5,
                          alpha=0.92))
    ax.set_xlabel("probe gain (selection stage)")
    ax.set_ylabel("held-out paired gain")
    ax.set_title("the probe ranks a rich pool", loc="left")
    grid(ax)
    legend_outside(ax, ncol=2, y=-0.28)
    fig.subplots_adjust(left=0.19, right=0.98, top=0.90, bottom=0.29)
    save(fig, "fig_probe_fidelity")


def main() -> None:
    gate_figure()
    fidelity_figure()


if __name__ == "__main__":
    main()
