"""Training-free pool novelty: how many *distinct* potentials does a pool contain?

Each candidate is evaluated as a vector of telescoping totals dPhi over a fixed set
of reference episodes. The effective dimensionality of that (episodes x candidates)
matrix --- the participation ratio of its singular values --- and the mean pairwise
correlation measure how redundant a pool is. A redundant pool has fewer directions a
probe can distinguish, so this is a candidate pre-training diagnostic of pool quality.

Run: python scripts/pool_novelty.py --provider deepseek_v4_flash --reps 0,1,2
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "src"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "scripts"))

from llm_proposal_experiment import (  # noqa: E402
    gen_llm_pool, gen_random_pool, load_env_spec, load_hand_pool,
)
from autocore.algos.vec_mpe import state_from_world  # noqa: E402
from autocore.dsl.compiler import compile_dsl  # noqa: E402
from autocore.envs.pettingzoo_mpe import make_mpe_env  # noqa: E402
from autocore.shaping.potentials import PotentialFunction, ShapingConfig  # noqa: E402


def reference_episodes(env_id: str, max_cycles: int, n_episodes: int, seed: int,
                       num_agents: int | None) -> list[list[dict]]:
    env = make_mpe_env(env_id, max_cycles=max_cycles, num_agents=num_agents)
    rng = np.random.default_rng(seed)
    eps = []
    for ep in range(n_episodes):
        env.reset(seed=seed * 1000 + ep)
        states = [state_from_world(env.aec_env.world)]
        for _ in range(max_cycles):
            acts = {a: int(rng.integers(0, env.action_space(a).n)) for a in env.agents}
            env.step(acts)
            states.append(state_from_world(env.aec_env.world))
        eps.append(states)
    env.close()
    return eps


def dphi_vector(dsl: dict, episodes: list[list[dict]], gamma: float = 0.99) -> np.ndarray | None:
    try:
        compiled = compile_dsl(dsl)
        pf = PotentialFunction(compiled, ShapingConfig(gamma=gamma, shaping_lambda=0.0,
                                                       potential_clip=(-1.0, 1.0)))
    except Exception:
        return None
    out = []
    for states in episodes:
        h = len(states) - 1
        phi0 = float(pf.compute_potential(states[0]))
        phiH = float(pf.compute_potential(states[-1]))
        out.append((gamma ** h) * phiH - phi0)
    return np.asarray(out, dtype=float)


def novelty(mat: np.ndarray) -> dict:
    """mat: (episodes x candidates). Returns participation ratio and correlations."""
    m = mat - mat.mean(axis=0, keepdims=True)
    norms = np.linalg.norm(m, axis=0)
    keep = norms > 1e-12
    m = m[:, keep]
    if m.shape[1] < 2:
        return {"effective_dim": float(m.shape[1]), "mean_abs_corr": float("nan"),
                "n_constant": int((~keep).sum())}
    s = np.linalg.svd(m, compute_uv=False)
    s2 = s ** 2
    eff = float((s2.sum() ** 2) / (s2 ** 2).sum())
    c = np.corrcoef(m, rowvar=False)
    iu = np.triu_indices_from(c, k=1)
    return {"effective_dim": eff, "mean_abs_corr": float(np.mean(np.abs(c[iu]))),
            "n_constant": int((~keep).sum())}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", default="deepseek_v4_flash")
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--num-agents", type=int, default=None)
    ap.add_argument("--k", type=int, default=6)
    ap.add_argument("--reps", default="0,1,2")
    ap.add_argument("--n-episodes", type=int, default=24)
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--tag", default="pool_novelty")
    args = ap.parse_args()

    env_spec = load_env_spec(args.env)
    preds = list(env_spec.get("allowed_predicates", []))
    pots = list(env_spec.get("allowed_potentials", []))
    episodes = reference_episodes(args.env, args.max_cycles, args.n_episodes, args.seed,
                                  args.num_agents)
    print(f"reference episodes={len(episodes)}, horizon={args.max_cycles}, env={args.env}")

    reps = [int(x) for x in args.reps.split(",")]
    report: dict[str, list] = {"llm": [], "rand": [], "hand": []}
    for r in reps:
        pools = {
            "llm": gen_llm_pool(args.provider, env_spec, r, args.k, True),
            "rand": gen_random_pool(args.k, preds, pots, args.env,
                                    np.random.default_rng(7000 + r)),
            "hand": load_hand_pool(args.env),
        }
        for arm, items in pools.items():
            cols = []
            for c in items:
                v = dphi_vector(c["dsl"], episodes)
                if v is not None:
                    cols.append(v)
            if len(cols) < 2:
                continue
            mat = np.stack(cols, axis=1)
            nv = novelty(mat)
            nv["rep"] = r
            nv["n_candidates"] = len(cols)
            report[arm].append(nv)
            print(f"  rep{r} {arm:<5s} n={len(cols)} "
                  f"effective_dim={nv['effective_dim']:.2f} "
                  f"mean|corr|={nv['mean_abs_corr']:.3f} constant={nv['n_constant']}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal", f"{args.tag}.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"env": args.env, "provider": args.provider, "n_episodes": args.n_episodes,
                   "report": report}, f, indent=2)
    print("\nsummary (mean over replicates):")
    for arm, rows in report.items():
        if rows:
            ed = np.mean([x["effective_dim"] for x in rows])
            mc = np.nanmean([x["mean_abs_corr"] for x in rows])
            print(f"  {arm:<5s} mean effective_dim={ed:.2f}  mean|corr|={mc:.3f}")
    print("wrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
