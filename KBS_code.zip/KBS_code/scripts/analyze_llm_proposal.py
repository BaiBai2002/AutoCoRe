"""Analyse the LLM-proposal experiment summaries (research_upgrade/06_RESULTS.md).

Reads artifacts/llm_proposal/conf_r*.json and reports, per arm, the deployed
held-out gain, and the paired (LLM - random-valid) difference over
(replicate, held-out seed) cells with a stratified bootstrap interval.

Run: python scripts/analyze_llm_proposal.py --tags conf_r0,conf_r1,conf_r2
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ARMS = ("llm", "llm_raw", "rand", "hand")


def safe(k: str) -> str:
    return k.replace("::", "_").replace(":", "_")


def load(tag: str) -> dict | None:
    p = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal", f"{tag}_summary.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def boot_ci_level(x: np.ndarray, level: float = 0.95, n: int = 20000,
                  seed: int = 0) -> tuple[float, float]:
    """Percentile bootstrap CI of the mean, resampling cell values."""
    if x.size == 0:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    means = [float(np.mean(rng.choice(x, x.size, replace=True))) for _ in range(n)]
    a = (1.0 - level) / 2.0 * 100.0
    return float(np.percentile(means, a)), float(np.percentile(means, 100.0 - a))


def boot_ci(x: np.ndarray, n: int = 20000, seed: int = 0) -> tuple[float, float]:
    return boot_ci_level(x, 0.95, n, seed)


def cluster_ci(clusters: list[np.ndarray], level: float = 0.95, n: int = 20000,
               seed: int = 0) -> tuple[float, float]:
    """Draw-level (cluster) bootstrap.

    The independent unit is the candidate-generation draw / full pipeline
    replicate, not the held-out seed: seeds inside a draw share the same
    deployed candidate and the same reference arms.  Resampling whole draws
    with replacement (all of a draw's seed cells kept together) is therefore
    the honest interval, and it is wider than the cell-level bootstrap.
    """
    clusters = [c for c in clusters if c.size > 0]
    if not clusters:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    k = len(clusters)
    means = []
    for _ in range(n):
        idx = rng.integers(0, k, k)
        means.append(float(np.concatenate([clusters[i] for i in idx]).mean()))
    a = (1.0 - level) / 2.0 * 100.0
    return float(np.percentile(means, a)), float(np.percentile(means, 100.0 - a))


_T_TABLE = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365,
            8: 2.306, 9: 2.262, 10: 2.228, 11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145,
            15: 2.131, 16: 2.120, 17: 2.110, 18: 2.101, 19: 2.093, 20: 2.086,
            22: 2.074, 24: 2.064, 26: 2.056, 28: 2.048, 30: 2.042}


def _t_crit(df: int) -> float:
    """Two-sided 95% Student-t multiplier (table lookup, normal limit beyond 30 df)."""
    if df <= 0:
        return float("nan")
    if df in _T_TABLE:
        return _T_TABLE[df]
    if df > 30:
        return 1.96
    return _T_TABLE[max(k for k in _T_TABLE if k <= df)]


def _signflip_p(x: np.ndarray) -> float:
    """Exact two-sided sign-flip p-value.

    Valid under exchangeability of the paired differences. Enumerated exactly, so it is only
    used for the small draw counts this paper has (2^k <= 1024 up to ten draws).
    """
    k = x.size
    if k == 0 or k > 16:
        return float("nan")
    obs = abs(float(x.mean()))
    hits = 0
    for mask in range(1 << k):
        s = np.asarray([1.0 if (mask >> i) & 1 else -1.0 for i in range(k)])
        if abs(float((x * s).mean())) >= obs - 1e-12:
            hits += 1
    return hits / float(1 << k)


def tost(clusters: list[np.ndarray], delta: float, alpha: float = 0.05,
         n: int = 20000, seed: int = 0) -> tuple[float, float, bool]:
    """Two one-sided tests for equivalence, via the (1-2*alpha) cluster CI.

    Equivalence within +/- ``delta`` (the pre-stated smallest effect of
    practical interest) is established iff the (1-2*alpha) confidence
    interval lies entirely inside (-delta, +delta).  ``delta`` must be stated
    in advance; it is a *practical* bound in return units, not a fitted one.
    """
    lo, hi = cluster_ci(clusters, level=1.0 - 2.0 * alpha, n=n, seed=seed)
    return lo, hi, (np.isfinite(lo) and lo > -delta and hi < delta)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", default="conf_r0,conf_r1,conf_r2")
    ap.add_argument("--pairs", action="store_true",
                    help="also compute the paired (llm - rand) difference")
    ap.add_argument("--cluster", action="store_true",
                    help="also report draw-level (cluster) bootstrap intervals, the honest "
                         "unit given that held-out seeds inside one draw are not independent")
    ap.add_argument("--tost", type=float, default=None, metavar="DELTA",
                    help="equivalence bound (+/- DELTA, return units) for a two-one-sided-test "
                         "equivalence verdict on the paired contrasts")
    ap.add_argument("--small-sample", action="store_true",
                    help="also print the small-sample t interval and the exact sign-flip p-value "
                         "(the sensitivity analysis the confirmation protocol freezes)")
    args = ap.parse_args()

    tags = [t.strip() for t in args.tags.split(",") if t.strip()]
    summaries = [(t, load(t)) for t in tags]
    summaries = [(t, d) for t, d in summaries if d]
    if not summaries:
        raise SystemExit("no summaries found")

    print(f"tags={[t for t, _ in summaries]}")
    for t, d in summaries:
        print(f"  {t}: held-out seeds={[str(s) for s in d['final_seeds']]}")
    print()

    def cell(d: dict, arm: str, seed: str) -> float | None:
        dep = d["decisions"][arm].get("deployed")
        if not dep:
            return None
        v = d["finals"].get(f"final_{safe(dep['key'])}_s{seed}")
        b = d["base_final_by_seed"].get(seed)
        if v is None or b is None:
            return None
        return float(v - b)

    print(f"{'tag':<10s}{'base':>9s}" + "".join(f"{a:>10s}" for a in ARMS))
    pools: dict[str, list[float]] = {a: [] for a in ARMS}
    draw_pools: dict[str, list[np.ndarray]] = {a: [] for a in ARMS}
    pair_llm_rand: list[float] = []
    pair_llm_hand: list[float] = []
    draw_lr: list[np.ndarray] = []
    draw_lh: list[np.ndarray] = []
    for tag, d in summaries:
        dseeds = [str(s) for s in d["final_seeds"]]
        bm = float(np.mean(list(d["base_final_by_seed"].values())))
        row = []
        for a in ARMS:
            vals = [cell(d, a, s) for s in dseeds]
            vals = [v for v in vals if v is not None]
            pools[a].extend(vals)
            if vals:
                draw_pools[a].append(np.asarray(vals, dtype=float))
            row.append(float(np.mean(vals)) if vals else float("nan"))
        print(f"{tag:<10s}{bm:>9.1f}" + "".join(f"{v:>+10.1f}" for v in row))
        lr_vals, lh_vals = [], []
        for s in dseeds:
            lr, rr, hr = cell(d, "llm", s), cell(d, "rand", s), cell(d, "hand", s)
            if lr is not None and rr is not None:
                pair_llm_rand.append(lr - rr)
                lr_vals.append(lr - rr)
            if lr is not None and hr is not None:
                pair_llm_hand.append(lr - hr)
                lh_vals.append(lr - hr)
        if lr_vals:
            draw_lr.append(np.asarray(lr_vals, dtype=float))
        if lh_vals:
            draw_lh.append(np.asarray(lh_vals, dtype=float))

    print("\npooled deployed gain (all replicates x seeds):")
    for a in ARMS:
        x = np.asarray(pools[a], dtype=float)
        lo, hi = boot_ci(x)
        print(f"  {a:<8s} mean={x.mean():+8.2f}  n={x.size:>3d}  95%CI=[{lo:+.2f},{hi:+.2f}]")

    if args.pairs:
        for nm, arr in (("llm - rand", pair_llm_rand), ("llm - hand", pair_llm_hand)):
            x = np.asarray(arr, dtype=float)
            if x.size == 0:
                continue
            lo, hi = boot_ci(x)
            print(f"\npaired {nm}: mean={x.mean():+.2f}  n={x.size}  "
                  f"95%CI=[{lo:+.2f},{hi:+.2f}]  excludes0={lo > 0 or hi < 0}")

    if args.cluster:
        print("\ndraw-level (cluster) bootstrap — the honest unit "
              "(seeds within a draw share the deployed candidate):")
        for a in ARMS:
            if not draw_pools[a]:
                continue
            lo, hi = cluster_ci(draw_pools[a])
            m = float(np.mean([c.mean() for c in draw_pools[a]]))
            print(f"  {a:<8s} draws={len(draw_pools[a]):>2d}  mean={m:+8.2f}  "
                  f"95%CI=[{lo:+.2f},{hi:+.2f}]")
        for nm, cl in (("llm - rand", draw_lr), ("llm - hand", draw_lh)):
            if not cl:
                continue
            lo, hi = cluster_ci(cl)
            m = float(np.mean([c.mean() for c in cl]))
            print(f"  paired {nm}: draws={len(cl)}  mean={m:+.2f}  "
                  f"95%CI=[{lo:+.2f},{hi:+.2f}]  excludes0={lo > 0 or hi < 0}")

    if args.tost is not None:
        print(f"\nequivalence test (two one-sided tests, bound +/-{args.tost:g} return units):")
        for nm, cl in (("llm - rand", draw_lr), ("llm - hand", draw_lh)):
            if not cl:
                continue
            lo, hi, ok = tost(cl, args.tost)
            m = float(np.mean([c.mean() for c in cl]))
            print(f"  paired {nm}: mean={m:+.2f}  90%CI=[{lo:+.2f},{hi:+.2f}]  "
                  f"equivalent_within_{args.tost:g}={ok}")

    if args.small_sample:
        print("\nsmall-sample sensitivity (per-draw means are the independent units):")
        for nm, cl in (("llm - rand", draw_lr), ("llm - hand", draw_lh)):
            if not cl:
                continue
            m = np.asarray([c.mean() for c in cl], dtype=float)
            k = m.size
            mean, sd = float(m.mean()), float(m.std(ddof=1)) if k > 1 else float("nan")
            se = sd / np.sqrt(k) if k > 1 else float("nan")
            tcrit = _t_crit(k - 1)
            lo, hi = mean - tcrit * se, mean + tcrit * se
            p = _signflip_p(m)
            print(f"  paired {nm}: draws={k} mean={mean:+.2f} t95=[{lo:+.2f},{hi:+.2f}] "
                  f"excludes0={lo > 0 or hi < 0}  signflip_p={p:.3f}")

    # Upper-tail view: the probe selects the max, so the pool's operative
    # statistic is its best candidate, not its average.
    print("\nupper-tail view (probe mean gain per arm/replicate):")
    print(f"{'tag':<10s}{'arm':<7s}{'max':>9s}{'mean':>9s}{'median':>9s}")
    for tag, d in summaries:
        for a in ARMS:
            pt = d["decisions"][a]["probe_table"]
            if not pt:
                continue
            g = np.asarray([x["probe_mean_gain"] for x in pt], dtype=float)
            print(f"{tag:<10s}{a:<7s}{g.max():>+9.1f}{g.mean():>+9.1f}{np.median(g):>+9.1f}")


if __name__ == "__main__":
    main()
