"""Figure for the deployment-coefficient ablation.

Reads ``artifacts/diagnostics/deploy_coefficient_ablation.json`` and plots the
pooled deployed gain against the unshaped and budget-matched baselines for each
calibration target. Selection is held fixed across targets (the same
configurations are retrained), so the only thing that changes is the coefficient.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import FAMILY, OUTCOME, apply_style, grid, legend_outside, save  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")


def main() -> None:
    with open(os.path.join(DIAG, "deploy_coefficient_ablation.json"), encoding="utf-8") as f:
        data = json.load(f)
    rows = sorted(data["rows"], key=lambda r: r["rho_target"])

    apply_style()
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.45, 2.95))
    x = np.arange(len(rows))
    w = 0.36
    c_base, c_bm = FAMILY["mpe"], FAMILY["sisl"]

    def series(field, lo_field, hi_field):
        v = [r[field] for r in rows]
        lo = [r[field] - r[lo_field] for r in rows]
        hi = [r[hi_field] - r[field] for r in rows]
        return np.asarray(v), np.vstack([lo, hi])

    vb, eb = series("gain_vs_base", "vs_base_lo", "vs_base_hi")
    vm, em = series("gain_vs_bm", "vs_bm_lo", "vs_bm_hi")

    ax.bar(x - w / 2, vb, w, yerr=eb, capsize=2.4, color=c_base, alpha=0.92,
           error_kw=dict(ecolor=OUTCOME["neutral"], lw=0.9), label="vs unshaped")
    ax.bar(x + w / 2, vm, w, yerr=em, capsize=2.4, color=c_bm, alpha=0.92,
           error_kw=dict(ecolor=OUTCOME["neutral"], lw=0.9),
           label="vs budget-matched")
    for i in range(len(rows)):
        ax.annotate(f"{vb[i]:+.1f}", xy=(i - w / 2, vb[i] + eb[1][i]), xytext=(0, 2.5),
                    textcoords="offset points", ha="center", fontsize=6.1,
                    color=c_base)
        ax.annotate(f"{vm[i]:+.1f}", xy=(i + w / 2, vm[i] + em[1][i]), xytext=(0, 2.5),
                    textcoords="offset points", ha="center", fontsize=6.1,
                    color=c_bm)
    ax.axhline(0, color=OUTCOME["neutral"], lw=0.8)
    top = float(np.max(np.concatenate([vb + eb[1], vm + em[1]])))
    ax.set_ylim(0.0, top * 1.22)
    ax.set_xticks(x)
    ax.set_xticklabels([rf"$\rho^\star={r['rho_target']:g}$" for r in rows])
    ax.set_xlabel("calibration target (held-out seeds $100$--$109$)")
    ax.set_ylabel("deployed pipeline gain")
    ax.set_title("the coefficient target is a free parameter", loc="left")
    grid(ax, "y")
    legend_outside(ax, ncol=2, y=-0.26)
    fig.subplots_adjust(left=0.16, right=0.98, top=0.89, bottom=0.27)
    save(fig, "fig_rho_ablation")


if __name__ == "__main__":
    main()
