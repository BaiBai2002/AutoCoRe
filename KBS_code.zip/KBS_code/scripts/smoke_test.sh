#!/bin/bash
set -e
echo "=== AutoCoRe Smoke Test ==="
echo "Step 1: Running unit tests..."
python -m pytest tests/ -v --tb=short
echo "Step 2: Running smoke experiment..."
python -m autocore.experiments.run_matrix --config configs/experiments_smoke.yaml
echo "Smoke test complete."
