from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from autocore.experiments.protocol import ExperimentProtocol, FROZEN_PROTOCOL


PROTOCOL_FIELDS = [
    "envs", "methods", "seeds", "training_steps", "eval_interval",
    "eval_episodes", "candidate_budget", "probe_budget", "lambda_grid",
    "lambda_mode", "selector_weights", "code_version", "prompt_version",
    "dsl_schema_version", "env_spec_version", "alg_config", "shp_config",
]


def _serialize_value(v: Any) -> str:
    return json.dumps(v, sort_keys=True, default=str)


def _extract_run_protocol(run: dict) -> dict[str, Any]:
    extracted: dict[str, Any] = {}
    env_id = run.get("env_id", run.get("env", ""))
    method = run.get("method", "")
    seed = run.get("seed")
    extracted["env_id"] = env_id
    extracted["method"] = method
    extracted["seed"] = seed
    return extracted


def check_phase(phase_name: str, results: list[dict]) -> dict[str, Any]:
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for run in results:
        env_id = run.get("env_id", run.get("env", ""))
        method = run.get("method", "")
        key = (env_id, method)
        groups[key].append(run)

    mismatches: list[dict] = []
    consistent_count = 0

    for (env_id, method), runs in groups.items():
        if len(runs) < 2:
            consistent_count += 1
            continue

        ref_run = runs[0]
        ref_seed = ref_run.get("seed", ref_run.get("training_seed"))
        group_ok = True

        for i, run in enumerate(runs[1:], start=2):
            run_seed = run.get("seed", run.get("training_seed"))
            diffs: dict[str, dict] = {}

            for field in PROTOCOL_FIELDS:
                v_ref = ref_run.get("protocol", {}).get(field) if isinstance(ref_run.get("protocol"), dict) else ref_run.get(field)
                v_run = run.get("protocol", {}).get(field) if isinstance(run.get("protocol"), dict) else run.get(field)

                if v_ref is None and v_run is None:
                    continue
                if v_ref is None or v_run is None:
                    diffs[field] = {"ref": v_ref, "run": v_run}
                    continue
                if _serialize_value(v_ref) != _serialize_value(v_run):
                    diffs[field] = {"ref": v_ref, "run": v_run}

            if diffs:
                group_ok = False
                mismatches.append({
                    "phase": phase_name,
                    "group": {"env_id": env_id, "method": method},
                    "ref_seed": ref_seed,
                    "mismatch_seed": run_seed,
                    "diffs": diffs,
                })

        if group_ok:
            consistent_count += 1

    total_groups = len(groups)
    return {
        "phase": phase_name,
        "total_runs": len(results),
        "total_groups": total_groups,
        "consistent_groups": consistent_count,
        "mismatch_groups": len(mismatches),
        "all_consistent": len(mismatches) == 0,
        "mismatches": mismatches,
    }


def main() -> None:
    processed_dir = PROJECT_ROOT / "artifacts" / "v3_final" / "processed"
    diagnostics_dir = PROJECT_ROOT / "artifacts" / "v3_final" / "diagnostics"
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    ckpt_files = sorted(processed_dir.glob("ckpt_*.json")) if processed_dir.exists() else []
    if not ckpt_files:
        processed_dir_alt = PROJECT_ROOT / "artifacts" / "processed"
        ckpt_files = sorted(processed_dir_alt.glob("ckpt_v3_*.json")) if processed_dir_alt.exists() else []

    all_phases: dict[str, dict] = {}
    overall_consistent = True

    for ckpt_file in ckpt_files:
        phase_name = ckpt_file.stem.replace("ckpt_v3_", "").replace("ckpt_", "")
        try:
            with open(ckpt_file, "r", encoding="utf-8") as f:
                results = json.load(f)
        except Exception as e:
            print(f"SKIP {ckpt_file.name}: {e}")
            continue

        if not isinstance(results, list):
            print(f"SKIP {ckpt_file.name}: not a list")
            continue

        phase_report = check_phase(phase_name, results)
        all_phases[phase_name] = phase_report
        if not phase_report["all_consistent"]:
            overall_consistent = False

    output: dict[str, Any] = {
        "overall_consistent": overall_consistent,
        "num_phases": len(all_phases),
        "phases": all_phases,
    }

    output_path = diagnostics_dir / "protocol_consistency.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False, default=str)
    print(f"Saved protocol consistency report to {output_path}")

    if not overall_consistent:
        print("\nPROTOCOL_MISMATCH detected in the following runs:")
        for phase_name, report in all_phases.items():
            for m in report.get("mismatches", []):
                group = m["group"]
                print(f"  Phase={m['phase']} env={group['env_id']} method={group['method']}")
                print(f"    Ref seed={m['ref_seed']} Mismatch seed={m['mismatch_seed']}")
                for field, diff in m["diffs"].items():
                    print(f"    {field}: ref={diff['ref']} != run={diff['run']}")
    else:
        print("\nAll protocol fields are consistent across all phases.")
        sys.exit(0)

    sys.exit(1 if not overall_consistent else 0)


if __name__ == "__main__":
    main()
