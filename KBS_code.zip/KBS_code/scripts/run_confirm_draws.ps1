# Confirmation draws + the causal (primitive-removal) ablation.
#
# Two jobs, both triggered by the review:
#
#  (1) UNDER-POWERING. The headline grounded claims rest on 2-3 draws. Recomputing at the draw
#      level (scripts/analyze_llm_proposal.py --cluster) shows the DeepSeek grounded - random
#      interval crosses zero at three draws. Adding draws is therefore the highest-value fix for
#      the main claim, exactly the case where the review says a draw-count increase IS justified.
#
#  (2) CAUSAL ATTRIBUTION (Priority A). `--exclude-predicates agent_target_assignment_distance`
#      removes the task-relevant primitive from the grounded whitelist AND the gate's allowed set,
#      so the ONLY change is that the primitive is unreachable. Same budget, same pool size K=12,
#      same seeds. If the grounded arm collapses toward the raw level and loses to random valid,
#      reachability of that primitive is the mechanism; if not, the review's objection stands and
#      the claim is narrowed accordingly. Nothing here is pre-selected for a favourable outcome.
#
# Usage:  powershell -NoProfile -File scripts/run_confirm_draws.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/confirm.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "waiting for the second-task study to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/second_task.log" -Pattern "SECOND_TASK_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}

Write-Log "--- stage 1: extra grounded draws (fix the draw-level under-powering) ---"
Run-Draw -Tag "confv2_r3" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
    "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "3")
foreach ($r in 2, 3) {
    Run-Draw -Tag "confv2gpt_6_astra_r$r" -Extra @("--provider", "gpt_6_astra", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}

Write-Log "--- stage 2: causal ablation, assignment primitive removed ---"
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confnoassign_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r",
        "--exclude-predicates", "agent_target_assignment_distance")
}
foreach ($r in 0, 1) {
    Run-Draw -Tag "confnoassigngpt_r$r" -Extra @("--provider", "gpt_6_astra", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r",
        "--exclude-predicates", "agent_target_assignment_distance")
}

Write-Log "CONFIRM_DRAWS_DONE"
