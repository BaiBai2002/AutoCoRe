# CONFIRM_V3 — fresh-training confirmation of the grounded proposer contrasts.
#
# Pre-registered in research_upgrade/kbs_upgrade/CONFIRM_V3_PROTOCOL.md (2026-10-09, before any
# confv3_* draw existed). The candidate draws are the published confv2_r0..r4 /
# confv2gpt_6_astra_r0..r4 pools (cache hits; generation held fixed); the probe and final training
# are re-run with FRESH seeds never used before: probes 300,301,302; finals 110..114. Two families
# x five draws = ten draws. Idempotent, self-healing (three attempts per draw per round, ten rounds,
# 20-minute cooldown). Nothing is tuned after seeing data; every draw is reported in full.
#
# Usage:  powershell -NoProfile -File scripts/run_confirm_v3.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/confirm_v3.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) { $m | Tee-Object -FilePath $log -Append | Out-Null }

$tags = @()
foreach ($r in 0, 1, 2, 3, 4) {
    $tags += @{ tag = "confv3_r$r";    provider = "deepseek_v4_flash"; rep = $r }
    $tags += @{ tag = "confv3gpt_r$r"; provider = "gpt_6_astra";      rep = $r }
}

Write-Log "CONFIRM_V3 starting (10 draws: 2 families x 5 fresh-training draws; probes 300-302, finals 110-114)"

for ($round = 1; $round -le 10; $round++) {
    $missing = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($missing.Count -eq 0) { break }

    Write-Log "CONFIRM_V3 round ${round} starting; missing $($missing.Count) of 10"
    foreach ($t in $missing) {
        $summary = "artifacts/llm_proposal/$($t.tag)_summary.json"
        for ($a = 1; $a -le 3; $a++) {
            Write-Log "=== $($t.tag) (attempt ${a}) ==="
            & python -u scripts/llm_proposal_experiment.py --provider $t.provider --llm-v2 `
                --k-llm 12 --k-raw 6 --k-rand 12 --rep-offset $t.rep `
                --replicates 1 --probe-steps 50000 --probe-seeds 300,301,302 `
                --final-steps 300000 --final-seeds 110,111,112,113,114 --tag $t.tag 2>&1 |
                Tee-Object -FilePath $log -Append | Out-Null
            if (Test-Path $summary) { Write-Log "OK: $($t.tag)"; break }
            Write-Log "FAILED attempt ${a} for $($t.tag)"
            Start-Sleep -Seconds 90
        }
    }

    $left = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($left.Count -eq 0) { break }
    Write-Log "CONFIRM_V3 round ${round} finished; $($left.Count) still missing; cooling down 20 min"
    Start-Sleep -Seconds 1200
}

$final = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
if ($final.Count -eq 0) { Write-Log "CONFIRM_V3_ALL_DONE" } else { Write-Log "CONFIRM_V3_EXIT_INCOMPLETE" }