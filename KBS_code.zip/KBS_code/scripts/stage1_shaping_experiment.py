"""Controlled test of whether potential-based shaping helps once its magnitude
is calibrated, and whether any gain comes from task information or merely from
injecting a signal of the same size.

Arms (all budget-matched at the same total interaction count):
  base            no shaping
  cov_legacy      coverage potential at the legacy coefficient (0.2)
  cov_cal         coverage potential at the analytic coefficient
  asg_cal         assignment potential at the analytic coefficient
  asg_randctl     task-uninformative random potential, matched range, same lambda
  rescale         raw reward scaled by the same factor the shaping adds, no shaping
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import csv
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.dsl.compiler import compile_dsl
from autocore.selection.magnitude_calibration import estimate_scales, legacy_grid
from autocore.shaping.potentials import PotentialFunction, ShapingConfig

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")
GAMMA = 0.99


def dsl_potential(name: str):
    with open(os.path.join(PROJECT_ROOT, "configs", "dsl", name), encoding="utf-8") as f:
        dsl = json.load(f)
    compiled = compile_dsl(dsl)
    pf = PotentialFunction(compiled, ShapingConfig(gamma=GAMMA, shaping_lambda=1.0,
                                                   potential_clip=(-1.0, 1.0)))
    return pf.compute_potential


def dsl_path(name: str) -> str:
    return os.path.join(PROJECT_ROOT, "configs", "dsl", name)


def build_sweep_arms(env_id: str, rho_target: float, max_cycles: int,
                     values: list[float],
                     dsls: tuple[str, str] = ("spread_coverage.json", "spread_assignment.json")
                     ) -> list[dict]:
    """Coefficient sweep on one potential, to map dominance against performance."""
    dsl = dsl_path(dsls[1])
    est = estimate_scales(env_id, dsl_potential(dsls[1]), gamma=GAMMA,
                          max_cycles=max_cycles, n_episodes=40, seed=0)
    star = est.required_lambda(rho_target)
    print(f"  assignment potential: E|R|={est.mean_abs_return:.1f} "
          f"E|dPhi|={est.mean_abs_delta_phi:.4f} lambda*({rho_target})={star:.2f}")
    arms = [{"arm": "base", "args": []}]
    for v in values:
        arms.append({"arm": f"lam{v:g}", "args": ["--dsl", dsl, "--lam", f"{v:.4f}"]})
    print(f"  lambda*={star:.2f} -> rho = " +
          ", ".join(f"{v:g}:{v * est.scale_ratio:.4f}" for v in values))
    return arms


def build_arms(env_id: str, rho_target: float, max_cycles: int,
               dsls: tuple[str, str] = ("spread_coverage.json", "spread_assignment.json"),
               num_agents: int | None = None) -> list[dict]:
    pot_dsl, asg_dsl = dsls
    lam = {}
    for name in (pot_dsl, asg_dsl):
        est = estimate_scales(env_id, dsl_potential(name), gamma=GAMMA,
                              max_cycles=max_cycles, n_episodes=40, seed=0,
                              num_agents=num_agents)
        lam[name] = est.required_lambda(rho_target)
        lo, hi = est.attainable_dominance(legacy_grid())
        print(f"  {name}: E|R|={est.mean_abs_return:.1f} E|dPhi|={est.mean_abs_delta_phi:.4f} "
              f"lambda*={lam[name]:.2f} legacy-grid rho in [{lo:.2e},{hi:.2e}] "
              f"feasible={est.feasible(legacy_grid(), rho_target)}")
    return [
        {"arm": "base", "args": []},
        {"arm": "pot_legacy", "args": ["--dsl", dsl_path(pot_dsl), "--lam", "0.2"]},
        {"arm": "pot_cal", "args": ["--dsl", dsl_path(pot_dsl),
                                    "--lam", f"{lam[pot_dsl]:.4f}"]},
        {"arm": "asg_cal", "args": ["--dsl", dsl_path(asg_dsl),
                                    "--lam", f"{lam[asg_dsl]:.4f}"]},
        {"arm": "asg_randctl", "args": ["--dsl", dsl_path(asg_dsl),
                                        "--lam", f"{lam[asg_dsl]:.4f}",
                                        "--control", "random_projection"]},
        {"arm": "rescale", "args": ["--reward-scale", f"{1.0 + rho_target:.4f}"]},
    ]


def run_one(arm: dict, seed: int, env_id: str, steps: int, tag: str,
            algo: str = "ippo", num_agents: int | None = None) -> dict:
    out = os.path.join(OUTDIR, f"{tag}_{arm['arm']}_seed{seed}.json")
    cmd = [sys.executable, "-u", os.path.join(PROJECT_ROOT, "scripts", "stage0_train.py"),
           "--env", env_id, "--steps", str(steps), "--eval-every", str(max(steps // 10, 10000)),
           "--seed", str(seed), "--hidden", "512", "--entropy", "0.003",
           "--epochs", "8", "--minibatches", "8", "--out", out, "--algo", algo,
           "--tag", f"{tag}_{arm['arm']}_s{seed}"]
    if num_agents is not None:
        cmd += ["--num-agents", str(num_agents)]
    cmd += arm["args"]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    if proc.returncode != 0 or not os.path.exists(out):
        tail = (proc.stdout or "")[-400:] + (proc.stderr or "")[-400:]
        return {"arm": arm["arm"], "seed": seed, "status": "failed", "error": tail}
    with open(out, encoding="utf-8") as f:
        data = json.load(f)
    data.update({"arm": arm["arm"], "seed": seed, "status": "completed"})
    return data


def auc_of(curve: list) -> float:
    if len(curve) < 2:
        return float("nan")
    steps = np.asarray([c[0] for c in curve], dtype=float)
    vals = np.asarray([c[1] for c in curve], dtype=float)
    return float(np.trapezoid(vals, steps) / (steps[-1] - steps[0]))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--steps", type=int, default=300_000)
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--rho-target", type=float, default=0.20)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--tag", default="shaping")
    ap.add_argument("--sweep", default=None,
                    help="comma-separated coefficients; runs a coefficient sweep instead")
    ap.add_argument("--dsls", default="spread_coverage.json,spread_assignment.json")
    ap.add_argument("--algo", default="ippo", choices=["ippo", "mappo"])
    ap.add_argument("--num-agents", type=int, default=None)
    args = ap.parse_args()

    dsls = tuple(args.dsls.split(","))  # type: ignore[assignment]

    os.makedirs(OUTDIR, exist_ok=True)
    seeds = [int(s) for s in args.seeds.split(",")]
    print(f"env={args.env} steps={args.steps} seeds={seeds} rho*={args.rho_target}")
    print("analytic calibration:")
    if args.sweep:
        values = [float(v) for v in args.sweep.split(",")]
        arms = build_sweep_arms(args.env, args.rho_target, 80, values, dsls=dsls)
    else:
        arms = build_arms(args.env, args.rho_target, 80, dsls=dsls,
                          num_agents=args.num_agents)

    jobs = [(arm, s) for arm in arms for s in seeds]
    results: list[dict] = []
    print(f"launching {len(jobs)} runs (algo={args.algo}, "
          f"num_agents={args.num_agents})", flush=True)
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(run_one, arm, s, args.env, args.steps, args.tag,
                               args.algo, args.num_agents)
                   for arm, s in jobs]
        for fut in cf.as_completed(futures):
            r = fut.result()
            results.append(r)
            if r.get("status") == "completed":
                print(f"  [{r['arm']:>12s} seed={r['seed']}] final={r['final_return']:8.2f} "
                      f"({r['wall_time']:.0f}s)", flush=True)
            else:
                print(f"  [{r['arm']:>12s} seed={r['seed']}] FAILED: {r.get('error','')[:160]}",
                      flush=True)

    ok = [r for r in results if r.get("status") == "completed"]
    base_by_seed = {r["seed"]: r["final_return"] for r in ok if r["arm"] == "base"}
    print("\narm summary (mean over seeds; delta vs base is paired by seed)")
    print(f"{'arm':>12s} {'n':>3s} {'mean final':>12s} {'std':>8s} {'mean AUC':>12s} "
          f"{'paired delta':>13s} {'noop':>9s}")
    rows = []
    for arm in arms:
        sel = [r for r in ok if r["arm"] == arm["arm"]]
        if not sel:
            continue
        finals = np.asarray([r["final_return"] for r in sel])
        aucs = np.asarray([auc_of(r["curve"]) for r in sel])
        diffs = [r["final_return"] - base_by_seed[r["seed"]]
                 for r in sel if r["seed"] in base_by_seed]
        row = {"arm": arm["arm"], "n": len(sel), "mean_final": float(finals.mean()),
               "std_final": float(finals.std(ddof=1)) if len(finals) > 1 else 0.0,
               "mean_auc": float(np.nanmean(aucs)),
               "paired_delta_vs_base": float(np.mean(diffs)) if diffs else float("nan"),
               "noop_return": sel[0].get("noop_return")}
        rows.append(row)
        print(f"{row['arm']:>12s} {row['n']:>3d} {row['mean_final']:>12.2f} "
              f"{row['std_final']:>8.2f} {row['mean_auc']:>12.2f} "
              f"{row['paired_delta_vs_base']:>+13.2f} {row['noop_return']:>9.2f}")

    csv_path = os.path.join(OUTDIR, f"{args.tag}_summary.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    with open(os.path.join(OUTDIR, f"{args.tag}_raw.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print("\nwrote", os.path.normpath(csv_path))


if __name__ == "__main__":
    main()
