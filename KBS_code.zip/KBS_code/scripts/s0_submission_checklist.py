"""S0-8 (T6c): IEEE TAI submission-checklist verification.

Measures the hard-format limits against the live LaTeX sources and the compiled
PDF, and prints a PASS/FAIL table. The script exits non-zero if any *mandatory*
item fails, so a submission bundle cannot be sealed with an out-of-spec
manuscript. Limits (IEEE TAI Regular Manuscript, verified against the author page
2026-09-27):

  * title word count        <= 15
  * abstract word count     <= 250
  * keyword count           3 .. 6
  * Impact Statement words  100 .. 150
  * page count              <= 15 (10 normal + up to 5 extra; 15 is a hard cap)
  * double-anonymous        (no author-identifying strings; the full sweep is in
                             scripts/s0_anonymity_audit.py)

Word counting replaces every inline/display math expression by a single token,
which is how a reader parses it (e.g. "lambda-star equals ..."), and drops LaTeX
control words and braces before counting.
"""
from __future__ import annotations

import os
import re
import subprocess

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PAPER = os.path.join(ROOT, "paper")

TITLE_MAX = 15
ABSTRACT_MAX = 250
KEYWORDS_MIN, KEYWORDS_MAX = 3, 6
IMPACT_MIN, IMPACT_MAX = 100, 150
PAGES_MAX = 15


def strip_tex(s: str) -> str:
    s = re.sub(r"(?<!\\)%.*", " ", s)
    s = re.sub(r"\\begin\{[^}]*\}|\\end\{[^}]*\}", " ", s)
    s = re.sub(r"\$\$.*?\$\$", " MATH ", s, flags=re.S)
    s = re.sub(r"\$[^$]*\$", " MATH ", s)
    s = re.sub(r"\\\[.*?\\\]", " MATH ", s, flags=re.S)
    s = re.sub(r"\\[a-zA-Z]+\*?", " ", s)
    s = re.sub(r"[{}\\]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def count_words(s: str) -> int:
    return len([w for w in strip_tex(s).split() if re.search(r"[A-Za-z0-9]", w)])


def between(text: str, start: str, end: str) -> str:
    m = re.search(re.escape(start) + r"(.*?)" + re.escape(end), text, re.S)
    return m.group(1) if m else ""


def pdf_pages(path: str) -> int | None:
    """Authoritative page count from the PDF itself, falling back to the TeX log."""
    if os.path.exists(path):
        try:
            xml = subprocess.run(
                ["pdftotext", "-bbox", path, "-"],
                capture_output=True, text=True, encoding="utf-8", errors="ignore",
            ).stdout
            n = len(re.split(r"<page\b", xml)) - 1
            if n > 0:
                return n
        except (OSError, ValueError):
            pass
    log = os.path.join(PAPER, "main.log")
    if os.path.exists(log):
        m = re.search(
            r"Output written on .*?\((\d+) pages",
            open(log, encoding="utf-8", errors="ignore").read(),
        )
        if m:
            return int(m.group(1))
    return None


def main() -> int:
    main_tex = open(os.path.join(PAPER, "main.tex"), encoding="utf-8").read()
    abs_tex = open(
        os.path.join(PAPER, "sections", "01_abstract.tex"), encoding="utf-8"
    ).read()

    title = re.sub(r"\\\\", " ", between(main_tex, r"\title{", "}"))
    n_title = count_words(title)

    abstract = between(abs_tex, r"\begin{abstract}", r"\end{abstract}")
    n_abstract = count_words(abstract)

    kw_raw = between(abs_tex, r"\begin{IEEEkeywords}", r"\end{IEEEkeywords}")
    keywords = [k.strip() for k in kw_raw.replace(".", ",").split(",") if k.strip()]
    n_keywords = len(keywords)

    impact = abs_tex.split("Impact Statement", 1)[-1] if "Impact Statement" in abs_tex else ""
    n_impact = count_words(impact)

    n_pages = pdf_pages(os.path.join(PAPER, "main.pdf"))
    anon_ok = ("Anonymous Authors" in main_tex) and (not re.search(r"[\w.+-]+@[\w-]+", main_tex))

    rows = [
        ("title words", n_title, f"<={TITLE_MAX}", n_title <= TITLE_MAX),
        ("abstract words", n_abstract, f"<={ABSTRACT_MAX}", n_abstract <= ABSTRACT_MAX),
        ("keywords", n_keywords, f"{KEYWORDS_MIN}-{KEYWORDS_MAX}", KEYWORDS_MIN <= n_keywords <= KEYWORDS_MAX),
        ("Impact Statement words", n_impact, f"{IMPACT_MIN}-{IMPACT_MAX}", IMPACT_MIN <= n_impact <= IMPACT_MAX),
        ("pages (main.pdf)", n_pages if n_pages is not None else -1, f"<={PAGES_MAX}", n_pages is not None and n_pages <= PAGES_MAX),
        ("double-anonymous", anon_ok, "True", anon_ok),
    ]

    width = max(len(r[0]) for r in rows) + 2
    print("=" * (width + 26))
    print(f"{'check':<{width}}{'value':>8}{'limit':>12}   result")
    print("=" * (width + 26))
    ok_all = True
    for name, val, limit, ok in rows:
        ok_all = ok_all and bool(ok)
        print(f"{name:<{width}}{str(val):>8}{limit:>12}   {'PASS' if ok else 'FAIL'}")
    print("=" * (width + 26))
    print(f"keywords: {', '.join(keywords)}")
    print(f"title ({n_title} words): {re.sub(r'[ ]+', ' ', title).strip()}")
    print(f"OVERALL: {'PASS' if ok_all else 'FAIL'}")
    return 0 if ok_all else 1


if __name__ == "__main__":
    raise SystemExit(main())
