# E2 + E3 — the two identification experiments the review asked for.
#
# E2 (identifiable contrast): a 2x2 over interface {raw, grounded} x proposer pool {K=6, K=12},
#   with the random-valid reference held fixed at K=12. The grounded-vs-raw contrast in the paper
#   moves the whitelist and the pool together, so it identifies the interface as a whole; E2
#   separates them. Cells: raw-K6 and grounded-K12 already exist; raw-K12 and grounded-K6 are new.
#
# E3 (equal-budget frontier): the union holds 2K=24 candidates, so its equal-budget reference is a
#   random-valid pool at K=24, not K=12. Three new draws supply that reference.
#
# Waits for E1 (E1_CONFIRM_DONE) so the single GPU stays serialised. Idempotent: a cell whose
# summary already exists is skipped.
#
# Usage:  powershell -NoProfile -File scripts/run_e2_e3.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/e2e3.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) { $m | Tee-Object -FilePath $log -Append | Out-Null }

Write-Log "E2/E3 waiting for E1_CONFIRM_DONE ..."
$e1 = "artifacts/llm_proposal/e1_confirm.log"
while ($true) {
    if ((Test-Path $e1) -and (Select-String -Path $e1 -Pattern "E1_CONFIRM_DONE" -Quiet)) { break }
    Start-Sleep -Seconds 120
}
Write-Log "E1 done; starting E2/E3"

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

# --- E2: raw interface at K=12 (raw-K6 is the existing conf_* family) ---
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confrawk12_r$r" -Extra @("--provider", "deepseek_v4_flash",
        "--k-llm", "12", "--k-raw", "12", "--k-rand", "12", "--rep-offset", "$r")
}

# --- E2: grounded interface at K=6 (grounded-K12 is the existing confv2_* family) ---
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confv2k6_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
        "--k-llm", "6", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}

# --- E3: equal-budget random-valid reference at K=24, for the 2K union ---
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confrandk24_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "24", "--rep-offset", "$r")
}

Write-Log "E2E3_DONE"
