"""Restore run records from the submission bundle.

The repository is not under version control; the released bundle
(``submission/pbrs-audit-bundle.zip``) is therefore the rollback point, and this
script uses it as one. It restores the named members to their original location and
verifies the restored record's step count, so a restore cannot silently install a
record produced at the wrong budget.

Why this exists: a sweep script written later reused ``run_id``, which does **not**
encode the training budget, and so overwrote three 299,520-step baseline records with
shorter runs. That is precisely the defect the paper reports (P6) and the reason the
harness checks the recorded step count on every cache hit. The bundle predated the
overwrite, so the originals were recoverable exactly.
"""
from __future__ import annotations

import argparse
import json
import os
import zipfile

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BUNDLE = os.path.join(PROJECT_ROOT, "submission", "pbrs-audit-bundle.zip")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--members", nargs="+", required=True,
                    help="bundle-relative paths, e.g. artifacts/bps_gate/x.json")
    ap.add_argument("--expect-steps", type=int, default=None,
                    help="verify the restored record reports this many steps")
    ap.add_argument("--bundle", default=BUNDLE)
    args = ap.parse_args()

    restored, failed = 0, 0
    with zipfile.ZipFile(args.bundle) as z:
        names = set(z.namelist())
        for m in args.members:
            key = m.replace(os.sep, "/")
            if key not in names:
                print(f"  MISSING in bundle: {key}")
                failed += 1
                continue
            payload = z.read(key)
            rec = json.loads(payload)
            if args.expect_steps is not None and int(rec.get("steps", -1)) != args.expect_steps:
                print(f"  REFUSED {key}: bundle copy has steps={rec.get('steps')}, "
                      f"expected {args.expect_steps}")
                failed += 1
                continue
            dest = os.path.join(PROJECT_ROOT, key.replace("/", os.sep))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(payload)
            print(f"  restored {key}  steps={rec.get('steps')}  "
                  f"final={rec.get('final_return'):.3f}")
            restored += 1
    print(f"\nrestored {restored}, failed {failed}")
    raise SystemExit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
