"""Budget-aware gated deployment of a shaping configuration.

Motivation from the measured evidence: magnitude calibration is an amplifier, not
a source of information. The same calibrated potential improved performance in
one environment and reliably degraded it in another, and no training-free
diagnostic predicted which. A pipeline that always deploys its best-ranked
candidate therefore inherits the failure mode.

This script evaluates a *gated* rule instead. After a short paired probe, every
candidate configuration must present a lower confidence bound on its improvement
over unshaped training; shaping is deployed only if some candidate clears the
gate, and otherwise the pipeline falls back to unshaped training. The decision is
made at a probe budget, but the outcome is taken from the full-budget runs.

Because both the probe and the full-budget evaluation already exist for every
configuration, the gate can be assessed without any additional training.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")


ARM_ALIASES = {"cov_legacy": "pot_legacy", "cov_cal": "pot_cal"}


def canonical_arm(name: str) -> str:
    return ARM_ALIASES.get(name, name)


def setting_key(run: dict) -> str:
    """Environment label that also separates algorithm and agent count."""
    env = run.get("env")
    algo = run.get("algo") or "ippo"
    n = run.get("num_agents")
    if algo == "ippo" and n is None:
        return str(env)
    suffix = f" [{algo}" + (f", N={n}]" if n is not None else "]")
    return f"{env}{suffix}"


def load_envs(tags: list[str]) -> dict[str, dict]:
    """Merge every completed run across tags, grouped by environment.

    Runs are keyed by (arm, seed); the same configuration evaluated under two
    tags is the same measurement, so merging them enlarges the candidate pool
    and the per-arm seed count instead of duplicating arms.
    """
    envs: dict[str, dict] = {}
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        for r in raw:
            if r.get("status") != "completed":
                continue
            entry = envs.setdefault(setting_key(r), {"arms": {}, "tags": set()})
            entry["tags"].add(tag)
            entry["arms"].setdefault(canonical_arm(r["arm"]), {})[r["seed"]] = r["curve"]
    return envs


def lcb(diffs: np.ndarray, z: float) -> float:
    if diffs.size == 0:
        return float("-inf")
    if diffs.size == 1:
        return float(diffs.mean())
    return float(diffs.mean() - z * diffs.std(ddof=1) / np.sqrt(diffs.size))


def score_candidate(diffs: np.ndarray, criterion: str, z: float,
                    tail: float = 0.25) -> float:
    """Score a candidate from its paired probe improvements.

    ``mean``   maximises the expected improvement (the usual criterion);
    ``cvar``   maximises the mean of the worst ``tail`` fraction of seeds, i.e.
               the improvement that can be relied on rather than the average;
    ``lcb``    subtracts a standard-error penalty;
    ``disp``   prefers the configuration whose improvement is most consistent.
    """
    if diffs.size == 0:
        return float("-inf")
    if criterion == "mean":
        return float(diffs.mean())
    if criterion == "cvar":
        k = max(1, int(np.ceil(tail * diffs.size)))
        return float(np.sort(diffs)[:k].mean())
    if criterion == "lcb":
        return lcb(diffs, z)
    if criterion == "disp":
        if diffs.size < 2:
            return float(diffs.mean())
        return float(diffs.mean() - diffs.std(ddof=1))
    raise ValueError(f"unknown criterion {criterion}")


def evaluate_gate(pool: dict, frac: float, z: float, base_arm: str = "base",
                  seeds: list[int] | None = None,
                  criterion: str = "lcb", tail: float = 0.25) -> dict:
    arms = pool["arms"]
    if base_arm not in arms:
        return {}
    if seeds is None:
        seeds = sorted(set.intersection(*[set(v) for v in arms.values()]))
    else:
        seeds = [s for s in seeds if all(s in v for v in arms.values())]
    if len(seeds) < 2:
        return {}
    n_points = min(len(arms[a][s]) for a in arms for s in seeds)
    idx = max(0, int(round(frac * (n_points - 1))))
    base = arms[base_arm]

    full = {a: float(np.mean([arms[a][s][-1][1] for s in seeds])) for a in arms}
    candidates = [a for a in arms if a != base_arm]

    scores = {}
    for a in candidates:
        diffs = np.asarray([arms[a][s][idx][1] - base[s][idx][1] for s in seeds], dtype=float)
        scores[a] = score_candidate(diffs, criterion, z, tail)

    best = max(scores, key=lambda a: scores[a]) if scores else base_arm
    deployed = best if scores.get(best, float("-inf")) > 0 else base_arm

    oracle = max(full, key=lambda a: full[a])
    return {
        "probe_fraction": frac, "probe_index": idx, "z": z, "criterion": criterion,
        "n_seeds": len(seeds),
        "deployed": deployed,
        "deployed_full_return": full[deployed],
        "base_full_return": full[base_arm],
        "oracle": oracle, "oracle_full_return": full[oracle],
        "realised_gain_vs_base": full[deployed] - full[base_arm],
        "oracle_gain_vs_base": full[oracle] - full[base_arm],
        "regret_vs_oracle": full[oracle] - full[deployed],
        "scores": scores,
    }


def seed_study(pool: dict, frac: float, z: float, seed_counts: list[int],
               n_repeats: int = 200, rng_seed: int = 0) -> list[dict]:
    """How does the gate behave as a function of the number of training seeds?

    Seeds are subsampled without replacement from the available pool, so the
    safety/gain trade-off can be characterised at seed counts the current runs
    do not yet reach directly.
    """
    arms = pool["arms"]
    available = sorted(set.intersection(*[set(v) for v in arms.values()]))
    rng = np.random.default_rng(rng_seed)
    rows = []
    for n in seed_counts:
        if n > len(available):
            continue
        gains, regrets, harmful, optimal = [], [], 0, 0
        for _ in range(n_repeats):
            sub = list(rng.choice(available, size=n, replace=False))
            r = evaluate_gate(pool, frac, z, seeds=[int(s) for s in sub])
            if not r:
                continue
            gains.append(r["realised_gain_vs_base"])
            regrets.append(r["regret_vs_oracle"])
            harmful += int(r["realised_gain_vs_base"] < -1e-9)
            optimal += int(r["regret_vs_oracle"] < 1e-9)
        if not gains:
            continue
        rows.append({
            "n_seeds": n, "probe_fraction": frac, "z": z, "repeats": len(gains),
            "mean_gain": float(np.mean(gains)), "mean_regret": float(np.mean(regrets)),
            "harmful_fraction": harmful / len(gains),
            "oracle_fraction": optimal / len(gains),
        })
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", default="main,main2,ref,ref2,push,mappo,n5,n7,sl")
    ap.add_argument("--fractions", default="0.1,0.2,0.3,0.4,0.5")
    ap.add_argument("--zs", default="0.0,0.5,1.0")
    ap.add_argument("--seed-study", action="store_true",
                    help="report gate behaviour as a function of the number of seeds")
    ap.add_argument("--seed-counts", default="2,3,4,5,6,7,8")
    ap.add_argument("--repeats", type=int, default=200)
    ap.add_argument("--arms", default=None,
                    help="restrict the candidate pool to these comma-separated arm names")
    ap.add_argument("--compare-criteria", action="store_true",
                    help="compare selection criteria at a fixed probe budget")
    ap.add_argument("--criteria", default="mean,cvar,lcb,disp")
    args = ap.parse_args()

    envs = load_envs([t for t in args.tags.split(",") if t])
    if args.arms:
        keep = set(args.arms.split(","))
        for pool in envs.values():
            pool["arms"] = {a: v for a, v in pool["arms"].items() if a in keep}
        envs = {k: v for k, v in envs.items() if v["arms"]}

    if args.compare_criteria:
        crits = [c for c in args.criteria.split(",") if c]
        table = []
        for env_name, pool in sorted(envs.items(), key=lambda kv: str(kv[0])):
            seeds = sorted(set.intersection(*[set(v) for v in pool["arms"].values()]))
            print(f"\n=== env={env_name}  n={len(seeds)} seeds ===")
            print(f"{'probe':>6s} {'criterion':>10s} {'deployed':>14s} {'mean gain':>10s} "
                  f"{'worst-seed gain':>16s} {'regret':>8s}")
            for frac in [0.2, 0.3, 0.5]:
                for crit in crits:
                    r = evaluate_gate(pool, frac, 0.5, criterion=crit)
                    if not r:
                        continue
                    base_min = min(pool["arms"]["base"][s][-1][1] for s in seeds)
                    dep_min = min(pool["arms"][r["deployed"]][s][-1][1] for s in seeds)
                    row = {"env": env_name, "probe_fraction": frac, "criterion": crit,
                           "deployed": r["deployed"],
                           "mean_gain": r["realised_gain_vs_base"],
                           "worst_seed_gain": dep_min - base_min,
                           "regret_vs_oracle": r["regret_vs_oracle"]}
                    table.append(row)
                    print(f"{frac:>6.0%} {crit:>10s} {r['deployed']:>14s} "
                          f"{r['realised_gain_vs_base']:>+10.2f} {dep_min - base_min:>+16.2f} "
                          f"{r['regret_vs_oracle']:>+8.2f}")
        out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "criteria_comparison.json")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            json.dump(table, f, indent=2)
        print("\nwrote", os.path.normpath(out))
        return

    if args.seed_study:
        counts = [int(v) for v in args.seed_counts.split(",")]
        study = []
        for env_name, pool in sorted(envs.items(), key=lambda kv: str(kv[0])):
            print(f"\n=== seed study  env={env_name}  "
                  f"available seeds={sorted(set.intersection(*[set(v) for v in pool['arms'].values()]))} ===")
            print(f"{'n':>3s} {'probe':>6s} {'z':>4s} {'mean gain':>10s} {'mean regret':>12s} "
                  f"{'harmful frac':>13s} {'reaches oracle':>15s}")
            for z in [0.5]:
                for frac in [0.3, 0.5]:
                    for row in seed_study(pool, frac, z, counts, args.repeats):
                        row["env"] = env_name
                        study.append(row)
                        print(f"{row['n_seeds']:>3d} {row['probe_fraction']:>6.0%} {z:>4.1f} "
                              f"{row['mean_gain']:>+10.2f} {row['mean_regret']:>+12.2f} "
                              f"{row['harmful_fraction']:>13.2f} {row['oracle_fraction']:>15.2f}")
        out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "gate_seed_study.json")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            json.dump(study, f, indent=2)
        print("\nwrote", os.path.normpath(out))
        return

    rows = []
    for env_name, pool in sorted(envs.items(), key=lambda kv: str(kv[0])):
        arms = pool["arms"]
        n_seeds = {a: len(v) for a, v in arms.items()}
        print(f"\n=== env={env_name}  arms={sorted(arms)}  seeds/arm={n_seeds} "
              f"(tags: {sorted(pool['tags'])}) ===")
        print(f"{'probe':>6s} {'z':>4s} {'deployed':>14s} {'gain vs base':>13s} "
              f"{'oracle gain':>12s} {'regret':>8s}")
        for z in [float(v) for v in args.zs.split(",")]:
            for frac in [float(v) for v in args.fractions.split(",")]:
                r = evaluate_gate(pool, frac, z)
                if not r:
                    continue
                r.update({"env": env_name, "tags": sorted(pool["tags"]),
                          "seeds_per_arm": n_seeds})
                rows.append(r)
                print(f"{frac:>6.0%} {z:>4.1f} {r['deployed']:>14s} "
                      f"{r['realised_gain_vs_base']:>+13.2f} "
                      f"{r['oracle_gain_vs_base']:>+12.2f} {r['regret_vs_oracle']:>+8.2f}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "gated_selection.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print("\nwrote", os.path.normpath(out))

    print("\nsummary at probe fraction 30%, z = 0.5")
    for r in rows:
        if r["probe_fraction"] == 0.3 and abs(r["z"] - 0.5) < 1e-9:
            print(f"  {r['env']:<28s} deployed={r['deployed']:<14s} "
                  f"gain={r['realised_gain_vs_base']:+.2f} "
                  f"(oracle {r['oracle_gain_vs_base']:+.2f}, regret {r['regret_vs_oracle']:+.2f})")


if __name__ == "__main__":
    main()
