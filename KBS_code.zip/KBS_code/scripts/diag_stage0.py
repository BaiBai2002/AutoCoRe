"""Stage-0 diagnostic: why are the learning curves flat?

A. environment contract (spaces, agents)
B. does reset(seed=...) actually change the trajectory?
C. does IPPO training change the policy parameters?
D. do eval returns move during a short training run?
E. eval with different seeds on the SAME frozen policy
"""
from __future__ import annotations

import copy
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np
from gymnasium import spaces

from autocore.algos.ippo import IPPOConfig, IPPOTrainer
from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.experiments.train import TrainingLogger, evaluate_agent, train_agent

ENV_ID = "simple_spread_v3"
MAX_CYCLES = 80
ALG_CFG = dict(lr=3e-4, gamma=0.99, gae_lambda=0.95, clip_epsilon=0.2,
               entropy_coef=0.01, value_coef=0.5, max_grad_norm=0.5,
               hidden_dim=384, batch_size=128, update_epochs=4, device="cuda")


def banner(t):
    print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)


def sample_action(aspace, rng):
    if isinstance(aspace, spaces.Discrete):
        return int(rng.integers(aspace.n))
    return rng.uniform(aspace.low, aspace.high).astype(np.float32)


def rollout(env, action_fn, seed, max_steps=200):
    res = env.reset(seed=seed)
    obs = res[0] if isinstance(res, tuple) else res
    total, n = 0.0, 0
    while n < max_steps:
        acts = {a: action_fn(a) for a in env.agents}
        res = env.step(acts)
        obs, rew, term, trunc = res[0], res[1], res[2], res[3]
        total += float(sum(rew.values()))
        n += 1
        if all(term.values()) or all(trunc.values()):
            break
    return total, n


def main():
    banner("A. environment contract")
    env = make_mpe_env(ENV_ID, max_cycles=MAX_CYCLES)
    a0 = env.possible_agents[0]
    aspace = env.action_space(a0)
    print("agents        :", env.possible_agents)
    print("obs space     :", env.observation_space(a0))
    print("action space  :", aspace)
    print("discrete?     :", isinstance(aspace, spaces.Discrete))

    r, n = rollout(env, lambda a: 0, seed=1)
    print(f"no-op episode : return={r:.3f} steps={n}")

    banner("B. reset(seed) sensitivity (identical action sequence, no-op policy)")
    seen = []
    for s in (1, 2, 3, 101, 202):
        r, n = rollout(env, lambda a: 0, seed=s)
        seen.append(round(r, 6))
        print(f"  seed={s:<4d} return={r:12.3f} steps={n}")
    print("  distinct returns:", len(set(seen)), "-> if 1, reset(seed) is ignored")

    banner("B2. same seed twice (determinism)")
    r1, _ = rollout(env, lambda a: 0, seed=7)
    r2, _ = rollout(env, lambda a: 0, seed=7)
    print(f"  seed=7 -> {r1:.6f} / {r2:.6f}  identical={abs(r1-r2) < 1e-9}")

    banner("C. does IPPO training change policy parameters?")
    od = int(np.prod(env.observation_space(a0).shape))
    ad = int(np.prod(aspace.shape)) if not isinstance(aspace, spaces.Discrete) else int(aspace.n)
    trainer = IPPOTrainer(od, ad, IPPOConfig(**ALG_CFG),
                          discrete_action=isinstance(aspace, spaces.Discrete))
    before = copy.deepcopy({k: v.detach().clone() for k, v in trainer.policy.state_dict().items()})

    logger = TrainingLogger()
    logger = train_agent(env, trainer, num_steps=4000, eval_interval=1000,
                         eval_episodes=5, logger=logger, seed=42)
    after = trainer.policy.state_dict()
    l2 = sum(float(((after[k] - before[k]) ** 2).sum()) for k in before)
    print(f"  policy L2 change after 4000 steps: {np.sqrt(l2):.6f}")

    banner("D. eval returns logged during the short run")
    df = logger.get_dataframe()
    if "eval_return" in df.columns:
        ev = df.loc[df["eval_return"].notna(), ["step", "eval_return"]]
        print(ev.to_string(index=False))
        print("  distinct eval values:", ev["eval_return"].round(9).nunique())
    else:
        print("  no eval_return column logged")
    if "episode_return" in df.columns:
        ep = df["episode_return"].dropna()
        print(f"  episode_return: n={len(ep)} first3={np.round(ep.head(3).values,1)} "
              f"last3={np.round(ep.tail(3).values,1)}")

    banner("E. eval with different seeds on the SAME frozen policy")
    for es in (4200, 4207, 4214, 42100, 42999):
        v = evaluate_agent(env, trainer, num_episodes=5, seed=es)
        print(f"  eval seed={es:<6d} mean_return={v:12.3f}")
    print("  -> if constant, either the policy is frozen or reset(seed) is ignored")

    env.close()


if __name__ == "__main__":
    main()
