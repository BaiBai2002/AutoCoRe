import json, os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
d = json.load(open(os.path.join(ROOT, "artifacts", "diagnostics", "lambda_feasibility.json"), encoding="utf-8"))
print("keys:", list(d.keys()))
print("grid:", d.get("grid"))
rows = d["rows"]
print("n rows:", len(rows))
print("row0 keys:", list(rows[0].keys()))
print()
for lm in (0.4, 0.2, 0.1):
    inf = [r for r in rows if 0.2 * r["mean_abs_return"] / r["mean_abs_delta_phi"] > lm]
    print(f"lam_max={lm} -> infeasible {len(inf)}/{len(rows)}")
print()
for r in rows:
    ls = 0.2 * r["mean_abs_return"] / r["mean_abs_delta_phi"]
    print(f"  {r['env_id']:<32s} {r['potential']:<20s} lam*={ls:9.4f}")

# now the normalized preflight runs
runs = json.load(open(os.path.join(ROOT, "audit", "preflight", "runs.json"), encoding="utf-8"))
print("\nruns.json type:", type(runs).__name__, "n=", len(runs))
have = [r for r in runs if r.get("mean_abs_return") is not None and r.get("mean_abs_delta_phi") is not None]
print("records with feasibility scales:", len(have))
from collections import Counter
print("envs:", Counter(r.get("env_id") for r in have))
lam_max = 0.4
inf = [r for r in have if 0.2 * float(r["mean_abs_return"]) / max(float(r["mean_abs_delta_phi"]), 1e-12) > lam_max]
print("infeasible at 0.4:", len(inf), "envs:", Counter(r.get("env_id") for r in inf))
