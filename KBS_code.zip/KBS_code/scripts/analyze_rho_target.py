"""Calibration-target ablation of the deployment pipeline.

The pipeline does not search a coefficient grid; it calibrates lambda directly
from a target dominance rho* (``lambda = rho* E|R| / E|dPhi|``). Section dose
shows that the raw-return optimum sits a factor of two to four *below* the
visibility scale, i.e. below the rho* = 0.2 that the pipeline had used. This
script compares the full pipeline run at several targets on the same pool, the
same probe seeds, the same held-out seeds and the same budget accounting, and
reports the pooled paired gain against the unshaped and budget-matched baselines.

Each setting lives in its own summary (``bps_n3_rho020``, ``bps_n3_rho005``,
``bps_n3_rho010``) whose per-run caches are namespaced by the run tag, so no run
is ever shared between settings (P6).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from analyze_bps_gate import OUTDIR, bootstrap_ci, per_seed  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "rho_target_ablation.json")

SETTINGS = [("bps_n3_rho020", 0.20), ("bps_n3_rho010", 0.10), ("bps_n3_rho005", 0.05)]


def analyse(summary: dict) -> dict | None:
    base = per_seed(summary, "base", summary["final_steps"])
    if len(base) < 2:
        return None
    seeds = sorted(base)
    bm = summary.get("budget_matched_baseline")
    bm_vals = {}
    if bm:
        for cand in (f"base_bm{bm['steps']}", "base_bm"):
            bm_vals = per_seed(summary, cand, bm["steps"])
            if bm_vals:
                break
    g_base, g_bm, deployed, opens = [], [], [], 0
    for d in summary["decisions"]:
        if d["gate_choice"]:
            vals = per_seed(summary, d["gate_choice"]["key"], summary["final_steps"])
            opens += 1
            deployed.append(d["gate_choice"]["name"])
        else:
            vals = dict(base)
            deployed.append("DECLINE")
        shared = [s for s in seeds if s in vals]
        if shared:
            g_base.append(np.asarray([vals[s] - base[s] for s in shared], dtype=float))
        if bm_vals:
            sh = [s for s in shared if s in bm_vals]
            if sh:
                g_bm.append(np.asarray([vals[s] - bm_vals[s] for s in sh], dtype=float))
    out = {"base_mean": float(np.mean(list(base.values()))), "n_seeds": len(seeds),
           "replicates": len(summary["decisions"]), "gate_opens": opens,
           "deployed": deployed}
    if bm:
        out["bm_steps"] = bm["steps"]
        out["bm_ratio"] = bm["budget_ratio_vs_unshaped"]
        out["bm_mean"] = float(bm["mean"])
    if g_base:
        m, lo, hi = bootstrap_ci(np.concatenate(g_base))
        out.update({"gain_vs_base": m, "gain_vs_base_lo": lo, "gain_vs_base_hi": hi,
                    "vs_base_sig": bool(lo > 0 or hi < 0)})
    if g_bm:
        m, lo, hi = bootstrap_ci(np.concatenate(g_bm))
        out.update({"gain_vs_bm": m, "gain_vs_bm_lo": lo, "gain_vs_bm_hi": hi,
                    "vs_bm_sig": bool(lo > 0 or hi < 0)})
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--settings", default=None,
                    help="comma-separated tag:rho pairs; default = the three sweeps")
    args = ap.parse_args()

    settings = SETTINGS
    if args.settings:
        settings = [(a.split(":")[0].strip(), float(a.split(":")[1]))
                    for a in args.settings.split(",")]

    rows = []
    for tag, rho in settings:
        path = os.path.join(OUTDIR, f"{tag}_summary.json")
        if not os.path.exists(path):
            print(f"missing {tag}, skipped")
            continue
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        r = analyse(s)
        if r is None:
            print(f"{tag}: incomplete, skipped")
            continue
        r["rho_target"] = rho
        r["tag"] = tag
        rows.append(r)

    print(f"\n{'rho*':>6s} {'n':>3s} {'reps':>5s} {'opens':>6s} {'base':>9s} "
          f"{'gain/base':>22s} {'gain/bm':>22s} {'bm steps':>9s}")
    for r in rows:
        gb = (f"{r['gain_vs_base']:+.2f} [{r['gain_vs_base_lo']:+.1f},"
              f"{r['gain_vs_base_hi']:+.1f}]" if "gain_vs_base" in r else "-")
        gm = (f"{r['gain_vs_bm']:+.2f} [{r['gain_vs_bm_lo']:+.1f},"
              f"{r['gain_vs_bm_hi']:+.1f}]" if "gain_vs_bm" in r else "-")
        print(f"{r['rho_target']:>6.2f} {r['n_seeds']:>3d} {r['replicates']:>5d} "
              f"{r['gate_opens']:>3d}/{r['replicates']:<2d} {r['base_mean']:>9.2f} "
              f"{gb:>22s} {gm:>22s} {r.get('bm_steps', 0):>9d}")
    print(f"\nrho* = calibration target dominance; the pipeline trains each")
    print(f"candidate at lambda = rho* E|R| / E|dPhi| for that candidate.")
    for r in rows:
        print(f"  rho*={r['rho_target']:.2f}: deployed {r['deployed']}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
