"""Interval for the screening-fidelity crossing (kappa), instead of a point.

Lemma 3 (theory/proofs.md) says the shaped probe score at coefficient kappa is
``raw + kappa*(shaped - raw)`` for a fixed policy, so the rank correlation between
the screen and the held-out raw gain can be traced over kappa without retraining.
The paper reports that this correlation decays and crosses zero; the crossing
location has until now been quoted as a point (kappa ~ 4) with a caveat that it is
pool-specific. This script replaces the point with an interval by bootstrapping over
the *candidates* (the 37 configurations of the rich pool, each with a probe raw
score, a probe shaped score and a held-out raw gain).

Reads ``artifacts/diagnostics/shaped_selection_audit.json``; writes
``artifacts/diagnostics/kappa_interval.json``.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")
OUT = os.path.join(DIAG, "kappa_interval.json")


def spearman(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    rx -= rx.mean()
    ry -= ry.mean()
    denom = np.sqrt((rx * rx).sum() * (ry * ry).sum())
    return float((rx * ry).sum() / denom) if denom > 0 else float("nan")


def crossing(kappa: np.ndarray, rho: np.ndarray) -> float:
    """First kappa at which the rank correlation changes sign, interpolated."""
    for i in range(1, kappa.size):
        if np.isfinite(rho[i - 1]) and np.isfinite(rho[i]) and rho[i - 1] > 0 >= rho[i]:
            # linear interpolation in log-kappa
            t = rho[i - 1] / (rho[i - 1] - rho[i])
            lk = np.log(kappa[i - 1]) + t * (np.log(kappa[i]) - np.log(kappa[i - 1]))
            return float(np.exp(lk))
    return float("nan")


def trace(a: np.ndarray, r: np.ndarray, s: np.ndarray, kappa: np.ndarray) -> np.ndarray:
    m = s - r
    return np.asarray([spearman(r + k * m, a) for k in kappa], dtype=float)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-boot", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    with open(os.path.join(DIAG, "shaped_selection_audit.json"), encoding="utf-8") as f:
        data = json.load(f)
    cands = data["candidates"]
    a = np.asarray([c["held_out_raw_gain"] for c in cands], dtype=float)
    r = np.asarray([c["raw_score"] for c in cands], dtype=float)
    s = np.asarray([c["shaped_score"] for c in cands], dtype=float)
    n = a.size

    kappa = np.exp(np.linspace(np.log(0.05), np.log(60.0), 600))
    rho = trace(a, r, s, kappa)
    # Reproduce the published sweep at kappa = 0, 1, 4, 8 for a consistency check.
    check = {k: round(float(spearman(r + k * (s - r), a)), 3) for k in (0.0, 1.0, 4.0, 8.0)}
    k_hat = crossing(kappa, rho)

    rng = np.random.default_rng(args.seed)
    boots = []
    for _ in range(args.n_boot):
        idx = rng.integers(0, n, size=n)
        kk = crossing(kappa, trace(a[idx], r[idx], s[idx], kappa))
        if np.isfinite(kk):
            boots.append(kk)
    boots = np.asarray(boots)
    lo, hi = (np.percentile(boots, [2.5, 97.5]) if boots.size else (np.nan, np.nan))

    out = {
        "n_candidates": int(n), "n_boot": int(args.n_boot),
        "delta": data.get("rho_target"),
        "check_spearman": check,
        "kappa_crossing": k_hat,
        "kappa_crossing_median": float(np.median(boots)) if boots.size else float("nan"),
        "kappa_crossing_lo": float(lo), "kappa_crossing_hi": float(hi),
        "bootstrap_resolved_fraction": float(boots.size / args.n_boot),
        "reportable_max": 60.0,
    }
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    print("consistency check (should match the published +0.848/+0.722/+0.068/-0.848):")
    print("  " + "  ".join(f"kappa={k}: {v:+.3f}" for k, v in check.items()))
    print(f"crossing kappa = {k_hat:.2f}   bootstrap median {out['kappa_crossing_median']:.2f}  "
          f"95% CI [{lo:.2f}, {hi:.2f}]   resolved in "
          f"{100 * out['bootstrap_resolved_fraction']:.0f}% of resamples")
    print("wrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
