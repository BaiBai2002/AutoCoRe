# GPT generation ladder — part 44 extension, pre-registered before any draw of these models
# existed. All nine draws are reported in full whichever way they fall; nothing is tuned after
# seeing data.
#
# Within-family model-generation ladder on the identical frozen pipeline as every other grounded
# family: {GPT-5.6 Sol, GPT-6 Sol, GPT-6.1 Sol}, grounded interface, K=12, probe 50K x 3 seeds
# (200,201,202), finals 300K x 5 seeds (100..104), IPPO N=3, simple_spread_v3, three draws each
# (r0..r2, matching the Gemini/GLM/Grok rows). The models were discovered via the proxy's
# /v1/models listing (scripts/probe_new_families.py) and probed healthy (HTTP 200) before the
# first draw (scripts/probe_new_gpt_line.py, 2026-10-08).
#
# Idempotent; three attempts per draw per round, up to ten rounds with a 20-minute cooldown,
# mirroring the self-healing Grok runner.
#
# Usage:  powershell -NoProfile -File scripts/run_gpt_ladder.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/gpt_ladder.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) { $m | Tee-Object -FilePath $log -Append | Out-Null }

$tags = @()
foreach ($m in @("gpt_56_sol", "gpt_6_sol", "gpt_61_sol")) {
    foreach ($r in 0, 1, 2) {
        $tags += @{ tag = "confv2$($m)_r$r"; model = $m; rep = $r }
    }
}

Write-Log "GPT_LADDER starting (9 draws: 5.6/6/6.1 Sol x 3 draws, grounded spread, frozen pipeline)"

for ($round = 1; $round -le 10; $round++) {
    $missing = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($missing.Count -eq 0) { break }

    Write-Log "GPT_LADDER round ${round} starting; missing $($missing.Count) of 9"
    foreach ($t in $missing) {
        $summary = "artifacts/llm_proposal/$($t.tag)_summary.json"
        for ($a = 1; $a -le 3; $a++) {
            Write-Log "=== $($t.tag) (attempt ${a}) ==="
            & python -u scripts/llm_proposal_experiment.py --provider $t.model --llm-v2 `
                --k-llm 12 --k-raw 6 --k-rand 12 --rep-offset $t.rep `
                --replicates 1 --probe-steps 50000 --probe-seeds 200,201,202 `
                --final-steps 300000 --final-seeds 100,101,102,103,104 --tag $t.tag 2>&1 |
                Tee-Object -FilePath $log -Append | Out-Null
            if (Test-Path $summary) { Write-Log "OK: $($t.tag)"; break }
            Write-Log "FAILED attempt ${a} for $($t.tag)"
            Start-Sleep -Seconds 90
        }
    }

    $left = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($left.Count -eq 0) { break }
    Write-Log "GPT_LADDER round ${round} finished; $($left.Count) still missing; cooling down 20 min"
    Start-Sleep -Seconds 1200
}

$final = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
if ($final.Count -eq 0) { Write-Log "GPT_LADDER_ALL_DONE" } else { Write-Log "GPT_LADDER_EXIT_INCOMPLETE" }