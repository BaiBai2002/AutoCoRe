"""Normalize the manuscript to IEEE house style (US English).

IEEE requires US spelling. This rewrites only the manuscript sections and the cover
letter; the internal governance notes are left as they are. Every pattern is matched
as a whole word (case-preserving) so that LaTeX command names, labels, and stems that
merely look British (``realistic``, ``optimistic``) are left untouched.
"""
from __future__ import annotations

import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
TARGETS = [os.path.join(ROOT, "paper", "sections")]
TARGETS += [os.path.join(ROOT, f) for f in ("cover_letter_draft.md", "overlap_disclosure.md")]

REPLACEMENTS = [
    # -re -> -er
    ("centre", "center"), ("centres", "centers"), ("metre", "meter"), ("litre", "liter"),
    # -our -> -or
    ("behaviour", "behavior"), ("behaviours", "behaviors"),
    ("colour", "color"), ("colours", "colors"),
    ("favour", "favor"), ("favours", "favors"), ("favoured", "favored"),
    ("favourable", "favorable"), ("favourably", "favorably"),
    ("honour", "honor"), ("labour", "labor"), ("neighbourhood", "neighborhood"),
    # doubled l -> single l
    ("labelled", "labeled"), ("labelling", "labeling"), ("mislabelled", "mislabeled"),
    ("modelling", "modeling"), ("modelled", "modeled"),
    ("travelling", "traveling"), ("travelled", "traveled"),
    ("cancelled", "canceled"), ("fuelled", "fueled"), ("signalling", "signaling"),
    # -ise/-isation -> -ize/-ization
    ("analyse", "analyze"), ("analysed", "analyzed"), ("analysing", "analyzing"),
    ("artefact", "artifact"), ("artefacts", "artifacts"),
    ("amortise", "amortize"), ("amortised", "amortized"), ("amortisation", "amortization"),
    ("categorise", "categorize"), ("categorised", "categorized"),
    ("characterise", "characterize"), ("characterised", "characterized"),
    ("characterisation", "characterization"),
    ("centralise", "centralize"), ("centralised", "centralized"),
    ("decentralise", "decentralize"), ("decentralised", "decentralized"),
    ("discretise", "discretize"), ("discretised", "discretized"),
    ("factorise", "factorize"), ("factorised", "factorized"), ("factorisation", "factorization"),
    ("generalise", "generalize"), ("generalises", "generalizes"),
    ("generalised", "generalized"), ("generalising", "generalizing"),
    ("generalisation", "generalization"), ("generalisations", "generalizations"),
    ("initialise", "initialize"), ("initialised", "initialized"), ("initialisation", "initialization"),
    ("maximise", "maximize"), ("maximised", "maximized"), ("maximising", "maximizing"),
    ("minimise", "minimize"), ("minimised", "minimized"), ("minimising", "minimizing"),
    ("normalise", "normalize"), ("normalises", "normalizes"),
    ("normalised", "normalized"), ("normalising", "normalizing"),
    ("normalisation", "normalization"), ("normalisations", "normalizations"),
    ("optimise", "optimize"), ("optimises", "optimizes"),
    ("optimised", "optimized"), ("optimising", "optimizing"),
    ("optimisation", "optimization"), ("optimisations", "optimizations"),
    ("organise", "organize"), ("organises", "organizes"),
    ("organised", "organized"), ("organising", "organizing"),
    ("organisation", "organization"), ("organisations", "organizations"),
    ("penalise", "penalize"), ("penalised", "penalized"),
    ("prioritise", "prioritize"), ("prioritised", "prioritized"),
    ("randomise", "randomize"), ("randomised", "randomized"), ("randomisation", "randomization"),
    ("realise", "realize"), ("realises", "realizes"),
    ("realised", "realized"), ("realising", "realizing"),
    ("recognise", "recognize"), ("recognised", "recognized"),
    ("specialise", "specialize"), ("standardise", "standardize"),
    ("summarise", "summarize"), ("summarises", "summarizes"),
    ("summarised", "summarized"), ("summarising", "summarizing"),
    ("summarisation", "summarization"), ("summarisations", "summarizations"),
    ("utilise", "utilize"), ("utilised", "utilized"), ("utilisation", "utilization"),
    # -ce -> -se, -ogue, -re nouns, misc
    ("licence", "license"), ("defence", "defense"), ("offence", "offense"),
    ("catalogue", "catalog"), ("dialogue", "dialog"),
    ("judgement", "judgment"), ("acknowledgement", "acknowledgment"),
    ("scepticism", "skepticism"), ("sceptical", "skeptical"), ("sceptic", "skeptic"),
    ("manoeuvre", "maneuver"), ("manoeuvres", "maneuvers"),
    ("per cent", "percent"),
]


def _sub_pattern(word: str) -> str:
    return r"\b" + re.escape(word) + r"\b"


def main() -> None:
    total = 0
    for target in TARGETS:
        paths = ([os.path.join(target, f) for f in sorted(os.listdir(target))
                  if f.endswith(".tex")] if os.path.isdir(target) else [target])
        for p in paths:
            if not os.path.exists(p):
                continue
            with open(p, encoding="utf-8") as f:
                text = f.read()
            orig = text
            n = 0
            for pat, rep in REPLACEMENTS:
                for variant, swap in ((pat, rep), (pat.capitalize(), rep.capitalize()),
                                      (pat.upper(), rep.upper())):
                    hits = len(re.findall(_sub_pattern(variant), text))
                    if hits:
                        text = re.sub(_sub_pattern(variant), swap, text)
                        n += hits
            if text != orig:
                with open(p, "w", encoding="utf-8", newline="\n") as f:
                    f.write(text)
                total += n
                print(f"  {os.path.relpath(p, ROOT)}: {n} replacement(s)")
    print(f"\ntotal {total} replacement(s)")


if __name__ == "__main__":
    main()
