"""Empirical calibration of the deployment gate's confidence bound.

The gate deploys a candidate only when the one-sided lower confidence bound on
its paired probe gain is positive. With ``z = sqrt(2 ln(1/alpha) / n)`` this is
a valid one-sided ``(1 - alpha)`` statement *under sub-Gaussian paired
differences*, which the reward distributions here do not obviously satisfy.

This script therefore measures the guarantee instead of assuming it: using the
full evaluation curves, every configuration is probed on random subsets of
seeds at a given budget fraction, the gate decision is recomputed, and the
decision is then scored against the realised paired gain at the full budget.
The quantity of interest is

    P(realised gain < 0 | gate opened)

as a function of the nominal ``alpha`` implied by ``z`` and ``n``.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")
ARM_ALIASES = {"cov_legacy": "pot_legacy", "cov_cal": "pot_cal"}


def canonical(name: str) -> str:
    return ARM_ALIASES.get(name, name)


def setting_key(run: dict) -> str:
    env = run.get("env")
    algo = run.get("algo") or "ippo"
    n = run.get("num_agents")
    if algo == "ippo" and n is None:
        return str(env)
    return f"{env} [{algo}" + (f", N={n}]" if n is not None else "]")


def load(tags: list[str]) -> dict[str, dict[str, dict[int, list]]]:
    envs: dict[str, dict[str, dict[int, list]]] = {}
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            for r in json.load(f):
                if r.get("status") != "completed":
                    continue
                envs.setdefault(setting_key(r), {}).setdefault(canonical(r["arm"]), {})[
                    r["seed"]] = r["curve"]
    return envs


def nominal_alpha(z: float, n: int) -> float:
    return float(np.exp(-0.5 * z * z * n))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags",
                    default="main,main2,sweep,mappo,n5b,push,ref,ref2,sl,n7,n5")
    ap.add_argument("--base", default="base")
    ap.add_argument("--fraction", type=float, default=0.3)
    ap.add_argument("--zs", default="0.0,0.5,1.0,1.5,2.0")
    ap.add_argument("--seed-counts", default="3,5,8")
    ap.add_argument("--repeats", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    envs = load([t for t in args.tags.split(",") if t])
    rng = np.random.default_rng(args.seed)
    counts = [int(c) for c in args.seed_counts.split(",")]
    zs = [float(z) for z in args.zs.split(",")]

    trials: dict[tuple[float, int], list[tuple[bool, float]]] = {
        (z, n): [] for z in zs for n in counts}

    used = 0
    for env_name, arms in sorted(envs.items(), key=lambda kv: str(kv[0])):
        if args.base not in arms:
            continue
        base = arms[args.base]
        for a in [x for x in arms if x != args.base]:
            shared = sorted(set(arms[a]) & set(base))
            if len(shared) < max(counts):
                continue
            npts = min(len(arms[a][s]) for s in shared)
            idx = max(0, int(round(args.fraction * (npts - 1))))
            diffs = {s: arms[a][s][idx][1] - base[s][idx][1] for s in shared}
            final_gain = float(np.mean([arms[a][s][-1][1] - base[s][-1][1] for s in shared]))
            used += 1
            for n in counts:
                for _ in range(args.repeats):
                    pick = rng.choice(shared, size=n, replace=False)
                    d = np.asarray([diffs[int(s)] for s in pick], dtype=float)
                    sd = d.std(ddof=1) if n > 1 else 0.0
                    for z in zs:
                        lcb = d.mean() - z * sd / np.sqrt(n) if n > 1 else d.mean()
                        trials[(z, n)].append((bool(lcb > 0), final_gain))

    print(f"configurations used: {used}")
    print(f"probe fraction: {args.fraction:.0%}; repeats per (z, n): {args.repeats}\n")
    print(f"{'z':>5s} {'n':>3s} {'nominal alpha':>14s} {'P(open)':>9s} "
          f"{'P(harm|open)':>13s} {'P(harm|shut)':>13s} {'violation ratio':>16s}")
    rows = []
    for z in zs:
        for n in counts:
            recs = trials[(z, n)]
            if not recs:
                continue
            opened = np.asarray([o for o, _ in recs])
            gains = np.asarray([g for _, g in recs])
            n_open = int(opened.sum())
            if n_open == 0:
                p_harm_open = float("nan")
            else:
                p_harm_open = float((gains[opened] < 0).mean())
            n_shut = int((~opened).sum())
            p_harm_shut = float((gains[~opened] < 0).mean()) if n_shut else float("nan")
            nom = nominal_alpha(z, n)
            ratio = p_harm_open / nom if nom > 0 and np.isfinite(p_harm_open) else float("nan")
            rows.append({"z": z, "n": n, "nominal_alpha": nom,
                         "p_open": float(opened.mean()),
                         "p_harmful_given_open": p_harm_open,
                         "p_harmful_given_shut": p_harm_shut,
                         "violation_ratio": ratio})
            print(f"{z:>5.1f} {n:>3d} {nom:>14.4f} {opened.mean():>9.3f} "
                  f"{p_harm_open:>13.4f} {p_harm_shut:>13.4f} {ratio:>16.2f}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "gate_calibration.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
