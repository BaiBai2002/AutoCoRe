#!/bin/bash
set -e
echo "=== AutoCoRe Full Experiments ==="
echo "Running full experiments..."
python -m autocore.experiments.run_matrix --config configs/experiments_full.yaml
echo "Aggregating and generating paper assets..."
python -c "
from autocore.experiments.aggregate import aggregate_results, compute_statistics
from autocore.analysis.plots import *
from autocore.analysis.tables import *
from autocore.analysis.report import generate_research_report
df = aggregate_results('artifacts/raw_runs')
stats = compute_statistics(df)
stats.to_csv('artifacts/processed/aggregate_metrics.csv', index=False)
df.to_csv('artifacts/processed/metrics.csv', index=False)
generate_learning_curves(df, 'artifacts/figures')
generate_sample_efficiency_chart(df, 'artifacts/figures')
generate_provider_validity_chart(df, 'artifacts/figures')
generate_ablation_chart(df, 'artifacts/figures')
generate_main_results_table(df, 'artifacts/tables')
generate_ablation_table(df, 'artifacts/tables')
generate_llm_validation_table(df, 'artifacts/tables')
generate_research_report('.')
print('Full experiments complete.')
"
