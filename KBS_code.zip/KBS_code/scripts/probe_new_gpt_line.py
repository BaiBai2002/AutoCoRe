"""Second probe pass: availability of the newly discovered GPT-line models on the uuapi
proxy, a retry of claude-opus-4-7, and the Mimo model list.

Keys from .env, never printed. Exit 0 if >=1 new GPT-line model responds.
"""
import json
import sys
import urllib.request

ENV = {}
for ln in open(".env", encoding="utf-8"):
    ln = ln.strip()
    if ln and not ln.startswith("#") and "=" in ln:
        k, v = ln.split("=", 1)
        ENV[k.strip()] = v.strip().strip('"').strip("'")

base = ENV.get("UUAPI_BASE_URL", "https://uuapi.shop/v1").rstrip("/")
oa = ENV.get("UUAPI_OPENAI_KEY", "")
an = ENV.get("UUAPI_ANTHROPIC_KEY", "")


def complete(url, key, model, max_tokens=5):
    req = urllib.request.Request(
        url,
        data=json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": "reply with the single word: ok"}],
            "max_tokens": max_tokens,
        }).encode(),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=120) as r:
        body = json.loads(r.read())
        return r.status, body["choices"][0]["message"]["content"][:60]


print("== new GPT-line models (uuapi, OpenAI key) ==")
ok = 0
for model in ["gpt-6.1-sol", "gpt-6-sol", "gpt-5.6-sol"]:
    try:
        status, content = complete(f"{base}/chat/completions", oa, model)
        print(f"{model}: status {status} | {content}")
        ok += 1
    except Exception as e:
        print(f"{model} FAILED: {str(e)[:160]}")

print("== claude-opus-4-7 retry ==")
try:
    status, content = complete(f"{base}/chat/completions", an, "claude-opus-4-7")
    print(f"claude-opus-4-7: status {status} | {content}")
    ok += 1
except Exception as e:
    print(f"claude-opus-4-7 FAILED: {str(e)[:160]}")

print("== mimo model list ==")
mimo_base = (ENV.get("MIMO_V2_5_PRO_BASE_URL") or "https://api.mimo.run/v1").rstrip("/")
mk = ENV.get("MIMO_V2_5_PRO_API_KEY", "")
try:
    req = urllib.request.Request(f"{mimo_base}/models", headers={"Authorization": f"Bearer {mk}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        lst = json.loads(r.read())
        ids = sorted({m.get("id", "?") for m in lst.get("data", [])})
        print(f"{len(ids)} models:", ", ".join(ids[:30]))
except Exception as e:
    print("mimo model list FAILED:", str(e)[:160])

sys.exit(0 if ok > 0 else 1)