# CONFIRM_V3B — per-draw independent training blocks for the grounded proposer contrasts.
#
# Pre-registered in research_upgrade/kbs_upgrade/CONFIRM_V3B_PROTOCOL.md (2026-10-10, before any
# confv3b_* draw existed). Candidate pools are the published r0..r4 pools (cache-served, generation
# held fixed; one distinct pool per draw). Unlike E1 and V3, EVERY draw now carries its own probe and
# final seed block: draw i -> probe seeds 300+3i..302+3i, final seeds 120+5i..124+5i. Two families x
# five draws = ten draws. Idempotent, self-healing (three attempts per draw per round, ten rounds,
# 20-minute cooldown). Nothing is tuned after seeing data; every draw is reported in full.
#
# Usage:  powershell -NoProfile -File scripts/run_confirm_v3b.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/confirm_v3b.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) { $m | Tee-Object -FilePath $log -Append | Out-Null }

$tags = @()
foreach ($r in 0, 1, 2, 3, 4) {
    $p0 = 300 + 3 * $r; $p1 = $p0 + 1; $p2 = $p0 + 2
    $f0 = 120 + 5 * $r; $f1 = $f0 + 1; $f2 = $f0 + 2; $f3 = $f0 + 3; $f4 = $f0 + 4
    $probe = "$p0,$p1,$p2"
    $final = "$f0,$f1,$f2,$f3,$f4"
    $tags += @{ tag = "confv3b_r$r";    provider = "deepseek_v4_flash"; rep = $r; probe = $probe; final = $final }
    $tags += @{ tag = "confv3bgpt_r$r"; provider = "gpt_6_astra";      rep = $r; probe = $probe; final = $final }
}

Write-Log "CONFIRM_V3B starting (10 draws: 2 families x 5 per-draw independent training blocks)"

for ($round = 1; $round -le 10; $round++) {
    $missing = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($missing.Count -eq 0) { break }

    Write-Log "CONFIRM_V3B round ${round} starting; missing $($missing.Count) of 10"
    foreach ($t in $missing) {
        $summary = "artifacts/llm_proposal/$($t.tag)_summary.json"
        for ($a = 1; $a -le 3; $a++) {
            Write-Log "=== $($t.tag) (attempt ${a}; probe $($t.probe); finals $($t.final)) ==="
            & python -u scripts/llm_proposal_experiment.py --provider $t.provider --llm-v2 `
                --k-llm 12 --k-raw 6 --k-rand 12 --rep-offset $t.rep `
                --replicates 1 --probe-steps 50000 --probe-seeds $t.probe `
                --final-steps 300000 --final-seeds $t.final --tag $t.tag 2>&1 |
                Tee-Object -FilePath $log -Append | Out-Null
            if (Test-Path $summary) { Write-Log "OK: $($t.tag)"; break }
            Write-Log "FAILED attempt ${a} for $($t.tag)"
            Start-Sleep -Seconds 90
        }
    }

    $left = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
    if ($left.Count -eq 0) { break }
    Write-Log "CONFIRM_V3B round ${round} finished; $($left.Count) still missing; cooling down 20 min"
    Start-Sleep -Seconds 1200
}

$final = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/$($_.tag)_summary.json") })
if ($final.Count -eq 0) { Write-Log "CONFIRM_V3B_ALL_DONE" } else { Write-Log "CONFIRM_V3B_EXIT_INCOMPLETE" }