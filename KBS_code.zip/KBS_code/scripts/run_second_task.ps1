# Study F: second task family (external validity).
#
# The proposer study currently rests on simple_spread_v3. This stage repeats it on simple_push_v3
# (N=2, same 7 allowed predicates), so the claim is not single-task. It runs after the effort sweep
# so it never contends for the GPU.
#
# Note on the hand-designed arm: configs/dsl holds the spread potentials, so on push they are
# *valid but task-mismatched* human designs. That is reported as such, not presented as a tuned
# push-specific human baseline.
#
# Usage:  powershell -NoProfile -File scripts/run_second_task.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/second_task.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "waiting for the effort sweep to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/effort_sweep.log" -Pattern "EFFORT_SWEEP_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}
Write-Log "starting second-task study (simple_push_v3)"

# grounded: DeepSeek x3 draws, GPT-6 Astra x2 draws
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confpush_deepseek_r$r" -Extra @("--env", "simple_push_v3",
        "--provider", "deepseek_v4_flash", "--llm-v2", "--k-llm", "12", "--k-raw", "6",
        "--k-rand", "12", "--rep-offset", "$r")
}
foreach ($r in 0, 1) {
    Run-Draw -Tag "confpush_gpt_6_astra_r$r" -Extra @("--env", "simple_push_v3",
        "--provider", "gpt_6_astra", "--llm-v2", "--k-llm", "12", "--k-raw", "6",
        "--k-rand", "12", "--rep-offset", "$r")
}
# raw interface contrast on the second task
foreach ($r in 0, 1) {
    Run-Draw -Tag "confpush_raw_deepseek_r$r" -Extra @("--env", "simple_push_v3",
        "--provider", "deepseek_v4_flash", "--k-llm", "6", "--k-raw", "6",
        "--k-rand", "6", "--rep-offset", "$r")
}

Write-Log "SECOND_TASK_DONE"
