"""Latency probe: sizeable completion on gpt-5.6-sol through the proxy (prints timing only)."""
import json
import sys
import time
import urllib.request

ENV = {}
for ln in open(".env", encoding="utf-8"):
    ln = ln.strip()
    if ln and not ln.startswith("#") and "=" in ln:
        k, v = ln.split("=", 1)
        ENV[k.strip()] = v.strip().strip('"').strip("'")

key = ENV.get("UUAPI_OPENAI_KEY", "")
req = urllib.request.Request(
    "https://uuapi.shop/v1/chat/completions",
    data=json.dumps({
        "model": "gpt-5.6-sol",
        "messages": [{"role": "user",
                      "content": "Write a JSON array of 3 short strings describing colors. Only JSON."}],
        "max_tokens": 300,
        "temperature": 0.9,
    }).encode(),
    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
)
t = time.time()
try:
    r = urllib.request.urlopen(req, timeout=300)
    b = json.loads(r.read())
    print("status", r.status, "| latency %.1fs" % (time.time() - t),
          "| chars", len(b["choices"][0]["message"]["content"]))
except Exception as e:
    print("FAILED after %.0fs:" % (time.time() - t), str(e)[:200])
    sys.exit(1)