#!/bin/bash
set -e
echo "=== AutoCoRe Pilot Experiments ==="
echo "Running pilot experiments..."
python -m autocore.experiments.run_matrix --config configs/experiments_pilot.yaml
echo "Aggregating results..."
python -c "
from autocore.experiments.aggregate import aggregate_results, compute_statistics
from autocore.analysis.plots import generate_learning_curves, generate_sample_efficiency_chart
from autocore.analysis.report import generate_research_report
df = aggregate_results('artifacts/raw_runs')
stats = compute_statistics(df)
stats.to_csv('artifacts/processed/aggregate_metrics.csv', index=False)
generate_learning_curves(df, 'artifacts/figures')
generate_sample_efficiency_chart(df, 'artifacts/figures')
generate_research_report('.')
print('Pilot experiments complete.')
"
