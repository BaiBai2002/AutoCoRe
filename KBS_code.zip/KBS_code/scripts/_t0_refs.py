import os, re

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SECT = os.path.join(ROOT, "paper", "sections")
MAIN = os.path.join(ROOT, "paper", "main.tex")

files = [MAIN] + [os.path.join(SECT, f) for f in sorted(os.listdir(SECT)) if f.endswith(".tex")]
text = {f: open(f, encoding="utf-8", errors="ignore").read() for f in files}
all_text = "\n".join(text.values())

labels = {}
for f, t in text.items():
    for m in re.finditer(r"\\label\{([^}]+)\}", t):
        labels.setdefault(m.group(1), os.path.basename(f))

refs = set(re.findall(r"\\(?:ref|eqref|autoref)\{([^}]+)\}", all_text))

fig_labels = {k: v for k, v in labels.items() if k.startswith("fig:")}
tab_labels = {k: v for k, v in labels.items() if k.startswith("tab:")}

print("=== figure labels ===")
for k, v in sorted(fig_labels.items()):
    print(f"  {'CITED  ' if k in refs else 'ORPHAN '} {k:<20} ({v})")
print("=== table labels ===")
for k, v in sorted(tab_labels.items()):
    print(f"  {'CITED  ' if k in refs else 'ORPHAN '} {k:<20} ({v})")

orphans = sorted(k for k in labels if k not in refs)
print(f"\ntotal labels={len(labels)}  orphan labels={len(orphans)}")
for k in orphans:
    print(f"  ORPHAN {k}  ({labels[k]})")
