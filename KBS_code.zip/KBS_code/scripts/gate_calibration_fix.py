"""Can the gate's error rate be made honest?

The paper's F3 result shows that the nominal error target of the LCB gate is
violated by up to three orders of magnitude. This script asks the constructive
follow-up: is there a decision rule whose *realised* rate of harmful deployment
matches a stated target? It reports three things on the candidate table assembled
from every audit in the paper.

1. Per setting, the operating point of the two scale-free rules: the LCB gate used
   throughout the paper, and the naive rule that deploys whenever the probe gain is
   non-negative.
2. For the one setting where *every* candidate was trained to the full budget (the
   rich pool), the error--coverage curve: how selective a gate must be to reach a
   target harmful rate, and what that costs in deployed gain.
3. A leave-one-setting-out calibration of a within-setting quantile rule, with the
   caveat that only one setting has full-pool outcomes, so the calibration pool is
   heterogeneous.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bps_gate_experiment import realized_steps  # noqa: E402

OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
RESULT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "gate_calibration_fix.json")

DEFAULT = ["spread_n3_fullpool10_summary.json", "spread_n3_axis_summary.json",
           "push_summary.json", "spread_n5_summary.json", "n7_summary.json",
           "spread_n3_mappo_summary.json", "pz_pursuit_full_summary.json"]

FULL_POOL = "spread_n3_fullpool10"


def prefix_of(s: dict) -> str:
    n = "na" if s["num_agents"] is None else str(s["num_agents"])
    return f"{s['env'].replace('/', '-')}_{s['algo']}_N{n}_final_"


def load_values(pfx: str, key: str, expected: int) -> dict[int, float]:
    out = {}
    for f in glob.glob(os.path.join(OUTDIR, pfx + key + "_s*.json")):
        with open(f, encoding="utf-8") as fh:
            d = json.load(fh)
        if int(d.get("steps", -1)) == realized_steps(expected):
            out[int(d["seed"])] = float(d["final_return"])
    return out


def build_table(paths: list[str]) -> list[dict]:
    rows = []
    for name in paths:
        path = os.path.join(OUTDIR, name)
        if not os.path.exists(path):
            print(f"  (skip missing {name})")
            continue
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        pfx = prefix_of(s)
        base = load_values(pfx, "base", s["final_steps"])
        if not base:
            print(f"  (skip {name}: no baseline)")
            continue
        seen: dict[str, bool] = {}
        setting = name.replace("_summary.json", "")
        for d in s.get("decisions", []):
            for c in d.get("probe_table", []):
                if seen.get(c["key"]):
                    continue
                vals = load_values(pfx, c["key"], s["final_steps"])
                shared = sorted(set(vals) & set(base))
                if len(shared) < 2:
                    continue
                gain = float(np.mean([vals[t] - base[t] for t in shared]))
                seen[c["key"]] = True
                rows.append({"setting": setting,
                             "label": f"{s['env'].replace('simple_', '')} N={s['num_agents']} {s['algo']}",
                             "key": c["key"], "name": c["name"],
                             "probe": float(c["probe_mean_gain"]),
                             "lcb": float(c["probe_lcb"]),
                             "gain": gain, "harmful": gain < 0.0})
    return rows


def rate(rows: list[dict], key: str) -> float:
    return float(np.mean([r[key] for r in rows])) if rows else float("nan")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summaries", default=",".join(DEFAULT))
    ap.add_argument("--target", type=float, default=0.05)
    args = ap.parse_args()

    rows = build_table([x.strip() for x in args.summaries.split(",") if x.strip()])
    settings = sorted({r["setting"] for r in rows})
    print(f"{len(rows)} candidate instances across {len(settings)} settings\n")

    out: dict = {"target": args.target, "per_setting": [], "sweep": [], "loo": []}

    # ---- 1. per-setting operating points -----------------------------------
    print(f"{'setting':<26s} {'n':>3s} {'lcb dep':>8s} {'lcb harm':>9s} "
          f"{'naive dep':>10s} {'naive harm':>11s}")
    for st in settings:
        grp = [r for r in rows if r["setting"] == st]
        dl = [r for r in grp if r["lcb"] >= 0]
        dn = [r for r in grp if r["probe"] >= 0]
        rec = {"setting": st, "n": len(grp),
               "lcb_deployed": len(dl), "lcb_harmful": rate(dl, "harmful"),
               "naive_deployed": len(dn), "naive_harmful": rate(dn, "harmful")}
        out["per_setting"].append(rec)
        print(f"{st:<26s} {len(grp):>3d} {len(dl):>8d} {rec['lcb_harmful']:>9.1%} "
              f"{len(dn):>10d} {rec['naive_harmful']:>11.1%}")

    # ---- 2. error-coverage curve on the full-pool setting ------------------
    rich = sorted([r for r in rows if r["setting"] == FULL_POOL],
                  key=lambda r: -r["probe"])
    print(f"\nerror-coverage on the rich pool ({FULL_POOL}, n={len(rich)}):")
    print(f"  {'deployed':>9s} {'harmful':>8s} {'mean gain':>10s}")
    for q in (0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0):
        k = max(1, int(round(q * len(rich))))
        dep = rich[:k]
        rec = {"q": q, "deployed": k, "harmful": rate(dep, "harmful"),
               "mean_gain": rate(dep, "gain")}
        out["sweep"].append(rec)
        print(f"  {k:>4d}/{len(rich):<4d} {rec['harmful']:>8.1%} {rec['mean_gain']:>+10.2f}")
    op = [r for r in rich if r["lcb"] >= 0]
    print(f"  lcb operating point: {len(op)}/{len(rich)} deployed, "
          f"{rate(op, 'harmful'):.1%} harmful, mean gain {rate(op, 'gain'):+.2f}")

    # ---- 3. leave-one-setting-out quantile calibration (with caveat) -------
    print(f"\nleave-one-setting-out quantile calibration (target {args.target:.0%}):")
    print(f"  {'held-out':<26s} {'q*':>6s} {'deployed':>9s} {'harmful':>8s}")
    for st in settings:
        calib = [r for r in rows if r["setting"] != st]
        test = sorted([r for r in rows if r["setting"] == st], key=lambda r: -r["probe"])
        best_q = 0.0
        for q in np.round(np.arange(0.05, 1.0001, 0.05), 2):
            dep = []
            for st2 in {r["setting"] for r in calib}:
                grp = sorted([r for r in calib if r["setting"] == st2], key=lambda r: -r["probe"])
                dep.extend(grp[:max(1, int(round(q * len(grp))))])
            if len(dep) < 3:
                continue
            if rate(dep, "harmful") <= args.target:
                best_q = float(q)
            else:
                break
        q = best_q if best_q > 0 else 0.05
        k = max(1, int(round(q * len(test))))
        rec = {"held_out": st, "q": q, "n": len(test), "deployed": k,
               "harmful": rate(test[:k], "harmful")}
        out["loo"].append(rec)
        print(f"  {st:<26s} {q:6.2f} {k:>4d}/{len(test):<4d} {rec['harmful']:>8.1%}")
    print(f"\n  mean realised rate: {np.mean([r['harmful'] for r in out['loo']]):.1%} "
          f"(target {args.target:.0%})")

    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("\nwrote", os.path.normpath(RESULT))


if __name__ == "__main__":
    main()
