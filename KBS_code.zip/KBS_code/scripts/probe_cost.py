"""Search-cost curve: what does the *probe budget* cost, once selection has saturated?

Reads the controlled probe-budget sweep (``artifacts/bps_gate/sweepc_<steps>_summary.json``;
identical task, pool, probe seeds and final budget, varying only ``--probe-steps``) and reports, per
budget, the search overhead, the budget-matched baseline it implies, and the **budget-matched** gain
of the deployed configuration. Because selection returns the *same* configuration at every budget
here, any change in the budget-matched gain is the cost of the search, not a change in quality.

Writes ``artifacts/diagnostics/probe_cost.json``.
"""
from __future__ import annotations

import glob
import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BP = os.path.join(ROOT, "artifacts", "bps_gate")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "probe_cost.json")


def main() -> None:
    rows = []
    for f in sorted(glob.glob(os.path.join(BP, "sweep[cde]_*_summary.json"))):
        d = json.load(open(f, encoding="utf-8"))
        bm = d.get("budget_matched_baseline") or {}
        gains = [r.get("gain_vs_budget_matched") for r in d.get("rows", [])
                 if r.get("arm") == "bps_gate"]
        gains = [g for g in gains if isinstance(g, (int, float))]
        deployed = sorted({r.get("deployed") for r in d.get("rows", [])
                           if r.get("arm") == "bps_gate"})
        rows.append({
            "summary": os.path.basename(f),
            "final_steps": d.get("final_steps"),
            "probe_steps": int(d.get("probe_steps", 0)),
            "search_overhead_interactions": d.get("search_overhead_interactions"),
            "budget_matched_steps_per_seed": bm.get("steps"),
            "budget_matched_mean": bm.get("mean"),
            "deployed_configs": deployed,
            "gain_vs_budget_matched": [round(g, 2) for g in gains],
            "gain_vs_budget_matched_mean": round(sum(gains) / len(gains), 2) if gains else None,
        })
    out = {
        "env": "simple_spread_v3", "probe_draws": 3,
        "design": ("identical task, pool, probe seeds and final budget; only --probe-steps varies, "
                   "so a change in the budget-matched gain is the cost of the search"),
        "rows": rows,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
