"""PBRS formula checker: verifies shaping = lambda * (gamma * phi_next - phi_prev)."""
import sys, numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from autocore.shaping.potentials import ShapingConfig, PotentialFunction
from autocore.dsl import compile_dsl

def test_pbrs():
    dsl = {
        "task_name": "test", "version": "1.0", "description": "test",
        "subgoals": [{"name": "s1", "scope": "global", "weight": 1.0,
                      "predicate": {"type": "min_distance_landmark_coverage",
                                    "args": {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}},
                      "potential": {"type": "negative_normalized_sum_min_distance", "clip": [-1.0, 0.0]},
                      "rationale": "test"}],
        "expected_effects": {}
    }
    compiled = compile_dsl(dsl)
    for gamma in [0.95, 0.99, 1.0]:
        for lam in [0.05, 0.1, 0.2]:
            cfg = ShapingConfig(gamma=gamma, shaping_lambda=lam)
            pf = PotentialFunction(compiled, cfg)
            s_a = {"agent_positions": [[0.0, 0.0]], "landmark_positions": [[1.0, 1.0]]}
            s_b = {"agent_positions": [[0.5, 0.5]], "landmark_positions": [[1.0, 1.0]]}
            phi_a = pf.compute_potential(s_a)
            phi_b = pf.compute_potential(s_b)
            shaping = pf.compute_shaping_reward(s_b, s_a)
            expected = lam * (gamma * phi_b - phi_a)
            err = abs(shaping - expected)
            status = "OK" if err < 1e-10 else f"FAIL (err={err:.2e})"
            print(f"  gamma={gamma} lam={lam}: phi_a={phi_a:.4f} phi_b={phi_b:.4f} shaping={shaping:.4f} expected={expected:.4f} -> {status}")
            assert err < 1e-10, f"PBRS formula mismatch: {shaping} vs {expected}"

if __name__ == "__main__":
    test_pbrs()
    print("\nPBRS formula verified: shaping = lambda * (gamma * phi_next - phi_prev)")
