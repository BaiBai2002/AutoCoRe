import os, re, json

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
P = os.path.join(ROOT, "paper")

# --- fig_method.pdf physical size -------------------------------------------------
import struct
def pdf_mediabox(path):
    with open(path, "rb") as f:
        data = f.read()
    m = re.search(rb"/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\]", data)
    if m:
        x0, y0, x1, y1 = (float(v) for v in m.groups())
        return x1 - x0, y1 - y0
    return None

for name in ("fig_method.pdf", "fig_feasibility.pdf", "fig_dose_response.pdf"):
    wh = pdf_mediabox(os.path.join(P, "figures", name))
    if wh:
        print(f"{name}: {wh[0]:.1f} x {wh[1]:.1f} pt = {wh[0]/72:.3f} x {wh[1]/72:.3f} in")

# --- column width from the log -----------------------------------------------------
log = open(os.path.join(P, "main_final.log"), encoding="utf-8", errors="ignore").read()
for pat in (r"\\columnwidth=\\the\\columnwidth", r"\\columnwidth[^\n]*"):
    pass
m = re.search(r"\\columnwidth=\\the\\columnwidth.*?\n(.*?)\n", log)
# simpler: ask LaTeX we already know; instead read \textwidth from log geometry
for line in log.splitlines():
    if "columnwidth" in line.lower() and "=" in line:
        print("LOG:", line.strip())

# --- page map from pdftotext -------------------------------------------------------
txt = open(os.path.join(ROOT, "fig1", "_render", "main_final.txt"), encoding="utf-8", errors="ignore").read()
pages = txt.split("\f")
print(f"\npages in text: {len(pages)}")
SEC = re.compile(r"^\s*(?:[IVX]+\.\s+)?(ABSTRACT|I\.\s|II\.\s|III\.\s|IV\.\s|V\.\s|VI\.\s|VII\.\s|VIII\.\s|IX\.\s)")
rows = []
for i, pg in enumerate(pages, 1):
    if not pg.strip():
        continue
    tabs = sorted(set(re.findall(r"TABLE\s+[IVX]+", pg)))
    figs = sorted(set(re.findall(r"Fig\.\s*\d+", pg)))
    words = len(pg.split())
    rows.append({"page": i, "words": words, "tables": tabs, "figs": figs})
    print(f"p{i:>2}  words={words:>4}  tables={tabs}  figs={figs}")
json.dump(rows, open(os.path.join(ROOT, "audit", "_page_map_raw.json"), "w"), indent=2)
