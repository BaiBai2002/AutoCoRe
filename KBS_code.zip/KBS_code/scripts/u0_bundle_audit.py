"""U0 — independent member audit of a submission bundle.

Reads a submission zip (not the working tree) and writes a per-member audit CSV,
together with a summary: member count, PDF count, presence of the stale
``main_final.*`` duplicate, forbidden-pattern members, and the bundle's own
sha256. It is deliberately independent of ``make_submission_bundle.py`` so that
"the builder says it is clean" is not the evidence.

Usage:
    python scripts/u0_bundle_audit.py [path/to/bundle.zip]
"""
from __future__ import annotations

import csv
import hashlib
import os
import sys
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DEFAULT_ZIP = os.path.join(ROOT, "submission", "pbrs-audit-bundle.zip")
OUT_CSV = os.path.join(ROOT, "submission", "U0_member_audit.csv")

# Substrings that must never appear in a member path of a public bundle.
FORBIDDEN = [
    ".env", "/archive/", "pytest_cache", "__pycache__", ".egg-info",
    "gpt_", "dashboard", "_t3_pages", "_t3_bands", "/fig1/",
    "build0", "build1", "build2", "build3",
    "overlap_disclosure", "cover_letter",
]
# File-name stems that are superseded duplicates of the authoritative artifact.
STALE_STEMS = ["main_final"]


def category(rel: str) -> str:
    rel = rel.replace(os.sep, "/")
    if rel.startswith("artifacts/") and rel.endswith(".json"):
        return "run_logs"
    if rel.startswith(("scripts/", "src/")):
        return "code"
    if rel.startswith("paper/"):
        return "paper"
    if rel.startswith(("workplan/", "audit/")):
        return "governance"
    if rel.startswith("configs/"):
        return "configs"
    if rel.startswith("theory/"):
        return "theory"
    return "other"


def main() -> int:
    zip_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_ZIP
    if not os.path.exists(zip_path):
        print(f"bundle not found: {zip_path}")
        return 2

    z = zipfile.ZipFile(zip_path)
    rows = []
    for info in z.infolist():
        if info.is_dir():
            continue
        rel = info.filename
        low = rel.lower()
        dig = hashlib.sha256(z.read(info)).hexdigest()
        forb = [p for p in FORBIDDEN if p in low]
        stale = [s for s in STALE_STEMS if s in os.path.basename(low)]
        decision = "FLAG" if (forb or stale) else "include"
        notes = []
        if forb:
            notes.append("forbidden:" + ",".join(forb))
        if stale:
            notes.append("stale-duplicate:" + ",".join(stale))
        rows.append([rel, dig, info.file_size, category(rel), decision, ";".join(notes)])

    rows.sort(key=lambda r: r[0])
    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    with open(OUT_CSV, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["member", "sha256", "size_bytes", "category", "decision", "notes"])
        w.writerows(rows)

    flags = [r for r in rows if r[3] == "FLAG"] if False else [r for r in rows if r[4] == "FLAG"]
    n_pdf = sum(1 for r in rows if r[0].lower().endswith(".pdf"))
    pdfs = [r[0] for r in rows if r[0].startswith("paper/") and r[0].lower().endswith(".pdf")]
    bundle_sha = hashlib.sha256(open(zip_path, "rb").read()).hexdigest()

    print("=" * 78)
    print(f"bundle           : {os.path.relpath(zip_path, ROOT)}")
    print(f"bundle sha256    : {bundle_sha}")
    print(f"members (files)  : {len(rows)}")
    print(f"pdf members      : {n_pdf}")
    print(f"paper pdfs       : {pdfs}")
    print(f"FLAGGED members  : {len(flags)}")
    for r in flags:
        print(f"   - {r[0]}  [{r[5]}]")
    print(f"wrote            : {os.path.relpath(OUT_CSV, ROOT)}")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
