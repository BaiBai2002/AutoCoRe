"""Supplement figure: the search-cost curve.

Reads ``artifacts/diagnostics/probe_cost.json`` (the controlled probe-budget sweeps) and plots the
budget-matched gain of the deployed configuration against the probe (search) budget, for the 50K and
the canonical 300K final budget. The point of the figure is that the *selected configuration* is the
same at every probe budget, so the decline is the search being charged to the baseline --- not a
change in selection quality.

Writes ``paper/figures/fig_probe_cost.pdf`` and ``.png``.
"""
from __future__ import annotations

import json
import os

import matplotlib.pyplot as plt

import figstyle
from figstyle import FAMILY, LINESTYLES, MARKERS, OUTCOME, grid, legend_outside, save

SRC = os.path.join(figstyle.PROJECT_ROOT, "artifacts", "diagnostics", "probe_cost.json")


def main() -> None:
    figstyle.apply_style()
    d = json.load(open(SRC, encoding="utf-8"))
    series: dict[int, dict[int, dict]] = {}
    for r in d["rows"]:
        if r["summary"].startswith(("sweepc", "sweepe")):
            series.setdefault(r["final_steps"], {})[r["probe_steps"]] = r

    fig, ax = plt.subplots(figsize=(3.4, 2.15))
    for i, final in enumerate(sorted(series)):
        pts = series[final]
        xs = sorted(pts)
        colour = FAMILY["mpe"] if final == 50000 else FAMILY["sisl"]
        ax.plot([p / 1000 for p in xs],
                [pts[p]["gain_vs_budget_matched_mean"] for p in xs],
                ls=LINESTYLES[i], marker=MARKERS[i], color=colour,
                label=f"final $= {final // 1000}$K", zorder=3)
        for p in xs:
            for g in pts[p]["gain_vs_budget_matched"]:
                ax.plot([p / 1000], [g], marker=MARKERS[i], ms=2.2, color=colour,
                        alpha=0.45, zorder=2)

    ax.axhline(0.0, color=OUTCOME["neutral"], lw=0.7, ls="--", zorder=1)
    ax.set_xscale("log")
    ax.minorticks_off()
    ax.set_xticks([5, 15, 50])
    ax.set_xticklabels(["5K", "15K", "50K"])
    ax.set_xlim(3.4, 72)
    ax.set_xlabel("probe (search) budget")
    ax.set_ylabel("gain vs budget-matched baseline")
    grid(ax, "y")
    legend_outside(ax, ncol=2, y=-0.30)
    save(fig, "fig_probe_cost")


if __name__ == "__main__":
    main()
