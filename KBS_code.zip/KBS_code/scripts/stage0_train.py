"""Stage-0 training entry point using the rebuilt vectorized PPO core.

Usage:
    python scripts/stage0_train.py --env simple_spread_v3 --steps 100000 --seed 0
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np
import torch

from autocore.algos.ppo_role import MARLPPO, MARLPPOConfig, Rollout
from autocore.algos.vec_mpe import MpeEvaluator, VecMPE

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def collect_value_steps(env, agent, buffer, obs: np.ndarray, horizon: int,
                        epsilon: float) -> np.ndarray:
    """Collect ``horizon`` vectorised steps for a value-decomposition learner.

    Transitions are stored per environment with the *team* reward
    ``sum_i r_i``, matching the evaluator's return definition and the paper's
    ``R(s,a) = sum_i r_i``. ``next_obs`` is the terminal observation and ``dones``
    is carried separately, so the bootstrap is masked correctly even though the
    environment auto-resets.
    """
    from autocore.algos.vdn_qmix import joint_state
    for _ in range(horizon):
        actions = agent.act(obs, epsilon=epsilon)
        out = env.step(actions)
        team_reward = out.rewards.sum(axis=1)
        js = joint_state(obs)
        njs = joint_state(out.next_obs)
        for i in range(env.num_envs):
            buffer.push(obs[i], js[i], actions[i].astype(np.int64),
                        float(team_reward[i]), out.next_obs[i], njs[i],
                        float(out.dones[i]))
        obs = out.obs
    return obs


def build_rollout(env: VecMPE, agent: MARLPPO, horizon: int,
                  current_obs: np.ndarray) -> tuple[Rollout, np.ndarray]:
    n_envs, n_agents = env.num_envs, env.num_agents
    obs = np.zeros((horizon, n_envs, n_agents, env.obs_dim), dtype=np.float32)
    actions = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    log_probs = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    rewards = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    values = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    next_values = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    terminated = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)
    dones = np.zeros((horizon, n_envs, n_agents), dtype=np.float32)

    for t in range(horizon):
        act, lp, val = agent.act(current_obs, deterministic=False)
        outcome = env.step(act)
        obs[t] = current_obs
        actions[t] = act
        log_probs[t] = lp
        values[t] = val
        next_values[t] = agent.value_of(outcome.next_obs)
        rewards[t] = outcome.rewards
        terminated[t] = outcome.terminated[:, None]
        dones[t] = outcome.dones[:, None]
        current_obs = outcome.obs

    rollout = Rollout(obs=obs, actions=actions, log_probs=log_probs, rewards=rewards,
                      values=values, next_values=next_values, terminated=terminated, dones=dones)
    return rollout, current_obs


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--steps", type=int, default=100_000)
    ap.add_argument("--num-envs", type=int, default=16)
    ap.add_argument("--horizon", type=int, default=80)
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--eval-episodes", type=int, default=20)
    ap.add_argument("--eval-every", type=int, default=10_000)
    ap.add_argument("--hidden", type=int, default=128)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--entropy", type=float, default=0.01)
    ap.add_argument("--epochs", type=int, default=4)
    ap.add_argument("--minibatches", type=int, default=4)
    ap.add_argument("--tag", default="")
    ap.add_argument("--dsl", default=None)
    ap.add_argument("--lam", type=float, default=0.0)
    ap.add_argument("--control", default="none",
                    choices=["none", "random_projection"])
    ap.add_argument("--reward-scale", type=float, default=1.0)
    ap.add_argument("--algo", default="ippo", choices=["ippo", "mappo", "qmix", "vdn"])
    ap.add_argument("--feature-weights", default=None,
                    help="comma-separated weights over the normalised feature bank")
    ap.add_argument("--rho-target", type=float, default=0.2,
                    help="target episode-level dominance when auto-calibrating lambda")
    ap.add_argument("--per-landmark-features", action="store_true",
                    help="add per-landmark distance features (task-aligned capacity)")
    ap.add_argument("--num-agents", type=int, default=None,
                    help="override the number of agents for scalable MPE tasks")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    from autocore.envs.vec_pz import PZ_ENV_IDS
    pz_family = args.env in PZ_ENV_IDS
    set_global_seed(args.seed)

    cfg = MARLPPOConfig(lr=args.lr, hidden_dim=args.hidden, num_layers=2,
                        update_epochs=args.epochs, num_minibatches=args.minibatches,
                        entropy_coef=args.entropy,
                        value_coef=0.5, max_grad_norm=0.5, device="cuda",
                        centralized_critic=(args.algo == "mappo"))

    eval_seeds = [10_000 + 137 * i for i in range(args.eval_episodes)]

    potential_fn = None
    if args.dsl:
        from autocore.dsl.compiler import compile_dsl
        from autocore.selection.magnitude_calibration import (
            RandomProjectionPotential, collect_reference_states, estimate_scales,
        )
        from autocore.shaping.potentials import PotentialFunction, ShapingConfig
        with open(args.dsl, encoding="utf-8") as f:
            dsl_dict = json.load(f)
        compiled = compile_dsl(dsl_dict)
        if args.lam <= 0.0:
            probe_pf = PotentialFunction(compiled, ShapingConfig(gamma=0.99, shaping_lambda=0.0,
                                                                 potential_clip=(-1.0, 1.0)))
            est = estimate_scales(args.env, probe_pf.compute_potential, gamma=0.99,
                                  max_cycles=args.max_cycles, n_episodes=24,
                                  seed=args.seed, num_agents=args.num_agents)
            args.lam = est.required_lambda(args.rho_target)
            print(f"analytic calibration: E|R|={est.mean_abs_return:.1f} "
                  f"E|dPhi|={est.mean_abs_delta_phi:.4f} -> lambda*={args.lam:.3f}")
        pf = PotentialFunction(compiled, ShapingConfig(gamma=0.99, shaping_lambda=args.lam,
                                                      potential_clip=(-1.0, 1.0)))
        potential_fn = pf.compute_potential
        print(f"shaping: dsl={os.path.basename(args.dsl)} lambda={args.lam} "
              f"subgoals={compiled.meta.get('names')}")
        if args.control == "random_projection":
            est = estimate_scales(args.env, potential_fn, gamma=0.99,
                                  max_cycles=args.max_cycles, n_episodes=24, seed=args.seed,
                                  num_agents=args.num_agents)
            states = collect_reference_states(args.env, max_cycles=args.max_cycles,
                                              n_episodes=6, seed=args.seed,
                                              num_agents=args.num_agents)
            control = RandomProjectionPotential(est, seed=args.seed).fit(states)
            potential_fn = control
            print(f"control: random projection matched to Phi in "
                  f"[{est.phi_min:.3f}, {est.phi_max:.3f}] (std {est.phi_std:.3f})")
        elif args.reward_scale != 1.0:
            print(f"control: raw reward scaled by {args.reward_scale}")

    if args.feature_weights:
        from autocore.selection.landscape_search import LinearPotential
        from autocore.selection.magnitude_calibration import estimate_scales
        weights = [float(x) for x in args.feature_weights.split(",")]
        if pz_family:
            from autocore.selection.obs_features import build_obs_bank
            bank = build_obs_bank(args.env, max_cycles=args.max_cycles,
                                  n_episodes=6, seed=args.seed)
        else:
            from autocore.selection.landscape_search import build_bank
            bank = build_bank(args.env, num_agents=args.num_agents,
                              max_cycles=args.max_cycles, n_episodes=6, seed=args.seed,
                              per_landmark=args.per_landmark_features)
        if bank.dim != len(weights):
            raise SystemExit(f"feature bank has {bank.dim} features, got {len(weights)} weights")
        potential_fn = LinearPotential(bank, weights)
        if args.lam <= 0.0:
            est = estimate_scales(args.env, potential_fn, gamma=0.99,
                                  max_cycles=args.max_cycles, n_episodes=24,
                                  seed=args.seed, num_agents=args.num_agents)
            args.lam = est.required_lambda(args.rho_target)
        print(f"shaping: linear potential over {bank.dim} features "
              f"(w={[round(w, 3) for w in weights]}), calibrated lambda={args.lam:.3f}")

    value_based = args.algo in ("qmix", "vdn")
    if pz_family:
        from autocore.envs.vec_pz import PzEvaluator, VecPZ
        env = VecPZ(args.env, num_envs=args.num_envs, max_cycles=args.max_cycles,
                    base_seed=args.seed * 1000, potential_fn=potential_fn,
                    shaping_lambda=args.lam, gamma=0.99, reward_scale=args.reward_scale)
        evaluator = PzEvaluator(args.env, max_cycles=args.max_cycles,
                                potential_fn=potential_fn, shaping_lambda=args.lam,
                                gamma=0.99, reward_scale=args.reward_scale)
    else:
        env = VecMPE(args.env, num_envs=args.num_envs, max_cycles=args.max_cycles,
                     base_seed=args.seed * 1000, potential_fn=potential_fn,
                     shaping_lambda=args.lam, gamma=0.99, reward_scale=args.reward_scale,
                     num_agents=args.num_agents)
        evaluator = MpeEvaluator(args.env, max_cycles=args.max_cycles,
                                 potential_fn=potential_fn, shaping_lambda=args.lam,
                                 gamma=0.99, reward_scale=args.reward_scale,
                                 num_agents=args.num_agents)
    current_obs = env.reset()

    buffer = None
    if value_based:
        from autocore.algos.vdn_qmix import QMixAgent, QMixConfig, ReplayBuffer
        if not all(r.discrete for r in env.roles.values()):
            raise SystemExit(f"--algo {args.algo} needs discrete action spaces")
        qcfg = QMixConfig(lr=args.lr, hidden_dim=args.hidden, num_layers=2, gamma=0.99,
                          mixer=("vdn" if args.algo == "vdn" else "qmix"),
                          device="cuda", replay_seed=args.seed)
        state_dim = env.num_agents * env.obs_dim
        agent = QMixAgent(env.num_agents, env.obs_dim, env.act_dim, state_dim, qcfg)
        buffer = ReplayBuffer(qcfg.buffer_size, env.num_agents, env.obs_dim, state_dim,
                              seed=args.seed)

        def greedy(ob: np.ndarray) -> np.ndarray:
            return agent.greedy(ob)
    else:
        qcfg = None
        agent = MARLPPO(env.roles, env.agent_index, env.num_agents, env.obs_dim, cfg)

        def greedy(ob: np.ndarray) -> np.ndarray:
            a, _, _ = agent.act(ob, deterministic=True)
            return a

    ref_noop = evaluator.run(
        lambda ob: np.zeros((1, len(evaluator.agent_names)), dtype=np.float32), eval_seeds)
    rand_rng = np.random.default_rng(20240101)
    n_agents = len(evaluator.agent_names)
    act_dims = np.asarray(evaluator.act_dims)

    def random_policy(ob: np.ndarray) -> np.ndarray:
        return rand_rng.integers(0, act_dims)[None, :].astype(np.float32)

    ref_random = evaluator.run(random_policy, eval_seeds)

    print(f"env={args.env} max_cycles={args.max_cycles} num_envs={args.num_envs} "
          f"horizon={args.horizon} steps={args.steps} seed={args.seed}")
    print(f"reference no-op : {ref_noop['mean_return']:9.2f} +- {ref_noop['std_return']:.2f}")
    print(f"reference random: {ref_random['mean_return']:9.2f} +- {ref_random['std_return']:.2f}")

    curve: list[tuple[int, float, float]] = []
    shaped_curve: list[tuple[int, float]] = []
    success_curve: list[tuple[int, float | None]] = []
    steps_done = 0
    next_eval = args.eval_every
    t0 = time.time()
    n_updates = max(1, args.steps // (args.num_envs * args.horizon))

    for update in range(1, n_updates + 1):
        if value_based:
            eps = agent.epsilon(update - 1, n_updates)
            current_obs = collect_value_steps(env, agent, buffer, current_obs,
                                              args.horizon, eps)
            stats = {"entropy": 0.0, "approx_kl": 0.0, "td_loss": float("nan")}
            if update > qcfg.warmup_collects:
                for _ in range(qcfg.updates_per_collect):
                    stats = agent.update(buffer)
                stats["entropy"] = 0.0
                stats["approx_kl"] = 0.0
            stats["epsilon"] = eps
        else:
            rollout, current_obs = build_rollout(env, agent, args.horizon, current_obs)
            stats = agent.update(rollout)
        steps_done += args.num_envs * args.horizon

        if steps_done >= next_eval or update == n_updates:
            res = evaluator.run(greedy, eval_seeds)
            curve.append((steps_done, res["mean_raw_return"], res["std_raw_return"]))
            shaped_curve.append((steps_done, res["mean_shaped_return"]))
            sr = res.get("success_rate")
            success_curve.append((steps_done, sr))
            extra = (f"eps {stats.get('epsilon', 0.0):.3f} "
                     f"td {stats.get('td_loss', float('nan')):.4f} "
                     if value_based else
                     f"ent {stats['entropy']:.3f} kl {stats['approx_kl']:.5f} ")
            print(f"  step {steps_done:>7d}  raw {res['mean_raw_return']:10.2f} "
                  f"+- {res['std_raw_return']:7.2f}  shaped {res['mean_shaped_return']:10.2f}  "
                  + (f"succ {sr:.2f}  " if sr is not None else "")
                  + extra + f"({time.time()-t0:.0f}s)", flush=True)
            next_eval += args.eval_every

    final = curve[-1][1] if curve else float("nan")
    summary = {
        "env": args.env, "steps": steps_done, "seed": args.seed,
        "num_envs": args.num_envs, "horizon": args.horizon, "max_cycles": args.max_cycles,
        "hidden_dim": args.hidden, "lr": args.lr,
        "dsl": os.path.basename(args.dsl) if args.dsl else None, "shaping_lambda": args.lam,
        "rho_target": args.rho_target,
        "control": args.control, "reward_scale": args.reward_scale,
        "algo": args.algo, "num_agents": args.num_agents,
        "noop_return": ref_noop["mean_return"], "noop_std": ref_noop["std_return"],
        "random_return": ref_random["mean_return"], "random_std": ref_random["std_return"],
        "curve": curve, "shaped_curve": shaped_curve, "success_curve": success_curve,
        "final_return": final,
        "final_shaped_return": shaped_curve[-1][1] if shaped_curve else float("nan"),
        "final_success_rate": success_curve[-1][1] if success_curve else None,
        "final_vs_noop": final - ref_noop["mean_return"],
        "wall_time": time.time() - t0,
    }
    out = args.out or os.path.join(
        PROJECT_ROOT, "artifacts", "diagnostics",
        f"stage0_{args.env}_seed{args.seed}"
        f"_h{args.hidden}_e{args.epochs}_mb{args.minibatches}_ent{args.entropy}"
        f"_{steps_done // 1000}k{('_' + args.tag) if args.tag else ''}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"\nfinal={final:.2f}  no-op={ref_noop['mean_return']:.2f}  "
          f"delta={final-ref_noop['mean_return']:+.2f}  wall={time.time()-t0:.0f}s")
    print("wrote", os.path.normpath(out))
    env.close()
    evaluator.close()


if __name__ == "__main__":
    main()
