"""Stage-0 reference policies for simple_spread_v3.

Establishes what a competent, non-learned policy achieves under the discrete
action space, so that IPPO's plateau can be judged against a real ceiling
rather than against no-op.
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.envs.pettingzoo_mpe import make_mpe_env

ENV_ID = "simple_spread_v3"
MAX_CYCLES = 80
EVAL_SEEDS = [10_000 + 137 * i for i in range(20)]
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "artifacts", "diagnostics", "stage0_oracle.json")


def greedy_assignment(agent_pos, landmark_pos):
    """Unique nearest-landmark assignment (greedy over the smallest distance first)."""
    n, m = len(agent_pos), len(landmark_pos)
    pairs = []
    for i in range(n):
        for j in range(m):
            pairs.append((float(np.linalg.norm(agent_pos[i] - landmark_pos[j])), i, j))
    pairs.sort()
    taken_a, taken_l = set(), set()
    assign = {}
    for _, i, j in pairs:
        if i in taken_a or j in taken_l:
            continue
        taken_a.add(i)
        taken_l.add(j)
        assign[i] = j
    return assign


def discrete_action_toward(delta, dead_zone):
    dx, dy = float(delta[0]), float(delta[1])
    if abs(dx) < dead_zone and abs(dy) < dead_zone:
        return 0
    if abs(dx) >= abs(dy):
        return 1 if dx < 0 else 2
    return 3 if dy < 0 else 4


def evaluate(policy_name, dead_zone=0.0):
    env = make_mpe_env(ENV_ID, max_cycles=MAX_CYCLES)
    names = list(env.possible_agents)
    returns = []
    for s in EVAL_SEEDS:
        env.reset(seed=int(s))
        total = 0.0
        for _ in range(MAX_CYCLES):
            world = env.aec_env.world
            apos = [np.asarray(a.state.p_pos) for a in world.agents]
            lpos = [np.asarray(l.state.p_pos) for l in world.landmarks]
            assign = greedy_assignment(apos, lpos)
            acts = {}
            for i, a in enumerate(names):
                j = assign.get(i)
                if j is None:
                    acts[a] = 0
                elif policy_name == "noop":
                    acts[a] = 0
                else:
                    acts[a] = discrete_action_toward(lpos[j] - apos[i], dead_zone)
            res = env.step(acts)
            total += float(sum(res[1].values()))
        returns.append(total)
    env.close()
    arr = np.asarray(returns)
    return float(arr.mean()), float(arr.std())


def main():
    results = {}
    for name, dz in [("noop", 0.0), ("goto_deadzone0.0", 0.0),
                     ("goto_deadzone0.2", 0.2), ("goto_deadzone0.4", 0.4)]:
        mu, sd = evaluate("noop" if name == "noop" else "goto", dz)
        results[name] = {"mean": mu, "std": sd}
        print(f"{name:>20s}: {mu:9.2f} +- {sd:6.2f}")
    os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print("wrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
