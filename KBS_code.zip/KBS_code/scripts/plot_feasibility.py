"""Feasibility figure: the calibrated coefficient versus the permitted grid.

Panel (a) shows the *per-agent* target lambda*/N for every (task, potential) pair we
audit, on a log axis, against the largest coefficient the legacy grid permits; the
shortfall is printed in a right-hand column so the labels cannot collide with the
markers. Panel (b) shows how the per-agent target grows with the team size for one
fixed task/potential. The per-agent convention is the one Table~\\ref{tab:feasibility}
reports (the wrappers add the term to each agent's reward), so the figure and the table
carry the same numbers. Agent counts are the true environment counts, the same ones the
table lists. Both panels are read from the JSON produced by ``calibrate_lambda.py``;
nothing is recomputed here.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import FAMILY, OUTCOME, apply_style, grid, save  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")

PRETTY = {
    "simple_spread_v3": "spread",
    "simple_reference_v3": "reference",
    "simple_push_v3": "push",
    "simple_speaker_listener_v4": "speaker\\_listener",
    "pursuit_v5": "pursuit (SISL)",
    "knights_archers_zombies_v11": "kaz (butterfly)",
}
POT = {"spread_coverage.json": "coverage", "spread_assignment.json": "assignment",
       "obs_features": "obs-features"}
FAM_MARK = {"mpe": "o", "sisl": "s", "butterfly": "^"}
FAM_LABEL = {"mpe": "MPE", "sisl": "SISL", "butterfly": "butterfly"}

# True agent counts of the audited environments, the same numbers Table~\ref{tab:feasibility}
# lists; the figure works in the per-agent convention (lambda*/N vs the grid).
N_AGENTS = {
    "simple_spread_v3": 3,
    "simple_reference_v3": 2,
    "simple_push_v3": 2,
    "simple_speaker_listener_v4": 2,
    "pursuit_v5": 8,
    "knights_archers_zombies_v11": 4,
}


def main() -> None:
    with open(os.path.join(DIAG, "lambda_feasibility.json"), encoding="utf-8") as f:
        feas = json.load(f)
    rows = [r for r in feas["rows"] if np.isfinite(r.get("lambda_star", np.nan))]
    ceiling = max(feas["grid"])
    apply_style()
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(6.42, 2.85),
                             gridspec_kw={"width_ratios": [1.65, 1.0], "wspace": 0.28})

    # ---- (a) lambda* per (task, potential), with a shortfall column ----------
    ax = axes[0]
    rows = sorted(rows, key=lambda r: r["lambda_star"])
    labels, vals, fams = [], [], []
    for r in rows:
        labels.append(f"{PRETTY.get(r['env_id'], r['env_id'])} / "
                      f"{POT.get(r.get('potential', ''), r.get('potential', ''))}")
        vals.append(r["lambda_star"] / N_AGENTS[r["env_id"]])
        fams.append(r.get("family", "mpe"))
    vals = np.asarray(vals, dtype=float)
    ypos = np.arange(len(vals))
    x_hi = max(vals) * 14.0

    ax.axvspan(ceiling, x_hi, color=OUTCOME["band"], zorder=0)
    for y, v in zip(ypos, vals):
        if v > ceiling:
            ax.hlines(y, ceiling, v, color=OUTCOME["muted"], lw=1.0, zorder=1)
    seen: set[str] = set()
    for y, v, fam in zip(ypos, vals, fams):
        lab = FAM_LABEL.get(fam, fam) if fam not in seen else None
        seen.add(fam)
        ax.scatter([v], [y], s=24, marker=FAM_MARK.get(fam, "o"),
                   color=FAMILY.get(fam, OUTCOME["neutral"]), zorder=3,
                   label=lab, linewidths=0.0)
    ax.axvline(ceiling, ls="--", lw=1.0, color=OUTCOME["neutral"], zorder=2)
    lab_x = max(vals) * 1.35
    for y, v in zip(ypos, vals):
        txt = (f"${v / ceiling:.1f}\\times$" if v / ceiling < 10 else f"${v / ceiling:.0f}\\times$") \
            if v > ceiling else "feasible"
        ax.annotate(txt, xy=(lab_x, y), fontsize=6.9, color=OUTCOME["neutral"],
                    ha="left", va="center")
    ax.annotate("grid ceiling $=0.4$", xy=(ceiling, -0.75), xytext=(-4, 0),
                textcoords="offset points", fontsize=6.9,
                color=OUTCOME["neutral"], ha="right", va="center")
    ax.set_xscale("log")
    ax.set_yticks(ypos)
    ax.set_yticklabels(labels)
    ax.set_ylim(-1.4, len(vals) - 0.35)
    ax.set_xlim(min(vals) * 0.45, x_hi)
    ax.set_xlabel("per-agent target $\\lambda^\\star/N$ (log scale)", fontsize=7.4)
    ax.set_title("(a)  nine of ten pairs are magnitude-infeasible", loc="left", fontsize=7.6)
    ax.tick_params(labelsize=7.2)
    grid(ax, "x")
    handles, hlabels = ax.get_legend_handles_labels()

    # ---- (b) growth with team size ------------------------------------------
    ax = axes[1]
    path = os.path.join(DIAG, "lambda_scaling.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            sc = json.load(f)
        n = [r["n_agents"] for r in sc["rows"]]
        lam = [r["lambda_star"] / r["n_agents"] for r in sc["rows"]]
        ax.plot(n, lam, "-o", color=FAMILY["mpe"], lw=1.3, label="spread / coverage")
        for x_, y_ in zip(n, lam):
            ax.annotate(f"{y_:.0f}", xy=(x_, y_), xytext=(0, 7),
                        textcoords="offset points", ha="center", fontsize=6.9,
                        color=FAMILY["mpe"])
        ax.axhline(ceiling, ls="--", lw=1.0, color=OUTCOME["neutral"])
        ax.annotate("grid ceiling $=0.4$", xy=(n[-1], ceiling), xytext=(0, 5),
                    textcoords="offset points", fontsize=6.9,
                    color=OUTCOME["neutral"], ha="right")
        ax.set_xticks(n)
        ax.set_yscale("log")
        ax.set_ylim(ceiling * 0.55, max(lam) * 4.5)
        ax.set_xlim(min(n) - 0.6, max(n) + 0.6)
        ax.set_xlabel("number of agents $N$", fontsize=7.4)
        ax.set_ylabel("$\\lambda^\\star/N$ (log scale)", fontsize=7.4)
        ax.set_title("(b)  the per-agent shortfall grows with the team", loc="left", fontsize=7.6)
        ax.tick_params(labelsize=7.2)
        grid(ax, "y")
        ax.legend(loc="upper left")
    else:
        ax.axis("off")
        ax.text(0.5, 0.5, "lambda_scaling.json not found", ha="center")

    fig.subplots_adjust(left=0.20, right=0.985, top=0.90, bottom=0.22)
    fig.legend(handles, hlabels, loc="lower center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, 0.005), handletextpad=0.35, columnspacing=1.6)
    save(fig, "fig_feasibility")


if __name__ == "__main__":
    main()
