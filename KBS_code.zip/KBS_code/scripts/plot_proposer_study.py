"""Figures for the proposer study, generated from the stored summaries.

Two figures, both decision-oriented rather than descriptive:

* ``fig_proposer_arms``      -- deployed held-out gain per arm (LLM / random-valid /
  hand-designed) for every configuration, with bootstrap 95% intervals and a zero line.
  Pool value and arm value are what an operator buys, so they are shown together.
* ``fig_proposer_decision``  -- the *decision* view: paired (LLM - random) and
  (LLM - hand) contrasts with intervals. A contrast whose interval crosses zero means
  "the proposer's contribution is not resolvable at this budget" -- the actionable
  statement, and the one Figure 1 of a decision-support paper should carry.

Every number is recomputed from ``artifacts/llm_proposal/*_summary.json``; nothing is
hard-coded, so the figures update automatically as studies finish.

Run: python scripts/plot_proposer_study.py
"""
from __future__ import annotations

import glob
import json
import os
import re
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figstyle  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

PROJECT_ROOT = figstyle.PROJECT_ROOT
SUMM = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal")
ARMS = ("llm", "rand", "hand")
ARM_LABEL = {"llm": "LLM proposer", "rand": "random valid", "hand": "hand-designed"}


def safe(k: str) -> str:
    return k.replace("::", "_").replace(":", "_")


def boot_ci(x: np.ndarray, n: int = 20000, seed: int = 0) -> tuple[float, float]:
    if x.size == 0:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    m = [float(np.mean(rng.choice(x, x.size, replace=True))) for _ in range(n)]
    return float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def cluster_ci(clusters: list[np.ndarray], level: float = 0.95, n: int = 20000,
               seed: int = 0) -> tuple[float, float]:
    """Draw-level bootstrap: the draw is the independent unit, not the seed."""
    clusters = [c for c in clusters if c.size > 0]
    if not clusters:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    k = len(clusters)
    means = [float(np.concatenate([clusters[i] for i in rng.integers(0, k, k)]).mean())
             for _ in range(n)]
    a = (1.0 - level) / 2.0 * 100.0
    return float(np.percentile(means, a)), float(np.percentile(means, 100.0 - a))


def config_of(tag: str) -> str | None:
    """Human-readable configuration for a tag, or None to exclude it."""
    learner_n = "IPPO N=3"
    if tag.startswith("confv2n5_") or tag.startswith("confn5_"):
        learner_n = "IPPO N=5"
    elif "mappo" in tag:
        learner_n = "MAPPO N=3"
    model = "DeepSeek"
    for key, name in (("gpt_61_sol", "GPT-6.1 Sol"), ("gpt_56_sol", "GPT-5.6 Sol"),
                      ("gpt_6_sol", "GPT-6 Sol"),
                      ("gpt_6_astra", "GPT-6 Astra"), ("gemini_31_pro", "Gemini 3.1 Pro"),
                      ("claude_sonnet_46", "Claude Sonnet 4.6"), ("grok_47", "Grok 4.7"),
                      ("glm", "GLM")):
        if key in tag:
            model = name
            break
    if tag.startswith("confeff_"):
        lvl = re.search(r"_(def|low|high)_r\d+$", tag)
        return f"{learner_n} · {model} · effort {lvl.group(1)}" if lvl else None
    if tag.startswith("confv3bgpt"):
        return f"{learner_n} · GPT-6 Astra · fresh indep."
    if tag.startswith("confv3b"):
        return f"{learner_n} · DeepSeek · fresh indep."
    if tag.startswith("confv3gpt"):
        return f"{learner_n} · GPT-6 Astra · fresh training"
    if tag.startswith("confv3"):
        return f"{learner_n} · DeepSeek · fresh training"
    if tag.startswith("confpush_"):
        raw = "raw" in tag
        if "gpt_6_astra" in tag:
            m = "GPT-6 Astra"
        elif "grok_47" in tag:
            m = "Grok 4.7"
        else:
            m = "DeepSeek"
        return f"push N=2 · {m} · {'raw' if raw else 'grounded'}"
    if tag.startswith("confrepair_"):
        return f"{learner_n} · {model} · repair"
    if tag.startswith("confv2glm"):
        return f"{learner_n} · GLM · grounded"
    if tag.startswith("confglm"):
        return f"{learner_n} · GLM · raw"
    if tag.startswith("confrawk12"):
        return f"{learner_n} · DeepSeek · raw K=12"
    if tag.startswith("confv2k6"):
        return f"{learner_n} · DeepSeek · grounded K=6"
    if tag.startswith("confv2_"):
        return f"{learner_n} · DeepSeek · grounded"
    if re.match(r"^conf_r\d+$", tag):
        return f"{learner_n} · DeepSeek · raw"
    if tag.startswith("confv2") and "_r" in tag:
        return f"{learner_n} · {model} · grounded"
    return None


def short(cfg: str) -> str:
    """Compact two-line axis label: 'IPPO-3 DS' / 'grounded'."""
    parts = cfg.split(" · ")
    learner = parts[0].replace(" N=", "-")
    model = {"DeepSeek": "DS", "Gemini 3.1 Pro": "Gemini", "Claude Sonnet 4.6": "Claude",
             "GPT-6 Astra": "GPT-6", "Grok 4.7": "Grok", "GPT-6.1 Sol": "GPT-6.1",
             "GPT-6 Sol": "GPT-6s", "GPT-5.6 Sol": "GPT-5.6"}.get(parts[1], parts[1]) if len(parts) > 1 else ""
    kind = parts[2].replace("grounded", "grnd").replace("effort ", "eff ") if len(parts) > 2 else ""
    return f"{learner} {model}\n{kind}".strip()


def short1(cfg: str) -> str:
    """Single-line ultra-compact label for the wide arms figure (many groups)."""
    parts = cfg.split(" · ")
    learner = parts[0].replace("IPPO", "I").replace("MAPPO", "M").replace(" N=", "")
    model = {"DeepSeek": "DS", "Gemini 3.1 Pro": "Gemini", "Claude Sonnet 4.6": "Claude",
             "GPT-6 Astra": "GPT-6", "Grok 4.7": "Grok", "GPT-6.1 Sol": "GPT-6.1",
             "GPT-6 Sol": "GPT-6s", "GPT-5.6 Sol": "GPT-5.6"}.get(parts[1], parts[1]) if len(parts) > 1 else ""
    kind = parts[2].replace("grounded", "gnd").replace("effort ", "eff ") if len(parts) > 2 else ""
    return f"{learner} {model} {kind}".strip()


def cells(d: dict, arm: str) -> np.ndarray:
    dep = d["decisions"].get(arm, {}).get("deployed")
    if not dep:
        return np.empty(0)
    base = d.get("base_final_by_seed", {})
    fin = d.get("finals", {})
    out = []
    for s in map(str, d.get("final_seeds", [])):
        v = fin.get(f"final_{safe(dep['key'])}_s{s}")
        if v is not None and s in base:
            out.append(float(v) - float(base[s]))
    return np.asarray(out, dtype=float)


def load() -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {}
    for p in sorted(glob.glob(os.path.join(SUMM, "conf*_summary.json"))):
        tag = os.path.basename(p).replace("_summary.json", "")
        cfg = config_of(tag)
        if cfg is None:
            continue
        with open(p, encoding="utf-8") as f:
            groups.setdefault(cfg, []).append(json.load(f))
    return groups


def pooled(groups: dict[str, list[dict]], arm: str) -> dict[str, tuple]:
    res = {}
    for cfg, ds in groups.items():
        clusters = [cells(d, arm) for d in ds]
        clusters = [c for c in clusters if c.size > 0]
        x = np.concatenate(clusters) if clusters else np.empty(0)
        if x.size == 0:
            continue
        lo, hi = cluster_ci(clusters)
        res[cfg] = (float(x.mean()), lo, hi, int(x.size))
    return res


def paired(groups: dict[str, list[dict]], a: str, b: str) -> dict[str, tuple]:
    res = {}
    for cfg, ds in groups.items():
        clusters = []
        for d in ds:
            seeds = list(map(str, d.get("final_seeds", [])))
            base = d.get("base_final_by_seed", {})
            fin = d.get("finals", {})
            dep_a = d["decisions"].get(a, {}).get("deployed")
            dep_b = d["decisions"].get(b, {}).get("deployed")
            if not dep_a or not dep_b:
                continue
            diffs = []
            for s in seeds:
                va = fin.get(f"final_{safe(dep_a['key'])}_s{s}")
                vb = fin.get(f"final_{safe(dep_b['key'])}_s{s}")
                if va is not None and vb is not None and s in base:
                    diffs.append(float(va) - float(vb))
            if diffs:
                clusters.append(np.asarray(diffs, dtype=float))
        if not clusters:
            continue
        x = np.concatenate(clusters)
        lo, hi = cluster_ci(clusters)
        res[cfg] = (float(x.mean()), lo, hi, int(x.size))
    return res


MAIN_ORDER = [
    "IPPO N=3 · DeepSeek · grounded",
    "IPPO N=3 · GPT-6 Astra · grounded",
    "IPPO N=3 · Grok 4.7 · grounded",
    "IPPO N=3 · GPT-6 Sol · grounded",
    "IPPO N=3 · GPT-5.6 Sol · grounded",
    "IPPO N=3 · GPT-6.1 Sol · grounded",
    "IPPO N=3 · Gemini 3.1 Pro · grounded",
    "IPPO N=3 · GLM · grounded",
    "IPPO N=5 · DeepSeek · grounded",
    "MAPPO N=3 · DeepSeek · grounded",
]


def row_label(cfg: str, ndraw: int) -> str:
    parts = cfg.split(" · ")
    learner = parts[0].replace(" N=", "-")
    model = {"GPT-6 Astra": "GPT-6 Astra", "Grok 4.7": "Grok 4.7",
             "GPT-5.6 Sol": "GPT-5.6 Sol", "GPT-6 Sol": "GPT-6 Sol",
             "GPT-6.1 Sol": "GPT-6.1 Sol", "Gemini 3.1 Pro": "Gemini 3.1 Pro",
             "DeepSeek": "DeepSeek", "GLM": "GLM"}.get(parts[1], parts[1])
    return f"{learner}  {model}  ({ndraw} draws)"


def fig_arms(groups: dict[str, list[dict]], order: list[str] | None = None,
             name: str = "fig_proposer_arms", width: float = 6.5) -> None:
    """Point-and-interval view: one row per configuration, one marker per arm.

    The main-text version plots only the load-bearing proposer sweep (``order`` =
    MAIN_ORDER): the six preprint families that were complete when the scan closed, the
    three rungs of the within-family GPT generation ladder, and the two external
    configurations (N=5, MAPPO). The shaded band behind each row is the hand design's
    pre-stated +/-20 equivalence margin. The full matrix, including the effort, repair,
    ablation and budget controls, is rendered by the same function with ``order=None``
    and is placed in the appendix.
    """
    figstyle.apply_style()
    st = {a: pooled(groups, a) for a in ARMS}
    if order is None:
        cfgs = [c for c in groups if all(any(cells(d, a).size for d in groups[c]) for a in ARMS)]
        cfgs = sorted(cfgs, key=lambda c: st["hand"].get(c, (0,))[0])
    else:
        cfgs = [c for c in order
                if c in groups and all(any(cells(d, a).size for d in groups[c]) for a in ARMS)]
    if not cfgs:
        print("no complete configurations yet")
        return
    n_rows = len(cfgs)
    main = order is not None

    fig, ax = plt.subplots(figsize=(width, 0.34 * n_rows + (1.35 if main else 1.15)))
    marks = {"llm": ("o", figstyle.FAMILY["mpe"], "LLM proposer"),
             "rand": ("^", figstyle.OUTCOME["muted"], "random valid"),
             "hand": ("s", figstyle.FAMILY["sisl"], "hand-designed")}
    offs = {"hand": 0.24, "llm": 0.0, "rand": -0.24}
    fs_tick = 8.0 if main else 6.2
    ms = 4.2 if main else 3.5

    y = np.arange(n_rows)[::-1].astype(float)
    xs: list[float] = []
    for i, c in enumerate(cfgs):
        if c in st["hand"]:
            hm = st["hand"][c][0]
            ax.fill_betweenx([y[i] - 0.45, y[i] + 0.45], hm - 20, hm + 20,
                             color=figstyle.OUTCOME["band"], zorder=0, lw=0)
            xs += [hm - 20, hm + 20]
        for a in ARMS:
            if c not in st[a]:
                continue
            m, lo, hi, _ = st[a][c]
            mk, col, lab = marks[a]
            if np.isfinite(lo) and np.isfinite(hi):
                ax.plot([lo, hi], [y[i] + offs[a]] * 2, color=col, lw=1.0, alpha=0.75, zorder=2)
                xs += [lo, hi]
            ax.plot([m], [y[i] + offs[a]], marker=mk, ms=ms, color=col, mec="white", mew=0.5,
                    zorder=3, label=(lab if i == 0 else None))

    for val in (48.2, 61.2):
        ax.axvline(val, color=figstyle.OUTCOME["muted"], lw=0.8, ls=(0, (4, 3)), zorder=1)
        xs.append(val)

    ax.axvline(0, color=figstyle.OUTCOME["neutral"], lw=0.9, zorder=1)
    if xs:
        ax.set_xlim(min(xs) - 4, max(xs) + 4)
    ax.set_yticks(y)
    ax.set_yticklabels([row_label(c, len(groups[c])) if main else f"{short1(c)}  (n={len(groups[c])})"
                        for c in cfgs], fontsize=fs_tick)
    ax.set_ylim(-0.90, n_rows + 0.05)
    ax.set_xlabel("deployed gain vs unshaped baseline (draw-level 95% intervals)"
                  + ("; shaded band = hand design $\\pm20$ margin" if main else ""), fontsize=8.0)
    figstyle.grid(ax, "x")
    if main:
        ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.01), ncol=3, fontsize=7.5,
                  borderaxespad=0.0, handlelength=1.3, columnspacing=1.2)
    else:
        figstyle.legend_outside(ax, ncol=3, y=-0.10)
    figstyle.save(fig, name)


def fig_decision(groups: dict[str, list[dict]], order: list[str] | None = None,
                 name: str = "fig_proposer_decision", width: float = 3.45) -> None:
    figstyle.apply_style()
    pr = paired(groups, "llm", "rand")
    ph = paired(groups, "llm", "hand")
    if order is None:
        cfgs = sorted(set(pr) & set(ph))
    else:
        cfgs = [c for c in order if c in pr and c in ph]
    if not cfgs:
        print("no paired contrasts yet")
        return
    n_rows = len(cfgs)
    fig, ax = plt.subplots(figsize=(width, 0.30 * n_rows + 0.95))
    ax.axvspan(-20, 20, color=figstyle.OUTCOME["band"], zorder=0, lw=0)
    y = np.arange(n_rows)[::-1]
    for off, st, mk, col, lab in ((0.16, pr, "o", figstyle.FAMILY["mpe"], "vs random valid"),
                                  (-0.16, ph, "s", figstyle.FAMILY["sisl"], "vs hand-designed")):
        m = np.array([st[c][0] for c in cfgs])
        lo = np.array([st[c][1] for c in cfgs])
        hi = np.array([st[c][2] for c in cfgs])
        ax.errorbar(m, y + off, xerr=[m - lo, hi - m], fmt=mk, ms=3.4, color=col,
                    elinewidth=0.9, capsize=2.0, label=lab, zorder=4)
    ax.axvline(0, color=figstyle.OUTCOME["neutral"], lw=0.9, zorder=2)
    ax.set_yticks(y)
    if order is not None:
        short_model = {"GPT-6 Astra": "GPT-6 Astra", "GPT-5.6 Sol": "GPT-5.6 Sol",
                       "GPT-6 Sol": "GPT-6 Sol", "GPT-6.1 Sol": "GPT-6.1 Sol",
                       "Gemini 3.1 Pro": "Gemini", "Grok 4.7": "Grok 4.7",
                       "DeepSeek": "DeepSeek", "GLM": "GLM"}
        labels = []
        for c in cfgs:
            learner = "IPPO-5" if c.startswith("IPPO N=5") else ("MAPPO" if c.startswith("MAPPO") else "")
            model = short_model.get(c.split(" · ")[1], c.split(" · ")[1])
            labels.append(f"{learner} {model}".strip() if learner else model)
        fs = 7.5
    else:
        labels = [short(c).replace("\n", " ") for c in cfgs]
        fs = 5.5
    ax.set_yticklabels(labels, fontsize=fs)
    ax.set_xlabel("paired difference in deployed gain (shaded: $\\pm20$ bound)", fontsize=7.5)
    ax.set_ylim(-0.7, n_rows - 0.3)
    figstyle.grid(ax, "x")
    ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.01), ncol=2, fontsize=7.0,
              borderaxespad=0.0, handlelength=1.3, columnspacing=1.2)
    figstyle.save(fig, name)


def block_groups() -> dict[str, list[dict]]:
    """The three pre-registered blocks behind the headline, per capable family.

    E1 = the ten-draw confirmation; confirm-v3 = the shared-seed-block fresh re-run;
    confirm-v3b = the per-draw independent training blocks. Compared side by side so the
    reader can see which block resolves which contrast (reviewer item).
    """
    def by_tags(tags: list[str]) -> list[dict]:
        out = []
        for t in tags:
            p = os.path.join(SUMM, f"{t}_summary.json")
            if os.path.exists(p):
                with open(p, encoding="utf-8") as fh:
                    out.append(json.load(fh))
        return out

    g = {
        "DeepSeek\nE1 ($10$ draws)": by_tags([f"confv2_r{i}" for i in range(10)]),
        "DeepSeek\nconfirm-v3 ($5$)": by_tags([f"confv3_r{i}" for i in range(5)]),
        "DeepSeek\nconfirm-v3b ($5$)": by_tags([f"confv3b_r{i}" for i in range(5)]),
        "GPT-6 Astra\nE1 ($10$ draws)": by_tags([f"confv2gpt_6_astra_r{i}" for i in range(10)]),
        "GPT-6 Astra\nconfirm-v3 ($5$)": by_tags([f"confv3gpt_r{i}" for i in range(5)]),
        "GPT-6 Astra\nconfirm-v3b ($5$)": by_tags([f"confv3bgpt_r{i}" for i in range(5)]),
    }
    return {k: v for k, v in g.items() if v}


def fig_estimand() -> None:
    """The three blocks side by side: levels on the left, paired contrasts on the right.

    Rendered at the embedding width so the printed type matches the rendered type.
    """
    figstyle.apply_style()
    g = block_groups()
    st = {a: pooled(g, a) for a in ARMS}
    pr = paired(g, "llm", "rand")
    ph = paired(g, "llm", "hand")
    cfgs = [c for c in g if c in st["llm"] and c in pr and c in ph]
    n_rows = len(cfgs)

    fig, (axl, axr) = plt.subplots(
        1, 2, figsize=(6.42, 0.42 * n_rows + 1.05),
        gridspec_kw={"width_ratios": [1.30, 1.00]})
    y = np.arange(n_rows)[::-1].astype(float)
    marks = {"llm": ("o", figstyle.FAMILY["mpe"], "LLM (grounded)"),
             "rand": ("^", figstyle.OUTCOME["muted"], "random valid"),
             "hand": ("s", figstyle.FAMILY["sisl"], "hand-designed")}
    offs = {"hand": 0.20, "llm": 0.0, "rand": -0.20}

    for i, c in enumerate(cfgs):
        if c in st["hand"]:
            hm = st["hand"][c][0]
            axl.fill_betweenx([y[i] - 0.40, y[i] + 0.40], hm - 20, hm + 20,
                              color=figstyle.OUTCOME["band"], zorder=0, lw=0)
        for a in ARMS:
            if c not in st[a]:
                continue
            m, lo, hi, _ = st[a][c]
            mk, col, lab = marks[a]
            if np.isfinite(lo) and np.isfinite(hi):
                axl.plot([lo, hi], [y[i] + offs[a]] * 2, color=col, lw=1.0, alpha=0.8, zorder=2)
            axl.plot([m], [y[i] + offs[a]], marker=mk, ms=4.0, color=col, mec="white",
                     mew=0.5, zorder=3, label=(lab if i == 0 else None))
    axl.axvline(0, color=figstyle.OUTCOME["neutral"], lw=0.9, zorder=1)
    axl.set_yticks(y)
    axl.set_yticklabels(cfgs, fontsize=7.2, linespacing=1.15)
    axl.set_ylim(-0.75, n_rows - 0.25)
    axl.set_xlabel("deployed gain vs unshaped baseline", fontsize=7.4)
    figstyle.grid(axl, "x")
    axl.legend(loc="lower left", bbox_to_anchor=(0.0, 1.01), ncol=3, fontsize=7.0,
               borderaxespad=0.0, handlelength=1.2, columnspacing=1.0)

    axr.axvspan(-20, 20, color=figstyle.OUTCOME["band"], zorder=0, lw=0)
    for off, st2, mk, col, lab in ((0.16, pr, "o", figstyle.FAMILY["mpe"], "vs random valid"),
                                   (-0.16, ph, "s", figstyle.FAMILY["sisl"], "vs hand-designed")):
        m = np.array([st2[c][0] for c in cfgs])
        lo = np.array([st2[c][1] for c in cfgs])
        hi = np.array([st2[c][2] for c in cfgs])
        axr.errorbar(m, y + off, xerr=[m - lo, hi - m], fmt=mk, ms=3.6, color=col,
                     elinewidth=0.9, capsize=2.0, label=lab, zorder=4)
    axr.axvline(0, color=figstyle.OUTCOME["neutral"], lw=0.9, zorder=2)
    axr.set_yticks(y)
    axr.set_yticklabels([])
    axr.set_ylim(-0.75, n_rows - 0.25)
    axr.set_xlabel("paired difference (shaded: $\\pm20$ bound)", fontsize=7.4)
    figstyle.grid(axr, "x")
    axr.legend(loc="lower left", bbox_to_anchor=(0.0, 1.01), ncol=2, fontsize=7.0,
               borderaxespad=0.0, handlelength=1.2, columnspacing=1.0)

    fig.tight_layout()
    figstyle.save(fig, "fig_proposer_estimand")


def main() -> None:
    groups = load()
    print("configurations:", len(groups))
    for c in sorted(groups):
        print(f"  {c:<42s} draws={len(groups[c])}")
    fig_arms(groups, order=MAIN_ORDER)
    fig_arms(groups, order=None, name="fig_proposer_arms_full", width=7.0)
    fig_decision(groups, order=MAIN_ORDER)
    fig_estimand()


if __name__ == "__main__":
    main()
