"""Build the reproducibility bundle for submission.

Produces, under ``submission/``:

* ``SHA256SUMS.txt``  - sha256 of every included file, sorted by path;
* ``MANIFEST.json``   - counts and sizes by category, plus the bundle's own digest;
* ``pbrs-audit-bundle.zip`` - the code, configs, governance records and *per-run logs*
  needed to recompute every number in the paper.

The per-run logs are included on purpose: the manuscript's central claim is that its
numbers can be recomputed from what was actually executed, so shipping only the analysis
code would undercut it.

What may be shipped is an **allow-list**, not a deny-list. A deny-list silently admits
anything new (a credential file, a scratch script, an internal note) until someone
remembers to ban it; an allow-list ships only the reproducible content named below, so a
credential or an internal working note cannot reach a public submission by accident.
Concretely, the following never enter the bundle: ``.env``/``.env.*`` (provider keys),
caches (``.pytest_cache``, ``__pycache__``, ``*.egg-info``), the archived pre-v3 runs
(``artifacts/archive``, which no shipped script reads), the page-render PNGs under
``audit/_t3_pages`` and ``audit/_t3_bands`` (renders of the shipped ``paper/main.pdf``),
and the Figure-1 design scratch directory. Under ``paper/`` only sources and rendered
outputs are kept (``.tex``, ``.bib``, ``.pdf``, image files); LaTeX build intermediates
and build logs are dropped. Exactly one authoritative typeset PDF (``paper/main.pdf``) is
shipped --- the superseded duplicate ``paper/main_final.pdf`` is excluded so the record
points at a single typeset version. The human-readable branch pilot logs under
``experiments/pilot_logs`` are kept because the governance record cites them as evidence.

Deliberately *not* shipped: the cover letter and the overlap-disclosure draft. Those go
to the editor as separate submission fields; they are not part of the reproducibility
record.
"""
from __future__ import annotations

import hashlib
import json
import os
import zipfile

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "submission")
BUNDLE = os.path.join(OUTDIR, "pbrs-audit-bundle.zip")
SUMS = os.path.join(OUTDIR, "SHA256SUMS.txt")
MANIFEST = os.path.join(OUTDIR, "MANIFEST.json")

# Top-level directories whose whole contents belong in the reproducibility record.
ALLOW_TOP_DIRS = {
    "artifacts",   # per-run logs and summaries (the evidence)
    "scripts",     # analysis and audit code, incl. REPRODUCE entry points
    "src",         # the framework package under audit
    "configs",     # environment specs and experiment configuration
    "paper",       # LaTeX sources, figure PDFs and the final main.pdf
    "workplan",    # pre-registration, claim ledger and decision log (governance)
    "audit",       # audits and provenance
    "theory",      # formal statements, proofs, measurement validity
    "related_work",
    "method",
    "experiments",  # value-of-information record and branch pilot logs
    "reviews",
    "summary",
    "tests",
}

# Top-level files that belong in the record (everything else at the root is scratch).
ALLOW_ROOT_FILES = {
    "REPRODUCE.md",
    "README.md",
    "pyproject.toml",
    "requirements.txt",
}

EXCLUDE_DIRS = {
    "__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".ipynb_checkpoints", ".venv", "venv", ".idea", "submission",
}
EXCLUDE_NAME_SUFFIX = (".egg-info",)
# Superseded duplicates of the authoritative artifacts (matched as a name prefix).
EXCLUDE_NAME_PREFIXES = ("main_final",)
EXCLUDE_NAMES = {
    "pbrs-audit-bundle.zip", "SHA256SUMS.txt", "MANIFEST.json",
    ".env", ".env.local", ".env.example",
}
# Superseded / scratch material that must not ship (relative to PROJECT_ROOT, posix).
# ``artifacts/archive`` holds superseded pre-v3 runs (unread by shipped scripts);
# ``audit/_t3_pages`` and ``audit/_t3_bands`` are page-render PNGs produced by the
# layout-QA helpers -- they are renders of ``paper/main.pdf`` (already shipped) and no
# audit record cites them.
EXCLUDE_PREFIXES = ("artifacts/archive", "artifacts/domain", "audit/_t3_pages", "audit/_t3_bands")
# Under paper/ ship only human-authored sources and rendered outputs; every LaTeX build
# intermediate (aux/log/out/blg/bbl) and ad-hoc build log (*.txt) is dropped.
PAPER_ALLOW_SUFFIX = (".tex", ".bib", ".pdf", ".png", ".jpg", ".jpeg", ".eps", ".svg")

# Fail-stop guard: path substrings that must never appear in a built bundle. This turns
# the packaging policy from a "we remembered to exclude it" into a hard build failure.
FORBIDDEN_PATH_SUBSTRINGS = (
    ".env", "/archive/", "pytest_cache", "__pycache__", ".egg-info",
    "gpt_", "dashboard", "_t3_pages", "_t3_bands", "/fig1/",
    "build0", "build1", "build2", "build3",
    "overlap_disclosure", "cover_letter", "main_final",
    "wargame/", "/secrets/", "llm.env", "artifacts/domain",
)
# Fail-stop guard: content patterns that indicate a leaked credential.
SECRET_CONTENT_PATTERNS = (
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    r"(?m)^[A-Z0-9_]*(?:API_KEY|APIKEY|SECRET|TOKEN|PASSWORD)\s*=\s*[^\s]{8,}\s*$",
)


def category(rel: str) -> str:
    rel = rel.replace(os.sep, "/")
    if rel.startswith("artifacts/") and rel.endswith(".json"):
        return "run_logs"
    if rel.startswith("scripts/") or rel.startswith("src/"):
        return "code"
    if rel.startswith("paper/"):
        return "paper"
    if rel.startswith("workplan/") or rel.startswith("audit/"):
        return "governance"
    if rel.startswith("configs/"):
        return "configs"
    if rel.startswith("theory/"):
        return "theory"
    return "other"


def _prune_dir(child_rel_posix: str) -> bool:
    """True if a directory (relative to PROJECT_ROOT, posix) must not be descended."""
    name = child_rel_posix.rsplit("/", 1)[-1]
    if name in EXCLUDE_DIRS or name.endswith(EXCLUDE_NAME_SUFFIX):
        return True
    for pre in EXCLUDE_PREFIXES:
        if child_rel_posix == pre or child_rel_posix.startswith(pre + "/"):
            return True
    return False


def included(rel: str) -> bool:
    rel_posix = rel.replace(os.sep, "/")
    parts = rel_posix.split("/")
    top = parts[0]
    if len(parts) == 1:
        return top in ALLOW_ROOT_FILES
    if top not in ALLOW_TOP_DIRS:
        return False
    if any(p in EXCLUDE_DIRS for p in parts):
        return False
    name = parts[-1]
    if name in EXCLUDE_NAMES or name.endswith(EXCLUDE_NAME_SUFFIX):
        return False
    if name.startswith(EXCLUDE_NAME_PREFIXES):
        return False
    if rel_posix.startswith("paper/") and not name.endswith(PAPER_ALLOW_SUFFIX):
        return False
    return True


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _scan_secrets(files) -> list[tuple[str, str]]:
    """Return (rel, pattern) for any included file whose content matches a secret pattern."""
    import re

    pats = [(p, re.compile(p)) for p in SECRET_CONTENT_PATTERNS]
    hits: list[tuple[str, str]] = []
    for rel, _, _ in files:
        path = os.path.join(PROJECT_ROOT, rel)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read(1 << 20)
        except OSError:
            continue
        for pat_src, pat in pats:
            if pat.search(text):
                hits.append((rel.replace(os.sep, "/"), pat_src))
                break
    return hits


def _assert_clean(files) -> None:
    """Refuse to build if a forbidden path or a secret pattern is present (fail-stop)."""
    offenders = sorted({
        rel.replace(os.sep, "/") for rel, _, _ in files
        if any(p in rel.replace(os.sep, "/").lower() for p in FORBIDDEN_PATH_SUBSTRINGS)
    })
    if offenders:
        print("REFUSING TO BUILD: forbidden member path(s):")
        for rel in offenders:
            print("   -", rel)
        raise SystemExit(1)
    leaks = _scan_secrets(files)
    if leaks:
        print("REFUSING TO BUILD: secret-like content found (values not printed):")
        for rel, what in leaks:
            print(f"   - {rel}  [{what}]")
        raise SystemExit(1)


def main() -> None:
    os.makedirs(OUTDIR, exist_ok=True)
    files: list[tuple[str, str, int]] = []  # rel, sha, size
    for root, dirs, names in os.walk(PROJECT_ROOT):
        relroot = os.path.relpath(root, PROJECT_ROOT)
        relroot_posix = "" if relroot == "." else relroot.replace(os.sep, "/")
        if relroot == ".":
            dirs[:] = [d for d in dirs if d in ALLOW_TOP_DIRS]
        else:
            dirs[:] = [d for d in dirs
                       if not _prune_dir(f"{relroot_posix}/{d}")]
        for n in names:
            full = os.path.join(root, n)
            rel = os.path.relpath(full, PROJECT_ROOT)
            if not included(rel):
                continue
            try:
                files.append((rel, sha256(full), os.path.getsize(full)))
            except OSError:
                continue
    files.sort(key=lambda t: t[0])
    _assert_clean(files)

    with open(SUMS, "w", encoding="utf-8", newline="\n") as f:
        for rel, dig, _ in files:
            f.write(f"{dig}  {rel.replace(os.sep, '/')}\n")

    cats: dict[str, dict[str, int]] = {}
    for rel, _, size in files:
        c = cats.setdefault(category(rel), {"files": 0, "bytes": 0})
        c["files"] += 1
        c["bytes"] += size
    total_bytes = sum(c["bytes"] for c in cats.values())

    with zipfile.ZipFile(BUNDLE, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(SUMS, "SHA256SUMS.txt")
        for rel, _, _ in files:
            z.write(os.path.join(PROJECT_ROOT, rel), rel.replace(os.sep, "/"))

    manifest = {
        "project": "Feasibility calibration, evaluation protocol and bounded deployment of PBRS in cooperative MARL",
        "purpose": "reproduce every number, table and figure in the manuscript",
        "entry_points": {
            "integrity_tests": "python scripts/audit_p0.py",
            "claims_audit": "python scripts/verify_claims.py",
            "guide": "REPRODUCE.md",
        },
        "packaging_policy": {
            "mode": "allow-list",
            "included_roots": sorted(ALLOW_TOP_DIRS),
            "included_root_files": sorted(ALLOW_ROOT_FILES),
            "excluded_by_policy": [
                ".env / .env.* (provider credentials)",
                "caches (__pycache__, .pytest_cache, *.egg-info)",
                "artifacts/archive (superseded pre-v3 runs; unread by shipped scripts)",
                "audit/_t3_pages and audit/_t3_bands (page-render PNGs of main.pdf)",
                "Figure-1 design scratch directory (fig1/)",
                "paper/ build intermediates and build logs (sources + the single authoritative paper/main.pdf)",
                "paper/main_final.pdf (superseded duplicate of the authoritative main.pdf)",
                "cover letter and overlap-disclosure drafts (separate submission fields)",
            ],
        },
        "included_files": len(files),
        "uncompressed_bytes": total_bytes,
        "by_category": cats,
        "bundle": os.path.basename(BUNDLE),
        "bundle_sha256": sha256(BUNDLE),
        "provenance_csv": "audit/provenance.csv",
    }
    with open(MANIFEST, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    print(f"files: {len(files)}  uncompressed {total_bytes / 1e6:.1f} MB  "
          f"bundle {os.path.getsize(BUNDLE) / 1e6:.1f} MB")
    for c, v in sorted(cats.items()):
        print(f"  {c:12s} {v['files']:5d} files  {v['bytes'] / 1e6:8.2f} MB")
    print("bundle sha256:", manifest["bundle_sha256"])
    print("wrote", os.path.normpath(BUNDLE))


if __name__ == "__main__":
    main()
