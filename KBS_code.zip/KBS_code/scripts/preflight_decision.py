"""Resolution-aware preflight: a cheap decision rule over whether a shaping search should run.

It answers the paper's decision question --- refuse / calibrate / abstain / deploy --- from
inputs that are either training-free or cheaply estimated:

* ``lambda_star``  : closed-form coefficient for the target dominance (reference rollouts only);
* ``grid``         : the coefficient search space actually available;
* ``rho_target``   : the dominance the study wants the signal to reach;
* ``mean_abs_return`` / ``dispersion`` : the return scale and the dispersion of the comparison
  used to report the effect (episode bootstrap);
* ``learn_lo/learn_hi`` : the paired interval of unshaped-baseline vs a random policy.

This is a **decision rule**, not a new algorithm: on a task where the grid is too small or the
signal is below resolution it declines to search, and otherwise it falls back to the protocol's
simplest selector (rank by the raw-return probe; deploy iff the paired estimate is non-negative).

Usage:
    python scripts/preflight_decision.py --self-test
    python scripts/preflight_decision.py --lambda-star 127.8 --grid 0.025,0.4 \
        --rho-target 0.2 --mean-abs-return 34.9 --dispersion 6.0 --learn-lo 3.0 --learn-hi 9.0
"""
from __future__ import annotations

import argparse
import json
import os


def decision(lambda_star: float, grid: tuple[float, float], rho_target: float,
             mean_abs_return: float, dispersion: float,
             learn_lo: float | None, learn_hi: float | None) -> tuple[str, str]:
    lo, hi = grid
    learnable = (learn_lo is not None and learn_hi is not None and learn_lo > 0)
    covered = lo <= lambda_star <= hi
    resolvable = rho_target * abs(mean_abs_return) >= dispersion

    if not learnable:
        return "REFUSE", ("task not shown learnable (baseline-vs-random interval includes 0): "
                          "a feasibility verdict would be uninterpretable")
    if not covered:
        return "REFUSE_CALIBRATE", (f"lambda*={lambda_star:.4g} is outside the grid "
                                    f"[{lo},{hi}]: the grid cannot reach rho*={rho_target}; "
                                    f"calibrate the coefficient or do not search")
    if not resolvable:
        return "ABSTAIN", (f"injected effect {rho_target*abs(mean_abs_return):.4g} is below the "
                           f"comparison's dispersion {dispersion:.4g}: the effect cannot be resolved")
    return "DEPLOY", ("preconditions hold: search the pool and deploy iff the paired raw-return "
                      "probe estimate is non-negative")


def _self_test() -> None:
    cases = [
        ((0.08, (0.025, 0.4), 0.2, 0.5, 0.2, 0.04, 0.22), "ABSTAIN"),          # kaz: covered but not resolvable
        ((127.8, (0.025, 0.4), 0.2, 34.9, 6.0, 3.0, 9.0), "REFUSE_CALIBRATE"),  # crypto: out of grid
        ((0.3, (0.025, 0.4), 0.2, 40.0, 1.0, 10.0, 30.0), "DEPLOY"),           # in grid, resolvable
        ((0.3, (0.025, 0.4), 0.2, 0.5, 0.9, 0.0, 0.2), "REFUSE"),              # not learnable
    ]
    ok = True
    for args, expect in cases:
        got, why = decision(*args)
        flag = "ok" if got == expect else "MISMATCH"
        ok = ok and got == expect
        print(f"  {flag:9s} expect={expect:17s} got={got:17s} :: {why}")
    print("self-test:", "PASS" if ok else "FAIL")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--lambda-star", type=float)
    ap.add_argument("--grid", default="0.025,0.4")
    ap.add_argument("--rho-target", type=float, default=0.2)
    ap.add_argument("--mean-abs-return", type=float)
    ap.add_argument("--dispersion", type=float, default=0.0)
    ap.add_argument("--learn-lo", type=float, default=None)
    ap.add_argument("--learn-hi", type=float, default=None)
    ap.add_argument("--json-out", default=None)
    args = ap.parse_args()

    if args.self_test:
        _self_test()
        return
    grid = tuple(float(x) for x in args.grid.split(","))
    dec, why = decision(args.lambda_star, grid, args.rho_target, args.mean_abs_return,
                        args.dispersion, args.learn_lo, args.learn_hi)
    out = {"decision": dec, "reason": why, "lambda_star": args.lambda_star, "grid": list(grid),
           "rho_target": args.rho_target, "mean_abs_return": args.mean_abs_return,
           "dispersion": args.dispersion, "learn_interval": [args.learn_lo, args.learn_hi]}
    print(json.dumps(out, indent=2))
    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2)


if __name__ == "__main__":
    main()
