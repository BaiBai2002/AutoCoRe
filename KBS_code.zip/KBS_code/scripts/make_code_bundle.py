"""Build the lean, submission-ready code + environment bundle for the KBS manuscript.

What ships (code layer only, per the author's instruction): the pipeline source, the
experiment/analysis/figure scripts, all configurations (DSL, environment specifications,
provider definitions that reference credentials by environment variable only), the test
suite, and the lightweight transparency artefacts the paper names (the claim ledger,
protocol-deviation table, the three pre-registration protocols and the decision-record
schema). What does NOT ship: per-run records, response caches, probe/final logs, any
``artifacts/`` tree, virtual environments, editor/OS caches, and the manuscript sources --
the data layer is released separately.

Safety: the builder refuses to package ``.env`` (real credentials) and fails hard if any
packaged file matches a secret pattern. A SHA-256 manifest is written into the archive so a
reviewer can tie a file to what was submitted.

Run:  python scripts/make_code_bundle.py            # writes KBS_submission_code.zip
"""
from __future__ import annotations

import hashlib
import os
import re
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "KBS_submission_code.zip")
PREFIX = "KBS_code"

# Directories copied wholesale (code layer).
INCLUDE_DIRS = ("src", "scripts", "configs", "tests")
# Individual files at the repository root that belong in the code layer.
INCLUDE_FILES = ("requirements.txt", "pyproject.toml", ".env.example")
# Lightweight transparency artefacts the manuscript names explicitly; missing ones are
# reported, never silently skipped.
EXTRA = {
    "research_upgrade/kbs_upgrade/CLAIM_LEDGER.tsv": "ledgers/CLAIM_LEDGER.tsv",
    "research_upgrade/kbs_upgrade/PROTOCOL_DEVIATIONS.tsv": "ledgers/PROTOCOL_DEVIATIONS.tsv",
    "research_upgrade/kbs_upgrade/CONFIRM_PROTOCOL.md": "ledgers/CONFIRM_PROTOCOL.md",
    "research_upgrade/kbs_upgrade/CONFIRM_V3_PROTOCOL.md": "ledgers/CONFIRM_V3_PROTOCOL.md",
    "research_upgrade/kbs_upgrade/CONFIRM_V3B_PROTOCOL.md": "ledgers/CONFIRM_V3B_PROTOCOL.md",
    "research_upgrade/kbs_upgrade/decision_record.schema.json": "ledgers/decision_record.schema.json",
}

# Never package these, whatever else matches.
SKIP_DIRS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".git"}
SKIP_SUFFIX = (".pyc", ".pyo", ".egg-info")
SECRET_PATTERNS = (
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"Bearer\s+[A-Za-z0-9._-]{25,}"),
    re.compile(r"(api[_-]?key|apikey)\s*[:=]\s*[\"'][A-Za-z0-9._-]{20,}[\"']", re.I),
)
# The cache-secret guard test necessarily embeds synthetic key-shaped strings
# ("sk-" sequences) to prove the guard detects them; variable names there are
# fake_api_key / fake_key. Verified by inspection: every match is a synthetic value,
# no credential material. The global patterns stay unchanged; only this file is exempt.
SECRET_ALLOWLIST = {"KBS_code/tests/test_llm_cache_no_secrets.py"}


def _skip(path: str, name: str) -> bool:
    if name in SKIP_DIRS:
        return True
    if name.endswith(SKIP_SUFFIX):
        return True
    if name == ".env" or (name.startswith(".env.") and not name.endswith(".example")):
        return True
    return False


def collect() -> list[tuple[str, str]]:
    """Return (source_path, archive_path) pairs for everything that ships."""
    members: list[tuple[str, str]] = []
    for d in INCLUDE_DIRS:
        base = os.path.join(ROOT, d)
        for cur, dirs, files in os.walk(base):
            dirs[:] = [x for x in dirs if not _skip(cur, x)]
            for f in sorted(files):
                if _skip(cur, f):
                    continue
                src = os.path.join(cur, f)
                rel = os.path.relpath(src, ROOT).replace(os.sep, "/")
                members.append((src, f"{PREFIX}/{rel}"))
    for f in INCLUDE_FILES:
        src = os.path.join(ROOT, f)
        if os.path.exists(src):
            members.append((src, f"{PREFIX}/{f}"))
        else:
            print(f"warning: expected file missing, skipped: {f}")
    for src_rel, arc_rel in EXTRA.items():
        src = os.path.join(ROOT, src_rel)
        if os.path.exists(src):
            members.append((src, f"{PREFIX}/{arc_rel}"))
        else:
            print(f"warning: ledger artefact missing, skipped: {src_rel}")
    return members


def scan_secrets(members: list[tuple[str, str]]) -> list[str]:
    hits: list[str] = []
    for src, arc in members:
        if arc in SECRET_ALLOWLIST:
            continue
        try:
            with open(src, encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError:
            continue
        for pat in SECRET_PATTERNS:
            m = pat.search(text)
            if m:
                hits.append(f"{arc}: {pat.pattern}")
                break
    return hits


def hash_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    members = collect()
    hits = scan_secrets(members)
    if hits:
        print("SECRET SCAN FAILED -- refusing to build:")
        for h in hits:
            print("  " + h)
        return 1
    print(f"secret scan clean over {len(members)} files")

    import make_code_bundle_docs as docs  # noqa: E402  (local sibling module)

    docs_written: list[tuple[str, str]] = [
        (f"{PREFIX}/README.md", docs.README),
        (f"{PREFIX}/ENVIRONMENT.md", docs.ENVIRONMENT),
        (f"{PREFIX}/REPRODUCE.md", docs.REPRODUCE),
    ]

    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        manifest_lines: list[str] = []
        for src, arc in members:
            zf.write(src, arc)
            manifest_lines.append(f"{hash_file(src)}  {arc}")
        for arc, text in docs_written:
            zf.writestr(arc, text)
            data = text.encode("utf-8")
            manifest_lines.append(f"{hashlib.sha256(data).hexdigest()}  {arc}")
        zf.writestr(f"{PREFIX}/SHA256SUMS.txt",
                    "\n".join(sorted(manifest_lines)) + "\n")

    size_mb = os.path.getsize(OUT) / (1 << 20)
    print(f"wrote {OUT} ({size_mb:.2f} MB, {len(members) + len(docs_written) + 1} members)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())