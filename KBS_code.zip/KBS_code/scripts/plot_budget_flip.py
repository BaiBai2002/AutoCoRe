"""The budget-flip figure: how much of the reported gain survives budget matching.

Panel (a) plots the held-out learning curves of the unshaped baseline at the
plain training budget and at the budget that includes the pipeline's search
overhead. Panel (b) reports the deployed pipeline's paired gain against three
reference points (no-op, the plain baseline, the budget-matched baseline) with
95% stratified bootstrap intervals, so the reader can see the gain collapse once
the search cost is charged to the baseline.

Every number is derived from the per-run logs already on disk; nothing is
recomputed or simulated here.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
FIGDIR = os.path.join(PROJECT_ROOT, "paper", "figures")


def load_run(full_key: str, seed: int) -> dict | None:
    path = os.path.join(OUTDIR, f"{full_key}_s{seed}.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def curves_of(full_key: str, seeds: list[int]) -> tuple[np.ndarray, np.ndarray]:
    """Mean and standard error of the evaluation curve over seeds."""
    ys = []
    xs = None
    for s in seeds:
        rec = load_run(full_key, s)
        if rec is None:
            continue
        curve = rec.get("curve", [])
        if not curve:
            continue
        x = np.asarray([c[0] for c in curve], dtype=float)
        y = np.asarray([c[1] for c in curve], dtype=float)
        # keep only the runs trained to the full budget of this key
        if xs is None:
            xs = x
        if x.shape == xs.shape:
            ys.append(y)
    if not ys:
        return np.asarray([]), np.asarray([])
    mat = np.vstack(ys)
    return mat.mean(axis=0), mat.std(axis=0, ddof=1) / np.sqrt(mat.shape[0])


def per_seed_values(full_key: str, seeds: list[int]) -> dict[int, float]:
    out = {}
    for s in seeds:
        rec = load_run(full_key, s)
        if rec is not None:
            out[s] = float(rec["final_return"])
    return out


def bootstrap_ci(diffs: np.ndarray, n_boot: int = 20000, alpha: float = 0.05,
                 seed: int = 0) -> tuple[float, float, float]:
    if diffs.size == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, diffs.size, size=(n_boot, diffs.size))
    means = diffs[idx].mean(axis=1)
    lo, hi = np.percentile(means, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(diffs.mean()), float(lo), float(hi)


def prefix(summary: dict, key: str) -> str:
    n = "na" if summary["num_agents"] is None else str(summary["num_agents"])
    return f"{summary['env'].replace('/', '-')}_{summary['algo']}_N{n}_final_{key}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default=os.path.join(OUTDIR, "spread_n3_summary.json"))
    ap.add_argument("--out", default=os.path.join(FIGDIR, "fig_budget_flip"))
    args = ap.parse_args()

    with open(args.summary, encoding="utf-8") as f:
        s = json.load(f)
    seeds = [int(x) for x in s["final_seeds"]]
    base_key = prefix(s, "base")

    bm = s.get("budget_matched_baseline")
    if not bm:
        raise SystemExit("summary has no budget-matched baseline")
    # Prefer the step-specific key; the bare ``base_bm`` name is a legacy alias
    # that may hold a run trained to a *different* budget.
    bm_key = prefix(s, f"base_bm{bm['steps']}")
    if not os.path.exists(os.path.join(OUTDIR, f"{bm_key}_s{seeds[0]}.json")):
        bm_key = prefix(s, "base_bm")

    base_vals = per_seed_values(base_key, seeds)
    bm_vals = per_seed_values(bm_key, seeds)
    shared = sorted(set(base_vals) & set(bm_vals))
    base_mean = float(np.mean([base_vals[x] for x in shared]))
    bm_mean = float(np.mean([bm_vals[x] for x in shared]))
    noop = float(np.mean([rec["noop_return"] for x in shared
                          for rec in [load_run(base_key, x)] if rec]))

    # deployed pipeline: per replicate, per seed
    gate_diffs_base, gate_diffs_bm, gate_diffs_noop = [], [], []
    rep_means = []
    for d in s["decisions"]:
        if not d.get("gate_choice"):
            continue
        key = d["gate_choice"]["key"]
        vals = per_seed_values(prefix(s, key), shared)
        sh = [x for x in shared if x in vals]
        if not sh:
            continue
        rep_means.append(float(np.mean([vals[x] for x in sh])))
        gate_diffs_base.append(np.asarray([vals[x] - base_vals[x] for x in sh]))
        gate_diffs_bm.append(np.asarray([vals[x] - bm_vals[x] for x in sh]))
        gate_diffs_noop.append(np.asarray([vals[x] - noop for x in sh]))

    def flat(list_of_arrays):
        return np.concatenate(list_of_arrays) if list_of_arrays else np.asarray([])

    d_base = flat(gate_diffs_base)
    d_bm = flat(gate_diffs_bm)
    d_noop = flat(gate_diffs_noop)
    deployed_mean = float(np.mean(rep_means)) if rep_means else float("nan")

    print(f"{s['env']} N={s['num_agents']}  seeds={shared}")
    print(f"  no-op reference        {noop:9.2f}")
    print(f"  base @ {s['final_steps']:>7d} steps   {base_mean:9.2f}")
    print(f"  base @ {bm['steps']:>7d} steps   {bm_mean:9.2f}   "
          f"(extra budget moves the baseline by {bm_mean - base_mean:+.2f})")
    print(f"  deployed pipeline      {deployed_mean:9.2f}")
    for label, arr in (("vs no-op", d_noop), ("vs base", d_base), ("vs budget-matched base", d_bm)):
        m, lo, hi = bootstrap_ci(arr)
        print(f"  gain {label:<24s} {m:+9.2f}  95% CI [{lo:+.2f}, {hi:+.2f}]")

    import sys as _sys
    _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from figstyle import FAMILY, OUTCOME, apply_style, save
    apply_style()
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
    ax = axes[0]
    yb, eb = curves_of(base_key, shared)
    ybm, ebm = curves_of(bm_key, shared)
    rec = load_run(base_key, shared[0])
    xb = np.asarray([c[0] for c in rec["curve"]], dtype=float)
    rec_bm = load_run(bm_key, shared[0])
    xbm = np.asarray([c[0] for c in rec_bm["curve"]], dtype=float)
    c_base, c_bm = FAMILY["mpe"], FAMILY["sisl"]
    ax.plot(xb / 1000, yb, "-o", ms=2.6, lw=1.2, color=c_base,
            label=f"unshaped baseline ({s['final_steps'] // 1000}K)")
    ax.fill_between(xb / 1000, yb - eb, yb + eb, color=c_base, alpha=0.18, lw=0)
    ax.plot(xbm / 1000, ybm, "-s", ms=2.6, lw=1.2, color=c_bm,
            label=f"budget-matched baseline ({bm['steps'] // 1000}K)")
    ax.fill_between(xbm / 1000, ybm - ebm, ybm + ebm, color=c_bm, alpha=0.18, lw=0)
    ax.axhline(noop, ls=":", lw=1.0, color=OUTCOME["neutral"])
    ax.annotate("no-op", xy=(xbm[-1] / 1000, noop), xytext=(2, 3),
                textcoords="offset points", fontsize=6.6, color=OUTCOME["neutral"])
    ax.set_xlabel("environment interactions ($\\times 10^3$)")
    ax.set_ylabel("held-out raw return")
    ax.set_title("(a)  extra search budget trains the baseline further", loc="left")
    ax.legend(loc="lower right")

    ax = axes[1]
    labels = ["vs no-op", "vs baseline\n(plain budget)", "vs baseline\n(budget-matched)"]
    vals = [d_noop.mean(), d_base.mean(), d_bm.mean()]
    cis = [bootstrap_ci(d_noop), bootstrap_ci(d_base), bootstrap_ci(d_bm)]
    err = np.asarray([[v - c[1] for v, c in zip(vals, cis)],
                      [c[2] - v for v, c in zip(vals, cis)]])
    colors = ["#7f7f7f", c_base, c_bm]
    ax.bar(range(3), vals, color=colors, width=0.62, alpha=0.9)
    ax.errorbar(range(3), vals, yerr=err, fmt="none", ecolor=OUTCOME["neutral"],
                capsize=3, lw=1.0)
    ax.axhline(0, color=OUTCOME["neutral"], lw=0.8)
    for i, v in enumerate(vals):
        top_i = v + err[1][i]
        ax.annotate(f"{v:+.1f}", xy=(i, top_i), xytext=(0, 3),
                    textcoords="offset points", ha="center", fontsize=6.8)
    ax.set_xticks(range(3))
    ax.set_xticklabels(labels, fontsize=6.2)
    ax.set_ylim(0.0, float(np.max(np.asarray(vals) + err[1])) * 1.16)
    ax.set_ylabel("deployed pipeline gain")
    ax.set_title("(b)  the gain shrinks as the baseline is charged more", loc="left")

    fig.subplots_adjust(left=0.075, right=0.99, top=0.90, bottom=0.16, wspace=0.20)
    save(fig, os.path.basename(args.out))


if __name__ == "__main__":
    main()
