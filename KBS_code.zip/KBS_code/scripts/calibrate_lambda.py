"""Measure the achievable shaping magnitude per (environment, potential).

Prints, for each candidate potential, the discounted return scale E|R|, the
unit shaping scale E|dPhi|, the analytic coefficient lambda* that realises a
target dominance, and the dominance interval that a pre-specified coefficient
grid can actually reach. The last two columns decide whether a pipeline that
searches over that grid can influence learning at all.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.dsl.compiler import compile_dsl
from autocore.selection.magnitude_calibration import (
    estimate_scales, legacy_grid,
)
from autocore.shaping.potentials import PotentialFunction, ShapingConfig

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

CANDIDATES = [
    (env_id, dsl)
    for env_id in ("simple_spread_v3", "simple_reference_v3",
                   "simple_push_v3", "simple_speaker_listener_v4")
    for dsl in ("spread_coverage.json", "spread_assignment.json")
]

PZ_CANDIDATES = ["pursuit_v5", "knights_archers_zombies_v11"]
# Horizon per PettingZoo environment. pursuit_v5 runs to 100 steps; the butterfly
# environment is given the same 100-step setting so the two are comparable as
# *settings* (this is a feasibility measurement, not a performance comparison).
PZ_CYCLES = {"pursuit_v5": 100, "knights_archers_zombies_v11": 100}


def load_potential(name: str, gamma: float):
    with open(os.path.join(PROJECT_ROOT, "configs", "dsl", name), encoding="utf-8") as f:
        dsl = json.load(f)
    compiled = compile_dsl(dsl)
    pf = PotentialFunction(compiled, ShapingConfig(gamma=gamma, shaping_lambda=1.0,
                                                   potential_clip=(-1.0, 1.0)))
    return pf.compute_potential, compiled.meta.get("weights")


def load_pz_potential(env_id: str, max_cycles: int, seed: int):
    """A fixed unit-norm direction over the generic observation-feature bank.

    The second family has no MPE-style world, so the potential is defined on
    joint-observation statistics. The direction is drawn once from a fixed
    stream so the calibration table is reproducible.
    """
    from autocore.selection.landscape_search import LinearPotential
    from autocore.selection.obs_features import build_obs_bank
    bank = build_obs_bank(env_id, max_cycles=max_cycles, n_episodes=6, seed=seed)
    rng = np.random.default_rng(seed)
    w = rng.normal(size=bank.dim)
    pot = LinearPotential(bank, list(w))
    return pot, bank.dim


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rho-target", type=float, default=0.20)
    ap.add_argument("--gamma", type=float, default=0.99)
    ap.add_argument("--eps-episodes", type=int, default=40)
    ap.add_argument("--families", default="mpe pz")
    ap.add_argument("--pz-max-cycles", type=int, default=None,
                    help="override the per-family horizon for all PettingZoo candidates; "
                         "by default each environment uses its PZ_CYCLES entry")
    ap.add_argument("--pz-seed", type=int, default=0)
    ap.add_argument("--n-sweep", default="3,5,7")
    ap.add_argument("--n-sweep-dsl", default="spread_coverage.json")
    ap.add_argument("--n-sweep-env", default="simple_spread_v3")
    args = ap.parse_args()

    families = set(args.families.split())
    grid = legacy_grid()
    rows = []
    print(f"target dominance rho* = {args.rho_target}   legacy grid = {grid}")
    print(f"{'env':<24s} {'potential':<20s} {'E|R|':>9s} {'E|dPhi|':>9s} "
          f"{'ratio':>8s} {'lambda*':>10s} {'rho range on grid':>24s} {'feasible':>9s}")
    if "mpe" in families:
        for env_id, dsl_name in CANDIDATES:
            fn, _ = load_potential(dsl_name, args.gamma)
            est = estimate_scales(env_id, fn, gamma=args.gamma, n_episodes=args.eps_episodes)
            lam_star = est.required_lambda(args.rho_target)
            rho_lo, rho_hi = est.attainable_dominance(grid)
            feas = est.feasible(grid, args.rho_target)
            rows.append({**est.to_dict(), "family": "mpe", "potential": dsl_name,
                         "rho_target": args.rho_target, "lambda_star": lam_star,
                         "rho_lo_on_grid": rho_lo, "rho_hi_on_grid": rho_hi,
                         "feasible": feas})
            print(f"{env_id:<24s} {dsl_name:<20s} {est.mean_abs_return:9.2f} "
                  f"{est.mean_abs_delta_phi:9.4f} {est.scale_ratio:8.5f} {lam_star:10.1f} "
                  f"[{rho_lo:.2e}, {rho_hi:.2e}]{'':>6s} {str(feas):>9s}")
    if "pz" in families:
        for env_id in PZ_CANDIDATES:
            cycles = (args.pz_max_cycles if args.pz_max_cycles is not None
                      else PZ_CYCLES.get(env_id, 100))
            pot, _ = load_pz_potential(env_id, cycles, args.pz_seed)
            est = estimate_scales(env_id, pot, gamma=args.gamma,
                                  max_cycles=cycles,
                                  n_episodes=args.eps_episodes, seed=args.pz_seed)
            lam_star = est.required_lambda(args.rho_target)
            rho_lo, rho_hi = est.attainable_dominance(grid)
            feas = est.feasible(grid, args.rho_target)
            rows.append({**est.to_dict(),
                         "family": "sisl" if env_id == "pursuit_v5" else "butterfly",
                         "potential": "obs_features", "rho_target": args.rho_target,
                         "lambda_star": lam_star,
                         "rho_lo_on_grid": rho_lo, "rho_hi_on_grid": rho_hi,
                         "feasible": feas})
            print(f"{env_id:<28s} {'obs_features':<20s} {est.mean_abs_return:9.2f} "
                  f"{est.mean_abs_delta_phi:9.4f} {est.scale_ratio:8.5f} {lam_star:10.1f} "
                  f"[{rho_lo:.2e}, {rho_hi:.2e}]{'':>6s} {str(feas):>9s}")

    n_rows = []
    if args.n_sweep:
        fn, _ = load_potential(args.n_sweep_dsl, args.gamma)
        print(f"\nN-sweep on {args.n_sweep_env} with {args.n_sweep_dsl}:")
        for n_agents in [int(x) for x in args.n_sweep.split(",")]:
            est = estimate_scales(args.n_sweep_env, fn, gamma=args.gamma,
                                  n_episodes=args.eps_episodes, num_agents=n_agents)
            lam = est.required_lambda(args.rho_target)
            n_rows.append({"n_agents": n_agents, "mean_abs_return": est.mean_abs_return,
                           "mean_abs_delta_phi": est.mean_abs_delta_phi,
                           "lambda_star": lam, "shortfall_vs_grid": lam / max(grid)})
            print(f"  N={n_agents}: E|R|={est.mean_abs_return:8.1f} "
                  f"E|dPhi|={est.mean_abs_delta_phi:.4f} lambda*={lam:7.1f} "
                  f"({lam / max(grid):.0f}x grid ceiling)")
        out_n = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "lambda_scaling.json")
        with open(out_n, "w", encoding="utf-8") as f:
            json.dump({"env": args.n_sweep_env, "potential": args.n_sweep_dsl,
                       "rho_target": args.rho_target, "grid_ceiling": max(grid),
                       "rows": n_rows}, f, indent=2)
        print("wrote", os.path.normpath(out_n))

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "lambda_feasibility.json")
    if not rows:
        print("\n(no feasibility rows requested; keeping existing file)")
        return
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"grid": grid, "rho_target": args.rho_target, "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
