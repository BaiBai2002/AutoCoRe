"""G0 audit: source, artefacts, claim classification, integrity.

Answers, mechanically and from the repository alone:

* does every claim in the ledger have (a) its named artefact on disk and (b) its named analysis
  script? Claims lacking either are classified TEXT_ONLY / NOT_AVAILABLE rather than trusted;
* is the shipped PDF byte-identical to the working-tree PDF (a copy that drifted would mean the
  bundle and the paper disagree);
* does the bundle contain any forbidden member (secrets, caches, superseded PDFs)?

Writes ``audit/G0_artifact_inventory.json`` and prints a summary. Exit code is non-zero if any
claim is NOT_AVAILABLE or the PDF hashes disagree.
"""
from __future__ import annotations

import csv
import glob
import hashlib
import json
import os
import re
import sys
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
LEDGER = os.path.join(ROOT, "workplan", "claim_ledger.csv")
SUMS = os.path.join(ROOT, "submission", "SHA256SUMS.txt")
BUNDLE = os.path.join(ROOT, "submission", "pbrs-audit-bundle.zip")
OUT = os.path.join(ROOT, "audit", "G0_artifact_inventory.json")


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def resolve(pattern: str) -> list[str]:
    """A ledger entry may be a path or a glob; return whatever exists."""
    p = os.path.join(ROOT, pattern.strip().replace("/", os.sep))
    return glob.glob(p) if any(c in pattern for c in "*?[") else ([p] if os.path.exists(p) else [])


def main() -> int:
    rows = list(csv.DictReader(open(LEDGER, encoding="utf-8")))
    claims = []
    for r in rows:
        arts = [a.strip() for a in r["artifacts"].split(";") if a.strip()]
        scripts = [s.strip() for s in r["analysis_script"].split(";") if s.strip()]
        have_arts = [a for a in arts if resolve(a)]
        have_scripts = [s for s in scripts if resolve(s)]
        if r["status"] == "blocked":
            verdict = "BLOCKED_AS_DECLARED"
        elif arts and not have_arts:
            verdict = "NOT_AVAILABLE"
        elif not arts:
            verdict = "TEXT_ONLY"
        elif scripts and not have_scripts:
            verdict = "TEXT_ONLY"
        else:
            verdict = "REPRODUCED_BY_SCRIPT"
        claims.append({"claim_id": r["claim_id"], "evidence_level": r["evidence_level"],
                       "status": r["status"], "verdict": verdict,
                       "artifacts_present": have_arts, "script_present": bool(have_scripts)})

    # working-tree vs shipped PDF
    working = os.path.join(ROOT, "paper", "main.pdf")
    w_hash = sha256(working) if os.path.exists(working) else None
    shipped = None
    sums = open(SUMS, encoding="utf-8").read() if os.path.exists(SUMS) else ""
    m = re.search(r"([0-9a-f]{64})\s+paper/main\.pdf", sums)
    if m:
        shipped = m.group(1)

    bundle_members, forbidden = [], []
    if os.path.exists(BUNDLE):
        with zipfile.ZipFile(BUNDLE) as z:
            bundle_members = z.namelist()
            bad = z.testzip()
            forbidden = [n for n in bundle_members
                         if n.endswith(".env") or ".pytest_cache" in n or "artifacts/archive" in n
                         or "main_final" in n or n.startswith("workplan/AI_")]

    out = {
        "claims_total": len(claims),
        "claim_verdicts": {v: sum(1 for c in claims if c["verdict"] == v)
                           for v in sorted({c["verdict"] for c in claims})},
        "claims": claims,
        "working_main_pdf_sha256": w_hash,
        "shipped_main_pdf_sha256": shipped,
        "pdf_hash_match": (w_hash == shipped) if (w_hash and shipped) else None,
        "bundle_members": len(bundle_members),
        "bundle_testzip": None,
        "forbidden_members": forbidden,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(out, open(OUT, "w", encoding="utf-8"), indent=2)

    print(f"claims: {out['claims_total']}  verdicts: {out['claim_verdicts']}")
    print(f"working main.pdf sha256 = {w_hash}")
    print(f"shipped main.pdf sha256 = {shipped}   match={out['pdf_hash_match']}")
    print(f"bundle members = {len(bundle_members)}  forbidden = {len(forbidden)}")
    bad = [c for c in claims if c["verdict"] in ("NOT_AVAILABLE", "TEXT_ONLY")]
    if bad:
        print("claims lacking full artefact+script support:")
        for c in bad:
            print(f"   - {c['claim_id']} [{c['evidence_level']}] -> {c['verdict']}")
    if out["pdf_hash_match"] is False:
        print("FAIL: working and shipped PDFs differ")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
