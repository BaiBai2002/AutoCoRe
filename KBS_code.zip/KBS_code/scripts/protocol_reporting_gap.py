"""The reporting gap: shaped return is a manipulable score, raw return is not.

Policy-based reward shaping adds a telescoping term to the return. For a fixed
policy evaluated on fixed seeds, the per-episode telescoping total is an exact
constant ``gamma^H * Phi(s_H) - Phi(s_0)`` that does not depend on the policy's
quality. The shaped return is therefore

    R_shaped(lambda) = R_raw + lambda * (gamma^H * Phi(s_H) - Phi(s_0)),

so the *reported* number can be moved arbitrarily by the coefficient while the
task performance is untouched. This script makes that concrete: it evaluates one
fixed reference policy at several coefficients and reports both quantities. A
pipeline that ranks arms by shaped return is ranking them by their coefficient,
not by their policies.

Runs on both benchmark families (MPE and PettingZoo SISL) to show the trap is
not specific to one environment family.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

MPE_TASKS = {
    "simple_spread_v3": "spread_coverage.json",
    "simple_push_v3": "spread_assignment.json",
}
PZ_TASKS = ["pursuit_v5"]


def mpe_potential(env_id: str, dsl_name: str, gamma: float):
    from autocore.dsl.compiler import compile_dsl
    from autocore.shaping.potentials import PotentialFunction, ShapingConfig
    with open(os.path.join(PROJECT_ROOT, "configs", "dsl", dsl_name), encoding="utf-8") as f:
        dsl = json.load(f)
    compiled = compile_dsl(dsl)
    pf = PotentialFunction(compiled, ShapingConfig(gamma=gamma, shaping_lambda=1.0,
                                                   potential_clip=(-1.0, 1.0)))
    return pf.compute_potential


def pz_potential(env_id: str, max_cycles: int, seed: int):
    from autocore.selection.landscape_search import LinearPotential
    from autocore.selection.obs_features import build_obs_bank
    bank = build_obs_bank(env_id, max_cycles=max_cycles, n_episodes=6, seed=seed)
    rng = np.random.default_rng(seed)
    return LinearPotential(bank, list(rng.normal(size=bank.dim)))


def random_policy(n_agents: int, act_dims: np.ndarray, seed: int):
    rng = np.random.default_rng(seed)

    def act_fn(_obs: np.ndarray) -> np.ndarray:
        return rng.integers(0, act_dims)[None, :].astype(np.float32)

    return act_fn


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gamma", type=float, default=0.99)
    ap.add_argument("--eval-episodes", type=int, default=20)
    ap.add_argument("--grid", default="0.025,0.05,0.1,0.2,0.4,1,5,25,100")
    args = ap.parse_args()

    grid = [float(x) for x in args.grid.split(",")]
    eval_seeds = [10_000 + 137 * i for i in range(args.eval_episodes)]
    rows = []

    for env_id, dsl_name in MPE_TASKS.items():
        from autocore.algos.vec_mpe import MpeEvaluator
        max_cycles = 80
        pot = mpe_potential(env_id, dsl_name, args.gamma)
        print(f"\n=== {env_id} (MPE, potential={dsl_name}) ===")
        print(f"{'lambda':>8s} {'raw return':>14s} {'shaped return':>16s} "
              f"{'reported gain':>14s}")
        ref = None
        for lam in [0.0] + grid:
            ev = MpeEvaluator(env_id, max_cycles=max_cycles, potential_fn=pot,
                              shaping_lambda=lam, gamma=args.gamma, reward_scale=1.0)
            act = random_policy(len(ev.agent_names), np.asarray(ev.act_dims), 20240101)
            res = ev.run(act, eval_seeds)
            if ref is None:
                ref = res["mean_raw_return"]
            print(f"{lam:>8.3f} {res['mean_raw_return']:>14.2f} "
                  f"{res['mean_shaped_return']:>16.2f} "
                  f"{res['mean_shaped_return'] - ref:>+14.2f}")
            rows.append({"env": env_id, "family": "mpe", "lambda": lam,
                         "raw_return": res["mean_raw_return"],
                         "shaped_return": res["mean_shaped_return"],
                         "reported_gain_vs_lambda0": res["mean_shaped_return"] - ref})
            ev.close()

    for env_id in PZ_TASKS:
        from autocore.envs.vec_pz import PzEvaluator
        max_cycles = 100
        pot = pz_potential(env_id, max_cycles, 0)
        print(f"\n=== {env_id} (PettingZoo SISL, potential=obs-features) ===")
        print(f"{'lambda':>8s} {'raw return':>14s} {'shaped return':>16s} "
              f"{'reported gain':>14s}")
        ref = None
        for lam in [0.0] + grid:
            ev = PzEvaluator(env_id, max_cycles=max_cycles, potential_fn=pot,
                             shaping_lambda=lam, gamma=args.gamma, reward_scale=1.0)
            act = random_policy(len(ev.agent_names), np.asarray(ev.act_dims), 20240101)
            res = ev.run(act, eval_seeds)
            if ref is None:
                ref = res["mean_raw_return"]
            print(f"{lam:>8.3f} {res['mean_raw_return']:>14.2f} "
                  f"{res['mean_shaped_return']:>16.2f} "
                  f"{res['mean_shaped_return'] - ref:>+14.2f}")
            rows.append({"env": env_id, "family": "pz", "lambda": lam,
                         "raw_return": res["mean_raw_return"],
                         "shaped_return": res["mean_shaped_return"],
                         "reported_gain_vs_lambda0": res["mean_shaped_return"] - ref})

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "reporting_gap.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"grid": grid, "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
