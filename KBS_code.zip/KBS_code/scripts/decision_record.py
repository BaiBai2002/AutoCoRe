"""Emit a structured, reproducible decision record from a stored run summary.

This is the operational artefact the paper's decision rule is meant to be read as: one
machine-readable record per deployment, carrying the inputs the rule consumed, the
verification outcome, the estimated coefficient with its uncertainty, the probe evidence,
the deploy/abstain reason, and the cost --- so a human operator (and a reviewer) can see
*why* a shaping term was shipped or refused.

Usage:
    python scripts/decision_record.py --tag confv2_r0
    python scripts/decision_record.py --tag confv2_r0 --json out.json

Exit codes: 0 = record written; 2 = summary not found.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
ART = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal")


def load(tag: str) -> dict | None:
    p = os.path.join(ART, f"{tag}_summary.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def build(tag: str, d: dict) -> dict:
    n_seeds = len(d.get("final_seeds", []))
    n_cand = d.get("n_candidates")
    if isinstance(n_cand, dict):
        n_cand = sum(v for v in n_cand.values() if isinstance(v, (int, float)))
    n_cand = int(n_cand or 0)
    lam = d.get("lambda_star")
    if isinstance(lam, dict):
        vals = sorted(v for v in lam.values() if isinstance(v, (int, float)))
        lam = ({"n": len(vals), "median": vals[len(vals) // 2], "min": vals[0], "max": vals[-1]}
               if vals else None)
    decisions = {}
    for arm, blk in d.get("decisions", {}).items():
        dep = blk.get("deployed")
        pt = blk.get("probe_table") or []
        reasons = blk.get("rejected") or []
        if dep:
            decisions[arm] = {
                "verdict": "deploy",
                "reason": "ranked first by the raw-return probe and its paired probe mean is non-negative",
                "deployed_candidate": dep.get("key"),
                "probe_mean_gain": dep.get("probe_mean_gain"),
                "probe_seeds": d.get("probe_seeds"),
                "rejected_candidates": len(reasons),
            }
        else:
            decisions[arm] = {
                "verdict": "abstain",
                "reason": "no candidate reached a non-negative paired probe mean; the rule refuses to shape",
                "candidates_evaluated": len(pt),
                "probe_seeds": d.get("probe_seeds"),
                "rejected_candidates": len(reasons),
            }
    return {
        "tag": tag,
        "environment": d.get("env"),
        "team_size": d.get("N"),
        "provider": d.get("provider"),
        "inputs": {
            "probe_steps": d.get("probe_steps"),
            "probe_seeds": d.get("probe_seeds"),
            "final_steps": d.get("final_steps"),
            "held_out_seeds": d.get("final_seeds"),
            "pool_sizes": {"llm": d.get("k_llm"), "random_valid": d.get("k_rand")},
        },
        "coefficient": {
            "lambda_star": lam,
            "applied_per_agent": d.get("lambda_used_per_agent") if isinstance(d.get("lambda_used_per_agent"), (int, float)) else None,
            "rho_target": d.get("rho_target"),
            "note": "lambda* is a ratio estimate; it is a scale screen, not a guarantee",
        },
        "verification": {
            "n_candidates": n_cand,
            "rule": "applicability gate + magnitude feasibility, charged to the baseline (P3)",
        },
        "decisions": decisions,
        "cost": {
            "probe_environment_steps": (d.get("probe_steps") or 0) * n_cand * len(d.get("probe_seeds", [])),
            "final_environment_steps": (d.get("final_steps") or 0) * n_seeds
                                      * max(1, len(d.get("decisions", {}))),
            "unit": "environment steps charged to the unshaped baseline",
        },
        "outcome": {
            "unshaped_baseline_mean": d.get("base_final_mean"),
            "per_arm_final": d.get("per_arm"),
        },
    }


def render(r: dict) -> str:
    lines = [
        f"decision record  {r['tag']}",
        f"  environment    {r['environment']}  N={r['team_size']}  proposer={r['provider']}",
        f"  inputs         probe {r['inputs']['probe_steps']} steps x seeds {r['inputs']['probe_seeds']}, "
        f"finals {r['inputs']['final_steps']} steps x seeds {r['inputs']['held_out_seeds']}",
        f"  pools          {r['inputs']['pool_sizes']}",
        f"  coefficient    lambda* = {r['coefficient']['lambda_star']}  (per agent {r['coefficient']['applied_per_agent']})",
        f"  verification   {r['verification']['n_candidates']} candidates; {r['verification']['rule']}",
    ]
    for arm, dec in r["decisions"].items():
        if dec["verdict"] == "deploy":
            lines.append(f"  [{arm}] DEPLOY {dec['deployed_candidate']}  probe mean gain "
                         f"{dec['probe_mean_gain']}, {dec['rejected_candidates']} rejected")
        else:
            lines.append(f"  [{arm}] ABSTAIN  ({dec['candidates_evaluated']} candidates evaluated; "
                         f"{dec['rejected_candidates']} rejected) --- {dec['reason']}")
    lines.append(f"  cost           {r['cost']['probe_environment_steps']} probe + "
                 f"{r['cost']['final_environment_steps']} final env steps ({r['cost']['unit']})")
    lines.append(f"  outcome        unshaped baseline {r['outcome']['unshaped_baseline_mean']}, "
                 f"per arm {r['outcome']['per_arm_final']}")
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--tag", required=True, help="summary tag, e.g. confv2_r0")
    ap.add_argument("--json", default=None, help="also write the record to this path")
    args = ap.parse_args()

    d = load(args.tag)
    if d is None:
        print(f"summary not found: {args.tag} (expected {ART}/{args.tag}_summary.json)", file=sys.stderr)
        raise SystemExit(2)

    rec = build(args.tag, d)
    print(render(rec))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(rec, f, indent=2)
        print(f"\nwrote {args.json}")


if __name__ == "__main__":
    main()
