import os, subprocess, glob, json
import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PDF = os.path.join(ROOT, "paper", "main_final.pdf")
OUT = os.path.join(ROOT, "audit", "_t3_pages")
os.makedirs(OUT, exist_ok=True)
for f in glob.glob(os.path.join(OUT, "*.png")):
    os.remove(f)
DPI = 150
subprocess.run(["pdftoppm", "-r", str(DPI), "-png", PDF, os.path.join(OUT, "pg")],
               check=False)
pages = sorted(glob.glob(os.path.join(OUT, "pg-*.png")))
PT = DPI / 72.0
print(f"{len(pages)} page images at {DPI} dpi")

COL_W_PT = 252.0
min_run = int(COL_W_PT * PT * 0.80)


def rules_on(img_path):
    a = np.asarray(Image.open(img_path).convert("L"))
    H, W = a.shape
    dark = a < 128
    rows = []
    for y in range(H):
        row = dark[y]
        best = 0
        cur = 0
        start = 0
        bs = 0
        for x in range(W):
            if row[x]:
                if cur == 0:
                    start = x
                cur += 1
                if cur > best:
                    best = cur
                    bs = start
            else:
                cur = 0
        if best >= min_run:
            rows.append((y, bs, bs + best))
    groups = []
    for y, x0, x1 in rows:
        if groups and y - groups[-1][-1][0] <= 2:
            groups[-1].append((y, x0, x1))
        else:
            groups.append([(y, x0, x1)])
    res = []
    for g in groups:
        ys = [t[0] for t in g]
        x0 = min(t[1] for t in g)
        x1 = max(t[2] for t in g)
        res.append({
            "y_in": round(sum(ys) / len(ys) / PT / 72.0, 2),
            "x0_in": round(x0 / PT / 72.0, 2),
            "x1_in": round(x1 / PT / 72.0, 2),
            "thick_in": round((max(ys) - min(ys) + 1) / PT / 72.0, 3),
        })
    return res


allr = {}
for i, p in enumerate(pages, 1):
    r = rules_on(p)
    full = [x for x in r if (x["x1_in"] - x["x0_in"]) > 3.0]
    allr[i] = full
    if full:
        print(f"p{i}: " + "; ".join(f"y={x['y_in']}(x {x['x0_in']}-{x['x1_in']})" for x in full))
json.dump(allr, open(os.path.join(ROOT, "audit", "_t3_tablerules.json"), "w"), indent=2)
