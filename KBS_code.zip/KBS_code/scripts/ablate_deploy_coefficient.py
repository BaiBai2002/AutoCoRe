"""Fixed-selection deployment-coefficient ablation.

The pipeline calibrates each candidate's coefficient as
``lambda = rho* E|R| / E|dPhi|``. Section dose shows the raw-return optimum sits a
factor of two to four *below* that visibility scale, so the pipeline's nominal
target ``rho* = 0.2`` is likely above the useful range. This script isolates the
deployment coefficient from selection: it takes the configurations the pipeline
actually deployed at ``rho* = 0.2`` (from the control summary), retrains *the same
configurations* at the ablated targets, and reports the paired gain against the
unshaped and budget-matched baselines.

Holding selection fixed is the point --- it makes the coefficient the only thing
that changes. The unshaped and budget-matched baselines are target-independent
(a target only affects shaped runs) and so are shared across settings.

Run ids are those of ``bps_gate_experiment.py`` with a ``--run-tag`` of the target,
so a run is never shared between targets (P6).
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bps_gate_experiment as bge  # noqa: E402
from analyze_bps_gate import per_seed  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BPS = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics",
                   "deploy_coefficient_ablation.json")


def tag_of(rho: float) -> str:
    return f"rho{int(round(rho * 100)):03d}"


def key_prefix(env: str, algo: str, num_agents, key: str, tag: str) -> str:
    n = "na" if num_agents is None else str(num_agents)
    suffix = f"_{tag}" if tag else ""
    return f"{env.replace('/', '-')}_{algo}_N{n}_final_{key}{suffix}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--control", default=os.path.join(BPS, "bps_n3_rho020_summary.json"))
    ap.add_argument("--targets", default="0.10,0.05")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--no-train", action="store_true",
                    help="only read existing runs; do not train missing ones")
    args = ap.parse_args()

    with open(args.control, encoding="utf-8") as f:
        ctrl = json.load(f)
    env, algo, na = ctrl["env"], ctrl["algo"], ctrl["num_agents"]
    steps = ctrl["final_steps"]
    max_cycles = ctrl["max_cycles"]
    seeds = [int(s) for s in ctrl["final_seeds"]]
    bm = ctrl["budget_matched_baseline"]
    bm_steps = bm["steps"]

    deployed = []
    for d in ctrl["decisions"]:
        if d.get("gate_choice"):
            deployed.append((d["gate_choice"]["key"], d["gate_choice"]["name"],
                             d["gate_choice"]["weights"]))
    print(f"control rho*=0.20 deployed {len(deployed)} configurations: "
          f"{[n for _, n, _ in deployed]}")

    base = per_seed(ctrl, "base", steps)
    bm_vals = per_seed(ctrl, f"base_bm{bm_steps}", bm_steps)
    print(f"unshaped baseline {np.mean(list(base.values())):.2f}; "
          f"budget-matched {bm_steps} steps {np.mean(list(bm_vals.values())):.2f}")

    import concurrent.futures as cf
    rows = []
    cells: dict[float, dict[tuple[str, int], float]] = {}
    settings = [("", 0.20)] + [(tag_of(float(x)), float(x))
                               for x in args.targets.split(",")]
    for tag, rho in settings:
        # 1) control row: the same configurations at the control target
        jobs = []
        for key, name, w in deployed:
            for s in seeds:
                rid = f"{key_prefix(env, algo, na, key, tag)}_s{s}"
                jobs.append((rid, key, name, w, s))

        def do(job):
            rid, key, name, w, s = job
            if args.no_train:
                path = os.path.join(bge.OUTDIR, f"{rid}.json")
                if not os.path.exists(path):
                    return key, name, s, None
            bge.RUN_TAG = tag
            val = bge.train(env, algo, na, steps, s, np.asarray(w, dtype=float),
                            rid, rho, max_cycles=max_cycles)
            return key, name, s, val

        got: dict[str, dict[int, float]] = {}
        with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
            for key, name, s, val in pool.map(do, jobs):
                if val is not None:
                    got.setdefault(key, {})[s] = val

        d_base, d_bm, per_cfg = [], [], {}
        this_cells: dict[tuple[str, int], float] = {}
        for key, name, _ in deployed:
            vals = got.get(key, {})
            sh = [s for s in seeds if s in vals and s in base]
            if not sh:
                per_cfg[name] = None
                continue
            for s in sh:
                this_cells[(key, s)] = float(vals[s])
            arr = np.asarray([vals[s] - base[s] for s in sh], dtype=float)
            d_base.append(arr)
            per_cfg[name] = float(arr.mean())
            shb = [s for s in sh if s in bm_vals]
            if shb:
                d_bm.append(np.asarray([vals[s] - bm_vals[s] for s in shb], dtype=float))
        cells[rho] = this_cells
        from analyze_bps_gate import bootstrap_ci
        r = {"rho_target": rho, "tag": tag, "n_configs": len(got),
             "per_config_gain_vs_base": per_cfg}
        if d_base:
            m, lo, hi = bootstrap_ci(np.concatenate(d_base))
            r.update({"gain_vs_base": m, "vs_base_lo": lo, "vs_base_hi": hi,
                      "vs_base_sig": bool(lo > 0 or hi < 0)})
        if d_bm:
            m, lo, hi = bootstrap_ci(np.concatenate(d_bm))
            r.update({"gain_vs_bm": m, "vs_bm_lo": lo, "vs_bm_hi": hi,
                      "vs_bm_sig": bool(lo > 0 or hi < 0)})
        rows.append(r)

    # Paired comparison against the control, on the same (configuration, seed)
    # cells --- this is the statistic that isolates the calibration target, since
    # selection is held fixed by construction.
    from analyze_bps_gate import bootstrap_ci
    ctrl_cells = cells.get(0.20, {})
    for r in rows:
        if abs(r["rho_target"] - 0.20) < 1e-9:
            continue
        cur = cells.get(r["rho_target"], {})
        shared = sorted(set(cur) & set(ctrl_cells))
        if len(shared) < 4:
            continue
        d = np.asarray([cur[c] - ctrl_cells[c] for c in shared], dtype=float)
        m, lo, hi = bootstrap_ci(d)
        r.update({"vs_control": m, "vs_control_lo": lo, "vs_control_hi": hi,
                  "vs_control_sig": bool(lo > 0 or hi < 0), "n_cells": len(shared)})

    print(f"\n{'rho*':>6s} {'cfgs':>5s} {'gain/base':>24s} {'gain/bm':>24s} "
          f"{'vs control':>24s}")
    for r in rows:
        gb = (f"{r['gain_vs_base']:+.2f} [{r['vs_base_lo']:+.1f},{r['vs_base_hi']:+.1f}]"
              if "gain_vs_base" in r else "-")
        gm = (f"{r['gain_vs_bm']:+.2f} [{r['vs_bm_lo']:+.1f},{r['vs_bm_hi']:+.1f}]"
              if "gain_vs_bm" in r else "-")
        gc = (f"{r['vs_control']:+.2f} [{r['vs_control_lo']:+.1f},"
              f"{r['vs_control_hi']:+.1f}]" if "vs_control" in r else "-")
        print(f"{r['rho_target']:>6.2f} {r['n_configs']:>5d} {gb:>24s} {gm:>24s} {gc:>24s}")
    for r in rows:
        print(f"  rho*={r['rho_target']:.2f} per-config gains vs base: "
              f"{ {k: (None if v is None else round(v, 1)) for k, v in r['per_config_gain_vs_base'].items()} }")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"control": os.path.basename(args.control), "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
