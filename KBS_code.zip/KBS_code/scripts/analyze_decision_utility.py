"""End-to-end decision utility and abstention accounting for the proposer study.

The paper claims the pipeline *abstains rather than ship a shaping term it cannot support*.
This script converts that claim into measured quantities over the released run records, at
the deployment level (one row per arm per draw), and writes a small table for the appendix.

For every arm (`llm`, `llm_raw`, `rand`, `hand`) pooled over a declared scope of tags it
reports:

* ``n``            -- draws in scope
* ``deploy``       -- draws in which the frozen rule deployed a candidate
* ``deploy_rate``  -- deploy / n
* ``mean_depl``    -- mean realised held-out gain *among deployments*
* ``pipe_gain``    -- mean **pipeline** gain: a deployment contributes its realised gain, an
                      abstention contributes 0 (the unshaped fallback). This is what an
                      operator who runs the pipeline unconditionally actually gets.
* ``harm``         -- deployments whose realised gain is negative (deployed but hurt)
* ``harm_rate``    -- harm / deploy
* ``min_depl``     -- worst realised gain among deployments

and, per configuration, the deploy/abstain marker and the pipeline gain.

Nothing is recomputed by hand: every number comes from ``*_summary.json``. Run:

    python scripts/analyze_decision_utility.py                 # default scope
    python scripts/analyze_decision_utility.py --all           # every study tag
"""
from __future__ import annotations

import argparse
import glob
import json
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUMM = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal")
ARMS = ("llm", "llm_raw", "rand", "hand")

# The main proposer study: one row per (task=simple_spread_v3, N=3, IPPO) configuration that
# carries the four arms. External configurations (N=5, MAPPO), the effort sweep, the budget
# controls and the second task are reported separately, so the headline table is the sweep.
MAIN_PREFIXES = (
    "conf_", "confv2_", "confv3_",
)


def is_main(tag: str) -> bool:
    return any(tag.startswith(p) for p in MAIN_PREFIXES)


def load() -> dict[str, dict]:
    out = {}
    for path in sorted(glob.glob(os.path.join(SUMM, "*_summary.json"))):
        tag = os.path.basename(path)[: -len("_summary.json")]
        if tag.startswith(("pilot_", "smoke_")):
            continue
        with open(path, encoding="utf-8") as fh:
            out[tag] = json.load(fh)
    return out


def arm_stats(summaries: dict[str, dict], arm: str) -> dict:
    n = deploy = harm = 0
    gains: list[float] = []
    for s in summaries.values():
        pa = (s.get("per_arm") or {}).get(arm)
        if not pa:
            continue
        n += 1
        if pa.get("abstain"):
            continue
        deploy += 1
        g = float(pa.get("deployed_mean_gain", 0.0))
        gains.append(g)
        if g < 0:
            harm += 1
    mean_depl = sum(gains) / len(gains) if gains else float("nan")
    pipe = sum(gains) / n if n else float("nan")   # abstentions contribute 0
    return {
        "n": n, "deploy": deploy, "deploy_rate": deploy / n if n else float("nan"),
        "mean_depl": mean_depl, "pipe_gain": pipe, "harm": harm,
        "harm_rate": harm / deploy if deploy else float("nan"),
        "min_depl": min(gains) if gains else float("nan"),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true",
                    help="include external, effort, budget and second-task tags")
    args = ap.parse_args()

    allsum = load()
    scope = {t: s for t, s in allsum.items() if args.all or is_main(t)}

    label = "all study tags" if args.all else "main sweep (simple_spread_v3, N=3, IPPO)"
    print(f"scope: {label} — {len(scope)} tags of {len(allsum)}\n")

    hdr = f"{'arm':<9}{'n':>4}{'deploy':>8}{'rate':>8}{'mean_depl':>11}{'pipe_gain':>11}{'harm':>6}{'harm_rate':>11}{'min_depl':>10}"
    print(hdr)
    print("-" * len(hdr))
    rows = {}
    for arm in ARMS:
        st = arm_stats(scope, arm)
        rows[arm] = st
        print(f"{arm:<9}{st['n']:>4}{st['deploy']:>8}{st['deploy_rate']:>8.2f}"
              f"{st['mean_depl']:>11.1f}{st['pipe_gain']:>11.1f}{st['harm']:>6}"
              f"{st['harm_rate']:>11.2f}{st['min_depl']:>10.1f}")

    # per-configuration marker table (pp = pipeline gain; A = abstained)
    print("\nper configuration (pipeline gain; 'A' = abstained):")
    for tag in sorted(scope):
        s = scope[tag]
        cells = []
        for arm in ARMS:
            pa = (s.get("per_arm") or {}).get(arm)
            if not pa:
                cells.append("--")
            elif pa.get("abstain"):
                cells.append("A")
            else:
                cells.append(f"{float(pa['deployed_mean_gain']):+.0f}")
        print(f"  {tag:<28s} llm={cells[0]:>5s} raw={cells[1]:>5s} "
              f"rand={cells[2]:>5s} hand={cells[3]:>5s}")

    # machine-readable record
    out = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal",
                       "decision_utility_all.json" if args.all else "decision_utility_main.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"scope": label, "n_tags": len(scope), "arms": rows}, fh, indent=2)
    print(f"\nwrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())