"""Rebuild a ``{tag}_raw.json`` aggregate from the per-run files of a sweep.

Sweeps write one JSON per (configuration, seed). If a sweep is interrupted the
aggregate file is never written, so the completed runs can otherwise only be
recovered by re-running them. This utility reconstructs the aggregate from
whatever per-run files exist.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    args = ap.parse_args()

    pattern = os.path.join(OUTDIR, f"{args.tag}_*_seed*.json")
    files = sorted(glob.glob(pattern))
    rx = re.compile(rf"{re.escape(args.tag)}_(.+)_seed(\d+)\.json$")
    records: dict[tuple[str, int], dict] = {}
    skipped = 0
    for path in files:
        m = rx.search(os.path.basename(path))
        if not m:
            skipped += 1
            continue
        arm, seed = m.group(1), int(m.group(2))
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            skipped += 1
            continue
        data["arm"] = data.get("arm", arm)
        data["seed"] = seed
        data["status"] = "completed"
        records[(data["arm"], seed)] = data

    out = os.path.join(OUTDIR, f"{args.tag}_raw.json")
    ordered = [records[k] for k in sorted(records, key=lambda k: (k[0], k[1]))]
    with open(out, "w", encoding="utf-8") as f:
        json.dump(ordered, f, indent=2)

    arms: dict[str, int] = {}
    for r in ordered:
        arms[r["arm"]] = arms.get(r["arm"], 0) + 1
    print(f"tag={args.tag}: recovered {len(ordered)} runs ({skipped} files skipped)")
    for arm in sorted(arms):
        print(f"  {arm:<16s} {arms[arm]} seeds")
    print("wrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
