"""Realistic-size latency probe: ~3.5K-char prompt, max_tokens=8192, temperature 0.2 —
the same request shape as one candidate-generation family call. Compares gpt-5.6-sol
with gpt-6-astra (a known-working family). Prints timings only.
"""
import json
import sys
import time
import urllib.request

ENV = {}
for ln in open(".env", encoding="utf-8"):
    ln = ln.strip()
    if ln and not ln.startswith("#") and "=" in ln:
        k, v = ln.split("=", 1)
        ENV[k.strip()] = v.strip().strip('"').strip("'")

key = ENV.get("UUAPI_OPENAI_KEY", "")
prompt = (
    "You are a reward-shaping designer for a cooperative multi-agent environment. "
    "Available predicates: at_landmark, near_landmark, agent_at_target, agent_target_assignment_distance, "
    "coverage_progress, collision_count, mean_pairwise_distance. Available potentials: "
    "distance_to_landmark, role_balance, coverage_gain, assignment_alignment. "
    "Produce exactly 6 candidate reward-shaping functions as a JSON object with key 'candidates', "
    "each having 'family_name', 'subgoals' (list of {predicate:{type,...}}), and a short 'rationale'. "
    "Explain the construction in detail for auditability, then give the JSON.\n\n"
    * 6
)
print("prompt chars:", len(prompt))
for model in ["gpt-5.6-sol", "gpt-6-astra"]:
    req = urllib.request.Request(
        "https://uuapi.shop/v1/chat/completions",
        data=json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 8192,
            "temperature": 0.2,
        }).encode(),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    t = time.time()
    try:
        r = urllib.request.urlopen(req, timeout=900)
        b = json.loads(r.read())
        c = b["choices"][0]["message"]["content"]
        print(f"{model}: {r.status} | {time.time()-t:.0f}s | out chars {len(c)}")
    except Exception as e:
        print(f"{model}: FAILED after {time.time()-t:.0f}s: {str(e)[:160]}")
    sys.stdout.flush()