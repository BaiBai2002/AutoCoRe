"""Out-of-sample fidelity of the probe for the budgeted-shaping pipeline.

The dev-set analysis in ``analyze_probe_prediction.py`` reads evaluation curves
that were also used to develop the pipeline. This script instead uses the
seed-role separation the protocol prescribes: every candidate is scored on the
*probe* seeds (200-204) and then trained to the full budget on the disjoint
*held-out* seeds (100-109). The probe score is never computed on the seeds that
decide the outcome, so the reported agreement is genuinely out of sample.

For each setting (one ``*_summary.json``) it reports, over all candidate keys
that were both probed and finally trained:

* Spearman rank correlation between probe gain and held-out paired gain;
* sign accuracy (does the probe get the direction of the effect right?);
* top-1 agreement (does the probe's best candidate coincide with the best one
  under the full budget?);
* leave-one-out calibrated MAE of the held-out gain, against the trivial
  ``gain = 0`` predictor.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bps_gate_experiment import realized_steps  # noqa: E402

RESULT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "heldout_fidelity.json")


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def loo_calibrated_mae(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    n = x.size
    if n < 3:
        return float("nan"), float("nan")
    errs_cal, errs_zero = [], []
    for i in range(n):
        m = np.ones(n, dtype=bool)
        m[i] = False
        A = np.vstack([x[m], np.ones(int(m.sum()))]).T
        try:
            coef, *_ = np.linalg.lstsq(A, y[m], rcond=None)
        except np.linalg.LinAlgError:
            continue
        errs_cal.append(abs(float(coef[0] * x[i] + coef[1] - y[i])))
        errs_zero.append(abs(float(0.0 - y[i])))
    if not errs_cal:
        return float("nan"), float("nan")
    return float(np.mean(errs_cal)), float(np.mean(errs_zero))


def finals_prefix(summary: dict) -> str:
    n = "na" if summary["num_agents"] is None else str(summary["num_agents"])
    env = summary["env"].replace("/", "-")
    return f"{env}_{summary['algo']}_N{n}_final_"


def per_seed(summary: dict, key: str, expected_steps: int | None = None) -> dict[int, float]:
    """Per-seed final returns read from the immutable per-run logs.

    Reading from disk picks up runs that were re-trained after the summary was
    written, and the step guard keeps stale short runs out of the statistics.
    """
    pfx = finals_prefix(summary) + key
    out: dict[int, float] = {}
    for path in sorted(glob.glob(os.path.join(OUTDIR, pfx + "_s*.json"))):
        try:
            with open(path, encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            continue
        if expected_steps is not None:
            if int(rec.get("steps", -1)) != realized_steps(expected_steps):
                continue
        out[int(rec["seed"])] = float(rec["final_return"])
    return out


def bootstrap_spearman(x: np.ndarray, y: np.ndarray, n_boot: int = 5000,
                       seed: int = 0) -> tuple[float, float, float]:
    """Bootstrap CI for the rank correlation over candidate pairs."""
    n = x.size
    if n < 3:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    obs = spearman(x, y)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        if np.unique(x[idx]).size < 3 or np.unique(y[idx]).size < 3:
            continue
        vals.append(spearman(x[idx], y[idx]))
    if not vals:
        return obs, float("nan"), float("nan")
    lo, hi = np.percentile(vals, [2.5, 97.5])
    return obs, float(lo), float(hi)


def probe_entries(summary: dict) -> dict[str, dict]:
    """Per-candidate probe score and label (the selection-stage information)."""
    out: dict[str, dict] = {}
    for d in summary.get("decisions", []):
        entries = list(d.get("probe_table", []))
        for slot in ("top_by_probe", "gate_choice", "random_choice"):
            c = d.get(slot)
            if c:
                entries.append(c)
        for c in entries:
            if "probe_mean_gain" in c:
                out.setdefault(c["key"], {"gain": float(c["probe_mean_gain"]),
                                          "name": c.get("name", c["key"])})
    return out


def probe_scores(summary: dict) -> dict[str, float]:
    """Best-known probe mean gain per candidate key (the selection-stage score)."""
    return {k: v["gain"] for k, v in probe_entries(summary).items()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summaries", default=None)
    args = ap.parse_args()

    paths = ([p.strip() for p in args.summaries.split(",")] if args.summaries
             else sorted(glob.glob(os.path.join(OUTDIR, "*_summary.json"))))
    paths = [p for p in paths if os.path.exists(p) and "smoke" not in os.path.basename(p)]

    out_rows = []
    for path in paths:
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        base = per_seed(s, "base", s["final_steps"])
        if not base:
            continue
        probe = probe_entries(s)
        name = f"{s['env']} [{s['algo']}" + (f", N={s['num_agents']}]" if s["num_agents"] else "]")

        keys, x, y, points = [], [], [], []
        for key, meta in probe.items():
            vals = per_seed(s, key, s["final_steps"])
            if not vals:
                continue
            shared = sorted(set(vals) & set(base))
            if len(shared) < 2:
                continue
            held = float(np.mean([vals[t] - base[t] for t in shared]))
            keys.append(key)
            x.append(meta["gain"])
            y.append(held)
            points.append({"key": key, "name": meta["name"],
                           "probe_gain": meta["gain"], "heldout_gain": held,
                           "n_seeds": len(shared)})
        if len(keys) < 3:
            print(f"\n{name}: {len(keys)} candidates both probed and trained -- skipped")
            continue

        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        sp, sp_lo, sp_hi = bootstrap_spearman(x, y)
        sign_acc = float(np.mean(np.sign(x) == np.sign(y)))
        mae_cal, mae_zero = loo_calibrated_mae(x, y)
        top1_match = keys[int(np.argmax(x))] == keys[int(np.argmax(y))]

        gate_keys = [d["gate_choice"]["key"] for d in s.get("decisions", []) if d.get("gate_choice")]
        gate_rank = float("nan")
        if gate_keys and np.isfinite(sp):
            order = np.argsort(-y)
            ranks = [int(np.where(order == keys.index(k))[0][0]) + 1 for k in gate_keys if k in keys]
            if ranks:
                gate_rank = float(np.mean(ranks))

        print(f"\n{name}   n_candidates={len(keys)}  "
              f"probe_seeds={s.get('probe_pool')}  held-out_seeds={s.get('final_seeds')}")
        print(f"  Spearman(probe, held-out gain) = {sp:+.3f}  "
              f"95% CI [{sp_lo:+.3f}, {sp_hi:+.3f}]")
        print(f"  sign accuracy                  = {sign_acc:.2f}")
        print(f"  top-1 agreement                = {top1_match}")
        print(f"  LOO-calibrated MAE {mae_cal:.2f}  vs  zero-predictor MAE {mae_zero:.2f}")
        if np.isfinite(gate_rank):
            print(f"  mean held-out rank of gate choice = {gate_rank:.1f} / {len(keys)}")

        out_rows.append({"setting": name, "n_candidates": len(keys), "spearman": sp,
                         "spearman_ci": [sp_lo, sp_hi],
                         "sign_accuracy": sign_acc, "top1_match": bool(top1_match),
                         "mae_calibrated": mae_cal, "mae_zero": mae_zero,
                         "mean_gate_rank": gate_rank, "points": points})

    if out_rows:
        sps = np.asarray([r["spearman"] for r in out_rows if np.isfinite(r["spearman"])])
        sas = np.asarray([r["sign_accuracy"] for r in out_rows])
        better = sum(1 for r in out_rows if r["mae_calibrated"] < r["mae_zero"])
        print(f"\nacross {len(out_rows)} settings: median Spearman "
              f"{np.median(sps):+.3f}, median sign accuracy {np.median(sas):.2f}, "
              f"calibrated beats zero in {better}/{len(out_rows)}")
    os.makedirs(os.path.dirname(RESULT), exist_ok=True)
    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(out_rows, f, indent=2)
    print("\nwrote", os.path.normpath(RESULT))


if __name__ == "__main__":
    main()
