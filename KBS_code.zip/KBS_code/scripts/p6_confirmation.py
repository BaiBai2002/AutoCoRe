"""P6 — analysis of the pre-registered independent confirmation.

Reads the confirmatory summary produced by

    python scripts/bps_gate_experiment.py ... --pipeline-seed-offset 100 \
        --probe-pool 300,301,302,303,304 --tag bps_confirm

and applies the decision rules fixed in ``workplan/analysis_plan.md`` *before*
the run was launched:

* CONFIRMED  - 95% CI of the pooled mean excludes 0, point estimate > 0, and the
               per-replicate mean is positive in >= 4/5 replicates;
* PARTIAL    - point estimate > 0 and positive in >= 3/5 replicates, CI includes 0;
* REFUTED    - otherwise.

The primary endpoint is the paired per-seed difference between the deployed
configuration and the *budget-matched* baseline. The comparison against unshaped
training and against a random draw from the same pool is reported alongside. The
multiplicity family is the full set of deployment claims (7); the family-corrected
interval (Bonferroni, alpha/7) is shown next to the uncorrected one.

Writes ``summary/per_setting.csv`` and prints the verdict. It never edits the
pre-registration; deviations go to the append-only log in that file.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np  # noqa: E402

from analyze_bps_gate import bootstrap_ci, per_seed  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
SUMMARY_DIR = os.path.join(PROJECT_ROOT, "summary")
FAMILY_SIZE = 7


def paired_vs(summary: dict, anchor: str) -> tuple[np.ndarray, list[float]]:
    """Pooled per-seed paired differences and per-replicate means.

    ``anchor`` is either ``"bm"`` (budget-matched baseline) or ``"base"``
    (unshaped baseline). The per-seed logs are read from disk, so a run retrained
    to the correct budget is picked up automatically.
    """
    base = per_seed(summary, "base", summary["final_steps"])
    bm = summary.get("budget_matched_baseline")
    ref = base
    if anchor == "bm":
        if not bm:
            raise SystemExit("no budget-matched baseline in this summary")
        for cand in ("base_bm", f"base_bm{bm['steps']}"):
            ref = per_seed(summary, cand, bm["steps"]) or ref
    diffs, reps = [], []
    seeds = sorted(ref)
    for d in summary["decisions"]:
        if not d["gate_choice"]:
            continue
        vals = per_seed(summary, d["gate_choice"]["key"], summary["final_steps"])
        shared = [s for s in seeds if s in vals]
        if not shared:
            continue
        dd = np.asarray([vals[s] - ref[s] for s in shared], dtype=float)
        diffs.append(dd)
        reps.append(float(dd.mean()))
    return (np.concatenate(diffs) if diffs else np.asarray([])), reps


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default=os.path.join(OUTDIR, "bps_confirm_summary.json"))
    ap.add_argument("--reference", default=os.path.join(OUTDIR, "bps_n3_rho020_summary.json"),
                    help="the exploratory summary, for a side-by-side comparison")
    ap.add_argument("--alpha", type=float, default=0.05)
    args = ap.parse_args()

    with open(args.summary, encoding="utf-8") as f:
        s = json.load(f)

    rows_out = []
    verdict = {}
    print(f"{'=' * 78}\nP6 independent confirmation  ({os.path.basename(args.summary)})\n{'=' * 78}")

    for anchor, label in (("bm", "vs budget-matched"), ("base", "vs unshaped")):
        pooled, reps = paired_vs(s, anchor)
        if pooled.size == 0:
            print(f"  {label}: no paired data")
            continue
        m, lo, hi = bootstrap_ci(pooled, alpha=args.alpha)
        m_f, lo_f, hi_f = bootstrap_ci(pooled, alpha=args.alpha / FAMILY_SIZE)
        n_pos = sum(1 for r in reps if r > 0)
        excludes0 = lo > 0 or hi < 0
        # Pre-registered rule (analysis_plan.md Sec. 5), evaluated on the primary
        # anchor only; the secondary anchor is reported but not decisive.
        if anchor == "bm":
            if m > 0 and excludes0 and n_pos >= 4:
                v = "CONFIRMED"
            elif m > 0 and n_pos >= 3:
                v = "PARTIAL"
            else:
                v = "REFUTED"
            verdict = {"verdict": v, "mean": m, "lo": lo, "hi": hi,
                       "mean_family": m_f, "lo_family": lo_f, "hi_family": hi_f,
                       "replicates_positive": n_pos, "replicates": len(reps),
                       "n_paired": int(pooled.size)}
        print(f"\n  {label}: pooled mean {m:+.2f}  95% CI [{lo:+.2f}, {hi:+.2f}]  "
              f"(n={pooled.size} seed-replicates)")
        print(f"       Bonferroni(x{FAMILY_SIZE}) CI [{lo_f:+.2f}, {hi_f:+.2f}]  "
              f"excludes 0: {'yes' if lo_f > 0 or hi_f < 0 else 'no'}")
        print(f"       replicates positive: {n_pos}/{len(reps)}   "
              f"per-replicate means: " + ", ".join(f"{r:+.1f}" for r in reps))
        rows_out.append({
            "setting": "confirm", "anchor": anchor, "n_paired": int(pooled.size),
            "mean": round(m, 3), "ci_lo": round(lo, 3), "ci_hi": round(hi, 3),
            "mean_family": round(m_f, 3), "lo_family": round(lo_f, 3),
            "hi_family": round(hi_f, 3),
            "replicates_positive": n_pos, "replicates": len(reps),
            "verdict": verdict.get("verdict", "") if anchor == "bm" else "",
        })

    # Optional side-by-side with the exploratory run.
    if args.reference and os.path.exists(args.reference) and args.reference != args.summary:
        with open(args.reference, encoding="utf-8") as f:
            ref = json.load(f)
        pooled, reps = paired_vs(ref, "bm")
        if pooled.size:
            m, lo, hi = bootstrap_ci(pooled, alpha=args.alpha)
            print(f"\n  exploratory reference ({os.path.basename(args.reference)}): "
                  f"{m:+.2f} [{lo:+.2f}, {hi:+.2f}]  "
                  f"replicates positive {sum(1 for r in reps if r > 0)}/{len(reps)}")
            rows_out.append({
                "setting": "exploratory", "anchor": "bm", "n_paired": int(pooled.size),
                "mean": round(m, 3), "ci_lo": round(lo, 3), "ci_hi": round(hi, 3),
                "mean_family": "", "lo_family": "", "hi_family": "",
                "replicates_positive": sum(1 for r in reps if r > 0),
                "replicates": len(reps), "verdict": "exploratory",
            })

    os.makedirs(SUMMARY_DIR, exist_ok=True)
    out_csv = os.path.join(SUMMARY_DIR, "per_setting.csv")
    fields = ["setting", "anchor", "n_paired", "mean", "ci_lo", "ci_hi",
              "mean_family", "lo_family", "hi_family",
              "replicates_positive", "replicates", "verdict"]
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows_out)

    print(f"\n{'=' * 78}")
    if verdict:
        print(f"PRE-REGISTERED VERDICT: {verdict['verdict']}  "
              f"(primary anchor = budget-matched)")
        print(f"  mean {verdict['mean']:+.2f} [{verdict['lo']:+.2f}, {verdict['hi']:+.2f}], "
              f"family-corrected [{verdict['lo_family']:+.2f}, {verdict['hi_family']:+.2f}], "
              f"{verdict['replicates_positive']}/{verdict['replicates']} replicates positive")
    print("wrote", os.path.normpath(out_csv))
    for r in rows_out:
        print("  ", {k: r[k] for k in ("setting", "anchor", "mean", "ci_lo", "ci_hi", "verdict")})


if __name__ == "__main__":
    main()
