# Patient, self-healing wrapper for the Grok family batch.
#
# The proxy's Grok endpoint returned transient 502 upstream errors mid-batch (the first draws'
# candidate generation succeeded at 16:03-16:14, then the upstream became unavailable), and the
# original runner's 90-second backoff exhausted its attempts too quickly. This wrapper re-runs
# scripts/run_grok_family.ps1 in rounds with a long cooldown between rounds. The batch runner is
# idempotent --- completed draws are skipped and cached family responses are reused --- so a round
# only costs what is still missing. Stops when all five summaries exist or the round cap is hit.
#
# Usage:  powershell -NoProfile -File scripts/run_grok_retry.ps1

$tags = @("confv2grok_47_r0", "confv2grok_47_r1", "confv2grok_47_r2",
          "confpush_grok_47_r0", "confpush_grok_47_r1")
$log = "artifacts/llm_proposal/grok_family.log"

for ($round = 1; $round -le 10; $round++) {
    $missing = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/${_}_summary.json") })
    if ($missing.Count -eq 0) {
        "GROK_RETRY_ALL_DONE (round $round): all five summaries present" | Add-Content $log
        break
    }
    "GROK_RETRY round $round starting; missing: $($missing -join ', ')" | Add-Content $log

    $p = Start-Process powershell `
        -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts\run_grok_family.ps1' `
        -WindowStyle Hidden -PassThru
    $p.WaitForExit()

    $missing = @($tags | Where-Object { -not (Test-Path "artifacts/llm_proposal/${_}_summary.json") })
    if ($missing.Count -eq 0) {
        "GROK_RETRY_ALL_DONE (round $round): all five summaries present" | Add-Content $log
        break
    }
    "GROK_RETRY round $round finished; still missing $($missing.Count) of 5; cooling down 20 min" | Add-Content $log
    Start-Sleep -Seconds 1200
}
"GROK_RETRY_WRAPPER_EXIT" | Add-Content $log
