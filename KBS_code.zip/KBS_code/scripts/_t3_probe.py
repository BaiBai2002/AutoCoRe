import os, re, subprocess, json

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PAPER = os.path.join(ROOT, "paper")

TARGETS = [
    ("fig:feasibility", os.path.join(PAPER, "sections", "06_results.tex")),
    ("tab:richness",    os.path.join(PAPER, "sections", "06_results.tex")),
    ("tab:report",      os.path.join(PAPER, "sections", "07_limitations.tex")),
    ("tab:learn",       os.path.join(PAPER, "sections", "06_results.tex")),
    ("tab:regime",      os.path.join(PAPER, "sections", "06_results.tex")),
    ("fig:dose",        os.path.join(PAPER, "sections", "06_results.tex")),
]

ENVS = ["table", "figure*", "figure"]


def find_block(text, label):
    i = text.index("\\label{%s}" % label)
    best_b, best_end = None, None
    for env in ENVS:
        b = text.rfind("\\begin{%s}" % env, 0, i)
        if b == -1:
            continue
        m = re.compile(r"\\end\{%s\}" % re.escape(env)).search(text, i)
        if m and (best_b is None or b > best_b):
            best_b, best_end = b, m.end()
    return (best_b, best_end) if best_b is not None else None


def compile_pages():
    for _ in range(2):
        subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "main"],
                       cwd=PAPER, capture_output=True)
    log = open(os.path.join(PAPER, "main.log"), encoding="utf-8", errors="ignore").read()
    m = re.findall(r"Output written on main\.pdf \((\d+) pages", log)
    return int(m[-1]) if m else -1


base = compile_pages()
print("baseline pages:", base)
results = {"baseline": base}
for label, path in TARGETS:
    txt = open(path, encoding="utf-8").read()
    blk = find_block(txt, label)
    if not blk:
        results[label] = "NOTFOUND"
        print(label, "NOTFOUND")
        continue
    b, e = blk
    new = txt[:b] + "\\iffalse\n" + txt[b:e] + "\n\\fi" + txt[e:]
    try:
        open(path, "w", encoding="utf-8").write(new)
        p = compile_pages()
    finally:
        open(path, "w", encoding="utf-8").write(txt)
    results[label] = p
    print("%-18s -> %d pages (saved %d)" % (label, p, base - p))

json.dump(results, open(os.path.join(ROOT, "audit", "_t3_probe.json"), "w"), indent=2)
print("done")
