"""Figure: how the reporting criterion destroys candidate screening.

Reads ``artifacts/diagnostics/shaped_selection_audit.json``. For each candidate in
the rich pool the audit has the probe score under both criteria and the held-out
raw outcome. Because the shaped return of a fixed policy is exactly
``R + lambda * mean(dPhi)``, the shaped score at any coefficient is
``raw + kappa (shaped - raw)`` with ``kappa = lambda / lambda_calibrated``, so the
screen's rank correlation with the held-out outcome can be traced over kappa
without retraining. The rank correlation is flat at kappa = 0 (the raw criterion)
and decays monotonically, crossing zero near kappa ~ 4.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import FAMILY, OUTCOME, apply_style, grid, save  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")
FIGDIR = os.path.join(PROJECT_ROOT, "paper", "figures")


def main() -> None:
    with open(os.path.join(DIAG, "shaped_selection_audit.json"), encoding="utf-8") as f:
        data = json.load(f)
    sweep = data["kappa_sweep"]
    k = np.asarray([r["kappa"] for r in sweep], dtype=float)
    rho = np.asarray([r["spearman_vs_held_out_raw"] for r in sweep], dtype=float)

    # Bootstrap interval for the sign change (scripts/kappa_interval.py). Drawn as a
    # band so the caption's interval is visible rather than only quoted.
    lo = hi = None
    kpath = os.path.join(DIAG, "kappa_interval.json")
    if os.path.exists(kpath):
        with open(kpath, encoding="utf-8") as f:
            ki = json.load(f)
        lo, hi = ki.get("kappa_crossing_lo"), ki.get("kappa_crossing_hi")

    apply_style()
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.45, 2.9))

    pos = k > 0
    ax.axvspan(4.0, 22, color=OUTCOME["band"], zorder=0)
    if lo is not None and hi is not None:
        ax.axvspan(lo, hi, color=OUTCOME["negative"], alpha=0.18, zorder=1,
                   label=f"sign-change 95% CI $[{lo:.1f}, {hi:.1f}]$")
    ax.axhline(0.0, color=OUTCOME["neutral"], lw=0.8)
    ax.plot(k[pos], rho[pos], "-o", ms=3.6, lw=1.3, color=FAMILY["mpe"], zorder=3,
            label="shaped criterion")
    ax.scatter([k[0]], [rho[0]], marker="s", s=28, color=OUTCOME["positive"], zorder=4,
               linewidths=0.0, label="raw criterion ($\\kappa=0$)")
    ax.axvline(1.0, ls=":", lw=1.0, color="0.35", zorder=1)
    ax.annotate("calibrated $\\lambda^\\star$", xy=(1.0, 0.97),
                xycoords=("data", "axes fraction"), xytext=(3, 0),
                textcoords="offset points", fontsize=6.3, color="0.3",
                ha="left", va="top")
    ax.annotate("screening\ncollapses", xy=(9.4, 0.90), xytext=(0, 0),
                textcoords="offset points", xycoords=("data", "axes fraction"),
                fontsize=6.3, color="0.3", ha="center", va="top")
    ax.annotate("screen becomes\nuninformative", xy=(3.6, 0.0), xytext=(-2, -15),
                textcoords="offset points", fontsize=6.0, color="0.25", ha="right")
    ax.set_xscale("log")
    ax.set_xlim(0.09, 22)
    ax.set_ylim(-1.0, 1.0)
    ax.set_xlabel(r"reporting coefficient  $\kappa=\lambda/\lambda^\star$ (log scale)")
    ax.set_ylabel("Spearman(score, held-out raw gain)")
    ax.set_title("the shaped criterion stops screening", loc="left")
    grid(ax)
    ax.legend(loc="lower left", handletextpad=0.35)
    fig.tight_layout()
    save(fig, "fig_shaped_screen")


if __name__ == "__main__":
    main()
