#!/bin/bash
set -e
echo "=== AutoCoRe Environment Setup ==="
python -m pip install --upgrade pip
pip install -e ".[dev]"
pip install -r requirements.txt
echo "Setup complete. Run 'source scripts/setup_env.sh' to activate."
