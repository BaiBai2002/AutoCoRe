"""Training-free diagnostics of candidate potentials, cross-referenced with the
measured realised benefit from the controlled shaping experiment.

If a diagnostic computed from random rollouts orders potentials the same way the
full training runs do, then candidate utility can be estimated before spending
the training budget. That is the hypothesis this script tests.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.dsl.compiler import compile_dsl
from autocore.selection.magnitude_calibration import (
    RandomProjectionPotential, alignment_diagnostics, calibration_window,
    collect_reference_states, estimate_scales,
)
from autocore.shaping.potentials import PotentialFunction, ShapingConfig

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")
GAMMA = 0.99


def dsl_potential(name: str):
    with open(os.path.join(PROJECT_ROOT, "configs", "dsl", name), encoding="utf-8") as f:
        dsl = json.load(f)
    compiled = compile_dsl(dsl)
    pf = PotentialFunction(compiled, ShapingConfig(gamma=GAMMA, shaping_lambda=1.0,
                                                   potential_clip=(-1.0, 1.0)))
    return pf.compute_potential


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--rho-min", type=float, default=0.02)
    ap.add_argument("--kappa", type=float, default=1.0)
    args = ap.parse_args()

    candidates = {
        "coverage": dsl_potential("spread_coverage.json"),
        "assignment": dsl_potential("spread_assignment.json"),
    }
    est_asg = estimate_scales(args.env, candidates["assignment"], gamma=GAMMA,
                              max_cycles=args.max_cycles, n_episodes=40, seed=0)
    states = collect_reference_states(args.env, max_cycles=args.max_cycles, n_episodes=6, seed=0)
    candidates["random_projection"] = RandomProjectionPotential(est_asg, seed=0).fit(states)

    measured = {}
    try:
        with open(os.path.join(OUTDIR, "main_analysis.json"), encoding="utf-8") as f:
            for row in json.load(f)["rows"]:
                measured[row["arm"]] = row["paired_delta"]
    except FileNotFoundError:
        pass
    arm_of = {"coverage": "cov_cal", "assignment": "asg_cal", "random_projection": "asg_randctl"}

    rows = []
    print(f"env={args.env}  (diagnostics from random rollouts; no training)")
    print(f"{'potential':>18s} {'value-align':>11s} {'redundancy R2':>13s} "
          f"{'align(dPhi,r)':>13s} {'non-interf':>10s} {'lam*':>7s} {'measured':>10s}")
    for name, fn in candidates.items():
        sc = estimate_scales(args.env, fn, gamma=GAMMA, max_cycles=args.max_cycles,
                             n_episodes=40, seed=0)
        dg = alignment_diagnostics(args.env, fn, gamma=GAMMA, max_cycles=args.max_cycles,
                                   n_episodes=40, seed=0)
        win = calibration_window(sc, rho_min=args.rho_min, kappa=args.kappa)
        delta = measured.get(arm_of.get(name, ""), float("nan"))
        rows.append({**sc.to_dict(), **dg.to_dict(), **win.to_dict(), "potential": name,
                     "measured_paired_delta": delta})
        print(f"{name:>18s} {dg.value_alignment:>11.4f} {dg.reward_redundancy_r2:>13.4f} "
              f"{dg.shaping_reward_alignment:>13.4f} {dg.non_interference:>10.4f} "
              f"{win.lambda_star:>7.2f} {delta:>+10.2f}")

    if len(rows) >= 3:
        va = np.asarray([r["value_alignment"] for r in rows], dtype=float)
        rd = np.asarray([r["reward_redundancy_r2"] for r in rows], dtype=float)
        meas = np.asarray([r["measured_paired_delta"] for r in rows], dtype=float)
        index = va * (1.0 - np.clip(rd, 0.0, 1.0))
        print("\ncomposite diagnostic  index = value_alignment * (1 - redundancy R2)")
        print(f"  Spearman(index, measured delta) = {_spearman(index, meas):.3f}")
        print(f"  Spearman(value_alignment, measured delta) = {_spearman(va, meas):.3f}")
        print(f"  Spearman(-redundancy,      measured delta) = {_spearman(-rd, meas):.3f}")
        order_meas = list(np.argsort(-meas))
        order_index = list(np.argsort(-index))
        print(f"  order by index  : {[rows[i]['potential'] for i in order_index]}")
        print(f"  order by benefit: {[rows[i]['potential'] for i in order_meas]}")
        print(f"  rank orders agree: {order_index == order_meas}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics",
                       f"potential_diagnostics_{args.env}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print("\nwrote", os.path.normpath(out))


def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    denom = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / denom) if denom > 0 else float("nan")


if __name__ == "__main__":
    main()
