#!/bin/bash
set -e
echo "=== Generating Paper Assets ==="
cp artifacts/figures/*.pdf paper/figures/ 2>/dev/null || echo "No figures to copy"
cp artifacts/tables/*.tex paper/tables/ 2>/dev/null || echo "No tables to copy"
echo "Paper assets prepared."
