import os, re, subprocess, json

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PDF = os.path.join(ROOT, "paper", "main_final.pdf")

xml = subprocess.run(["pdftotext", "-bbox", PDF, "-"],
                     capture_output=True, text=True, encoding="utf-8").stdout
pages = re.split(r"<page\b", xml)[1:]
rows = []
for i, p in enumerate(pages, 1):
    m = re.search(r'width="([\d.]+)" height="([\d.]+)"', p)
    W, H = float(m.group(1)), float(m.group(2))
    ys = [float(y) for y in re.findall(r'yMax="([\d.]+)"', p)]
    y0 = [float(y) for y in re.findall(r'yMin="([\d.]+)"', p)]
    if not ys:
        rows.append({"page": i, "words": 0, "bottom_gap_in": None})
        continue
    bottom_gap = (H - max(ys)) / 72.0
    rows.append({"page": i, "words": len(ys),
                 "first_y_in": min(y0) / 72.0, "last_y_in": max(ys) / 72.0,
                 "bottom_gap_in": round(bottom_gap, 2)})
print(f"page  words  lastY(in)  bottom-gap(in)")
for r in rows:
    print(f"{r['page']:>4}  {r['words']:>5}  "
          f"{r.get('last_y_in', float('nan')):>8.2f}  {r.get('bottom_gap_in', float('nan')):>8.2f}")
json.dump(rows, open(os.path.join(ROOT, "audit", "_whitespace_raw.json"), "w"), indent=2)
