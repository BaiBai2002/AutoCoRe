"""Vector Figure 1 for the IEEE-TAI submission (T2).

Scheme A from fig1/design_decision.md, drawn at the *real* two-column width so that a
9 pt label here is a 9 pt label in the paper (the PDF is included at width=\textwidth with
no scaling). Output:

  paper/figures/fig1_method.pdf   vector, embedded, fonttype 42
  fig1/print_grayscale.png        300 dpi greyscale print simulation
  fig1/fig1_render_100.png        full-scale screen render

Run:  python scripts/fig1_method.py
"""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIGDIR = os.path.join(ROOT, "paper", "figures")
OUT = os.path.join(ROOT, "fig1")

# two-column text width of the IEEEtran journal class, in inches (516 pt / 72)
W = 516.0 / 72.0
H = 3.15

INK = "#1a1a1a"
BOX = "#f2f2f2"
EDGE = "#7d7d7d"
ACC = "#a4262c"
BLU = "#eef3f8"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman No9 L", "Liberation Serif",
                   "DejaVu Serif"],
    "mathtext.fontset": "stix",          # Times-compatible math, avoids DejaVu fallback
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.dpi": 200,
})

FS = 9.0          # body label size (hard floor is 9 pt)
FS_T = 9.5        # panel title size

CA, CB, CC = 0.06, 2.462, 4.864
CW = 2.242
TOP = 2.66        # content top (panel titles occupy y in [2.70, 3.08])


def box(ax, x, y, w, h, text, *, fs=FS, fc=BOX, ec=EDGE, bold=False,
        style="normal", color=INK, ls="-", lw=0.7):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.05",
        linewidth=lw, edgecolor=ec, facecolor=fc, linestyle=ls))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            color=color, linespacing=1.30, style=style,
            fontweight=("bold" if bold else "normal"))


def arrow(ax, p, q, *, ls="-", color=INK, rad=0.0, lw=0.9, ms=9):
    ax.add_patch(FancyArrowPatch(
        p, q, arrowstyle="-|>", mutation_scale=ms, linewidth=lw, linestyle=ls,
        color=color, connectionstyle=f"arc3,rad={rad}", shrinkA=1.0, shrinkB=1.0))


def new_axes():
    fig, ax = plt.subplots(figsize=(W, H))
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.axis("off")
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    return fig, ax


def panel_titles(ax):
    for x, t in [(CA, "(a)  four quantities a\n      result depends on"),
                 (CB, "(b)  a decision workflow\n      guarded by P1--P7"),
                 (CC, "(c)  the outcome is\n      regime-dependent")]:
        ax.text(x, H - 0.07, t, fontsize=FS_T, fontweight="bold", va="top",
                ha="left", color=INK)


def build(ax):
    # ----------------------------------------------------------- panel (a) #
    a_items = [
        (r"$\lambda$   coefficient", r"(the team term is $N\lambda$)"),
        (r"$\rho^\star$   target dominance", r"(itself a free choice)"),
        (r"$R$   which return is reported", r"(raw / shaped)"),
        (r"$S$   search budget", r"(charged to the baseline)"),
    ]
    top = TOP
    bh = 0.50
    for t1, t2 in a_items:
        box(ax, CA, top - bh, CW, bh, t1 + "\n" + t2, fs=FS)
        top -= (bh + 0.08)
    ax.text(CA + CW / 2, top + 0.02,
            "all measurable before or during training",
            fontsize=FS, ha="center", va="top", color=EDGE, style="italic")

    # ----------------------------------------------------------- panel (b) #
    box(ax, CB, TOP - 0.18, CW, 0.18, "seven machine-checkable guards",
        fs=FS, fc=BLU)
    chips = ["P1", "P2", "P3", "P4", "P5", "P6", "P7"]
    cwid = CW / 7.0
    for i, c in enumerate(chips):
        box(ax, CB + i * cwid, TOP - 0.39, cwid - 0.03, 0.17, c,
            fs=FS, bold=True, fc="#ffffff")

    stages = ["1  characterise\n    the regime",
              "2  search the pool\n    (probe: raw return)",
              "3  confirm on held-out\n    (paired, per seed)",
              "4  decide: deploy\n    or abstain"]
    tops = [2.20, 1.74, 1.28, 0.82]
    sh = 0.38
    for s, st in zip(stages, tops):
        box(ax, CB, st - sh, CW, sh, s, fs=FS)
    for st in tops[:-1]:
        arrow(ax, (CB + CW / 2, st - sh), (CB + CW / 2, st - sh - 0.06))

    # UNKNOWN / infeasible exit: kept INSIDE panel (b), below the spine
    arrow(ax, (CB + CW / 2, 0.44), (CB + CW / 2, 0.38), ls="--", color=ACC)
    box(ax, CB, 0.02, CW, 0.34,
        r"if the grid cannot reach $\lambda^\star$ (P5)" "\n"
        r"or a guard is undecidable $\rightarrow$ abstain",
        fs=FS, fc="#faf0ef", ec=ACC, ls="--")

    # ----------------------------------------------------------- panel (c) #
    c_items = [(r"grid cannot reach $\lambda^\star$", "scale-infeasible at\nthe target dominance"),
               ("learning regime", "small and bounded"),
               ("baseline fails structurally", "the search is repaid")]
    top = TOP
    for t1, t2 in c_items:
        box(ax, CC, top - 0.50, CW, 0.50, t1 + "\n" + t2, fs=FS)
        top -= (0.50 + 0.08)
    box(ax, CC, 0.06, CW, 0.86,
        "any such gate errs BOTH ways\n"
        "it deploys a harmful candidate\n"
        "and abstains on a helpful one,\n"
        "so abstention is a COST",
        fs=FS, fc="#faf0ef", ec=ACC, color=INK)


def main():
    os.makedirs(FIGDIR, exist_ok=True)
    fig, ax = new_axes()
    panel_titles(ax)
    build(ax)

    pdf = os.path.join(FIGDIR, "fig1_method.pdf")
    fig.savefig(pdf, format="pdf")
    fig.savefig(os.path.join(OUT, "fig1_render_100.png"), dpi=100)
    plt.close(fig)

    from PIL import Image
    rgb = Image.open(os.path.join(OUT, "fig1_render_100.png")).convert("RGB")
    w, h = rgb.size
    rgb.resize((int(w * 3), int(h * 3)), Image.LANCZOS).convert("L").save(
        os.path.join(OUT, "print_grayscale.png"))
    print("wrote", pdf)
    print("wrote", os.path.join(OUT, "fig1_render_100.png"))
    print("wrote", os.path.join(OUT, "print_grayscale.png"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
