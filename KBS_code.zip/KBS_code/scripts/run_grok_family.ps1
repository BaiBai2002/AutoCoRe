# Grok family batch — the last planned family of the proposer study.
#
# Adds a sixth grounded family to tab:frontier (confv2grok_47_r0..r2, three draws, matching the
# Gemini/GLM rows) and its second-task variant (confpush_grok_47_r0..r1, two draws, matching the
# GPT-6 push coverage). Same frozen pipeline as every other family: grounded interface, K=12,
# probe 50K x 3 seeds, finals 300K x 5 seeds, frozen deploy-or-abstain rule. Idempotent; 3
# attempts per draw. This batch was planned before any Grok draw existed (run_grounded_queue.ps1
# lists grok_47 among the strong families); nothing here is tuned after seeing results.
#
# Usage:  powershell -NoProfile -File scripts/run_grok_family.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/grok_family.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) { $m | Tee-Object -FilePath $log -Append | Out-Null }

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "Grok family batch starting (grounded spread x3, grounded push x2)"

foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confv2grok_47_r$r" -Extra @("--provider", "grok_47", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}
foreach ($r in 0, 1) {
    Run-Draw -Tag "confpush_grok_47_r$r" -Extra @("--env", "simple_push_v3",
        "--provider", "grok_47", "--llm-v2", "--k-llm", "12", "--k-raw", "6",
        "--k-rand", "12", "--rep-offset", "$r")
}

Write-Log "GROK_FAMILY_DONE"
