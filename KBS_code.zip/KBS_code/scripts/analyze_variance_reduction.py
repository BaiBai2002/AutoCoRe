"""Characterises shaping as a variance-reduction intervention.

Three quantities are reported for every configuration, using the per-seed
evaluation curves:

* level        -- mean final raw task return across seeds;
* dispersion   -- mean across evaluation checkpoints of the between-seed
                  standard deviation of the raw return, i.e. how widely the
                  seeds fan out during training;
* worst case   -- the return of the least successful seed at the end.

The diagnostic of interest is the relation between a configuration's gain and
the unshaped return of the *same* seed. A strong negative relation means the
gain is concentrated on seeds where unshaped training fails, which is the
signature of variance reduction rather than of a uniform improvement.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")
ARM_ALIASES = {"cov_legacy": "pot_legacy", "cov_cal": "pot_cal"}


def canonical_arm(name: str) -> str:
    return ARM_ALIASES.get(name, name)


def setting_key(run: dict) -> str:
    """Environment label that also separates algorithm and agent count."""
    env = run.get("env")
    algo = run.get("algo") or "ippo"
    n = run.get("num_agents")
    if algo == "ippo" and n is None:
        return str(env)
    suffix = f" [{algo}" + (f", N={n}]" if n is not None else "]")
    return f"{env}{suffix}"


def load_envs(tags: list[str]) -> dict[str, dict]:
    envs: dict[str, dict] = {}
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        for r in raw:
            if r.get("status") != "completed":
                continue
            entry = envs.setdefault(setting_key(r), {"arms": {}})
            entry["arms"].setdefault(canonical_arm(r["arm"]), {})[r["seed"]] = r["curve"]
    return envs


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    denom = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / denom) if denom > 0 else float("nan")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags", default="main,main2,ref,push")
    ap.add_argument("--base", default="base")
    args = ap.parse_args()

    envs = load_envs([t for t in args.tags.split(",") if t])
    out_rows = []
    for env_name, pool in sorted(envs.items(), key=lambda kv: str(kv[0])):
        arms = pool["arms"]
        if args.base not in arms:
            continue
        seeds = sorted(set.intersection(*[set(v) for v in arms.values()]))
        if len(seeds) < 3:
            continue
        n_points = min(len(arms[a][s]) for a in arms for s in seeds)
        steps = [arms[args.base][seeds[0]][i][0] for i in range(n_points)]

        prof = {}
        for a in arms:
            mat = np.asarray([[arms[a][s][i][1] for i in range(n_points)] for s in seeds],
                             dtype=float)
            prof[a] = {
                "mean_curve": mat.mean(axis=0),
                "sd_curve": mat.std(axis=0, ddof=1),
                "final": mat[:, -1],
            }

        base_final = prof[args.base]["final"]
        base_disp = float(prof[args.base]["sd_curve"].mean())
        print(f"\n=== env={env_name}  seeds={seeds} (n={len(seeds)}) ===")
        print(f"  base: mean final {base_final.mean():.2f}, "
              f"final sd {base_final.std(ddof=1):.2f}, "
              f"range [{base_final.min():.2f}, {base_final.max():.2f}], "
              f"mean between-seed sd over training {base_disp:.2f}")
        print(f"{'arm':>14s} {'mean final':>11s} {'final sd':>9s} {'disp':>9s} "
              f"{'disp ratio':>11s} {'worst seed':>11s} {'corr(base,gain)':>16s} "
              f"{'seeds better':>13s}")
        for a in sorted(arms, key=lambda x: -prof[x]["final"].mean()):
            final = prof[a]["final"]
            disp = float(prof[a]["sd_curve"].mean())
            diffs = final - base_final
            ratio = disp / base_disp if base_disp > 0 else float("nan")
            corr = float(np.corrcoef(base_final, diffs)[0, 1]) if diffs.std() > 0 else float("nan")
            out_rows.append({
                "env": env_name, "arm": a, "n_seeds": len(seeds),
                "mean_final": float(final.mean()),
                "final_sd": float(final.std(ddof=1)),
                "between_seed_dispersion": disp,
                "dispersion_ratio_vs_base": ratio,
                "worst_seed": float(final.min()),
                "worst_seed_gain": float(final.min() - base_final.min()),
                "mean_gain": float(diffs.mean()),
                "corr_base_level_vs_gain": corr,
                "spearman_base_level_vs_gain": spearman(base_final, diffs),
                "seeds_improved": int(np.sum(diffs > 0)),
            })
            print(f"{a:>14s} {final.mean():>11.2f} {final.std(ddof=1):>9.2f} "
                  f"{disp:>9.2f} {ratio:>11.2f} {final.min():>11.2f} {corr:>+16.3f} "
                  f"{int(np.sum(diffs > 0))}/{len(seeds):<11d}")

        steps_arr = np.asarray(steps, dtype=float)
        for a in arms:
            if a == args.base:
                continue
            r = [x for x in out_rows if x["env"] == env_name and x["arm"] == a][0]
            r["tightens_fraction"] = float(
                np.mean(prof[a]["sd_curve"] < prof[args.base]["sd_curve"]))
            r["steps"] = steps_arr.tolist()

        # Insurance decomposition: does the shaped outcome collapse to a level L
        # that is nearly independent of the seed, and is the mean gain explained
        # by how much baseline mass lies below that level?
        print(f"\n  insurance decomposition (L = mean shaped outcome; "
              f"base median = {np.median(base_final):.2f})")
        print(f"  {'arm':>14s} {'L':>9s} {'sd(L)':>8s} {'p(base<L)':>10s} "
              f"{'recovery':>9s} {'penalty':>9s} {'mean gain':>10s} {'check':>8s}")
        for a in sorted(arms):
            if a == args.base:
                continue
            y = prof[a]["final"]
            L = float(y.mean())
            below = base_final < L
            p = float(below.mean())
            recovery = float((L - base_final[below]).mean()) if below.any() else 0.0
            penalty = float((L - base_final[~below]).mean()) if (~below).any() else 0.0
            gain = float((y - base_final).mean())
            check = p * recovery + (1 - p) * penalty
            row = [x for x in out_rows if x["env"] == env_name and x["arm"] == a][0]
            row.update({"collapse_level_L": L, "collapse_sd": float(y.std(ddof=1)),
                        "p_base_below_L": p, "recovery": recovery, "penalty": penalty,
                        "decomposition_check": check})
            print(f"  {a:>14s} {L:>9.2f} {y.std(ddof=1):>8.2f} {p:>10.2f} "
                  f"{recovery:>9.2f} {penalty:>9.2f} {gain:>+10.2f} {check:>+8.2f}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "variance_reduction.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(out_rows, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
