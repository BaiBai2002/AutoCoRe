"""Route B pilot: how to spend a *fixed total budget* --- probe breadth vs final training.

G3 deliverable of the 2026-09-30 manual (PBRS_Q1_期刊定位与研究重构). The manual's
blocking question B2 was that the earlier "search-cost" trend was an accounting identity;
this pilot instead holds the **total** interaction budget ``B`` fixed per replicate and
varies how it is split between *probing candidates* and *training the deployed candidate*.

Design (one task, one learner, one replicate, two held-out seeds --- a pilot, not a
confirmatory run):

* task ``simple_spread_v3`` (N=3), learner IPPO, horizon 80, single probe draw (seed 200).
* a fixed pool of 24 random direction candidates; the pool is **nested** so the n=4 and
  n=12 allocations are prefixes of the n=24 one.
* three allocations at ``B = 150{,}000`` interactions per replicate, differing only in how
  many candidates are probed:  ``n`` candidates probed at 5K each, the remainder spent on
  the deployed candidate's final training:
      n = 24  ->  search 120K, final 30K
      n = 12  ->  search  60K, final 90K
      n =  4  ->  search  20K, final 130K
* baselines: unshaped training at the *same* B (150K) --- the honest comparator when the
  budget is fixed --- and a "fixed" rule that deploys candidate 0 at each allocation's final.

For each allocation we report, on held-out raw return: the deployed candidate under the
``mean>0`` and ``argmax`` rules, the no-shaping baseline at B, the paired difference, and a
per-bin wrong-decision indicator.  For the smallest allocation we also train every candidate
at its final budget to get a true oracle (selection regret).  Negative outcomes are kept.

Runs are cached by a run id that encodes the probe and final budgets (the D34 lesson), and
namespaced with ``--run-tag``-style ``RUN_TAG`` so they never collide with the paper's caches.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bps_gate_experiment as H  # noqa: E402

ENV = "simple_spread_v3"
ALGO = "ippo"
N = 3
MC = 80
PROBE_STEPS = 5_000
PROBE_SEED = 200
FINAL_SEEDS = [100, 101]
N_CANDIDATES = 24
ALLOC_NS = [24, 12, 4]
SPARSE = 0.4
RHO = 0.2

PROJECT_ROOT = H.PROJECT_ROOT
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "pilot_b_budget.json")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--budget", type=int, default=150_000)
    ap.add_argument("--workers", type=int, default=10)
    ap.add_argument("--run-tag", default="pb1")
    args = ap.parse_args()

    H.RUN_TAG = args.run_tag
    B = args.budget

    states = H.collect_reference_states(ENV, max_cycles=MC, n_episodes=6, seed=0, num_agents=N)
    bank = H.FeatureBank().fit(states)
    rng = np.random.default_rng(10_000)
    cands = H.sample_directions(N_CANDIDATES, bank.dim, rng, sparse_prob=SPARSE)
    keys = [H.weight_key(np.asarray(w, dtype=float)) for w in cands]
    print(f"bank dim={bank.dim}  candidates={N_CANDIDATES}  B={B}", flush=True)

    def probe_rid(k: str) -> str:
        return H.run_id(ENV, ALGO, N, "probe", f"p{PROBE_STEPS}_{k}", PROBE_SEED)

    def final_rid(key: str, seed: int, steps: int) -> str:
        # the *seed* is the run-id seed; the *steps* are encoded in the key so two seeds never
        # share a cache slot (a bug caught by the bogus `_s30000` run-id suffix).
        return H.run_id(ENV, ALGO, N, "final", f"f{steps}_{key}", seed)

    # ---- probes: the unshaped baseline and every candidate, all at PROBE_STEPS -------------
    probe_jobs = [(probe_rid("base"), None)] + [(probe_rid(k), w) for k, w in zip(keys, cands)]
    probe: dict[str, float] = {}

    def do_probe(job):
        rid, w = job
        return rid, H.train(ENV, ALGO, N, PROBE_STEPS, PROBE_SEED, w, rid, RHO, max_cycles=MC)

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for rid, val in pool.map(do_probe, probe_jobs):
            if val is not None:
                probe[rid] = val
    base_probe = probe.get(probe_rid("base"))

    # ---- for each allocation, decide which candidates to final-train -----------------------
    final_jobs: list[tuple[str, int, int, np.ndarray | None]] = []

    def add_final(key: str, steps: int) -> None:
        w = None if key == "base" else cands[keys.index(key)]
        for f in FINAL_SEEDS:
            final_jobs.append((key, steps, f, w))

    # baseline at the fixed total B (identical for every allocation)
    for f in FINAL_SEEDS:
        final_jobs.append(("base", B, f, None))

    allocations = []
    for n in ALLOC_NS:
        final_steps = B - n * PROBE_STEPS
        sub = keys[:n]
        gains = {}
        for k in sub:
            if base_probe is not None and probe_rid(k) in probe:
                gains[k] = probe[probe_rid(k)] - base_probe
        ranked = sorted(gains, key=lambda k: -gains[k]) if gains else []
        argmax_key = ranked[0] if ranked else None
        meanpos_key = argmax_key if (argmax_key and gains[argmax_key] > 0) else None
        # final-train: fixed(0), mean>0 selection, argmax selection, plus the n=4 oracle set
        add_final(keys[0], final_steps)
        if meanpos_key:
            add_final(meanpos_key, final_steps)
        if argmax_key:
            add_final(argmax_key, final_steps)
        allocations.append({"n": n, "final_steps": final_steps, "pool": sub,
                            "gains": gains, "argmax_key": argmax_key,
                            "meanpos_key": meanpos_key})
        if n == min(ALLOC_NS):  # oracle: train every candidate in the smallest pool
            for k in sub:
                add_final(k, final_steps)

    final_vals: dict[tuple[str, int], dict[int, float]] = {}

    def do_final(job):
        key, steps, seed, w = job
        rid = final_rid(key, seed, steps)
        return key, steps, seed, H.train(ENV, ALGO, N, steps, seed, w, rid, RHO, max_cycles=MC)

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for key, steps, seed, val in pool.map(do_final, final_jobs):
            if val is not None:
                final_vals.setdefault((key, steps), {})[seed] = val

    def mean_at(key: str, steps: int) -> float | None:
        vals = list(final_vals.get((key, steps), {}).values())
        return float(np.mean(vals)) if vals else None

    base_mean = mean_at("base", B)
    result = {"env": ENV, "algo": ALGO, "N": N, "B": B, "probe_steps": PROBE_STEPS,
              "probe_seed": PROBE_SEED, "final_seeds": FINAL_SEEDS,
              "baseline_mean_at_B": base_mean, "allocations": []}

    for a in allocations:
        fs = a["final_steps"]
        fixed = mean_at(keys[0], fs)
        dep_meanpos = (mean_at(a["meanpos_key"], fs) if a["meanpos_key"] else None)
        dep_argmax = (mean_at(a["argmax_key"], fs) if a["argmax_key"] else None)
        oracle = None
        if a["n"] == min(ALLOC_NS):
            vals = [mean_at(k, fs) for k in a["pool"]]
            vals = [v for v in vals if v is not None]
            oracle = max(vals) if vals else None
        result["allocations"].append({
            "n_candidates": a["n"], "final_steps": fs,
            "probe_gains": a["gains"],
            "mean_gt_0": {"abstain": a["meanpos_key"] is None,
                          "deployed_mean": dep_meanpos if a["meanpos_key"] else base_mean,
                          "delta_vs_B": (dep_meanpos - base_mean) if dep_meanpos is not None else 0.0},
            "argmax": {"deployed_mean": dep_argmax,
                       "delta_vs_B": (dep_argmax - base_mean) if dep_argmax is not None else None},
            "fixed_cand0": {"deployed_mean": fixed,
                            "delta_vs_B": (fixed - base_mean) if fixed is not None else None},
            "oracle_mean": oracle,
            "argmax_regret": (oracle - dep_argmax) if (oracle is not None and dep_argmax is not None) else None,
        })

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print("\n=== Route B fixed-budget pilot ===")
    print(f"no-shaping baseline at B={B}: {base_mean}")
    for a in result["allocations"]:
        print(f"n={a['n_candidates']:<3d} final={a['final_steps']:<7d} "
              f"mean>0 delta={a['mean_gt_0']['delta_vs_B']} "
              f"argmax delta={a['argmax']['delta_vs_B']} "
              f"fixed0 delta={a['fixed_cand0']['delta_vs_B']} oracle={a['oracle_mean']}")
    print("wrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
