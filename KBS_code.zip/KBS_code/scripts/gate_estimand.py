"""G1 / B1: put the gate's two probability events on the same footing.

The released calibration table divided ``Pr(harmful | open)`` --- a *posterior* over deployments ---
by the nominal ``alpha``, which bounds a *different* event: the per-candidate probability of opening
when the candidate is not actually beneficial. The ratio is therefore not a violation of the bound.
This script recomputes, from the stored per-cell rates, the quantities that *are* comparable:

    Pr(harmful)        = Pr(h|open)*Pr(open) + Pr(h|shut)*Pr(shut)
    Pr(open | harmful) = Pr(h|open)*Pr(open) / Pr(harmful)      <- the event alpha covers
    ratio              = Pr(open | harmful) / alpha

Writes ``artifacts/diagnostics/gate_estimand.json``.
"""
from __future__ import annotations

import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SRC = os.path.join(ROOT, "artifacts", "diagnostics", "gate_calibration.json")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "gate_estimand.json")


def main() -> None:
    rows, headline = [], None
    for r in json.load(open(SRC, encoding="utf-8")):
        po, pho, phs, a = r["p_open"], r["p_harmful_given_open"], r["p_harmful_given_shut"], r["nominal_alpha"]
        ph = pho * po + phs * (1 - po)
        p_open_given_harm = (pho * po / ph) if ph else None
        rec = {
            "z": r["z"], "n": r["n"], "nominal_alpha": a,
            "p_open": po, "p_harmful_given_open": pho, "p_harmful": round(ph, 4),
            "p_open_given_harmful": round(p_open_given_harm, 4) if p_open_given_harm else None,
            "ratio_same_event": round(p_open_given_harm / a, 2) if (p_open_given_harm and a) else None,
            "ratio_mixed_events_INVALID": round(pho / a, 2) if a else None,
        }
        rows.append(rec)
        if r["z"] == 2.0 and r["n"] == 5:
            headline = rec

    out = {
        "note": ("ratio_same_event compares Pr(open|harmful) with the bound alpha; "
                 "ratio_mixed_events_INVALID is the retracted comparison of Pr(harmful|open) with alpha"),
        "rows": rows,
        "headline_z2_n5": headline,
    }
    json.dump(out, open(OUT, "w", encoding="utf-8"), indent=2)
    print(json.dumps(out["headline_z2_n5"], indent=2))


if __name__ == "__main__":
    main()
