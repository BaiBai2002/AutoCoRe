"""Shared figure style for the manuscript.

One place defines the typography, the colour semantics and the export settings, so that
every figure in the paper looks like part of one document. Two things matter beyond
aesthetics and are enforced here:

* **Colour semantics are fixed.** Each experimental family has one colour and keeps it
  in every figure; red/green are reserved for *harmful* and *beneficial* outcomes, never
  for a category, so a reader can carry the meaning across panels. Colour is never the
  only cue -- markers and line styles repeat the distinction, which matters for
  greyscale printing and for colour-vision deficiency.
* **Fonts are embedded as Type 42.** IEEE requires embeddable fonts; Type 3 (the
  matplotlib default for PDF) is rejected by some production pipelines.

Every figure is written twice: a PDF for LaTeX and a PNG for visual inspection, so
overlaps can be caught without compiling the paper.
"""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
FIGDIR = os.path.join(PROJECT_ROOT, "paper", "figures")

# --------------------------------------------------------------------- palette
# Families (categorical): distinguishable in greyscale and for deuteranopia.
FAMILY = {
    "mpe": "#1f4e79",          # dark blue
    "sisl": "#b5651d",         # burnt orange
    "butterfly": "#6a4c93",    # muted purple
}
# Outcomes (semantic): reserved, never used as a category colour.
OUTCOME = {
    "positive": "#2e7d32",     # green: replicated / beneficial
    "negative": "#b3261e",     # red: harmful
    "neutral": "#4d4d4d",      # grey: reference lines, ceilings, no-ops
    "grid": "0.86",
    "band": "0.93",
    "muted": "#7a7a7a",
}
MARKERS = ["o", "s", "^", "D", "v", "P"]
LINESTYLES = ["-", "--", "-.", ":"]


def apply_style() -> None:
    plt.rcParams.update({
        # typography: Times-compatible serif with STIX math (pairs with IEEEtran)
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Nimbus Roman", "Liberation Serif",
                       "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 7.0,
        "axes.titlesize": 7.5,
        "axes.labelsize": 7.0,
        "xtick.labelsize": 6.4,
        "ytick.labelsize": 6.4,
        "legend.fontsize": 6.2,
        # geometry
        "axes.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "lines.linewidth": 1.2,
        "lines.markersize": 3.4,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.6,
        "ytick.major.size": 2.6,
        # legends: frameless, tight, never on top of the data
        "legend.frameon": False,
        "legend.handlelength": 1.4,
        "legend.handletextpad": 0.4,
        "legend.columnspacing": 0.9,
        "legend.labelspacing": 0.25,
        "legend.borderaxespad": 0.2,
        # export
        "figure.dpi": 140,
        "savefig.dpi": 400,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.grid": False,
    })


def grid(ax, axis: str = "both") -> None:
    ax.grid(axis=axis, ls=":", lw=0.5, color=OUTCOME["grid"], zorder=0)
    ax.set_axisbelow(True)


def legend_outside(ax, ncol: int = 2, y: float = -0.30) -> None:
    """Legend below the axes, so it can never overlap the data."""
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, y), ncol=ncol,
              borderaxespad=0.0, handlelength=1.4, columnspacing=1.0)


def save(fig, name: str, also_png: bool = True) -> None:
    os.makedirs(FIGDIR, exist_ok=True)
    pdf = os.path.join(FIGDIR, f"{name}.pdf")
    fig.savefig(pdf)
    if also_png:
        fig.savefig(os.path.join(FIGDIR, f"{name}.png"), dpi=150)
    plt.close(fig)
    print("wrote", os.path.normpath(pdf))
