"""Emit paper_upgrade/claim_evidence_matrix.csv from the real claim ledger.

Phase 0 of the ESWA task book. Column schema follows the task book:
claim / section / evidence figure-table / raw-run path / closest prior work / confidence / missing evidence / action.
Section and prior-work mappings are curated maps keyed by claim_id (not invented per-row).
"""
from __future__ import annotations

import csv
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER = os.path.join(ROOT, "workplan", "claim_ledger.csv")
OUT_DIR = os.path.join(ROOT, "paper_upgrade")

SECTION = {
    "F1": "Sec IV-A (F1) / Table II", "F1-unc": "Sec IV-A / Table II",
    "F1-rhofree": "Sec IV-A (rho*-free form)", "F1-N": "Sec IV-A / Fig 3",
    "F1-dose": "Sec IV-A / Fig 3", "F1-cal": "Sec IV-A / Fig 3",
    "F2-sign": "Sec IV-C (F2)", "F2-bias": "Sec IV-C / Table IV",
    "F2-select": "Sec IV-C / Table IV", "F2-screen": "Sec IV-C / Fig 4",
    "F3": "Sec IV-D (F3) / Table III", "F3-fix": "Sec IV-D / Table III",
    "POOL": "Sec V-A", "H2": "Sec V-A", "H3": "Sec V-A (negative)",
    "DEPLOY": "Sec V-B / Table V", "REGIME": "Sec V-B / Table VI",
    "DEPLOY-conf": "Sec V-B / Table V (confirmatory)",
    "RHO": "Sec V-C", "KAZ": "Sec V-D", "LEARN": "Sec III-A / Table I",
    "REF": "Sec IV-A (robustness)", "CTRL": "Sec V-E (controls)",
    "QMIX": "Sec V-F (learner swap)", "PREFLIGHT-BLIND": "Sec V-G",
    "BRANCH-B-BLOCKED": "Supplement S1 (defect 5)",
    "PROBE-COST": "Supplement S4", "B-ALLOC": "Supplement S5",
    "ALLOC-ADAPT": "Supplement S5",
}

NEAREST = {
    "F1": "PBRS feasibility (Ng et al. 1999; Devlin & Kudenko 2012)",
    "F1-unc": "bootstrap CIs (Efron 1979)", "F1-rhofree": "dominance criterion (ours)",
    "F1-N": "coefficient scaling (Hu et al. 2020)", "F1-dose": "dose-response (ours)",
    "F1-cal": "potential shaping scale (ours)",
    "F2-sign": "reward-reporting bias (ours)", "F2-bias": "shaped-criterion OPE (ours)",
    "F2-select": "post-selection bias (ours)", "F2-screen": "Kendall/Spearman selection (ours)",
    "F3": "selective prediction (El-Yaniv & Wiener 2010)", "F3-fix": "threshold calibration (ours)",
    "POOL": "best-arm identification (Jamieson & Talwalkar 2016)", "H2": "fidelity/cheap proxy (ours)",
    "H3": "magnitude prediction (ours, refuted)", "DEPLOY": "LCB selection (Even-Dar et al. 2006)",
    "REGIME": "regime diagnosis (ours)", "DEPLOY-conf": "pre-registered replication (ours)",
    "RHO": "target dominance (ours)", "KAZ": "resolution limit (ours)",
    "LEARN": "learnability audit (ours)", "REF": "reference-policy sensitivity (ours)",
    "CTRL": "simple baselines (ours)", "QMIX": "value decomposition (Rashid et al. 2018)",
    "PREFLIGHT-BLIND": "injected-defect testing (ours)", "BRANCH-B-BLOCKED": "(blocked)",
    "PROBE-COST": "search cost vs selection quality (ours)",
    "B-ALLOC": "budget allocation (Successive Halving, Jamieson & Talwalkar 2016)",
    "ALLOC-ADAPT": "successive halving (Karnin et al. 2013)",
}

ACTION = {
    "supported": "keep; cite artefact",
    "supported-with-caveat": "keep; state the caveat in the caption",
    "refuted": "keep as a declared negative result",
    "refuted-as-evidence": "keep; explicitly non-evidential",
    "blocked": "keep as a declared blocked branch",
}


def main() -> None:
    os.makedirs(OUT_DIR, exist_ok=True)
    rows = list(csv.DictReader(open(LEDGER, encoding="utf-8")))
    out = os.path.join(OUT_DIR, "claim_evidence_matrix.csv")
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["claim_id", "claim", "section", "evidence_artifacts", "raw_run_path",
                    "closest_prior_work", "confidence", "missing_evidence", "action", "status"])
        for r in rows:
            cid = r["claim_id"]
            status = r["status"].strip()
            w.writerow([cid, r["claim"], SECTION.get(cid, "TBD"), r["artifacts"],
                        r["analysis_script"], NEAREST.get(cid, "TBD"), r["evidence_level"],
                        r.get("boundary_or_caveat", ""), ACTION.get(status, "review"), status])
    print(json.dumps({"rows": len(rows), "out": os.path.relpath(out, ROOT)}, indent=2))


if __name__ == "__main__":
    main()
