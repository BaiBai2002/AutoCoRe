"""Figure 1: the paper's method and architecture.

A single schematic that carries the whole argument at a glance:
  (a) the three degrees of freedom the literature leaves uncontrolled,
  (b) the seven protocol rules as a pipeline,
  (c) the regime-dependent outcome that the protocol predicts.
Rendered as a vector PDF with the same type/colour conventions as the other figures.
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "font.size": 7.0,
})

INK = "#1a1a1a"
BLUE = "#1f4e79"      # inputs / uncontrolled quantities
ORANGE = "#b5651d"    # protocol rules
GREEN = "#2e7d32"     # beneficial outcome
RED = "#b3261e"       # harmful / inert outcome
GREY = "#4d4d4d"      # neutral
FILL = {"blue": "#eaf1f8", "orange": "#fbf1e6", "green": "#eaf5eb",
        "red": "#fbebea", "grey": "#f2f2f2"}


def box(ax, x, y, w, h, text, edge, fill, fs=6.4, weight="normal", align="center"):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.012",
        linewidth=0.7, edgecolor=edge, facecolor=fill, zorder=2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, color=INK, weight=weight, zorder=3, linespacing=1.25)


def arrow(ax, p0, p1, color=GREY, style="-|>", lw=0.8, ls="-", rad=0.0):
    ax.add_patch(FancyArrowPatch(
        p0, p1, arrowstyle=style, mutation_scale=6.5, linewidth=lw,
        color=color, linestyle=ls, zorder=1,
        connectionstyle=f"arc3,rad={rad}"))


def main() -> None:
    fig, ax = plt.subplots(figsize=(3.45, 3.30))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # ---------------------------------------------------------------- band (a)
    ax.text(0.0, 0.985, r"(a) three degrees of freedom left uncontrolled",
            fontsize=6.6, color=INK, weight="bold", va="top")
    y, h = 0.855, 0.095
    w, gap = 0.305, 0.042
    xs = [0.0, w + gap, 2 * (w + gap)]
    labels = [r"coefficient $\lambda$" "\n" r"(grid too small:"
              "\n" r"$4.4$–$101\times$ short)",
              r"reporting return" "\n" r"$R_{\mathrm{raw}}$ invariant vs" "\n" r"$R_{\mathrm{shaped}}$ biased",
              r"search budget" "\n" r"$S$ charged to" "\n" r"the baseline"]
    for x, t in zip(xs, labels):
        box(ax, x, y, w, h, t, BLUE, FILL["blue"])
    ax.text(0.5, y - 0.028, r"each is measurable before training",
            ha="center", va="top", fontsize=5.9, color=GREY, style="italic")

    arrow(ax, (0.5, y - 0.002), (0.5, 0.775), BLUE, lw=0.9)

    # ---------------------------------------------------------------- band (b)
    ax.text(0.0, 0.775, r"(b) protocol P1–P7  (machine-checkable)",
            fontsize=6.6, color=INK, weight="bold", va="top")
    y2, h2 = 0.615, 0.105
    stages = [(r"calibrate", r"$\lambda^\star$ in closed" "\n" r"form, no search"),
              (r"propose", r"candidate pool" "\n" r"$\Phi$ directions"),
              (r"probe", r"short paired" "\n" r"raw-return run"),
              (r"decide", r"deploy iff" "\n" r"estimate $\geq 0$"),
              (r"report", r"raw return, paired" "\n" r"$95\%$ interval")]
    n = len(stages)
    w2 = (1.0 - (n - 1) * 0.022) / n
    cx = []
    for i, (top, bot) in enumerate(stages):
        x = i * (w2 + 0.022)
        cx.append(x + w2 / 2)
        box(ax, x, y2, w2, h2, top + "\n" + bot, ORANGE, FILL["orange"], fs=5.5)
        if i:
            arrow(ax, (cx[i - 1] + w2 / 2, y2 + h2 / 2), (x, y2 + h2 / 2), ORANGE)
    ax.text(0.0, y2 - 0.018,
            r"P5 feasibility first · P6 configuration-keyed caches · P7 seeded sources"
            "\n" r"P1 raw return · P2 disjoint seed roles · P3 budget matching · P4 paired statistics",
            fontsize=5.5, color=GREY, va="top", linespacing=1.3)

    arrow(ax, (0.5, y2 - 0.062), (0.5, 0.415), ORANGE, lw=0.9)

    # ---------------------------------------------------------------- band (c)
    ax.text(0.0, 0.415, r"(c) the protocol predicts the outcome from the regime",
            fontsize=6.6, color=INK, weight="bold", va="top")
    y3, h3 = 0.135, 0.185
    w3, g3 = 0.300, 0.050
    out = [(r"grid infeasible", r"scale-infeasible:" "\n" r"no permitted" "\n"
            r"coefficient reaches" "\n" r"the target dominance", RED, FILL["red"]),
           (r"learning regime", r"$+25.74$, replicated" "\n" r"at $+29.39$;" "\n"
            r"bounded by team" "\n" r"size and pool", GREEN, FILL["green"]),
           (r"failing regime", r"$+109.9$ vs a budget-" "\n" r"matched baseline;" "\n"
            r"selection worth" "\n" r"$+967$", GREEN, FILL["green"])]
    for i, (top, bot, edge, fill) in enumerate(out):
        x = i * (w3 + g3)
        box(ax, x, y3, w3, h3, top + "\n" + bot, edge, fill, fs=5.5)
        ax.text(x + w3 / 2, y3 - 0.020, f"{i+1}",
                ha="center", va="top", fontsize=5.6, color=edge, weight="bold")
    ax.text(0.5, 0.095, r"abstention is a cost, not a safeguard: under a value-decomposition"
                        "\n" r"learner the gate declines although every candidate helps",
            ha="center", va="top", fontsize=5.5, color=GREY, style="italic", linespacing=1.3)

    fig.subplots_adjust(left=0.005, right=0.995, top=0.995, bottom=0.005)
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(here, "..", "paper", "figures")
    os.makedirs(out_dir, exist_ok=True)
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(out_dir, f"fig_method.{ext}"), dpi=400,
                    bbox_inches="tight", pad_inches=0.02)
    print("wrote", os.path.normpath(os.path.join(out_dir, "fig_method.pdf")))


if __name__ == "__main__":
    main()
