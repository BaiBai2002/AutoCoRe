"""Authoritative agent counts for every environment used in the feasibility table."""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))


def main() -> None:
    from autocore.envs.pettingzoo_mpe import make_mpe_env
    from autocore.envs.vec_pz import make_pz_env, PZ_ENV_IDS

    print("PZ_ENV_IDS =", PZ_ENV_IDS)
    for env_id in ("simple_spread_v3", "simple_reference_v3", "simple_push_v3",
                   "simple_speaker_listener_v4"):
        try:
            env = make_mpe_env(env_id, max_cycles=80)
            inner = getattr(env, "aec_env", env)
            agents = list(getattr(inner, "possible_agents", getattr(env, "possible_agents", [])))
            print(f"{env_id:<30s} num_agents = {len(agents)}   agents = {agents}")
            env.close()
        except Exception as e:  # noqa: BLE001
            print(f"{env_id:<30s} ERROR {type(e).__name__}: {e}")

    for env_id in ("pursuit_v5", "knights_archers_zombies_v11"):
        try:
            env = make_pz_env(env_id, max_cycles=100)
            names = list(env.possible_agents)
            print(f"{env_id:<30s} num_agents = {len(names)}   agents = {names[:6]}"
                  f"{' ...' if len(names) > 6 else ''}")
            env.close()
        except Exception as e:  # noqa: BLE001
            print(f"{env_id:<30s} ERROR {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
