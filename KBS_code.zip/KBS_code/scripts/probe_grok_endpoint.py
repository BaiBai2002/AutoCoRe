"""One-shot availability probe for the Grok endpoint on the proxy.

Reads UUAPI_GROK_KEY from .env (never prints the key) and issues a minimal chat completion.
Used to decide whether to relaunch the Grok retry rounds. Exit 0 = endpoint healthy.
"""
import json
import os
import sys
import urllib.request

KEY = ""
for ln in open(".env", encoding="utf-8"):
    ln = ln.strip()
    if ln.startswith("UUAPI_GROK_KEY") and "=" in ln:
        KEY = ln.split("=", 1)[1].strip().strip('"').strip("'")

if not KEY:
    print("no UUAPI_GROK_KEY in .env")
    sys.exit(2)

req = urllib.request.Request(
    "https://uuapi.shop/v1/chat/completions",
    data=json.dumps({
        "model": "grok-4.7",
        "messages": [{"role": "user", "content": "reply with the single word: ok"}],
        "max_tokens": 5,
    }).encode(),
    headers={"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"},
)
try:
    r = urllib.request.urlopen(req, timeout=90)
    body = json.loads(r.read())
    print("probe status:", r.status, "| content:", body["choices"][0]["message"]["content"][:40])
except Exception as e:
    print("probe FAILED:", str(e)[:200])
    sys.exit(1)
