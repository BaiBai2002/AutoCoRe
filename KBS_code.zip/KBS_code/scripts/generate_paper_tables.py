"""Generate LaTeX tables from experiment data."""
import sys, os, json, glob
from pathlib import Path
from collections import defaultdict
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from autocore.utils.io import ensure_dir

OUT = PROJECT_ROOT / "artifacts/tables/paper_ready"
ensure_dir(str(OUT))

PAPER_NAMES = {"base":"Base","human_pb":"Human PB","random_valid_single":"Rand-1","random_valid_best_of_k":"Rand-K",
               "llm_schema_only":"LLM-Sch","autocore_single":"AutoCoRe","autocore_select":"CoReSel","autocore_consensus":"Consensus"}
METHODS = ["base","human_pb","random_valid_single","random_valid_best_of_k","llm_schema_only","autocore_single","autocore_select","autocore_consensus"]

def load():
    all_data = []
    for f in glob.glob(str(PROJECT_ROOT / "artifacts/processed/ckpt_*.json")):
        try: all_data.extend(json.load(open(f)))
        except: pass
    completed = [r for r in all_data if r.get('status') == 'completed' and r.get('final_return') is not None]
    em = defaultdict(list)
    for r in completed: em[(r['env_id'], r['method'])].append(r['final_return'])
    envs = sorted(set(e for e,_ in em.keys()))
    return em, envs, completed

def table1_main(em, envs):
    lines = [r"\begin{table}[htbp]", r"\centering",
             r"\caption{Main Results: Mean Return $\pm$ Std (5 seeds, 100K steps)}",
             r"\label{tab:main}", r"\small",
             r"\begin{tabular}{l"+"c"*len(METHODS)+"}", r"\toprule",
             "Env & " + " & ".join(PAPER_NAMES[m] for m in METHODS) + r" \\ \midrule"]
    for e in envs:
        row = [e.replace('_','\\_')]
        for m in METHODS:
            vals = em.get((e,m), [])
            if len(vals)>=2:
                mu,sd = np.mean(vals), np.std(vals, ddof=1)
                row.append(f"${mu:.0f}\\pm{sd:.0f}$")
            elif len(vals)==1: row.append(f"${vals[0]:.0f}$")
            else: row.append("--")
        lines.append(" & ".join(row)+r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT/"table1_main_results.tex").write_text('\n'.join(lines))
    print(f"  table1_main_results.tex saved")

def table5_lambda(em, envs):
    lines = [r"\begin{table}[htbp]", r"\centering",
             r"\caption{Lambda Ablation: shaping\_lambda = [0.00, 0.05, 0.10, 0.20, 0.30]}",
             r"\label{tab:lambda}", r"\small",
             r"\begin{tabular}{lccccc}", r"\toprule",
             r"\lambda & Final Return & AUC & Reward Dominance & Success Rate & n \\ \midrule"]
    for lam in [0.0, 0.05, 0.10, 0.20, 0.30]:
        lines.append(f"{lam:.2f} & -- & -- & -- & -- & -- \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (OUT/"table5_lambda_ablation.tex").write_text('\n'.join(lines))
    print(f"  table5_lambda_ablation.tex saved")

if __name__ == "__main__":
    em, envs, completed = load()
    table1_main(em, envs)
    table5_lambda(em, envs)
    print(f"\nLaTeX tables generated in {OUT}")
