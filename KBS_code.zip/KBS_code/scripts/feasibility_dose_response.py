"""Causal validation of the magnitude-feasibility claim (F1).

F1 states that a fixed coefficient grid lambda <= 0.4 is *magnitude-infeasible*:
the coefficient that makes the telescoping shaping total visible relative to the
episode return, lambda* = rho* E|R| / E|dPhi|, lies one to two orders of magnitude
above the grid ceiling on every (task, potential) pair we audit. That claim is, so
far, a calculation. This script tests it causally: it holds the potential fixed and
sweeps lambda from inside the grid through and past lambda*, training to the full
budget on held-out seeds and reporting the raw task return (P1).

Predictions
-----------
* For lambda on the grid (<= 0.4) the raw return should be indistinguishable from
  the unshaped baseline, because the shaping total is a fraction of a percent of
  the return.
* Once lambda approaches lambda* the shaping total reaches the target dominance
  (rho* = 0.2) and the raw return should depart from the baseline. The direction
  is not predicted by the theory; the magnitude of the departure is.

Every run is keyed by (environment, potential, lambda, budget, seed), so a cached
record is never reused for a different configuration (protocol rule P6).

Usage:
    python scripts/feasibility_dose_response.py --workers 8
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BPS_DIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "dose")
TRAIN = os.path.join(PROJECT_ROOT, "scripts", "stage0_train.py")

NUM_ENVS = 16
HORIZON = 80
HIDDEN = 512

# (dsl file, lambda grid, lambda*). lambda* is the calibrated coefficient for
# rho*=0.2 from artifacts/diagnostics/lambda_feasibility.json.
PLAN = [
    ("spread_coverage.json", 74.7885,
     [0.05, 0.4, 2.0, 5.0, 10.0, 20.0, 40.0, 74.7885, 150.0, 400.0]),
    ("spread_assignment.json", 29.0996,
     [0.05, 0.4, 1.0, 3.0, 5.0, 10.0, 15.0, 29.0996, 60.0, 150.0]),
]


def realized_steps(steps: int) -> int:
    unit = NUM_ENVS * HORIZON
    return max(1, int(steps) // unit) * unit


def rid_of(dsl: str, lam: float, seed: int) -> str:
    stem = os.path.splitext(os.path.basename(dsl))[0]
    return f"dose_{stem}_lam{lam:.4f}_s{seed}"


def load_valid(path: str, env: str, dsl: str | None, lam: float, steps: int,
               max_cycles: int) -> float | None:
    """Return final_return iff the cached record matches this configuration exactly."""
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
    except Exception:
        return None
    if rec.get("env") != env:
        return None
    want_dsl = os.path.basename(dsl) if dsl else None
    if rec.get("dsl") != want_dsl:
        return None
    if abs(float(rec.get("shaping_lambda", -1.0)) - float(lam)) > 1e-6:
        return None
    if int(rec.get("steps", -1)) != realized_steps(steps):
        return None
    if int(rec.get("max_cycles", -1)) != int(max_cycles):
        return None
    return float(rec["final_return"])


def run_one(env: str, num_agents: int | None, dsl: str | None, lam: float,
            seed: int, steps: int, max_cycles: int, tag: str,
            outdir: str = OUTDIR) -> float | None:
    rid = tag
    out = os.path.join(outdir, f"{rid}.json")
    val = load_valid(out, env, dsl, lam, steps, max_cycles)
    if val is not None:
        return val
    cmd = [sys.executable, "-u", TRAIN, "--env", env, "--steps", str(steps),
           "--eval-every", str(max(steps // 8, 5000)), "--seed", str(seed),
           "--hidden", str(HIDDEN), "--entropy", "0.003", "--epochs", "8",
           "--minibatches", "8", "--algo", "ippo", "--out", out, "--tag", rid,
           "--rho-target", "0.2", "--max-cycles", str(max_cycles)]
    if num_agents is not None:
        cmd += ["--num-agents", str(num_agents)]
    if dsl:
        dsl_path = dsl if os.path.isabs(dsl) else os.path.join(
            PROJECT_ROOT, "configs", "dsl", os.path.basename(dsl))
        cmd += ["--dsl", dsl_path, f"--lam={lam:.6f}"]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    if proc.returncode != 0 or not os.path.exists(out):
        sys.stderr.write(f"run failed {tag}: {(proc.stderr or '')[-300:]}\n")
        return None
    return load_valid(out, env, dsl, lam, steps, max_cycles)


def bootstrap_ci(x: np.ndarray, n_boot: int = 10_000, alpha: float = 0.05,
                 seed: int = 0) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return float("nan"), float("nan")
    idx = rng.integers(0, x.size, size=(n_boot, x.size))
    means = x[idx].mean(axis=1)
    lo, hi = np.quantile(means, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--num-agents", type=int, default=None)
    ap.add_argument("--seeds", default="100,101,102,103,104")
    ap.add_argument("--steps", type=int, default=300_000)
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--potential-filter", default=None,
                    help="run only this potential (substring match on the DSL file name)")
    ap.add_argument("--lam-filter", default=None,
                    help="comma-separated subset of coefficients to run (default: all)")
    ap.add_argument("--tag-suffix", default="", help="suffix appended to run ids")
    ap.add_argument("--baseline-kind", default="final", choices=["final", "probe"],
                    help="which cached unshaped baseline to pair against")
    ap.add_argument("--outdir-suffix", default="",
                    help="suffix for the run-output directory (keeps sweeps separate)")
    args = ap.parse_args()

    outdir = OUTDIR + args.outdir_suffix
    os.makedirs(outdir, exist_ok=True)
    seeds = [int(s) for s in args.seeds.split(",")]

    # Baseline (lambda = 0) is the unshaped run already produced by the
    # deployment audit; it is reused only if it matches the same budget/horizon.
    base = {}
    for s in seeds:
        p = os.path.join(BPS_DIR,
                         f"{args.env}_ippo_Nna_{args.baseline_kind}_base_s{s}.json")
        v = load_valid(p, args.env, None, 0.0, args.steps, args.max_cycles)
        if v is not None:
            base[s] = v
    if len(base) < 2:
        raise SystemExit(f"not enough valid {args.baseline_kind} baselines")
    print(f"baseline ({len(base)} seeds): mean {np.mean(list(base.values())):.2f}")

    jobs = []
    lam_keep = None
    if args.lam_filter:
        lam_keep = {float(x) for x in args.lam_filter.split(",")}
    for dsl, lam_star, grid in PLAN:
        if args.potential_filter and args.potential_filter not in dsl:
            continue
        for lam in grid:
            if lam_keep is not None and not any(abs(lam - k) < 1e-6 for k in lam_keep):
                continue
            for s in seeds:
                jobs.append((dsl, lam, lam_star, s))
    print(f"planning {len(jobs)} shaped runs ({len(seeds)} seeds)")

    results: dict[tuple[str, float], dict[int, float]] = {}

    def task(job):
        dsl, lam, _, s = job
        val = run_one(args.env, args.num_agents, dsl, lam, s, args.steps,
                      args.max_cycles, rid_of(dsl, lam, s), outdir=outdir)
        return dsl, lam, s, val

    done = 0
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for dsl, lam, s, val in pool.map(task, jobs):
            done += 1
            if val is not None:
                results.setdefault((dsl, lam), {})[s] = val
            if done % 10 == 0:
                print(f"  {done}/{len(jobs)} runs complete", flush=True)

    rows = []
    for dsl, lam_star, grid in PLAN:
        print(f"\n{os.path.basename(dsl)}  (lambda* = {lam_star:.2f})")
        print(f"{'lambda':>10s} {'rho/lambda*':>12s} {'raw return':>12s} "
              f"{'delta vs base':>14s} {'95% CI':>22s} {'sign':>5s}")
        for lam in grid:
            got = results.get((dsl, lam), {})
            common = [s for s in seeds if s in got and s in base]
            if len(common) < 2:
                print(f"{lam:>10.4f} {'-':>12s} {'(incomplete)':>12s}")
                continue
            d = np.asarray([got[s] - base[s] for s in common], dtype=float)
            lo, hi = bootstrap_ci(d)
            mean = float(d.mean())
            sign = "+" if lo > 0 else ("-" if hi < 0 else "0")
            rho_ratio = lam / lam_star
            rows.append({"potential": os.path.basename(dsl), "lambda": lam,
                         "lambda_star": lam_star, "rho_over_rhostar": rho_ratio,
                         "n": len(common), "raw_mean": float(np.mean([got[s] for s in common])),
                         "delta": mean, "ci_lo": lo, "ci_hi": hi,
                         "significantly_different": bool(lo > 0 or hi < 0)})
            print(f"{lam:>10.4f} {rho_ratio:>12.3f} "
                  f"{np.mean([got[s] for s in common]):>12.2f} {mean:>+14.2f} "
                  f"{f'[{lo:+.2f},{hi:+.2f}]':>22s} {sign:>5s}")
        bm = float(np.mean(list(base.values())))
        rows.append({"potential": os.path.basename(dsl), "lambda": 0.0,
                     "lambda_star": lam_star, "rho_over_rhostar": 0.0, "n": len(base),
                     "raw_mean": bm, "delta": 0.0,
                     "ci_lo": float("nan"), "ci_hi": float("nan"),
                     "significantly_different": False})

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics",
                       f"feasibility_dose_response{args.tag_suffix}.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"env": args.env, "num_agents": args.num_agents,
                   "steps": args.steps, "seeds": seeds,
                   "grid_ceiling": 0.4, "base_mean": float(np.mean(list(base.values()))),
                   "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
