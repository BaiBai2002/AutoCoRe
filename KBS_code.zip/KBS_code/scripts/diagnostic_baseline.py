"""Training-free diagnostics as a ranking baseline for the probe (H2).

H2 claims the probe ranks candidates better than any diagnostic that requires no
training. This script makes that comparison concrete on the rich pool: it computes
four training-free diagnostics for every candidate that was trained to the full
budget on the held-out seeds, and reports the rank correlation of each diagnostic
--- and of the probe score --- against the held-out paired gain.

Diagnostics are computed from random rollouts only (``alignment_diagnostics``), so
they consume no training budget and are a fair, strong baseline for a claim about
*selection*.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bps_gate_experiment import realized_steps  # noqa: E402
from autocore.selection.landscape_search import FeatureBank, LinearPotential  # noqa: E402
from autocore.selection.magnitude_calibration import (  # noqa: E402
    alignment_diagnostics, collect_reference_states,
)

OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
RESULT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics",
                      "diagnostic_baseline.json")


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def bootstrap_spearman(x, y, n_boot: int = 5000, seed: int = 0):
    n = x.size
    if n < 3:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    obs = spearman(x, y)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        if np.unique(x[idx]).size < 3 or np.unique(y[idx]).size < 3:
            continue
        vals.append(spearman(x[idx], y[idx]))
    if not vals:
        return obs, float("nan"), float("nan")
    lo, hi = np.percentile(vals, [2.5, 97.5])
    return obs, float(lo), float(hi)


def bootstrap_spearman_diff(x1, x2, y, n_boot: int = 5000, seed: int = 0):
    """Paired bootstrap CI for Spearman(x1,y) - Spearman(x2,y) over candidates."""
    n = x1.size
    if n < 3:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    diffs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        if np.unique(y[idx]).size < 3:
            continue
        s1 = spearman(x1[idx], y[idx])
        s2 = spearman(x2[idx], y[idx])
        if np.isfinite(s1) and np.isfinite(s2):
            diffs.append(s1 - s2)
    if not diffs:
        return float("nan"), float("nan"), float("nan")
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return float(np.mean(diffs)), float(lo), float(hi)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default=os.path.join(OUTDIR, "spread_n3_fullpool_summary.json"))
    ap.add_argument("--eps-episodes", type=int, default=40)
    args = ap.parse_args()

    with open(args.summary, encoding="utf-8") as f:
        s = json.load(f)
    env, algo, n_agents = s["env"], s["algo"], s["num_agents"]

    # candidate weights, from the decision tables (flat schedule probes the pool)
    weights: dict[str, list[float]] = {}
    for d in s.get("decisions", []):
        for c in d.get("probe_table", []):
            if "weights" in c:
                weights.setdefault(c["key"], c["weights"])

    # probe score (selection stage) and held-out gain (evaluation stage)
    probe = {}
    for d in s.get("decisions", []):
        for c in d.get("probe_table", []):
            if "probe_mean_gain" in c:
                probe.setdefault(c["key"], float(c["probe_mean_gain"]))

    prefix = f"{env}_{algo}_N{'na' if n_agents is None else n_agents}_final_"
    seed_vals: dict[str, dict[int, float]] = {}
    for key in weights:
        got = {}
        for path in sorted(glob.glob(os.path.join(OUTDIR, prefix + key + "_s*.json"))):
            with open(path, encoding="utf-8") as f:
                rec = json.load(f)
            if int(rec.get("steps", -1)) == realized_steps(s["final_steps"]):
                got[int(rec["seed"])] = float(rec["final_return"])
        if got:
            seed_vals[key] = got
    base = {}
    for path in sorted(glob.glob(os.path.join(OUTDIR, prefix + "base_s*.json"))):
        with open(path, encoding="utf-8") as f:
            rec = json.load(f)
        if int(rec.get("steps", -1)) == realized_steps(s["final_steps"]):
            base[int(rec["seed"])] = float(rec["final_return"])
    if not base:
        raise SystemExit("no baseline runs")

    max_cycles = int(s.get("max_cycles", 80))
    states = collect_reference_states(env, max_cycles=max_cycles, n_episodes=6,
                                      seed=0, num_agents=n_agents)
    bank = FeatureBank().fit(states)

    keys, held, probe_scores = [], [], []
    diag: dict[str, list[float]] = {}
    for key, w in weights.items():
        got = seed_vals.get(key)
        if not got:
            continue
        shared = sorted(set(got) & set(base))
        if len(shared) < 2:
            continue
        pot = LinearPotential(bank, w)
        d = alignment_diagnostics(env, pot, max_cycles=max_cycles,
                                  n_episodes=args.eps_episodes, seed=0)
        keys.append(key)
        held.append(float(np.mean([got[t] - base[t] for t in shared])))
        probe_scores.append(probe.get(key, float("nan")))
        for name in ("shaping_reward_alignment", "non_interference",
                     "value_alignment", "reward_redundancy_r2"):
            diag.setdefault(name, []).append(float(getattr(d, name)))

    y = np.asarray(held, dtype=float)
    rows = []
    print(f"{env} [{algo}]  n_candidates={len(keys)}   held-out paired gain")
    print(f"{'predictor':<28s} {'Spearman':>9s}  95% CI")
    x_probe = np.asarray(probe_scores, dtype=float)
    sp, lo, hi = bootstrap_spearman(x_probe, y)
    rows.append({"predictor": "probe (uses 50K training)", "spearman": sp,
                 "ci": [lo, hi], "requires_training": True})
    print(f"{'probe (50K training)':<28s} {sp:>+9.3f}  [{lo:+.3f}, {hi:+.3f}]")
    for name, vals in diag.items():
        x = np.asarray(vals, dtype=float)
        sp, lo, hi = bootstrap_spearman(x, y)
        dm, dlo, dhi = bootstrap_spearman_diff(x_probe, x, y)
        rows.append({"predictor": name, "spearman": sp, "ci": [lo, hi],
                     "delta_vs_probe": dm, "delta_ci": [dlo, dhi],
                     "requires_training": False})
        print(f"{name:<28s} {sp:>+9.3f}  [{lo:+.3f}, {hi:+.3f}]   "
              f"probe$-$diag {dm:+.3f} [{dlo:+.3f}, {dhi:+.3f}]")

    out = {"setting": f"{env} [{algo}]", "n_candidates": len(keys),
           "final_steps": s["final_steps"], "rows": rows}
    os.makedirs(os.path.dirname(RESULT), exist_ok=True)
    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("\nwrote", os.path.normpath(RESULT))


if __name__ == "__main__":
    main()
