"""Availability probe for candidate *new* model families (part 44 extension).

1. GETs /v1/models on the uuapi proxy with the OpenAI key (discovers servable model ids).
2. Issues minimal chat completions for the untested configured providers
   (claude_opus_47, mimo_v2_5_pro) to confirm the endpoints work.

Keys are read from .env and never printed. Exit 0 = at least the configured-family
probes responded; the model list is informational.
"""
import json
import os
import sys
import urllib.request

ENV = {}
for ln in open(".env", encoding="utf-8"):
    ln = ln.strip()
    if ln and not ln.startswith("#") and "=" in ln:
        k, v = ln.split("=", 1)
        ENV[k.strip()] = v.strip().strip('"').strip("'")


def get(url, key):
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {key}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def complete(url, key, model, prompt="reply with the single word: ok"):
    req = urllib.request.Request(
        url,
        data=json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 5,
        }).encode(),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=120) as r:
        body = json.loads(r.read())
        return r.status, body["choices"][0]["message"]["content"][:40]


base = ENV.get("UUAPI_BASE_URL", "https://uuapi.shop/v1").rstrip("/")
oa = ENV.get("UUAPI_OPENAI_KEY", "")

print("== uuapi model list ==")
try:
    lst = get(f"{base}/models", oa)
    ids = sorted({m.get("id", "?") for m in lst.get("data", [])})
    print(f"{len(ids)} models:")
    for i in ids:
        print("  ", i)
except Exception as e:
    print("model list FAILED:", str(e)[:200])

candidates = [
    ("claude_opus_47", f"{base}/chat/completions", ENV.get("UUAPI_ANTHROPIC_KEY", ""), "claude-opus-4-7"),
    ("mimo_v2_5_pro", (ENV.get("MIMO_V2_5_PRO_BASE_URL") or "https://api.mimo.run/v1").rstrip("/") + "/chat/completions",
     ENV.get("MIMO_V2_5_PRO_API_KEY", ""), ENV.get("MIMO_V2_5_PRO_MODEL", "mimo-v2.5-pro")),
]

ok = 0
print("== candidate family probes ==")
for name, url, key, model in candidates:
    if not key:
        print(f"{name}: NO KEY in .env")
        continue
    try:
        status, content = complete(url, key, model)
        print(f"{name} ({model}): status {status} | {content}")
        ok += 1
    except Exception as e:
        print(f"{name} ({model}) FAILED: {str(e)[:200]}")

sys.exit(0 if ok > 0 else 1)