"""Emit the two artifacts the preflight validator needs to decide P1 and P5 on this study.

The validator refuses to pass a rule it cannot decide, so it returns UNKNOWN for
  * P1 — unless records declare the *fixed policy* precondition (a training sweep cannot
    test P1, because different coefficients give different policies), and
  * P5 — unless records carry the reference scales E|R| and |dPhi| from the calibration.

This script reads what already exists in the repository and writes normalised records:

  audit/preflight/runs.json     a list of run records, including
                                  * the fixed-policy raw-vs-shaped evaluation (P1),
                                  * one record per (task, potential) with the reference
                                    scales (P5), and
                                  * the budgeted-audit runs, normalised to the schema
                                    `control`/`steps`/`seed` (P3, P6, P7).
  audit/preflight/summaries.json a list of audit summaries (P2, P3, P4, P6).

Nothing is invented: every field is copied from a stored artifact, and the raw-vs-shaped
pairs come from `reporting_gap.json`, which is a fixed-policy evaluation by construction.
"""
from __future__ import annotations

import glob
import json
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
D = os.path.join(ROOT, "artifacts", "diagnostics")
G = os.path.join(ROOT, "artifacts", "bps_gate")
OUT = os.path.join(ROOT, "audit", "preflight")


def load(path: str):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    runs: list[dict] = []

    # ---- P1: fixed-policy evaluation (raw vs shaped at a swept coefficient) ---------------
    gap_path = os.path.join(D, "reporting_gap.json")
    n_fixed = 0
    if os.path.exists(gap_path):
        gap = load(gap_path)
        for row in gap.get("rows", []) if isinstance(gap, dict) else gap:
            lam = row.get("lambda", row.get("shaping_lambda"))
            raw = row.get("raw_return", row.get("raw", row.get("R_raw")))
            shaped = row.get("shaped_return", row.get("shaped", row.get("R_shaped")))
            if lam is None or raw is None:
                continue
            runs.append({
                "run_id": f"fixedpolicy_{row.get('env', row.get('env_id', 'ref'))}_lam{lam}",
                "env_id": row.get("env", row.get("env_id", "simple_spread_v3")),
                "algo": "reference-policy", "num_agents": row.get("num_agents"),
                "max_cycles": row.get("max_cycles", 80), "steps": 0,
                "seed": row.get("seed", 0), "control": "evaluation",
                "shaping_lambda": float(lam), "final_return": float(raw),
                "shaped_return": float(shaped) if shaped is not None else None,
                "fixed_policy": True,
            })
            n_fixed += 1

    # ---- P5: reference scales per (task, potential) ---------------------------------------
    feas_path = os.path.join(D, "lambda_feasibility.json")
    n_scales = 0
    if os.path.exists(feas_path):
        feas = load(feas_path)
        for r in feas.get("rows", []):
            runs.append({
                "run_id": f"scales_{r['env_id']}_{r['potential'].replace('.json', '')}",
                "env_id": r["env_id"], "algo": "reference-policy",
                "num_agents": None, "max_cycles": r["max_cycles"], "steps": 0,
                "seed": 0, "control": "evaluation", "shaping_lambda": 1.0,
                "final_return": None,
                "mean_abs_return": r["mean_abs_return"],
                "mean_abs_delta_phi": r["mean_abs_delta_phi"],
            })
            n_scales += 1

    # ---- P3 / P6 / P7: the budgeted audit runs, normalised -------------------------------
    n_runs = 0
    for path in sorted(glob.glob(os.path.join(G, "*_s1*.json"))):
        try:
            obj = load(path)
        except Exception:
            continue
        recs = obj if isinstance(obj, list) else [obj]
        for rec in recs:
            if not isinstance(rec, dict) or "steps" not in rec:
                continue
            rid = os.path.basename(path).replace(".json", "")
            # the stage is declared by the file name when the record itself omits `control`
            ctrl = str(rec.get("control", "")).lower()
            is_base = ctrl in ("base", "baseline", "bm") or bool(
                re.search(r"_(base|baseline|bm)", rid))
            runs.append({
                "run_id": rid,
                "env_id": rec.get("env", rec.get("env_id")),
                "algo": rec.get("algo"), "num_agents": rec.get("num_agents"),
                "max_cycles": rec.get("max_cycles"), "steps": rec.get("steps"),
                "seed": rec.get("seed"), "control": "baseline" if is_base else "shaped",
                "stage": "baseline" if is_base else "final",
                "shaping_lambda": rec.get("shaping_lambda"),
                "final_return": rec.get("final_return"),
            })
            n_runs += 1

    # ---- summaries (P2, P3, P4, P6) --------------------------------------------------------
    summaries = []
    for name in ("bps_n3_rho020_summary.json", "bps_confirm_summary.json"):
        path = os.path.join(G, name)
        if os.path.exists(path):
            s = load(path)
            s["final_seeds"] = [int(x) for x in s.get("final_seeds", [])]
            s["probe_pool"] = [int(x) for x in s.get("probe_pool", [])]
            summaries.append(s)

    with open(os.path.join(OUT, "runs.json"), "w", encoding="utf-8") as f:
        json.dump(runs, f, indent=1)
    with open(os.path.join(OUT, "summaries.json"), "w", encoding="utf-8") as f:
        json.dump(summaries, f, indent=1)

    print(f"wrote {os.path.relpath(os.path.join(OUT, 'runs.json'), ROOT)}: "
          f"{len(runs)} records ({n_fixed} fixed-policy, {n_scales} scale rows, {n_runs} audit runs)")
    print(f"wrote {os.path.relpath(os.path.join(OUT, 'summaries.json'), ROOT)}: {len(summaries)} summaries")


if __name__ == "__main__":
    main()
