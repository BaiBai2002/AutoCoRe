import os, re, subprocess, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PDF = os.path.join(ROOT, "paper", "main.pdf")
xml = subprocess.run(["pdftotext", "-bbox", PDF, "-"],
                     capture_output=True, text=True, encoding="utf-8").stdout
pages = re.split(r"<page\b", xml)[1:]
print("total pages", len(pages))
first = int(sys.argv[1]) if len(sys.argv) > 1 else 1
for i, p in enumerate(pages, 1):
    if i < first:
        continue
    m = re.search(r'width="([\d.]+)" height="([\d.]+)"', p)
    W, H = float(m.group(1)), float(m.group(2))
    Wm = W / 2.0
    ws = re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">', p)
    L = [float(d) for a, b, c, d in ws if float(a) < Wm]
    R = [float(d) for a, b, c, d in ws if float(a) >= Wm]
    lL = (max(L) if L else 0) / 72.0
    lR = (max(R) if R else 0) / 72.0
    print(f"p{i:>2} H={H/72:.2f} nL={len(L)} nR={len(R)} lastL={lL:.2f}in lastR={lR:.2f}in")
