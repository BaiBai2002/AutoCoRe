"""Flowchart of the bounded deployment rule (Section: Bounded Deployment Rule).

Renders the five-step decision procedure as a single-column figure: two cheap
gates (feasibility, pool richness) that can stop the experiment before any final
training is spent, then a probe-ranked selection under budget matching, then a
gate whose error rate is measured rather than assumed.
"""
from __future__ import annotations

import os

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
FIGDIR = os.path.join(PROJECT_ROOT, "paper", "figures")


def main() -> None:
    import sys as _sys
    _sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from figstyle import OUTCOME, apply_style, save
    apply_style()
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

    fig, ax = plt.subplots(figsize=(3.45, 4.85))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 20)
    ax.axis("off")

    b_proc, b_dec, b_stop = "#dce6f1", "#fdf0d5", "#f6d8d8"
    e_proc, e_dec, e_stop = "#2f5496", "#b8860b", "#9c2b2b"

    def box(y, text, kind="proc", h=1.9, w=7.2, x=1.4):
        fc, ec = {"proc": (b_proc, e_proc), "dec": (b_dec, e_dec),
                  "stop": (b_stop, e_stop)}[kind]
        p = FancyBboxPatch((x, y - h / 2), w, h, boxstyle="round,pad=0.16,rounding_size=0.28",
                           linewidth=0.9, edgecolor=ec, facecolor=fc, zorder=2)
        ax.add_patch(p)
        ax.text(x + w / 2, y, text, ha="center", va="center", fontsize=7.2,
                color="#111111", zorder=3, linespacing=1.35)

    def arrow(y0, y1, x=5.0):
        ax.add_patch(FancyArrowPatch((x, y0), (x, y1), arrowstyle="-|>",
                                     mutation_scale=9, lw=0.9,
                                     color=OUTCOME["neutral"], zorder=1))

    def side_arrow(y, text, x0=8.6):
        ax.add_patch(FancyArrowPatch((x0, y), (9.7, y), arrowstyle="-|>",
                                     mutation_scale=8, lw=0.9,
                                     color=OUTCOME["muted"], zorder=1))
        ax.text(9.75, y, text, ha="left", va="center", fontsize=6.3,
                color=OUTCOME["neutral"])

    box(19.0, "candidate pool + coefficient space", "proc", h=1.5)
    box(16.6, "P5: compute $\\lambda^\\star=\\rho^\\star\\,\\mathbb{E}|R|/\\mathbb{E}|\\Delta\\Phi|$, bracket $\\lambda$ below it\nand require the task to be learnable and resolvable", "proc", h=2.2, w=8.4, x=0.8)
    box(14.0, "a usable $\\lambda$ exists for some candidate?", "dec", h=1.9, w=8.4, x=0.8)
    box(11.5, "pool rich enough for a short probe?", "dec", h=1.9, w=8.4, x=0.8)
    box(9.0, "probe-rank under budget matching (P2, P3)", "proc", h=1.6, w=8.4, x=0.8)
    box(6.4, "LCB gate opens, using an error rate\nmeasured on held-out seeds (F3)?", "dec", h=2.0, w=8.4, x=0.8)
    box(3.6, "final-train; report $R_{\\mathrm{raw}}$ (P1)\nwith paired bootstrap intervals (P4)", "proc", h=2.0, w=8.4, x=0.8)

    arrow(18.25, 17.7)
    arrow(15.5, 14.95)
    arrow(13.05, 12.45)
    arrow(10.55, 9.8)
    arrow(8.2, 7.4)
    arrow(5.4, 4.6)

    side_arrow(14.0, "no\ndo not shape")
    side_arrow(11.5, "no\nenrich pool")
    side_arrow(6.4, "no\ndeploy nothing")

    ax.text(5.0, 0.6, "P6: cache keyed by the full configuration    P7: every stochastic source seeded",
            ha="center", va="center", fontsize=6.1, color=OUTCOME["neutral"],
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.75", lw=0.7))

    fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.01)
    save(fig, "fig_deployment_rule")


if __name__ == "__main__":
    main()
