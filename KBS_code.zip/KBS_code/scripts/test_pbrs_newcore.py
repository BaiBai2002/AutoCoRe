"""Verify the PBRS implementation in the rebuilt core.

Checks, for a fixed policy and a fixed episode:
  1. the discounted shaping sequence telescopes:
         sum_t gamma^(t-1) F_t  ==  gamma^H * Phi(s_H) - Phi(s_0)
  2. lambda = 0 leaves the environment reward exactly unchanged
  3. the shaped reward returned by VecMPE equals raw + lambda*(gamma*Phi' - Phi)
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

from autocore.algos.vec_mpe import VecMPE, state_from_world
from autocore.dsl.compiler import compile_dsl
from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.shaping.potentials import PotentialFunction, ShapingConfig

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
GAMMA = 0.99
MAX_CYCLES = 80


def load_potential(name: str, lam: float) -> PotentialFunction:
    with open(os.path.join(PROJECT_ROOT, "configs", "dsl", name), encoding="utf-8") as f:
        dsl = json.load(f)
    compiled = compile_dsl(dsl)
    return PotentialFunction(compiled, ShapingConfig(gamma=GAMMA, shaping_lambda=lam,
                                                     potential_clip=(-1.0, 1.0)))


def episode_with_logging(pf: PotentialFunction, seed: int):
    env = make_mpe_env("simple_spread_v3", max_cycles=MAX_CYCLES)
    names = list(env.possible_agents)
    env.reset(seed=seed)
    rng = np.random.default_rng(seed)
    phis = [float(pf.compute_potential(state_from_world(env.aec_env.world)))]
    raws, shapes, acts = [], [], []
    for _ in range(MAX_CYCLES):
        a = {n: int(rng.integers(5)) for n in names}
        res = env.step(a)
        raws.append(float(sum(res[1].values())))
        phis.append(float(pf.compute_potential(state_from_world(env.aec_env.world))))
        acts.append(a)
    for t in range(MAX_CYCLES):
        shapes.append(pf.config.shaping_lambda * (GAMMA * phis[t + 1] - phis[t]))
    env.close()
    return np.asarray(raws), np.asarray(shapes), np.asarray(phis), acts


def main() -> None:
    ok = True
    for dsl_name in ("spread_coverage.json", "spread_assignment.json"):
        for lam in (0.0, 0.2, 0.5):
            pf = load_potential(dsl_name, lam)
            raws, shapes, phis, _ = episode_with_logging(pf, seed=3)
            H = len(raws)
            discs = GAMMA ** np.arange(H)
            lhs = float(np.sum(discs * shapes))
            rhs = float(pf.config.shaping_lambda * ((GAMMA ** H) * phis[H] - phis[0]))
            err = abs(lhs - rhs)
            good = err < 1e-6 * max(1.0, abs(rhs))
            ok &= good
            print(f"{dsl_name:<26s} lambda={lam:<4}  telescoping lhs={lhs:+.8f} "
                  f"rhs={rhs:+.8f} |err|={err:.2e} {'OK' if good else 'FAIL'}")

    print("\nlambda = 0 -> shaped reward identical to raw reward")
    pf0 = load_potential("spread_assignment.json", 0.0)
    raws, shapes, _, _ = episode_with_logging(pf0, seed=5)
    print(f"  max |shaping| = {np.abs(shapes).max():.3e} "
          f"{'OK' if np.abs(shapes).max() == 0.0 else 'FAIL'}")

    print("\nVecMPE shaped reward == raw env reward + lambda*(gamma*Phi' - Phi)")
    pf = load_potential("spread_assignment.json", 0.2)
    lam = 0.2
    vec = VecMPE("simple_spread_v3", num_envs=1, max_cycles=MAX_CYCLES, base_seed=11,
                 potential_fn=pf.compute_potential, shaping_lambda=lam, gamma=GAMMA)
    plain = make_mpe_env("simple_spread_v3", max_cycles=MAX_CYCLES)
    names = list(vec.agent_names)
    vec.reset(seeds=[11])
    plain.reset(seed=11)
    rng = np.random.default_rng(11)
    max_dev = 0.0
    for _ in range(MAX_CYCLES):
        phi_prev = pf.compute_potential(state_from_world(plain.aec_env.world))
        act = rng.integers(0, 5, size=(1, vec.num_agents))
        out = vec.step(act)
        raw_res = plain.step({n: int(act[0, i]) for i, n in enumerate(names)})
        phi_curr = pf.compute_potential(state_from_world(plain.aec_env.world))
        shaping = lam * (GAMMA * phi_curr - phi_prev)
        for i, n in enumerate(names):
            expected = float(raw_res[1][n]) + shaping
            max_dev = max(max_dev, abs(float(out.rewards[0, i]) - expected))
    vec.close()
    plain.close()
    good3 = max_dev < 1e-5
    ok &= good3
    print(f"  max per-agent deviation = {max_dev:.3e} {'OK' if good3 else 'FAIL'}")
    print("\nRESULT:", "ALL CHECKS PASSED" if ok else "FAILURES PRESENT")


if __name__ == "__main__":
    main()
