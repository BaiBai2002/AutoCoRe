# Grounded-proposer experiment queue (detached runner).
#
# Priority order:
#   1. Strong non-domestic models (GPT-6 Astra, Gemini 3.1 Pro, Claude Sonnet 4.6, Grok 4.7),
#      grounded interface, N=3 IPPO -- the novelty lever: does a stronger model actually
#      beat the hand-designed potential once the interface is fixed?
#   2. Finish the grounded cross-configuration check (N=5, then MAPPO).
#
# Reference arms (random-valid K=12, hand-designed) are identical across providers and are
# served from cache, so the marginal cost of each new model is its own LLM arm only.
#
# Usage:  powershell -NoProfile -File scripts/run_grounded_queue.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/grounded_queue.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Invoke-Replicate {
    param([string]$Tag, [string[]]$Extra)
    Write-Output "=== $Tag ===" | Tee-Object -FilePath $log -Append
    $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
        "--replicates", "1",
        "--probe-steps", "50000", "--probe-seeds", "200,201,202",
        "--tag", $Tag)
    & python @argv 2>&1 | Tee-Object -FilePath $log -Append |
        Select-String -Pattern "deploy ->|=== summary" | Out-Null
}

# ---- 1. strong models, grounded, N=3 IPPO, 300K finals x 5 seeds
$strong = @("gpt_6_astra", "gemini_31_pro", "claude_sonnet_46", "grok_47")
$draws = @{ "gpt_6_astra" = 3; "gemini_31_pro" = 3; "claude_sonnet_46" = 2; "grok_47" = 2 }
foreach ($p in $strong) {
    for ($r = 0; $r -lt $draws[$p]; $r++) {
        Invoke-Replicate -Tag "confv2${p}_r$r" -Extra @(
            "--provider", $p, "--llm-v2", "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
            "--rep-offset", "$r", "--final-steps", "300000",
            "--final-seeds", "100,101,102,103,104")
    }
}

# ---- 2. finish the grounded cross-configuration check on DeepSeek
foreach ($r in 1, 2) {
    Invoke-Replicate -Tag "confv2n5_r$r" -Extra @(
        "--provider", "deepseek_v4_flash", "--num-agents", "5", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
        "--rep-offset", "$r", "--final-steps", "300000",
        "--final-seeds", "100,101,102,103,104")
}
foreach ($r in 0, 1, 2) {
    Invoke-Replicate -Tag "confv2mappo_r$r" -Extra @(
        "--provider", "deepseek_v4_flash", "--algo", "mappo", "--llm-v2",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
        "--rep-offset", "$r", "--final-steps", "200000",
        "--final-seeds", "100,101,102,103")
}

Write-Output "GROUNDED_QUEUE_DONE" | Tee-Object -FilePath $log -Append
