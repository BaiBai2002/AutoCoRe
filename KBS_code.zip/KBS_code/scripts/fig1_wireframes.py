"""Low-fidelity wireframes for the Figure-1 redesign (T1).

Two schemes are drawn so the information architecture can be judged before any effort is spent on
the vector redraw (T2):

  A  audit-workflow mainline + P1-P7 guardrails + explicit exits
  B  audit of the standard pipeline + three measurement-failure classes + consequence

Both are deliberately grey, unpolished, and number-free: they exist to test the *argument* the
figure makes, not its styling. Output: fig1/wireframe_A.{pdf,png}, fig1/wireframe_B.{pdf,png}.

Run:  python scripts/fig1_wireframes.py
"""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "fig1")

INK = "#222222"
BOX = "#f4f4f4"
EDGE = "#8a8a8a"
ACC = "#b3261e"          # exits / failures only
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 7.0,
    "pdf.fonttype": 42,
    "figure.dpi": 200,
})


def box(ax, x, y, w, h, text, *, fs=6.6, fc=BOX, ec=EDGE, ls="-", bold=False):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.35,rounding_size=1.4",
        linewidth=0.7, edgecolor=ec, facecolor=fc, linestyle=ls, mutation_aspect=1.0))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
            color=INK, linespacing=1.35,
            fontweight=("bold" if bold else "normal"))


def arrow(ax, p, q, *, ls="-", color=INK, rad=0.0, lw=0.9):
    ax.add_patch(FancyArrowPatch(
        p, q, arrowstyle="-|>", mutation_scale=8, linewidth=lw,
        linestyle=ls, color=color, connectionstyle=f"arc3,rad={rad}",
        shrinkA=1.5, shrinkB=1.5))


def new_axes(w=7.2, h=2.95):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")
    fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.01)
    return fig, ax


# ------------------------------------------------------------------ scheme A #
def scheme_a():
    fig, ax = new_axes(7.2, 2.95)

    ax.text(1, 97, "(a) a result depends on four\nquantities", fontsize=7.2,
            fontweight="bold", va="top", color=INK)
    a_items = [
        "λ   coefficient\n(team term is Nλ)",
        "ρ*  target dominance\n(free choice)",
        "R   which return is\nreported (raw / shaped)",
        "S   search budget\n(charged to baseline)",
    ]
    for i, t in enumerate(a_items):
        y = 76 - i * 19
        box(ax, 2, y, 26, 15, t, fs=6.3)
    ax.text(15, 3, "all measurable before /\nduring training", fontsize=6.0,
            ha="center", va="bottom", color=EDGE, style="italic")

    # column 2: workflow spine
    ax.text(35, 97, "(b) P1–P7 guard a decision\nworkflow", fontsize=7.2,
            fontweight="bold", va="top", color=INK)
    stages = [
        "1 · characterise regime\nfeasibility · learnability",
        "2 · search the pool\nprobe on the RAW return",
        "3 · confirm on held-out\npaired per-seed stats",
        "4 · decide\ndeploy / abstain",
    ]
    ys = [72, 54, 36, 18]
    for y, t in zip(ys, stages):
        box(ax, 35, y, 34, 13, t, fs=6.3)
    for y0, y1 in zip(ys[:-1], ys[1:]):
        arrow(ax, (52, y0), (52, y1 + 13))

    # guard strip
    chips = ["P1", "P2", "P3", "P4", "P5", "P6", "P7"]
    for i, c in enumerate(chips):
        box(ax, 35 + i * 4.9, 8, 4.3, 5.2, c, fs=6.0, bold=True)
    ax.text(52, 5.4, "guards, executed by preflight (one chip per rule)",
            fontsize=5.8, ha="center", va="top", color=EDGE, style="italic")

    # exits
    arrow(ax, (35, 78.5), (28.5, 78.5), ls="--", color=ACC)   # -> back to col a edge
    ax.text(31.7, 84, "grid\nunreachable", fontsize=5.6, ha="center", color=ACC, va="bottom")
    arrow(ax, (52, 18), (52, 1.5), ls="--", color=ACC)
    ax.text(53.5, 12, "UNKNOWN → abstain", fontsize=5.6, ha="left", color=ACC, rotation=90)

    # column 3: regimes
    ax.text(70, 97, "(c) the value of shaping\nis regime-dependent", fontsize=7.2,
            fontweight="bold", va="top", color=INK)
    regs = [
        "grid is magnitude-\ninfeasible →  INERT",
        "learning regime →\nSMALL, BOUNDED",
        "baseline fails →\nSEARCH IS REPAID",
    ]
    for i, t in enumerate(regs):
        y = 72 - i * 16
        box(ax, 70, y, 28, 13, t, fs=6.3)
    box(ax, 70, 6, 28, 13,
        "any such gate errs BOTH ways:\ndeploys a harmful candidate,\nand abstains on a helpful one,\nso abstention is a COST",
        fs=6.2, fc="#faf0ef", ec=ACC)

    p = os.path.join(OUT, "wireframe_A")
    fig.savefig(p + ".pdf")
    fig.savefig(p + ".png", dpi=300)
    plt.close(fig)
    print("wrote", p + ".pdf / .png")


# ------------------------------------------------------------------ scheme B #
def scheme_b():
    fig, ax = new_axes(7.2, 2.95)

    ax.text(1, 97, "(a) the pipeline as\ncommonly run", fontsize=7.2,
            fontweight="bold", va="top", color=INK)
    steps = [
        "pick λ from a small grid",
        "score candidates on a probe",
        "RANK BY SHAPED RETURN",
        "compare to an unshaped baseline",
        "deploy the best",
    ]
    ys = [78, 63, 48, 33, 18]
    for y, t in zip(ys, steps):
        box(ax, 2, y, 29, 11, t, fs=6.2)
    for y0, y1 in zip(ys[:-1], ys[1:]):
        arrow(ax, (16.5, y0), (16.5, y1 + 11))

    ax.text(36, 97, "(b) three measurement-\nfailure classes", fontsize=7.2,
            fontweight="bold", va="top", color=INK)
    fails = [
        "F1 magnitude — the grid never\nreaches λ*; search over an\ninert region",
        "F2 convention + budget — ranking\nby shaped return and leaving the\nsearch uncharged flip the sign",
        "F3 integrity — reused seeds,\nunseeded sources, config-blind\ncaches make it irreproducible",
    ]
    for i, t in enumerate(fails):
        y = 74 - i * 21
        box(ax, 36, y, 30, 17, t, fs=6.0, fc="#faf0ef", ec=ACC)
    for i, y in enumerate([74, 53, 32]):
        arrow(ax, (31, (78 - i * 15) + 5.5), (36, y + 8.5), ls="--", color=ACC, rad=0.12)

    ax.text(72, 97, "(c) consequence", fontsize=7.2, fontweight="bold",
            va="top", color=INK)
    box(ax, 72, 56, 26, 34,
        "replace (a) with the protocol:\n\ncharacterise → search under\nP1–P7 → confirm → deploy\nor abstain\n\nbounded, and honestly wrong\nin both directions",
        fs=6.2)
    box(ax, 72, 20, 26, 26,
        "the binding constraint is the\nPOOL, not the threshold;\nno new selector is proposed",
        fs=6.2, fc="#eef3f8", ec=EDGE)

    p = os.path.join(OUT, "wireframe_B")
    fig.savefig(p + ".pdf")
    fig.savefig(p + ".png", dpi=300)
    plt.close(fig)
    print("wrote", p + ".pdf / .png")


def main():
    os.makedirs(OUT, exist_ok=True)
    scheme_a()
    scheme_b()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
