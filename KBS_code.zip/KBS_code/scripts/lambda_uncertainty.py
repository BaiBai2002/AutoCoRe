"""Uncertainty of the calibrated coefficient lambda*.

The feasibility verdict (F1) rests on lambda* = rho* E|R| / E|dPhi|, both of whose
expectations are estimated from a finite number of reference-policy episodes. A
reviewer is entitled to ask whether the "one to two orders of magnitude above
the grid ceiling" claim survives that estimation error. This script answers it:

* for every (task, potential) pair in the feasibility table, it re-collects the
  per-episode |R| and |dPhi| under the *same* reference policy used by
  ``calibrate_lambda.py`` (imported, not re-implemented, so the two cannot drift);
* it bootstraps lambda* over episodes (paired resampling: |R| and |dPhi| of the
  same episode move together, because the ratio is an episode-level quantity);
* it reports the shortfall against the grid ceiling with an interval, and the
  same for the practitioner convention lambda*/N;
* it adds a *hierarchical* interval for the median log-shortfall across pairs,
  resampling pairs first and episodes within pairs, so the reader sees how much
  of the spread is between-pair rather than between-episode.

Writes ``artifacts/diagnostics/lambda_uncertainty.json``.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np  # noqa: E402

from autocore.selection.magnitude_calibration import estimate_scales, legacy_grid  # noqa: E402
from calibrate_lambda import (  # noqa: E402
    CANDIDATES, PZ_CANDIDATES, PZ_CYCLES, load_potential, load_pz_potential,
)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "lambda_uncertainty.json")


def bootstrap_lambda_star(abs_returns: np.ndarray, abs_dphis: np.ndarray,
                          rho_target: float, n_boot: int, seed: int
                          ) -> tuple[float, float, float]:
    """Paired bootstrap CI for lambda* = rho* mean|R| / mean|dPhi|.

    The two arrays are indexed by episode; a resample draws episode indices and
    takes both values from the same episode, because lambda* is a ratio of
    episode-level expectations and the numerator and denominator are correlated.
    """
    n = abs_returns.size
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_boot, n))
    num = abs_returns[idx].mean(axis=1)
    den = abs_dphis[idx].mean(axis=1)
    lam = rho_target * num / np.maximum(den, 1e-12)
    point = float(rho_target * abs_returns.mean() / max(abs_dphis.mean(), 1e-12))
    lo, hi = np.percentile(lam, [2.5, 97.5])
    return point, float(lo), float(hi)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rho-target", type=float, default=0.20)
    ap.add_argument("--gamma", type=float, default=0.99)
    ap.add_argument("--episodes", type=int, default=40,
                    help="must match the feasibility table so the point estimate agrees")
    ap.add_argument("--n-boot", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    grid = legacy_grid()
    ceiling = max(grid)
    rows = []

    def record(env_id: str, potential: str, family: str, est, n_agents: int | None) -> None:
        r = np.asarray(est.episode_abs_returns, dtype=float)
        d = np.asarray(est.episode_abs_dphis, dtype=float)
        point, lo, hi = bootstrap_lambda_star(r, d, args.rho_target, args.n_boot, args.seed)
        short = point / ceiling
        short_lo, short_hi = lo / ceiling, hi / ceiling
        applied = point / n_agents if n_agents else point
        applied_short = applied / ceiling
        rows.append({
            "env_id": env_id, "potential": potential, "family": family,
            "n_agents": n_agents, "n_episodes": int(r.size),
            "mean_abs_return": float(r.mean()),
            "mean_abs_delta_phi": float(d.mean()),
            "lambda_star": point, "lambda_star_lo": lo, "lambda_star_hi": hi,
            "grid_ceiling": ceiling,
            "shortfall_vs_ceiling": short,
            "shortfall_lo": short_lo, "shortfall_hi": short_hi,
            "applied_lambda_star": float(applied),
            "applied_shortfall_vs_ceiling": float(applied_short),
            # ``feasible_point``: the point estimate lies inside the grid.
            # ``infeasible_with_ci``: even the *lower* end of the 95% interval
            #   exceeds the grid ceiling, i.e. infeasibility is not an artefact of
            #   estimating E|R| and E|dPhi| from 40 episodes.
            "feasible_point": bool(ceiling / len(grid) <= point <= ceiling),
            "infeasible_with_ci": bool(lo > ceiling),
        })
        print(f"{env_id:<28s} {potential:<20s} "
              f"lambda*={point:8.2f} [{lo:7.2f},{hi:8.2f}]  "
              f"shortfall {short:6.1f}x [{short_lo:5.1f},{short_hi:6.1f}]  "
              f"applied(N={n_agents if n_agents else '-'}) {applied_short:5.1f}x")

    for env_id, dsl_name in CANDIDATES:
        fn, _ = load_potential(dsl_name, args.gamma)
        est = estimate_scales(env_id, fn, gamma=args.gamma, n_episodes=args.episodes)
        record(env_id, dsl_name, "mpe", est, 3)

    for env_id in PZ_CANDIDATES:
        cycles = PZ_CYCLES.get(env_id, 100)
        pot, _ = load_pz_potential(env_id, cycles, args.seed)
        # The practitioner convention divides by the number of agents that carry
        # the shaping term, so the count is read from the environment rather than
        # assumed.
        from autocore.envs.vec_pz import make_pz_env
        _env = make_pz_env(env_id, max_cycles=cycles)
        n_agents = len(_env.possible_agents)
        _env.close()
        est = estimate_scales(env_id, pot, gamma=args.gamma, max_cycles=cycles,
                              n_episodes=args.episodes, seed=args.seed)
        record(env_id, "obs_features",
               "sisl" if env_id.startswith("pursuit") else "butterfly", est, n_agents)

    shorts = np.asarray([r["shortfall_vs_ceiling"] for r in rows], dtype=float)
    logs = np.log(np.maximum(shorts, 1e-9))
    rng = np.random.default_rng(args.seed + 1)
    hier = []
    n_pairs = logs.size
    for _ in range(args.n_boot):
        pick = rng.integers(0, n_pairs, size=n_pairs)
        hier.append(np.median(logs[pick]))
    hier = np.asarray(hier)
    hier_lo, hier_hi = np.exp(np.percentile(hier, [2.5, 97.5]))
    summary = {
        "rho_target": args.rho_target, "grid": grid, "grid_ceiling": ceiling,
        "n_pairs": int(n_pairs),
        "median_shortfall": float(np.median(shorts)),
        "median_shortfall_hier_lo": float(hier_lo),
        "median_shortfall_hier_hi": float(hier_hi),
        "min_shortfall": float(shorts.min()),
        "max_shortfall": float(shorts.max()),
        "pairs_infeasible_with_ci": int(sum(
            1 for r in rows if r["infeasible_with_ci"])),
        "applied_shortfall_min": float(min(
            r["applied_shortfall_vs_ceiling"] for r in rows if r["infeasible_with_ci"])),
        "applied_shortfall_max": float(max(
            r["applied_shortfall_vs_ceiling"] for r in rows if r["infeasible_with_ci"])),
        "rows": rows,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"\nmedian shortfall {summary['median_shortfall']:.1f}x "
          f"hierarchical 95% CI [{hier_lo:.1f}x, {hier_hi:.1f}x]")
    print(f"pairs infeasible even at the 95% CI lower bound: "
          f"{summary['pairs_infeasible_with_ci']}/{n_pairs}; "
          f"applied-convention shortfall {summary['applied_shortfall_min']:.1f}x"
          f"-{summary['applied_shortfall_max']:.1f}x")
    print("wrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
