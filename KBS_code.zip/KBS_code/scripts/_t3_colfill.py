import os, re, subprocess, json

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
PDF = os.path.join(ROOT, "paper", "main_final.pdf")
xml = subprocess.run(["pdftotext", "-bbox", PDF, "-"],
                     capture_output=True, text=True, encoding="utf-8").stdout
pages = re.split(r"<page\b", xml)[1:]
rows = []
for i, p in enumerate(pages, 1):
    m = re.search(r'width="([\d.]+)" height="([\d.]+)"', p)
    W, H = float(m.group(1)), float(m.group(2))
    Wmid = W / 2.0
    words = re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">', p)
    if not words:
        rows.append({"page": i, "words": 0, "full_cols": 0})
        continue
    left = [(float(a), float(b), float(c), float(d)) for a, b, c, d in words if float(a) < Wmid]
    right = [(float(a), float(b), float(c), float(d)) for a, b, c, d in words if float(a) >= Wmid]
    def lasty(col):
        return max((d for _, _, _, d in col), default=0.0)
    def firsty(col):
        return min((b for _, b, _, _ in col), default=0.0)
    ly_l, ly_r = lasty(left), lasty(right)
    ny_l, ny_r = len(left), len(right)
    rows.append({
        "page": i, "words": len(words),
        "nL": ny_l, "nR": ny_r,
        "lastL_in": round(ly_l / 72.0, 2), "lastR_in": round(ly_r / 72.0, 2),
        "gapL_in": round((H - ly_l) / 72.0, 2) if ny_l else None,
        "gapR_in": round((H - ly_r) / 72.0, 2) if ny_r else None,
    })
print("page words    nL   nR   lastL lastR  gapL  gapR")
for r in rows:
    print(f"{r['page']:>4} {r['words']:>5}  {r.get('nL',''):>4} {r.get('nR',''):>4}  "
          f"{r.get('lastL_in',''):>5} {r.get('lastR_in',''):>5}  "
          f"{r.get('gapL_in',''):>5} {r.get('gapR_in',''):>5}")
json.dump(rows, open(os.path.join(ROOT, "audit", "_colfill_raw.json"), "w"), indent=2)
