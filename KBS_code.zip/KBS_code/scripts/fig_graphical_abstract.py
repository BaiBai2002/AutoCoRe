"""Graphical abstract for the KBS submission.

The review found that the submitted graphical abstract was the *same* file as Figure 1, which both
wastes the one page the journal gives the abstract and hides the paper's actual claim. This script
draws a distinct figure whose only job is to make the paper's argument visible at a glance:

    typed knowledge about the environment -> what a proposer may express
                                          -> what the audit verifies
                                          -> deploy or abstain, at a stated cost.

Vector output (PDF) with Type 42 fonts, greyscale-safe, one shared style with every other figure.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib.patches as mpatches  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

import figstyle  # noqa: E402

INK = "#1a1a1a"
MUTED = "#5f6b76"
POS = figstyle.OUTCOME["positive"]
NEG = figstyle.OUTCOME["negative"]
FAM = figstyle.FAMILY["mpe"]


def box(ax, x, y, w, h, title, body, edge=INK, face="white", lw=1.1, ts=8.4, bs=6.9,
        title_color=None):
    ax.add_patch(mpatches.FancyBboxPatch(
        (x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.02",
        linewidth=lw, edgecolor=edge, facecolor=face, zorder=2))
    ax.text(x + w / 2, y + h - 0.028, title, ha="center", va="top", fontsize=ts,
            fontweight="bold", color=title_color or INK, zorder=3)
    ax.text(x + w / 2, y + h - 0.088, body, ha="center", va="top", fontsize=bs,
            color=MUTED, linespacing=1.35, zorder=3)


def arrow(ax, x0, y0, x1, y1, color=INK, lw=1.15, style="-|>", ls="-"):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0), zorder=1,
                arrowprops=dict(arrowstyle=style, color=color, linewidth=lw,
                                linestyle=ls, shrinkA=1.5, shrinkB=2.5))


def main() -> None:
    figstyle.apply_style()
    # Elsevier graphical-abstract guidance: about 2.5:1, at least 1328 x 531 px. At 7.5 x 3.0 in
    # the 300-dpi PNG export below is 2250 x 900 px.
    fig, ax = plt.subplots(figsize=(7.5, 3.0))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # ---------------------------------------------------------------- row 1
    box(ax, 0.015, 0.60, 0.215, 0.33, "Environment knowledge",
        "typed DSL of implementable\npredicates and potentials\n(what may be expressed)")
    box(ax, 0.275, 0.60, 0.215, 0.33, "Candidate sources",
        "human   ·   random valid\nLLM raw  ·  LLM grounded\nunion of several  (2K)")
    box(ax, 0.535, 0.60, 0.215, 0.33, "Audit",
        "feasibility  $\\lambda^\\star = \\rho^\\star\\,E|R|/E|\\Delta\\Phi|$\napplicability gate\nraw-return probe")
    box(ax, 0.795, 0.60, 0.19, 0.33, "Decision",
        "deploy the best\nor\nABSTAIN", edge=POS, title_color=INK)

    arrow(ax, 0.232, 0.765, 0.273, 0.765)
    arrow(ax, 0.492, 0.765, 0.533, 0.765)
    arrow(ax, 0.752, 0.765, 0.793, 0.765)

    # optional, higher-cost paths drawn as dashed side channels
    ax.text(0.385, 0.565, "repair / union: optional, higher probe cost", ha="center",
            va="top", fontsize=6.4, color=MUTED, style="italic")
    arrow(ax, 0.615, 0.60, 0.615, 0.52, color=MUTED, lw=0.9, ls=(0, (3, 2)))
    arrow(ax, 0.615, 0.52, 0.385, 0.52, color=MUTED, lw=0.9, ls=(0, (3, 2)))

    # ---------------------------------------------------------------- row 2: findings
    ax.text(0.015, 0.55, "What the audit measures", ha="left", va="top", fontsize=7.6,
            fontweight="bold", color=INK)

    rows = [
        ("raw LLM proposer", "no reliable advantage over valid random search", NEG),
        ("grounded proposer", "two families above random valid at three agents; one\n"
                              "reaches the hand design within its $\\pm20$ margin", POS),
        ("remove one primitive", "the gain collapses: the task-relevant primitive is\n"
                                 "load-bearing", NEG),
        ("GPT generation ladder", "newer generations did not separate: recency did not\n"
                                  "predict utility", NEG),
        ("union of two proposers", "matches the hand design, at twice the probe cost", POS),
    ]
    y = 0.42
    for name, txt, col in rows:
        ax.add_patch(mpatches.Rectangle((0.015, y - 0.012), 0.006, 0.055,
                                        facecolor=col, edgecolor="none", zorder=2))
        ax.text(0.035, y + 0.031, name, ha="left", va="center", fontsize=7.0,
                fontweight="bold", color=INK)
        ax.text(0.30, y + 0.031, txt, ha="left", va="center", fontsize=6.8,
                color=MUTED, linespacing=1.3)
        y -= 0.075

    # ---------------------------------------------------------------- footer
    ax.plot([0.015, 0.985], [0.045, 0.045], color="#c9d2da", lw=0.8, zorder=1)
    ax.text(0.015, 0.022, "Every number regenerated from immutable run records; "
                          "the audit abstains rather than ship a shaping term it cannot support.",
            ha="left", va="center", fontsize=6.3, color=MUTED)

    # Standalone submission copies (separate files for the journal, not only the in-paper figure).
    sub = os.path.join(figstyle.PROJECT_ROOT, "paper", "submission")
    os.makedirs(sub, exist_ok=True)
    fig.savefig(os.path.join(sub, "graphical_abstract.pdf"), format="pdf")
    fig.savefig(os.path.join(sub, "graphical_abstract.png"), dpi=300)
    print("wrote", os.path.join(sub, "graphical_abstract.pdf"),
          "+ graphical_abstract.png (2250x900 px, 2.5:1)")

    figstyle.save(fig, "fig_graphical_abstract")


if __name__ == "__main__":
    main()
