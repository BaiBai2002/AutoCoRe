"""G1 / B2: is the "search-cost" decline an accounting identity?

The claim under test: "the probe budget's effect is its cost --- the budget-matched gain falls as the
search lengthens". The objection: if the deployed configuration is *invariant* to the probe budget
while the budget-matched baseline is charged the (larger) search and therefore trains *longer*, then

    gain_vs_BM(probe) = deployed_return - BM_return(S(probe))

so any decline is the baseline's improvement under the charged compute --- arithmetic, not a property
of the search. This script decomposes the identity: it recovers the implied deployed return
(`BM_mean + gain_vs_BM`) for every point of the sweep and reports, side by side, how the baseline
moves. If the deployed return is flat and the baseline rises, the "cost" reading is an identity.

Writes ``artifacts/diagnostics/cost_decomposition.json``.
"""
from __future__ import annotations

import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SRC = os.path.join(ROOT, "artifacts", "diagnostics", "probe_cost.json")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "cost_decomposition.json")


def main() -> None:
    d = json.load(open(SRC, encoding="utf-8"))
    rows = []
    for r in d["rows"]:
        if not r["summary"].startswith(("sweepc", "sweepe")):
            continue
        bm = r["budget_matched_mean"]
        g = r["gain_vs_budget_matched_mean"]
        rows.append({
            "final_steps": r["final_steps"],
            "probe_steps": r["probe_steps"],
            "search_overhead": r["search_overhead_interactions"],
            "budget_matched_steps_per_seed": r["budget_matched_steps_per_seed"],
            "budget_matched_mean": bm,
            "gain_vs_budget_matched_mean": g,
            "implied_deployed_mean": round(bm + g, 2),
            "deployed_configs": r["deployed_configs"],
        })
    out = {
        "identity": "gain_vs_BM = deployed_return - BM_return(S(probe))",
        "reading": ("if implied_deployed_mean is flat within a final budget while budget_matched_mean "
                    "rises with the charged search, the decline is the baseline's improvement under "
                    "the charged compute (an accounting identity), not a property of the search"),
        "rows": rows,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(out, open(OUT, "w", encoding="utf-8"), indent=2)
    for r in rows:
        print(f"final={r['final_steps']:>6} probe={r['probe_steps']:>5} "
              f"overhead={r['search_overhead']:>8} BM_steps={r['budget_matched_steps_per_seed']:>8} "
              f"BM_mean={r['budget_matched_mean']:>8.2f} gain_vs_BM={r['gain_vs_budget_matched_mean']:>7.2f} "
              f"=> deployed={r['implied_deployed_mean']:>8.2f} {r['deployed_configs']}")


if __name__ == "__main__":
    main()
