"""Reproduce the pre-registered search-budget check (P1 of ``workplan/PROSPECTIVE_PREREG.md``).

The pre-registered test asked whether the *simplest* selector would have captured the held-out
gain the gate forfeited. This script answers it from the cached probe records: for the search
budget actually used, how many candidate x seed probe means are positive, what the maximum is,
and what the full-budget oracle is.

Writes ``artifacts/diagnostics/prereg_probe_check.json``.
"""
from __future__ import annotations

import collections
import glob
import json
import os
import re
import statistics as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BP = os.path.join(ROOT, "artifacts", "bps_gate")
SUMMARY = os.path.join(BP, "prereg_P1_summary.json")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "prereg_probe_check.json")


def main() -> None:
    summ = json.load(open(SUMMARY, encoding="utf-8"))
    requested = int(summ["probe_steps"])
    lo, hi = 0.9 * requested, 1.1 * requested

    grouped: dict[tuple[str, int], list[float]] = collections.defaultdict(list)
    realized = set()
    for f in glob.glob(os.path.join(BP, "simple_spread_v3_ippo_Nna_probe*_s*.json")):
        rec = json.load(open(f, encoding="utf-8"))
        steps = int(rec.get("steps", 0))
        if not (lo <= steps <= hi):
            continue
        realized.add(steps)
        m = re.search(r"_probe_?([0-9a-f]*)_s(\d+)\.json$", os.path.basename(f))
        key = m.group(1) if (m and m.group(1)) else os.path.basename(f).split("_probe")[1].split("_s")[0]
        grouped[(key, int(rec["seed"]))].append(float(rec["final_return"]))

    means = [st.mean(v) for v in grouped.values()]
    out = {
        "env": summ["env"],
        "probe_steps_requested": requested,
        "probe_steps_realized": sorted(realized),
        "n_probe_means": len(means),
        "n_positive": sum(1 for m in means if m > 0),
        "max_probe_mean": round(max(means), 4) if means else None,
        "oracle_gain": round(float(summ["oracle_gain"]), 4),
        "note": ("no selector (mean>0 or argmax) can deploy over this evidence; the search budget "
                 "itself is below resolution, while the full-budget oracle is positive"),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
