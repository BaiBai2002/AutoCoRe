"""Dose-response figure: the coefficient sweep under two reporting returns.

Reads ``artifacts/diagnostics/dose_response_merged.json``. For each fixed potential,
plots the paired change relative to the unshaped baseline as the shaping coefficient is
swept from inside the permitted grid (lambda <= 0.4) through and past the calibrated
lambda*. Two series are shown: the raw task return (P1) and the shaped return. The point
of the figure is that the two criteria rank the sweep differently: the shaped return is
monotone in lambda and selects the largest coefficient, while the raw return has an
interior optimum. The legend is placed once, below both panels, so it can never sit on
top of a curve.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import FAMILY, OUTCOME, apply_style, grid, save  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DIAG = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")

PRETTY = {"spread_coverage": "coverage potential",
          "spread_assignment": "assignment potential"}


def main() -> None:
    with open(os.path.join(DIAG, "dose_response_merged.json"), encoding="utf-8") as f:
        data = json.load(f)
    ceiling = data.get("grid_ceiling", 0.4)
    pots = []
    for r in data["rows"]:
        if r["potential"] not in pots:
            pots.append(r["potential"])
    order = {k: i for i, k in enumerate(["spread_coverage", "spread_assignment"])}
    pots.sort(key=lambda p: order.get(p, 99))
    lam_star = {r["potential"]: r["lambda_star"] for r in data["rows"]}

    apply_style()
    import matplotlib.pyplot as plt

    n = len(pots)
    # Render at the 0.98\textwidth embedding width so the printed point sizes equal the
    # rendered sizes (reviewer round 6: embedded axis text measured 5.5--6.1 pt).
    fig, axes = plt.subplots(1, n, figsize=(6.42, 2.95), squeeze=False)
    panels = ["(a)", "(b)"]
    handles_labels = None

    for i, (ax, pot) in enumerate(zip(axes[0], pots)):
        rows = [r for r in data["rows"] if r["potential"] == pot and r["lambda"] > 0]
        rows.sort(key=lambda r: r["lambda"])
        ls = lam_star.get(pot, 1.0)
        x = np.asarray([r["lambda"] / ls for r in rows], dtype=float)
        raw = np.asarray([r["delta"] for r in rows], dtype=float)
        lo = np.asarray([r["ci_lo"] for r in rows], dtype=float)
        hi = np.asarray([r["ci_hi"] for r in rows], dtype=float)
        shp = np.asarray([r["shaped_delta"] for r in rows], dtype=float)
        yerr = np.vstack([np.clip(raw - lo, 0, None), np.clip(hi - raw, 0, None)])

        band_lo, band_hi = x.min() * 0.55, ceiling / ls
        ax.axvspan(band_lo, band_hi, color=OUTCOME["band"], zorder=0)
        ax.axhline(0.0, color=OUTCOME["muted"], lw=0.7, zorder=1)
        ax.axvline(1.0, ls=":", lw=0.9, color=OUTCOME["neutral"], zorder=1)
        ax.plot(x, shp, "--s", color=FAMILY["sisl"], ms=3.0, lw=1.2,
                label="shaped return (invalid criterion)", zorder=2)
        ax.errorbar(x, raw, yerr=yerr, fmt="-o", color=FAMILY["mpe"], ms=3.4,
                    lw=1.3, capsize=2.2, label="raw return (P1)", zorder=3)
        ax.annotate("permitted grid", xy=(np.sqrt(band_lo * band_hi), 0.025),
                    xycoords=("data", "axes fraction"), xytext=(0, 0),
                    textcoords="offset points", fontsize=6.9,
                    color=OUTCOME["neutral"], ha="center", va="bottom")
        ax.annotate(r"$\lambda^\star$", xy=(1.0, 0.02),
                    xycoords=("data", "axes fraction"), xytext=(2, 0),
                    textcoords="offset points", fontsize=7.2,
                    color=OUTCOME["neutral"])
        ax.set_xscale("log")
        ax.set_xlabel(r"shaping coefficient  $\lambda\,/\,\lambda^\star$ (log scale)",
                      fontsize=7.4)
        ax.tick_params(labelsize=7.2)
        if i == 0:
            ax.set_ylabel("paired $\\Delta$ vs unshaped baseline", fontsize=7.4)
        ax.set_title(f"{panels[i]}  {PRETTY.get(pot, pot)}", loc="left", fontsize=7.6)
        grid(ax)
        handles_labels = ax.get_legend_handles_labels()

    fig.subplots_adjust(left=0.09, right=0.99, top=0.90, bottom=0.215, wspace=0.20)
    if handles_labels:
        fig.legend(*handles_labels, loc="lower center", ncol=2, frameon=False,
                   bbox_to_anchor=(0.5, 0.005), handletextpad=0.4, columnspacing=1.8)
    save(fig, "fig_dose_response")


if __name__ == "__main__":
    main()
