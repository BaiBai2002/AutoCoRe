"""Tests whether a short probe predicts the *outcome* of full-budget shaping.

Two questions, both answerable from evaluation curves already on disk:

H2 (ranking)  does the probe order configurations the way the full budget does?
H3 (forecast) does the probe predict the sign and the magnitude of the realised
              paired gain, better than the trivial predictor ``gain = 0``?

For each setting the paired gain of every configuration against the unshaped
baseline is computed at a probe checkpoint and at the final checkpoint, using
the same seeds. Magnitude prediction is assessed with leave-one-configuration-out
linear calibration so the reported error is out of sample.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "shaping_experiment")
ARM_ALIASES = {"cov_legacy": "pot_legacy", "cov_cal": "pot_cal"}


def canonical(name: str) -> str:
    return ARM_ALIASES.get(name, name)


def setting_key(run: dict) -> str:
    env = run.get("env")
    algo = run.get("algo") or "ippo"
    n = run.get("num_agents")
    if algo == "ippo" and n is None:
        return str(env)
    return f"{env} [{algo}" + (f", N={n}]" if n is not None else "]")


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return float("nan")
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def load(tags: list[str]) -> dict[str, dict[str, dict[int, list]]]:
    envs: dict[str, dict[str, dict[int, list]]] = {}
    for tag in tags:
        path = os.path.join(OUTDIR, f"{tag}_raw.json")
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            for r in json.load(f):
                if r.get("status") != "completed":
                    continue
                envs.setdefault(setting_key(r), {}).setdefault(canonical(r["arm"]), {})[
                    r["seed"]] = r["curve"]
    return envs


def loo_calibrated_mae(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    """Leave-one-out MAE of a linear predictor y ~ a*x + b, and of y = 0."""
    n = x.size
    if n < 3:
        return float("nan"), float("nan")
    errs_cal, errs_zero = [], []
    for i in range(n):
        m = np.ones(n, dtype=bool)
        m[i] = False
        A = np.vstack([x[m], np.ones(m.sum())]).T
        try:
            coef, *_ = np.linalg.lstsq(A, y[m], rcond=None)
        except np.linalg.LinAlgError:
            continue
        errs_cal.append(abs(float(coef[0] * x[i] + coef[1] - y[i])))
        errs_zero.append(abs(float(0.0 - y[i])))
    if not errs_cal:
        return float("nan"), float("nan")
    return float(np.mean(errs_cal)), float(np.mean(errs_zero))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tags",
                    default="main,main2,sweep,mappo,n5b,push,ref,ref2,sl,n7,n5")
    ap.add_argument("--base", default="base")
    ap.add_argument("--fractions", default="0.1,0.2,0.3,0.5")
    args = ap.parse_args()

    envs = load([t for t in args.tags.split(",") if t])
    rows = []
    for env_name, arms in sorted(envs.items(), key=lambda kv: str(kv[0])):
        if args.base not in arms:
            continue
        base = arms[args.base]
        cands = [a for a in arms if a != args.base]
        if len(cands) < 3:
            continue
        print(f"\n=== {env_name} ({len(cands)} configurations) ===")
        print(f"{'probe':>6s} {'Spearman':>9s} {'top1 (probe/final)':>21s} "
              f"{'sign acc':>9s} {'LOO MAE cal':>12s} {'LOO MAE zero':>13s}")
        for frac in [float(v) for v in args.fractions.split(",")]:
            probe_g, final_g = [], []
            for a in cands:
                shared = sorted(set(arms[a]) & set(base))
                if len(shared) < 2:
                    continue
                npts = min(len(arms[a][s]) for s in shared)
                idx = max(0, int(round(frac * (npts - 1))))
                probe_g.append(np.mean([arms[a][s][idx][1] - base[s][idx][1] for s in shared]))
                final_g.append(np.mean([arms[a][s][-1][1] - base[s][-1][1] for s in shared]))
            if len(probe_g) < 3:
                continue
            x = np.asarray(probe_g, dtype=float)
            y = np.asarray(final_g, dtype=float)
            sign_acc = float(np.mean(np.sign(x) == np.sign(y)))
            best_probe = cands[int(np.argmax(x))]
            best_final = cands[int(np.argmax(y))]
            mae_cal, mae_zero = loo_calibrated_mae(x, y)
            rows.append({"setting": env_name, "probe_fraction": frac,
                         "spearman": spearman(x, y), "sign_accuracy": sign_acc,
                         "top1_probe": best_probe, "top1_final": best_final,
                         "mae_calibrated": mae_cal, "mae_zero": mae_zero,
                         "n_configs": len(x)})
            print(f"{frac:>6.0%} {spearman(x, y):>9.3f} "
                  f"{(best_probe + ' / ' + best_final):>21s} {sign_acc:>9.2f} "
                  f"{mae_cal:>12.2f} {mae_zero:>13.2f}")

    out = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "probe_prediction.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    if rows:
        sp = np.asarray([r["spearman"] for r in rows if np.isfinite(r["spearman"])])
        sa = np.asarray([r["sign_accuracy"] for r in rows])
        print(f"\nacross {len(rows)} (setting, probe) units: "
              f"median Spearman {np.median(sp):.3f}, median sign accuracy {np.median(sa):.2f}")
        better = sum(1 for r in rows if r["mae_calibrated"] < r["mae_zero"])
        print(f"calibrated predictor beats the zero predictor in {better}/{len(rows)} units")
    print("\nwrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
