"""Preflight validator for a potential-based reward-shaping (PBRS) result.

The paper's seven protocol rules (P1-P7) are stated as prose. This tool turns them into an
executable check: give it the run records and the audit summaries of a shaping study and it
returns, per rule, one of

    PASS     the rule is satisfied on the supplied artifacts
    FAIL     the rule is violated, with the offending record named
    UNKNOWN  the artifact needed to decide is missing (never silently a pass)

Design notes
------------
* It is deliberately conservative: a rule that cannot be decided is UNKNOWN, not PASS. The
  two conditions that need task knowledge --- pool richness and task learnability --- are
  reported UNKNOWN and flagged `manual`, because they cannot be read off a config.
* It is deterministic and dependency-free (stdlib only) so a reviewer can run it on the
  artefacts without the training stack.
* `--inject` runs the validator's regression suite: eight injected failure modes --- one per
  rule, with a second cache-integrity case --- plus a clean control, asserting that each
  injected case is caught while the clean control is not (nine assertions in all). The six
  defects actually observed in the study (five P6 cache-integrity, one P7 seed-discipline) are
  a separate, documented catalogue in the supplement.

Run records (JSON) are assumed to carry at least::

    run_id, env_id, algo, num_agents, max_cycles, steps, seed, control, shaping_lambda,
    final_return

Audit summaries (JSON) are assumed to carry at least::

    env, algo, num_agents, final_steps, final_seeds, probe_pool, replicates,
    search_overhead_interactions, decisions
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import statistics
import sys

RULES = ("P1", "P2", "P3", "P4", "P5", "P6", "P7")
STATUS = ("PASS", "FAIL", "UNKNOWN")

RUN_ID_RE = re.compile(
    r"^(?P<env>[a-z0-9_]+)_(?P<algo>[a-z]+)_N(?P<n>\d+|[a-z]+)"
    r"_(?P<stage>final|probe|screen|baseline)_"
)


def load_many(pattern: str) -> list[dict]:
    out = []
    for path in sorted(glob.glob(pattern, recursive=True)):
        try:
            with open(path, encoding="utf-8") as f:
                obj = json.load(f)
        except Exception:
            continue
        if isinstance(obj, list):
            for r in obj:
                if isinstance(r, dict):
                    r.setdefault("_path", path)
                    out.append(r)
        elif isinstance(obj, dict):
            obj.setdefault("_path", path)
            out.append(obj)
    return out


# --------------------------------------------------------------------------------------- #
# rule implementations                                                                     #
# --------------------------------------------------------------------------------------- #
def check_p1_raw_return(runs: list[dict]) -> tuple[str, str]:
    """P1: arms must be ranked and reported on the *raw* return.

    The check is only meaningful on a *fixed policy*: in a training sweep, two coefficients
    legitimately produce two different policies, so a return that moves with the coefficient
    is expected and proves nothing. We therefore require the records to declare the
    precondition (`fixed_policy: true`, as a reference-policy evaluation does) and report
    UNKNOWN otherwise rather than a spurious failure.

    Given that precondition, a shaped score is by construction a function of the coefficient,
    so the reported return must be identical across coefficients to machine precision.
    """
    eligible = [r for r in runs if r.get("fixed_policy") or r.get("policy_id") is not None]
    if not eligible:
        return "UNKNOWN", ("no fixed-policy records declared; set `fixed_policy: true` on a "
                           "reference-policy evaluation to apply P1 (a training sweep cannot "
                           "test it: different coefficients give different policies)")
    groups: dict[tuple, list[dict]] = {}
    for r in eligible:
        if r.get("final_return") is None:
            continue
        key = (r.get("env_id"), r.get("algo"), r.get("num_agents"),
               r.get("policy_id", "fixed"), r.get("seed"), r.get("steps"))
        groups.setdefault(key, []).append(r)
    checked = varied = 0
    offenders = []
    for key, recs in groups.items():
        lams = {r.get("shaping_lambda") for r in recs}
        if len(lams) < 2:
            continue
        checked += 1
        vals = [float(r["final_return"]) for r in recs]
        spread = max(vals) - min(vals)
        scale = max(1.0, abs(statistics.fmean(vals)))
        if spread / scale > 1e-6:          # raw return must be identical to machine precision
            varied += 1
            offenders.append((key[0], key[4], round(spread, 4)))
    if checked == 0:
        return "UNKNOWN", "no fixed-policy group with two coefficients to compare"
    if varied:
        return "FAIL", (f"{varied}/{checked} fixed-policy groups report a return that moves "
                        f"with the coefficient -> a shaped score is being reported; "
                        f"e.g. {offenders[:3]}")
    return "PASS", f"{checked} fixed-policy groups invariant across the coefficient (raw return)"


def check_p2_seed_roles(summaries: list[dict]) -> tuple[str, str]:
    """P2: probe seeds and held-out seeds must be disjoint."""
    checked = 0
    offenders = []
    for s in summaries:
        probe, final = s.get("probe_pool"), s.get("final_seeds")
        if not isinstance(probe, list) or not isinstance(final, list):
            continue
        checked += 1
        overlap = sorted(set(probe) & set(final))
        if overlap:
            offenders.append((s.get("_path", "?"), overlap[:5]))
    if checked == 0:
        return "UNKNOWN", "no summary declares both probe_pool and final_seeds"
    if offenders:
        return "FAIL", f"probe/held-out seed overlap in {len(offenders)} summary(ies): {offenders[:2]}"
    return "PASS", f"{checked} summary(ies) with disjoint probe and held-out seed sets"


def check_p3_budget_matching(runs: list[dict], summaries: list[dict]) -> tuple[str, str]:
    """P3: the search overhead must be charged to the baseline.

    Expected baseline steps per seed: T' = T (1 + (S/R)/T_total), with T_total = T |seeds|.
    """
    seen = 0
    detail = []
    for s in summaries:
        T, seeds = s.get("final_steps"), s.get("final_seeds")
        S, R = s.get("search_overhead_interactions"), s.get("replicates")
        if not all(isinstance(x, (int, float)) for x in (T, S, R)) or not isinstance(seeds, list):
            continue
        if S == 0:
            continue
        t_total = T * len(seeds)
        expected = round(T * (1.0 + (S / max(1, R)) / t_total))
        have = [r for r in runs
                if r.get("env_id") == s.get("env") and r.get("control") == "baseline"
                and isinstance(r.get("steps"), int)]
        if not have:
            detail.append(f"{s.get('_path','?')}: no baseline record to verify (expected {expected})")
            continue
        seen += 1
        matched = [int(r["steps"]) for r in have
                   if abs(int(r["steps"]) - expected) <= 0.02 * expected]
        ok = bool(matched)
        detail.append(f"{os.path.basename(s.get('_path','?'))}: expected {expected}, "
                      f"baseline step counts {sorted({int(r['steps']) for r in have})}; "
                      f"matched {sorted(set(matched)) if matched else 'none'} -> "
                      f"{'ok' if ok else 'MISMATCH'}")
        if not ok:
            return "FAIL", "; ".join(detail)
    if seen == 0:
        return "UNKNOWN", "; ".join(detail) or "no summary with a search overhead and a baseline record"
    return "PASS", "; ".join(detail)


def check_p4_paired_statistics(summaries: list[dict]) -> tuple[str, str]:
    """P4: per-replicate paired statistics with a candidate-wise interval."""
    checked, weak = 0, []
    for s in summaries:
        R = s.get("replicates")
        seeds = s.get("final_seeds")
        if not isinstance(R, int) or not isinstance(seeds, list):
            continue
        checked += 1
        if R < 5 or len(seeds) < 5:
            weak.append((os.path.basename(s.get("_path", "?")), R, len(seeds)))
    if checked == 0:
        return "UNKNOWN", "no summary declares replicates and final_seeds"
    if weak:
        return "FAIL", f"fewer than 5 replicates or 5 held-out seeds: {weak[:3]}"
    return "PASS", f"{checked} summary(ies) have >=5 replicates and >=5 held-out seeds"


def check_p5_feasibility(runs: list[dict], grid: list[float]) -> tuple[str, str]:
    """P5: the magnitude-feasibility test must be *run* before a coefficient search.

    The rule is procedural, so an infeasible verdict is a *finding*, not a violation. Two
    outcomes are failures: no feasibility evidence at all would be UNKNOWN (not a pass), and
    searching a grid on a setting the check has marked infeasible is a FAIL --- the check was
    performed and then ignored.
    """
    have = [r for r in runs
            if r.get("mean_abs_return") is not None and r.get("mean_abs_delta_phi") is not None]
    search_runs = [r for r in runs if str(r.get("stage", "")) in ("probe", "screen")]
    if not have:
        if search_runs:
            return "FAIL", (f"{len(search_runs)} probe/screen run(s) present but no feasibility "
                            f"evidence attached --- the rule was skipped where it mattered")
        return "UNKNOWN", "no feasibility evidence and no search to check"
    lam_max = max(grid)
    infeasible_rows, infeasible_envs = 0, set()
    for r in have:
        lam_star = 0.2 * float(r["mean_abs_return"]) / max(float(r["mean_abs_delta_phi"]), 1e-12)
        if lam_star > lam_max:
            infeasible_rows += 1
            infeasible_envs.add(r.get("env_id"))
    return "PASS", (f"feasibility evaluated before searching on {len(have)} setting(s); "
                    f"{infeasible_rows}/{len(have)} above the grid ceiling "
                    f"({len(infeasible_envs)} distinct environment(s)) --- a verdict, not a "
                    f"violation (whether a fixed grid was then searched is a judgement, "
                    f"reported in §IV step 1)")


def check_p6_cache_integrity(runs: list[dict], summaries: list[dict]) -> tuple[str, str]:
    """P6: every artifact must be keyed by its full configuration, and a cache hit must be
    re-validated --- the recorded step count must match the configuration it claims.

    Three decidable sub-checks:
      (a) the run id must encode the stage it claims (final/probe/screen/baseline);
      (b) no two records may share a run id while disagreeing on configuration;
      (c) a record that claims a *final* or *baseline* stage may not carry a step count far
          below the final budget its own summary declares --- this is the smoke-run-as-baseline
          defect, and it is invisible to (a) and (b).
    """
    by_id: dict[str, set] = {}
    offenders = []
    unconventional = 0
    for r in runs:
        rid = str(r.get("run_id") or os.path.basename(str(r.get("_path", ""))))
        cfg = (r.get("env_id"), r.get("algo"), r.get("num_agents"),
               r.get("max_cycles"), r.get("steps"), r.get("seed"))
        by_id.setdefault(rid, set()).add(cfg)
        if os.path.sep not in rid and not RUN_ID_RE.match(rid):
            unconventional += 1     # style note, not a defect: see (b) and (c) for the hard checks
    for k, v in list(by_id.items())[:200]:
        if len(v) > 1:
            offenders.append((k, f"same id, {len(v)} different configurations (budget not in the key?)"))

    declared: dict[str, float] = {}
    for s in summaries:
        if s.get("env") and isinstance(s.get("final_steps"), (int, float)):
            declared[str(s["env"])] = max(declared.get(str(s["env"]), 0.0), float(s["final_steps"]))
    # an id that names its own budget (e.g. `..._base102k_s100`, `..._bm425000`) is
    # self-declaring: a short run there is a deliberate regime sweep, not a defect.
    self_declaring = re.compile(
        r"(base|bm|budget)\d+k?|lowbudget|smoke|pilot|regime|sweep|halving|probe\d*k?", re.I)
    for r in runs:
        env, steps = r.get("env_id"), r.get("steps")
        tag = f"{r.get('run_id', '')} {r.get('_path', '')}"
        if self_declaring.search(tag):
            continue
        # the defect is *using a smoke run as a baseline*: the record must claim to be one.
        # A short record keyed by a candidate hash is a probe/screen run, which is legitimate.
        if not re.search(r"(base|baseline|bm)", tag, re.I):
            continue
        if env in declared and isinstance(steps, (int, float)) and declared[env] > 0:
            if steps < 0.5 * declared[env]:
                offenders.append((tag.strip()[:70],
                                  f"steps={int(steps)} vs declared budget {int(declared[env])}"))

    if not runs:
        return "UNKNOWN", "no run records supplied"
    if offenders:
        return "FAIL", f"{len(offenders)} cache-key problem(s): {offenders[:3]}"
    note = (f" ({unconventional} id(s) do not follow the env_algo_N_stage convention)"
            if unconventional else "")
    return "PASS", (f"{len(runs)} record(s); no id-collision and every step count matches the "
                    f"declared budget{note}")


def check_p7_seed_discipline(runs: list[dict]) -> tuple[str, str]:
    """P7: every stochastic source must be explicitly seeded."""
    unseeded = [r for r in runs if r.get("seed") is None]
    tainted = [r for r in runs
               if "space.sample()" in json.dumps(r.get("flags", r.get("notes", "")))]
    if not runs:
        return "UNKNOWN", "no run records supplied"
    if unseeded:
        return "FAIL", f"{len(unseeded)} record(s) declare no seed"
    if tainted:
        return "FAIL", f"{len(tainted)} record(s) flag an unseeded sampler (space.sample())"
    return "PASS", f"{len(runs)} record(s) declare a seed"


# --------------------------------------------------------------------------------------- #
# driver                                                                                   #
# --------------------------------------------------------------------------------------- #
def run_all(runs: list[dict], summaries: list[dict], grid: list[float]) -> list[dict]:
    checks = {
        "P1": check_p1_raw_return(runs),
        "P2": check_p2_seed_roles(summaries),
        "P3": check_p3_budget_matching(runs, summaries),
        "P4": check_p4_paired_statistics(summaries),
        "P5": check_p5_feasibility(runs, grid),
        "P6": check_p6_cache_integrity(runs, summaries),
        "P7": check_p7_seed_discipline(runs),
    }
    out = []
    for rule in RULES:
        status, detail = checks[rule]
        manual = rule in ("P5",) and status == "UNKNOWN"
        out.append({"rule": rule, "status": status, "detail": detail, "manual": manual})
    return out


def render(results: list[dict]) -> str:
    width = max(len(r["detail"]) for r in results)
    width = min(width, 96)
    lines = ["", "=" * 78,
             "PBRS preflight — protocol P1-P7", "=" * 78,
             f"{'rule':<5s} {'status':<8s} detail", "-" * 78]
    for r in results:
        d = r["detail"]
        lines.append(f"{r['rule']:<5s} {r['status']:<8s} {d[:width]}")
        if len(d) > width:
            lines.append(f"{'':<14s} {d[width:]}")
    n_fail = sum(1 for r in results if r["status"] == "FAIL")
    n_unk = sum(1 for r in results if r["status"] == "UNKNOWN")
    lines += ["-" * 78, f"FAIL={n_fail}  UNKNOWN={n_unk}  PASS={len(results)-n_fail-n_unk}",
              "verdict: " + ("BLOCK" if n_fail else
                             ("INCOMPLETE — resolve UNKNOWNs" if n_unk else "CLEAR")), ""]
    return "\n".join(lines)


# --------------------------------------------------------------------------------------- #
# failure injection (the validator's own regression test)                                   #
# --------------------------------------------------------------------------------------- #
def _clean_fixture() -> tuple[list[dict], list[dict]]:
    runs = []
    for lam in (0.0, 0.4, 20.0):
        for seed in (100, 101, 102):
            runs.append({
                "_path": f"clean/spread_v3_ippo_N3_final_s{seed}_lam{lam}.json",
                "run_id": f"spread_v3_ippo_N3_final_s{seed}_lam{lam}",
                "env_id": "simple_spread_v3", "algo": "ippo", "num_agents": 3,
                "max_cycles": 80, "steps": 300000, "seed": seed,
                "control": "shaped" if lam else "base", "shaping_lambda": lam,
                "final_return": -182.40,          # raw return: invariant in lambda
                "fixed_policy": True,             # P1's precondition
                # scales chosen so lambda* = 0.2 * 1.0 / 5.0 = 0.04 lies inside the grid
                "mean_abs_return": 1.0, "mean_abs_delta_phi": 5.0,
            })
    for seed in (100, 101, 102):
        runs.append({
            "_path": f"clean/spread_v3_ippo_N3_baseline_s{seed}.json",
            "run_id": f"spread_v3_ippo_N3_baseline_s{seed}",
            "env_id": "simple_spread_v3", "algo": "ippo", "num_agents": 3,
            "max_cycles": 80, "steps": 425000, "seed": seed,
            "control": "baseline", "shaping_lambda": 0.0, "final_return": -169.45,
        })
    summaries = [{
        "_path": "clean/bps_n3_summary.json",
        "env": "simple_spread_v3", "algo": "ippo", "num_agents": 3,
        "final_steps": 300000,
        "final_seeds": [100, 101, 102, 103, 104, 105, 106, 107, 108, 109],
        "probe_pool": [200, 201, 202, 203, 204], "replicates": 5,
        "search_overhead_interactions": 6250000, "decisions": [],
    }]
    return runs, summaries


def _injections() -> list[tuple[str, list[dict], list[dict], str]]:
    """Each entry: (label, runs, summaries, rule that must FAIL)."""
    cases = []

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs]
    for r in runs:
        if r.get("shaping_lambda"):
            r["final_return"] = -182.40 + 5.0 * r["shaping_lambda"]   # shaped score reported
    cases.append(("P1 shaped score reported as the return", runs, summ, "P1"))

    runs, summ = _clean_fixture()
    summ = [dict(summ[0])]
    summ[0]["final_seeds"] = [100, 101, 202, 103, 104]                 # 202 is a probe seed
    cases.append(("P2 probe seed reused as held-out", runs, summ, "P2"))

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs]
    for r in runs:
        if r.get("control") == "baseline":
            r["steps"] = 300000                                        # overhead never charged
    cases.append(("P3 search overhead uncharged", runs, summ, "P3"))

    runs, summ = _clean_fixture()
    summ = [dict(summ[0])]
    summ[0]["replicates"] = 3
    summ[0]["final_seeds"] = [100, 101, 102]
    cases.append(("P4 three replicates", runs, summ, "P4"))

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs]
    for r in runs:
        r["run_id"] = f"spread_v3_ippo_N3_final_s{r['seed']}"          # budget dropped from key
    cases.append(("P6a run id omits the budget", runs, summ, "P6"))

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs] + [{
        "_path": "inj/baseline_s104.json", "run_id": "spread_v3_ippo_N3_baseline_s104",
        "env_id": "simple_spread_v3", "algo": "ippo", "num_agents": 3, "max_cycles": 80,
        "steps": 11520, "seed": 104, "control": "baseline", "shaping_lambda": 0.0,
        "final_return": -266.20,
    }]
    cases.append(("P6b smoke run served as a full baseline", runs, summ, "P6"))

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs]
    for r in runs:                                   # drop the feasibility evidence ...
        r.pop("mean_abs_return", None)
        r.pop("mean_abs_delta_phi", None)
    runs.append({                                    # ... but a probe search is present
        "_path": "inj/probe_x_s200.json", "run_id": "spread_v3_ippo_N3_probe_x_s200",
        "env_id": "simple_spread_v3", "algo": "ippo", "num_agents": 3, "max_cycles": 80,
        "steps": 50000, "seed": 200, "control": "shaped", "shaping_lambda": 0.4,
        "final_return": -180.0, "stage": "probe",
    })
    cases.append(("P5 search with no feasibility evidence", runs, summ, "P5"))

    runs, summ = _clean_fixture()
    runs = [dict(r) for r in runs]
    runs[0]["seed"] = None
    cases.append(("P7 unseeded sampler", runs, summ, "P7"))

    return cases


def selftest() -> int:
    print("=" * 78)
    print("preflight failure-injection suite (the validator's regression test)")
    print("=" * 78)
    failures = 0

    runs, summ = _clean_fixture()
    res = {r["rule"]: r["status"] for r in run_all(runs, summ, [0.025, 0.05, 0.1, 0.2, 0.4])}
    clean_ok = all(v in ("PASS",) for k, v in res.items() if k != "P5")
    print(f"  [{'ok ' if clean_ok else 'BAD'}] clean control        -> {res}")
    failures += 0 if clean_ok else 1

    for label, r_, s_, rule in _injections():
        res = {x["rule"]: x["status"] for x in run_all(r_, s_, [0.025, 0.05, 0.1, 0.2, 0.4])}
        caught = res.get(rule) == "FAIL"
        print(f"  [{'ok ' if caught else 'MISSED'}] {label:<42s} -> {rule}={res.get(rule)}")
        failures += 0 if caught else 1

    total = 1 + len(_injections())
    print("-" * 78)
    print(f"{total - failures}/{total} checks behaved as required")
    return 0 if failures == 0 else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--runs", default="", help="glob for per-run JSON records")
    ap.add_argument("--summaries", default="", help="glob for audit summary JSONs")
    ap.add_argument("--grid", default="0.025,0.05,0.1,0.2,0.4")
    ap.add_argument("--json", default="", help="write the result table as JSON here")
    ap.add_argument("--inject", action="store_true", help="run the failure-injection suite")
    args = ap.parse_args()

    if args.inject:
        return selftest()

    grid = [float(x) for x in args.grid.split(",") if x.strip()]
    runs = load_many(args.runs) if args.runs else []
    summaries = load_many(args.summaries) if args.summaries else []
    results = run_all(runs, summaries, grid)
    print(render(results))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print("wrote", args.json)
    return 1 if any(r["status"] == "FAIL" for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
