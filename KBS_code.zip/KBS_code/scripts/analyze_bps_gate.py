"""Paired statistics for the budgeted-shaping deployment experiment.

Reads one or more ``*_summary.json`` files produced by ``bps_gate_experiment.py``
and reports, for the deployed pipeline and for the non-adaptive baselines:

* paired per-seed differences against unshaped training, pooled over pipeline
  replicates, with a stratified bootstrap confidence interval;
* the same against the budget-matched baseline when one was trained;
* the difference against a random draw from the same candidate pool;
* the rate at which the deployed configuration is worse than unshaped training;
* deployment regret against the best final-trained configuration.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bps_gate_experiment import realized_steps  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
STATS_OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "bps_gate_stats.json")

# Pooled statistics are persisted here rather than only printed, so that every number
# quoted in the manuscript is present in an artefact and the claim ledger's containment
# check can verify it. Keyed by summary file name; appended across invocations.
_STATS: dict[str, dict] = {}


def prefix(summary: dict, key: str) -> str:
    n = "na" if summary["num_agents"] is None else str(summary["num_agents"])
    env = summary["env"].replace("/", "-")
    tag = summary.get("run_tag") or ""
    suffix = f"_{tag}" if tag else ""
    return f"{env}_{summary['algo']}_N{n}_final_{key}{suffix}"


def per_seed(summary: dict, key: str, expected_steps: int | None = None) -> dict[int, float]:
    """Per-seed final returns, read from the immutable per-run logs.

    Reading from disk (rather than from the values cached inside the summary)
    means a run that was later re-trained to the correct budget is picked up
    automatically. ``expected_steps`` rejects any run whose realised step count
    does not match the intended budget, so a stale short run can never enter the
    statistics. When both the summary and the record carry a calibration target,
    they must agree as well: a run produced under a different ``rho_target`` is a
    different configuration and must not be pooled with this one.
    """
    pfx = prefix(summary, key)
    want_rho = summary.get("rho_target")
    out: dict[int, float] = {}
    for path in sorted(glob.glob(os.path.join(OUTDIR, pfx + "_s*.json"))):
        try:
            with open(path, encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            continue
        if expected_steps is not None:
            if int(rec.get("steps", -1)) != realized_steps(expected_steps):
                continue
        got_rho = rec.get("rho_target")
        if want_rho is not None and got_rho is not None:
            if abs(float(got_rho) - float(want_rho)) > 1e-9:
                continue
        out[int(rec["seed"])] = float(rec["final_return"])
    return out


def bootstrap_ci(diffs: np.ndarray, n_boot: int = 20000, alpha: float = 0.05,
                 seed: int = 0) -> tuple[float, float, float]:
    if diffs.size == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, diffs.size, size=(n_boot, diffs.size))
    means = diffs[idx].mean(axis=1)
    lo, hi = np.percentile(means, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(diffs.mean()), float(lo), float(hi)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summaries", default=None,
                    help="comma-separated summary json paths; default = all in artifacts/bps_gate")
    args = ap.parse_args()

    paths = ([p.strip() for p in args.summaries.split(",")] if args.summaries
             else sorted(glob.glob(os.path.join(OUTDIR, "*_summary.json"))))
    paths = [p for p in paths if os.path.exists(p) and "smoke" not in os.path.basename(p)]
    if not paths:
        raise SystemExit("no summaries found")

    for path in paths:
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        name = f"{s['env']} [{s['algo']}" + (f", N={s['num_agents']}]" if s["num_agents"] else "]")
        print(f"\n{'=' * 78}\n{name}   tag={os.path.basename(path)}\n{'=' * 78}")
        base = per_seed(s, "base", s["final_steps"])
        if not base:
            print("  no baseline runs, skipping")
            continue
        seeds = sorted(base)
        bm = s.get("budget_matched_baseline")
        bm_vals: dict[int, float] = {}
        if bm:
            for cand in ("base_bm", f"base_bm{bm['steps']}"):
                bm_vals = per_seed(s, cand, bm["steps"])
                if bm_vals:
                    break

        print(f"  baseline mean {np.mean(list(base.values())):.2f} over {len(seeds)} held-out seeds")
        if bm:
            print(f"  budget-matched baseline ({bm['steps']} steps/seed, "
                  f"{bm['scope']} amortisation, {bm['budget_ratio_vs_unshaped']:.2f}x budget): "
                  f"mean {bm['mean']:.2f}")

        gate_diffs, rand_diffs, gate_bm_diffs = [], [], []
        rows = []
        for d in s["decisions"]:
            rep = d["replicate"]
            if d["gate_choice"]:
                key = d["gate_choice"]["key"]
                label = d["gate_choice"]["name"]
                vals = per_seed(s, key, s["final_steps"])
            else:
                label, vals = "FALLBACK(base)", dict(base)
            shared = [x for x in seeds if x in vals]
            gd = np.asarray([vals[x] - base[x] for x in shared], dtype=float)
            gate_diffs.append(gd)
            if bm_vals:
                shared_bm = [x for x in shared if x in bm_vals]
                gate_bm_diffs.append(np.asarray([vals[x] - bm_vals[x] for x in shared_bm], dtype=float))
            rd = np.asarray([], dtype=float)
            if d["random_choice"]:
                rv = per_seed(s, d["random_choice"]["key"], s["final_steps"])
                sh = [x for x in shared if x in rv]
                if sh:
                    rd = np.asarray([rv[x] - base[x] for x in sh], dtype=float)
                    rand_diffs.append(rd)
            rows.append((rep, label, gd.mean(), rd.mean() if rd.size else float("nan"),
                         d["gate_deployed"]))

        gate_all = np.concatenate(gate_diffs) if gate_diffs else np.asarray([])
        rand_all = np.concatenate(rand_diffs) if rand_diffs else np.asarray([])
        g_m, g_lo, g_hi = bootstrap_ci(gate_all)
        print(f"\n  {'rep':>4s} {'deployed':<34s} {'mean gain':>10s} {'random-k gain':>14s} {'gate open':>10s}")
        for rep, label, gm, rm, deployed in rows:
            print(f"  {rep:>4d} {label:<34s} {gm:>+10.2f} {rm:>+14.2f} {str(deployed):>10s}")

        print(f"\n  H1 vs unshaped: mean {g_m:+.2f}  95% CI [{g_lo:+.2f}, {g_hi:+.2f}]  "
              f"(n={gate_all.size} seed-replicates)")
        print(f"       CI excludes 0: {'YES' if g_lo > 0 or g_hi < 0 else 'no'}")
        print(f"       marginal mean over replicates: {np.mean([r[2] for r in rows]):+.2f}   "
              f"replicates improved: {sum(1 for r in rows if r[2] > 0)}/{len(rows)}")
        bm_stats: dict[str, float | None] = {"mean": None, "lo": None, "hi": None}
        if gate_bm_diffs:
            bm_all = np.concatenate(gate_bm_diffs)
            bm_mean, bm_lo, bm_hi = bootstrap_ci(bm_all)
            bm_stats = {"mean": float(bm_mean), "lo": float(bm_lo), "hi": float(bm_hi)}
            print(f"  H1 vs budget-matched baseline: mean {bm_mean:+.2f}  "
                  f"95% CI [{bm_lo:+.2f}, {bm_hi:+.2f}]")
        rand_stats: dict[str, float | None] = {"mean": None, "lo": None, "hi": None}
        if rand_all.size:
            r_mean, r_lo, r_hi = bootstrap_ci(rand_all)
            rand_stats = {"mean": float(r_mean), "lo": float(r_lo), "hi": float(r_hi)}
            print(f"  random-k (same pool, non-adaptive): mean {r_mean:+.2f}  "
                  f"95% CI [{r_lo:+.2f}, {r_hi:+.2f}]")
            print(f"  gate - random-k difference in means: "
                  f"{gate_all.mean() - rand_all.mean():+.2f}")
            print(f"  random-k harmful replicates: "
                  f"{sum(1 for r in rows if r[3] < 0)}/{len(rows)}")
        oracle_gain = None
        gains = []
        for key in s.get("per_config", {}):
            if key.startswith("dsl::"):
                continue
            vals = per_seed(s, key, s["final_steps"])
            sh = [x for x in seeds if x in vals]
            if sh:
                gains.append(float(np.mean([vals[x] - base[x] for x in sh])))
        if gains:
            oracle_gain = max(gains)
        if oracle_gain is not None:
            regret = oracle_gain - np.mean([r[2] for r in rows])
            print(f"  oracle (best final-trained) gain {oracle_gain:+.2f}; "
                  f"mean regret of the gate {regret:+.2f}")

        _STATS[os.path.basename(path)] = {
            "env": s["env"], "algo": s["algo"], "num_agents": s["num_agents"],
            "final_steps": s["final_steps"], "run_tag": s.get("run_tag") or "",
            "n_held_out_seeds": len(seeds),
            "baseline_mean": float(np.mean(list(base.values()))),
            "budget_matched_mean": (float(bm["mean"]) if bm else None),
            "budget_matched_steps": (int(bm["steps"]) if bm else None),
            "vs_unshaped_mean": g_m, "vs_unshaped_lo": g_lo, "vs_unshaped_hi": g_hi,
            "replicates_improved": int(sum(1 for r in rows if r[2] > 0)),
            "replicates": len(rows),
            "marginal_mean_over_replicates": float(np.mean([r[2] for r in rows])),
            "vs_budget_matched_mean": bm_stats["mean"],
            "vs_budget_matched_lo": bm_stats["lo"],
            "vs_budget_matched_hi": bm_stats["hi"],
            "random_k_mean": rand_stats["mean"],
            "random_k_lo": rand_stats["lo"],
            "random_k_hi": rand_stats["hi"],
            "gate_minus_random_k": (float(gate_all.mean() - rand_all.mean())
                                    if rand_all.size else None),
            "random_k_harmful_replicates": (int(sum(1 for r in rows if r[3] < 0))
                                           if rand_all.size else None),
            "oracle_gain": (float(oracle_gain) if oracle_gain is not None else None),
            "mean_regret": (float(oracle_gain - np.mean([r[2] for r in rows]))
                            if oracle_gain is not None else None),
        }

    os.makedirs(os.path.dirname(STATS_OUT), exist_ok=True)
    existing = {}
    if os.path.exists(STATS_OUT):
        try:
            with open(STATS_OUT, encoding="utf-8") as f:
                existing = json.load(f)
        except Exception:
            existing = {}
    existing.update(_STATS)
    with open(STATS_OUT, "w", encoding="utf-8") as f:
        json.dump(existing, f, indent=2)
    print(f"\nwrote {os.path.normpath(STATS_OUT)} ({len(_STATS)} summar"
          f"{'y' if len(_STATS) == 1 else 'ies'} updated)")


if __name__ == "__main__":
    main()
