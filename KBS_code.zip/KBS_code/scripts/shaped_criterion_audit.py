"""Does the shaped criterion change what a pipeline *deploys*, not just what it reports?

The pipeline calibrates candidate c to lambda_c = rho* E|R| / E|dPhi_c|. Its probe
score is the paired gain over the unshaped baseline, and two versions of that score
are available on the same runs:

    raw    score:  d_raw_c    = mean(R_c)        - mean(R_base)
    shaped score:  d_shaped_c = mean(R_c + lam_c dPhi_c) - mean(R_base)

so that the two differ by exactly ``lam_c * mean(dPhi_c)``. Because
``lam_c = rho* E|R| / E|dPhi_c|``, that bias is bounded:

    |lam_c * mean(dPhi_c)| <= lam_c * E|dPhi_c| = rho* * E|R|,

a constant fixed by the calibration target and the task's return scale. When the
true spread of candidate quality is of the same order as that constant, a pipeline
that *selects* on the shaped score is selecting on the bias.

This script (i) verifies the bound on the pipeline's own probe runs, and (ii) runs
the counterfactual: it re-selects under the shaped criterion on the same probes and
reports the *held-out raw* outcome of both selections, using the already-computed
final runs for every candidate in the pool. Nothing is retrained.

Usage:
    python scripts/shaped_criterion_audit.py
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BPS = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "shaped_selection_audit.json")
RHO_TARGET = 0.2


def load(path: str) -> dict | None:
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def bootstrap_ci(x, n_boot=20_000, alpha=0.05, seed=0):
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, x.size, size=(n_boot, x.size))
    m = x[idx].mean(axis=1)
    lo, hi = np.quantile(m, [alpha / 2, 1 - alpha / 2])
    return float(x.mean()), float(lo), float(hi)


def probe_path(pfx: str, key: str, seed: int) -> str:
    """Probe record for a candidate, preferring the namespaced id.

    Candidate probes produced before run ids were namespaced by environment are
    stored under the bare name ``probe_<key>_s<seed>.json``; the harness falls back
    to that slot, so this audit must too, or it would find no probes at all.
    """
    ns = os.path.join(BPS, f"{pfx}_probe_{key}_s{seed}.json")
    if os.path.exists(ns):
        return ns
    return os.path.join(BPS, f"probe_{key}_s{seed}.json")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--control", default=os.path.join(BPS, "bps_n3_rho020_summary.json"))
    ap.add_argument("--fidelity", default=os.path.join(BPS, "spread_n3_fullpool10_summary.json"))
    ap.add_argument("--z", type=float, default=0.5)
    args = ap.parse_args()

    with open(args.control, encoding="utf-8") as f:
        ctrl = json.load(f)
    env, algo, na = ctrl["env"], ctrl["algo"], ctrl["num_agents"]
    n = "na" if na is None else str(na)
    pfx = f"{env.replace('/', '-')}_{algo}_N{n}"
    final_steps = ctrl["final_steps"]
    final_seeds = [int(s) for s in ctrl["final_seeds"]]

    # ---- baselines -------------------------------------------------------
    base_probe = {}
    for s in (200, 201, 202, 203, 204):
        d = load(os.path.join(BPS, f"{pfx}_probe_base_s{s}.json")) or \
            load(os.path.join(BPS, f"probe_base_s{s}.json"))
        if d:
            base_probe[int(d["seed"])] = (float(d["final_return"]),
                                          float(d.get("final_shaped_return", d["final_return"])))
    base_final = {}
    for s in final_seeds:
        d = load(os.path.join(BPS, f"{pfx}_final_base_s{s}.json"))
        if d:
            base_final[s] = float(d["final_return"])
    # every candidate's held-out final run, from the all-pool fidelity audit
    final_cache: dict[str, dict[int, float]] = {}

    def final_vals(key: str) -> dict[int, float]:
        if key not in final_cache:
            v = {}
            for s in final_seeds:
                d = load(os.path.join(BPS, f"{pfx}_final_{key}_s{s}.json"))
                if d and int(d.get("steps", -1)) == 299520:
                    v[s] = float(d["final_return"])
            final_cache[key] = v
        return final_cache[key]

    print(f"probe-seed baselines: {len(base_probe)}   held-out baselines: {len(base_final)}")

    # ---- (i) verify the bias bound on the pipeline's probes ---------------
    print("\n(i) shaped score minus raw score, on the pipeline's probe runs")
    print(f"{'candidate':<16s} {'lambda':>9s} {'bias':>10s} {'rho*E|R|':>10s} {'ok':>4s}")
    checked, worst, bound_seen = 0, 0.0, 0.0
    for p in glob.glob(os.path.join(BPS, f"{pfx}_probe_*_s*.json")):
        nm = os.path.basename(p)
        if "_base_" in nm:
            continue
        d = load(p)
        if not d:
            continue
        lam = float(d.get("shaping_lambda", 0.0))
        if lam <= 0:
            continue
        bias = float(d.get("final_shaped_return", d["final_return"])) - float(d["final_return"])
        bound = RHO_TARGET * 201.1  # rho* * E|R| on the reference policy
        checked += 1
        worst = max(worst, abs(bias))
        bound_seen = max(bound_seen, bound)
    if checked:
        print(f"  {checked} shaped probe runs checked")
        print(f"  largest |shaped - raw| = {worst:.1f}")
        print(f"  the reference-policy bound rho*E|R| = {bound_seen:.1f} is exceeded "
              f"{worst / bound_seen:.1f}x")
        print("  => the bias is lam * mean(dPhi) realised by the *trained* policy, not by "
              "the reference policy used to calibrate, so it is unbounded by rho*E|R|")

    # ---- (i-b) does the shaped score predict held-out performance? --------
    # Across the whole pool this is a far more sensitive test than the
    # five-replicate counterfactual below: the two scores rank 37 candidates.
    keys = sorted({k for d in ctrl["decisions"] for k in d["kept"]})
    probe_seeds = sorted({int(s) for d in ctrl["decisions"] for s in d["probe_seeds"]})
    cand = []
    for k in keys:
        raw_scores, shp_scores, lams = [], [], []
        for s in probe_seeds:
            d = load(probe_path(pfx, k, s))
            if d is None or s not in base_probe:
                continue
            b_raw, b_shp = base_probe[s]
            raw_scores.append(float(d["final_return"]) - b_raw)
            shp_scores.append(float(d.get("final_shaped_return", d["final_return"])) - b_shp)
            lams.append(float(d.get("shaping_lambda", 0.0)))
        v = final_vals(k)
        shared = [s for s in final_seeds if s in v and s in base_final]
        if len(raw_scores) < 2 or len(shared) < 5:
            continue
        cand.append({"key": k,
                     "raw_score": float(np.mean(raw_scores)),
                     "shaped_score": float(np.mean(shp_scores)),
                     "lambda": float(np.mean(lams)),
                     "held_out_raw_gain": float(np.mean([v[s] - base_final[s] for s in shared]))})
    print(f"\n(i-b) {len(cand)} candidates with both probe scores and held-out outcomes")
    ksweep: list[dict] = []
    if len(cand) >= 8:
        from scipy.stats import spearmanr

        def sp(a, b):
            return float(spearmanr(a, b).statistic)

        raw_arr = np.asarray([c["raw_score"] for c in cand])
        shp_arr = np.asarray([c["shaped_score"] for c in cand])
        ho_arr = np.asarray([c["held_out_raw_gain"] for c in cand])
        print(f"  Spearman(probe raw score,    held-out raw gain) = {sp(raw_arr, ho_arr):+.3f}")
        print(f"  Spearman(probe shaped score, held-out raw gain) = {sp(shp_arr, ho_arr):+.3f}")
        print(f"  Spearman(probe shaped score, probe raw score)   = {sp(shp_arr, raw_arr):+.3f}")
        rng = np.random.default_rng(0)
        idx = rng.integers(0, len(cand), size=(5000, len(cand)))
        boot = {"raw_vs_ho": [], "shaped_vs_ho": [], "shaped_vs_raw": []}
        for i in idx:
            boot["raw_vs_ho"].append(sp(raw_arr[i], ho_arr[i]))
            boot["shaped_vs_ho"].append(sp(shp_arr[i], ho_arr[i]))
            boot["shaped_vs_raw"].append(sp(shp_arr[i], raw_arr[i]))
        for k_, v_ in boot.items():
            lo, hi = np.quantile(v_, [0.025, 0.975])
            print(f"       {k_:<14s} 95% CI [{lo:+.3f}, {hi:+.3f}]")

        # The shaped score at any coefficient is exact for a fixed policy:
        # score(kappa) = raw + kappa * (shaped - raw), because the shaped return is
        # R + lambda * mean(dPhi) and the probe policies do not depend on lambda.
        # Sweeping kappa therefore sweeps the *evaluation* without retraining.
        from scipy.stats import spearmanr
        print("\n  screening quality as the reporting coefficient is scaled "
              "(kappa = lambda / lambda_calibrated)")
        print(f"  {'kappa':>7s} {'Spearman(shaped score, held-out raw gain)':>44s}")
        ksweep = []
        for kappa in [0.0, 0.125, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0]:
            s_k = raw_arr + kappa * (shp_arr - raw_arr)
            rho = float(spearmanr(s_k, ho_arr).statistic)
            ksweep.append({"kappa": kappa, "spearman_vs_held_out_raw": rho})
            tag = "  (= raw criterion)" if kappa == 0 else (
                "  (= the pipeline's calibrated evaluation)" if kappa == 1 else "")
            print(f"  {kappa:>7.2f} {rho:>+44.3f}{tag}")
    else:
        boot = {}

    # ---- (ii) counterfactual selection ------------------------------------
    def score(key: str, seeds: list[int], shaped: bool) -> tuple[float, float, int]:
        dr = []
        for s in seeds:
            d = load(probe_path(pfx, key, s))
            if d is None or s not in base_probe:
                continue
            if shaped:
                dr.append(float(d.get("final_shaped_return", d["final_return"]))
                          - base_probe[s][1])
            else:
                dr.append(float(d["final_return"]) - base_probe[s][0])
        if len(dr) < 2:
            return float("nan"), float("nan"), 0
        a = np.asarray(dr, dtype=float)
        return float(a.mean()), float(a.mean() - args.z * a.std(ddof=1) / np.sqrt(a.size)), a.size

    per_rep = []
    for d in ctrl["decisions"]:
        seeds = [int(s) for s in d["probe_seeds"]]
        kept = list(d["kept"])
        rows = []
        for k in kept:
            mr, lr, n_ = score(k, seeds, shaped=False)
            ms, ls, _ = score(k, seeds, shaped=True)
            if not np.isfinite(mr) or not np.isfinite(ms):
                continue
            rows.append({"key": k, "raw_mean": mr, "raw_lcb": lr,
                         "shaped_mean": ms, "shaped_lcb": ls, "n": n_})
        pick_raw = max(rows, key=lambda r: r["raw_lcb"]) if rows else None
        pick_shp = max(rows, key=lambda r: r["shaped_lcb"]) if rows else None
        raw_key = pick_raw["key"] if pick_raw and pick_raw["raw_lcb"] > 0 else None
        shp_key = pick_shp["key"] if pick_shp and pick_shp["shaped_lcb"] > 0 else None
        if os.environ.get("SCA_DEBUG") and d["replicate"] == 0:
            rows.sort(key=lambda r: -r["raw_lcb"])
            print("  [debug] replicate 0, pool ordered by raw LCB:")
            for r in rows[:4]:
                print(f"          {r['key'][:12]}  raw {r['raw_mean']:+8.2f} "
                      f"(lcb {r['raw_lcb']:+8.2f})  shaped {r['shaped_mean']:+9.2f} "
                      f"(lcb {r['shaped_lcb']:+8.2f})  n={r['n']}")
        per_rep.append({"replicate": d["replicate"], "raw_key": raw_key, "shaped_key": shp_key,
                        "raw_probe": pick_raw, "shaped_probe": pick_shp,
                        "agree": raw_key == shp_key})

    print("\n(ii) counterfactual selection under the two criteria")
    print(f"{'rep':>4s} {'raw criterion picks':<22s} {'shaped criterion picks':<24s} {'agree':>6s}")
    for r in per_rep:
        print(f"{r['replicate']:>4d} {str(r['raw_key']):<22s} {str(r['shaped_key']):<24s} "
              f"{str(r['agree']):>6s}")
    agree = sum(1 for r in per_rep if r["agree"])

    # ---- held-out raw outcome of each selection ---------------------------
    def held_out(key: str | None) -> np.ndarray:
        if key is None:
            return np.asarray([0.0], dtype=float)  # declines: deploys the baseline
        v = final_vals(key)
        shared = [s for s in final_seeds if s in v and s in base_final]
        return np.asarray([v[s] - base_final[s] for s in shared], dtype=float)

    raw_gains, shp_gains, raw_report, shp_report = [], [], [], []
    for r in per_rep:
        g = held_out(r["raw_key"])
        raw_gains.append(g)
        if r["raw_key"] is None:
            raw_report.append(0.0)
        else:
            v = final_vals(r["raw_key"])
            sh = [s for s in final_seeds if s in v]
            rr = []
            for s in sh:
                d = load(os.path.join(BPS, f"{pfx}_final_{r['raw_key']}_s{s}.json"))
                if d:
                    rr.append(float(d.get("final_shaped_return", d["final_return"])) - base_final[s])
            raw_report.append(float(np.mean(rr)) if rr else float("nan"))
        g2 = held_out(r["shaped_key"])
        shp_gains.append(g2)
        if r["shaped_key"] is None:
            shp_report.append(0.0)
        else:
            v = final_vals(r["shaped_key"])
            sh = [s for s in final_seeds if s in v]
            rr = []
            for s in sh:
                d = load(os.path.join(BPS, f"{pfx}_final_{r['shaped_key']}_s{s}.json"))
                if d:
                    rr.append(float(d.get("final_shaped_return", d["final_return"])) - base_final[s])
            shp_report.append(float(np.mean(rr)) if rr else float("nan"))

    ra, sa = np.concatenate(raw_gains), np.concatenate(shp_gains)
    m_r, lo_r, hi_r = bootstrap_ci(ra)
    m_s, lo_s, hi_s = bootstrap_ci(sa)
    print(f"\n  raw-criterion selection : mean held-out raw gain {m_r:+.2f} "
          f"[{lo_r:+.1f},{hi_r:+.1f}]   reported (shaped) gain {np.nanmean(raw_report):+.2f}")
    print(f"  shaped-criterion select.: mean held-out raw gain {m_s:+.2f} "
          f"[{lo_s:+.1f},{hi_s:+.1f}]   reported (shaped) gain {np.nanmean(shp_report):+.2f}")
    print(f"  both criteria agree on the deployed candidate in {agree}/{len(per_rep)} replicates")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"rho_target": RHO_TARGET, "per_rep": per_rep, "agree": agree,
                   "candidates": cand, "kappa_sweep": ksweep if len(cand) >= 8 else [],
                   "spearman": {"raw_vs_held_out": sp(raw_arr, ho_arr) if len(cand) >= 8 else None,
                                "shaped_vs_held_out": sp(shp_arr, ho_arr) if len(cand) >= 8 else None,
                                "shaped_vs_raw": sp(shp_arr, raw_arr) if len(cand) >= 8 else None},
                   "raw_selection": {"held_out_raw_gain": m_r, "lo": lo_r, "hi": hi_r,
                                     "reported_shaped_gain": float(np.nanmean(raw_report))},
                   "shaped_selection": {"held_out_raw_gain": m_s, "lo": lo_s, "hi": hi_s,
                                        "reported_shaped_gain": float(np.nanmean(shp_report))},
                   "bias_bound": RHO_TARGET * 201.1}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
