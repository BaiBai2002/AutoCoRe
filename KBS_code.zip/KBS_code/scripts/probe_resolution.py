"""Probe-budget floor: is the *search* budget large enough to justify a deployment?

A candidate can only be deployed if its probe score beats the unshaped baseline by more than the
noise of that comparison. We measure the operative quantity at each probe budget, using only cached
probe records:

    paired_gain(c, s) = probe(c, s) - probe(unshaped baseline, s)        # same seed, so the
                                                                          # episode noise cancels
    signal = mean_s paired_gain(c*, s)      for the best candidate c*
    noise  = std_s  paired_gain(c*, s)
    S/B    = signal / noise

``S/B >= 1`` is the *floor*: the best candidate has reached the comparison's own noise, so a
selector can (with enough seeds / a confidence bound) justify deploying. Below it, no candidate is
distinguishable from the baseline and **every** selector abstains, whatever the threshold -- which
is what the pre-registered P1 run found at a 14K probe. We also report the between-candidate vs
within-candidate ratio, to show the probe still *ranks* at the short budget (so the failure is
resolution of the deployment decision, not the probe's ranking).

Writes ``artifacts/diagnostics/probe_resolution.json``.
"""
from __future__ import annotations

import collections
import glob
import json
import os
import re
import statistics as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BP = os.path.join(ROOT, "artifacts", "bps_gate")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "probe_resolution.json")
ENV = "simple_spread_v3"


def key_of(path: str) -> str:
    m = re.search(r"_probe_(.+?)_s(\d+)\.json$", os.path.basename(path))
    if not m:
        return "UNPARSED"
    return m.group(1).split("_")[0].lstrip("_")


def main() -> None:
    data: dict[int, dict[str, dict[int, float]]] = collections.defaultdict(
        lambda: collections.defaultdict(dict))
    for f in glob.glob(os.path.join(BP, f"{ENV}_ippo_Nna_probe*.json")):
        rec = json.load(open(f, encoding="utf-8"))
        data[int(rec.get("steps", 0))][key_of(f)][int(rec["seed"])] = float(rec["final_return"])

    rows = []
    for steps in sorted(data):
        cands = data[steps]
        base = cands.get("base", {})
        if not base:
            rows.append({"probe_steps": steps, "note": "no unshaped baseline record cached"})
            continue

        best = None
        for k, byseed in cands.items():
            if k == "base":
                continue
            common = [s for s in byseed if s in base]
            if len(common) < 2:
                continue
            g = [byseed[s] - base[s] for s in common]
            m_, sd_ = st.mean(g), st.stdev(g)
            if best is None or m_ > best[2]:
                best = (k, common, m_, sd_)
        if best is None:
            rows.append({"probe_steps": steps, "note": "no candidate paired with the baseline"})
            continue

        # secondary: does the probe still rank candidates at this budget?
        cm, wi = [], []
        for k, byseed in cands.items():
            if k == "base" or len(byseed) < 2:
                continue
            cm.append(st.mean(byseed.values()))
            wi.append(st.stdev(byseed.values()))
        ratio = round(st.stdev(cm) / st.mean(wi), 2) if len(cm) >= 3 and st.mean(wi) else None

        k, common, m_, sd_ = best
        rows.append({
            "probe_steps": steps,
            "n_seeds": len(common),
            "best_candidate": k,
            "paired_gain_vs_unshaped": round(m_, 2),
            "noise_std_across_seeds": round(sd_, 2),
            "signal_over_noise": round(m_ / sd_, 2) if sd_ else None,
            "reaches_noise_floor": bool(sd_ and m_ / sd_ >= 1.0),
            "between_over_within": ratio,
            "probe_ranks_candidates": bool(ratio and ratio > 1.0),
        })

    out = {"env": ENV,
           "metric": ("mean paired gain of the best candidate over the unshaped baseline, divided "
                      "by its across-seed scatter, at the probe (search) budget"),
           "rows": rows}
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
