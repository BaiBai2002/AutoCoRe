"""Collect all raw run results into unified CSVs."""
import sys, os, json, glob, csv
from pathlib import Path
from collections import defaultdict
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from autocore.utils.io import ensure_dir

RAW = PROJECT_ROOT / "artifacts" / "raw_runs"
PROC = PROJECT_ROOT / "artifacts" / "processed"
OUT = PROJECT_ROOT / "artifacts" / "paper_ready"
ensure_dir(str(OUT))
ensure_dir(str(PROJECT_ROOT / "artifacts" / "csv"))

def collect():
    all_runs = []
    for f in glob.glob(str(RAW / "*.json")):
        try:
            d = json.load(open(f))
            all_runs.append(d)
        except: pass

    # Run Index CSV
    rows = []
    for r in sorted(all_runs, key=lambda x: x.get('job_name', x.get('run_id', ''))):
        rows.append({
            'run_id': r.get('run_id', r.get('job_name', '?')),
            'env': r.get('env_id', '?'),
            'method': r.get('method', '?'),
            'provider': r.get('provider', '?'),
            'seed': r.get('seed', '?'),
            'status': r.get('status', '?'),
            'final_return': r.get('final_return'),
            'wall_time': r.get('wall_time', 0),
            'error': (r.get('error', '')[:150]) if r.get('error') else '',
            'timestamp': r.get('timestamp', ''),
        })

    with open(PROJECT_ROOT / 'artifacts' / 'csv' / 'run_index.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['run_id','env','method','provider','seed','status','final_return','wall_time','error','timestamp'])
        w.writeheader(); w.writerows(rows)

    # Main results per env per method
    completed = [r for r in all_runs if r.get('status') == 'completed' and r.get('final_return') is not None]
    env_method = defaultdict(list)
    for r in completed:
        env_method[(r['env_id'], r['method'])].append(r['final_return'])

    mrows = []
    for (env, method), returns in sorted(env_method.items()):
        arr = np.array(returns)
        mrows.append({
            'env': env, 'method': method,
            'mean': np.mean(arr), 'std': np.std(arr, ddof=1),
            'n': len(arr), 'min': np.min(arr), 'max': np.max(arr),
        })

    with open(PROJECT_ROOT / 'artifacts' / 'csv' / 'main_results.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['env','method','mean','std','n','min','max'])
        w.writeheader(); w.writerows(mrows)

    print(f"Collected: {len(rows)} runs, {len(mrows)} env×method groups")
    print(f"CSV saved to artifacts/csv/")

if __name__ == "__main__":
    collect()
