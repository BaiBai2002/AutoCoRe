"""Unshaped-baseline sweep: locate the "structurally failing" regime and close the
learnability table.

Two open items in the manuscript are addressed by one measurement.

1. *The failing-baseline regime.* The paper's limitations section notes that the
   regime in which shaping has the best chance of a genuine effect — an unshaped
   baseline that still earns what a no-op policy earns — is untested, because at
   300K steps the baselines already learn. Which budget puts a baseline back into
   that regime is an empirical question, and it can be read off a budget sweep of the
   *unshaped* baseline.

2. *Learnability coverage.* The preconditions are stated and measured, but only for
   the settings that happened to have held-out runs. Every setting whose feasibility
   verdict the paper reports needs a learnability row, or its verdict is
   uninterpretable by the paper's own rule.

Both use the harness's own `train()`, so the protocol — budget accounting, seeding,
evaluator, cache keys — is identical to the audits. Runs are cached, so re-running is
free and the 300K rows reuse the published baselines where the seeds match.

Writes ``artifacts/diagnostics/baseline_sweep.json``.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np  # noqa: E402

from bps_gate_experiment import OUTDIR, realized_steps, run_id, train  # noqa: E402

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "baseline_sweep.json")


def bootstrap_ci(diffs: np.ndarray, n_boot: int = 20000, seed: int = 0
                 ) -> tuple[float, float, float]:
    if diffs.size == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, diffs.size, size=(n_boot, diffs.size))
    means = diffs[idx].mean(axis=1)
    lo, hi = np.percentile(means, [2.5, 97.5])
    return float(diffs.mean()), float(lo), float(hi)


def sweep_rid(env: str, algo: str, n: int | None, budget: int, seed: int,
              harness_budget: int) -> str:
    """Run id for a sweep cell, never colliding with a full-budget record.

    ``run_id`` deliberately omits the training budget, because within one audit the
    budget is constant. A sweep varies it, so reusing the harness's canonical id would
    let a 12.8K run overwrite a 299,520-step record -- the defect the manuscript
    reports as P6, and one this script actually caused on its first run (recovered from
    the released bundle; see ``scripts/restore_from_bundle.py``). Only the harness's own
    budget may reuse its id, where the call is a cache hit rather than a write.
    """
    if budget == harness_budget:
        return run_id(env, algo, n, "final", "base", seed)
    return run_id(env, algo, n, "baseline", f"base{budget // 1000}k", seed)


def run_one(job: tuple) -> tuple:
    env, n, budget, seed, algo, max_cycles, harness_budget = job
    rid = sweep_rid(env, algo, n, budget, seed, harness_budget)
    val = train(env, algo, n, budget, seed, None, rid, 0.2, hidden=512,
                max_cycles=max_cycles)
    rec = None
    p = os.path.join(OUTDIR, f"{rid}.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                rec = json.load(f)
        except Exception:
            rec = None
    return (env, n, budget, seed, val, rec)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--budgets", default="12800,25600,51200,102400,300000")
    ap.add_argument("--seeds", default="100,101,102")
    ap.add_argument("--workers", type=int, default=5)
    ap.add_argument("--algo", default="ippo")
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--harness-budget", type=int, default=300000,
                    help="the budget at which the harness's own (budget-agnostic) run "
                         "id may be reused; any other budget gets its own namespace")
    args = ap.parse_args()

    budgets = [int(b) for b in args.budgets.split(",")]
    seeds = [int(s) for s in args.seeds.split(",")]

    # (env, num_agents, budgets) triples. `num_agents=None` means "the environment's
    # own default" and reproduces the harness's cache key exactly, so the 300K rows
    # reuse the published baselines instead of retraining them. The first block
    # locates the failing regime; the second closes the learnability table for the
    # settings whose feasibility verdict the paper reports.
    configs = [
        ("simple_spread_v3", None, budgets),
        ("simple_spread_v3", 7, budgets),
        ("simple_reference_v3", None, [300000]),
        ("simple_speaker_listener_v4", None, [300000]),
        ("simple_push_v3", None, [300000]),
    ]
    jobs = [(env, n, b, s, args.algo, args.max_cycles, args.harness_budget)
            for env, n, bs in configs for b in bs for s in seeds]
    print(f"jobs: {len(jobs)} ({len(configs)} configs x {len(seeds)} seeds)")

    results = []
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for out in pool.map(run_one, jobs):
            results.append(out)
            env, n, b, s, val, rec = out
            print(f"  {env:<26s} N={n} budget={b:>7d} seed={s} final="
                  f"{'None' if val is None else f'{val:.2f}'}", flush=True)

    rows = []
    for env, n, bs in configs:
        for b in bs:
            sel = [r for r in results if r[0] == env and r[1] == n and r[2] == b]
            fin, noop, rand = [], [], []
            for _, _, _, _, val, rec in sel:
                if rec is None or val is None:
                    continue
                fin.append(rec["final_return"])
                if "noop_return" in rec:
                    noop.append(rec["noop_return"])
                if "random_return" in rec:
                    rand.append(rec["random_return"])
            if not fin:
                continue
            fin_a = np.asarray(fin, dtype=float)
            noop_a = np.asarray(noop, dtype=float) if noop else np.full_like(fin_a, np.nan)
            rand_a = np.asarray(rand, dtype=float) if rand else np.full_like(fin_a, np.nan)
            d = fin_a - noop_a
            m, lo, hi = bootstrap_ci(d, seed=b)
            rows.append({
                "env": env, "num_agents": n, "budget": b, "n_seeds": int(fin_a.size),
                "baseline_mean": float(fin_a.mean()),
                "noop_mean": float(np.nanmean(noop_a)),
                "random_mean": float(np.nanmean(rand_a)),
                "gap_vs_noop": m, "gap_lo": lo, "gap_hi": hi,
                "gain_over_random": float(np.nanmean(rand_a) - fin_a.mean()),
                "realized_steps": realized_steps(b),
                # "failing regime" = the baseline is not distinguishable from no-op
                "structurally_failing": bool(lo <= 0.0 <= hi),
            })

    # num_agents is None for the environments' own default, so it is mapped to -1
    # before sorting: comparing None with an int raises.
    rows.sort(key=lambda r: (r["env"],
                             -1 if r["num_agents"] is None else r["num_agents"],
                             r["budget"]))
    print(f"\n{'env':<26s} {'N':>2s} {'budget':>8s} {'baseline':>10s} {'noop':>10s} "
          f"{'gap vs noop':>28s} {'gain vs rand':>13s}  regime")
    for r in rows:
        n_lab = "def" if r["num_agents"] is None else str(r["num_agents"])
        print(f"{r['env']:<26s} {n_lab:>2s} {r['budget']:>8d} "
              f"{r['baseline_mean']:>10.2f} {r['noop_mean']:>10.2f} "
              f"{r['gap_vs_noop']:>+9.2f} [{r['gap_lo']:+8.2f},{r['gap_hi']:+8.2f}] "
              f"{r['gain_over_random']:>13.2f}  "
              f"{'FAILING' if r['structurally_failing'] else 'learning'}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"algo": args.algo, "seeds": seeds, "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
