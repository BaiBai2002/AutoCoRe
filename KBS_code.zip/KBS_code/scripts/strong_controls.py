"""P4: strong simple controls for the selection rule.

The P5 go/no-go question is whether the simplest alternatives explain the pipeline's
gain. Everything here is re-analysis of runs already on disk (evidence level C): the
probe records, the final runs for *every* candidate in the rich pool, and the
target-independent unshaped and budget-matched baselines. Nothing is retrained.

Rules compared, all on the same pool, the same probe seeds, the same held-out seeds
and the same budget accounting:

  abstain          deploy nothing
  aligned          deploy the task-aligned potential at the calibrated coefficient,
                   with no search at all
  lcb              our rule: raw-return probe LCB > 0, then the highest LCB
  mean>0           a plain threshold on the probe mean instead of an LCB
  argmax           deploy the best probe mean unconditionally (no gate)
  random           a uniformly random candidate from the pool
  shaped-lcb       the same LCB rule scored on the *shaped* probe return (F2 control)

Usage: python scripts/strong_controls.py
"""
from __future__ import annotations

import glob
import json
import os
import sys

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
BPS = os.path.join(ROOT, "artifacts", "bps_gate")
OUT = os.path.join(ROOT, "artifacts", "diagnostics", "strong_controls.json")
CTRL = os.path.join(BPS, "bps_n3_rho020_summary.json")
Z = 0.5


def load(p):
    if not os.path.exists(p):
        return None
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def probe_path(pfx, key, seed):
    ns = os.path.join(BPS, f"{pfx}_probe_{key}_s{seed}.json")
    return ns if os.path.exists(ns) else os.path.join(BPS, f"probe_{key}_s{seed}.json")


def boot_ci(x, n=20000, alpha=0.05, seed=0):
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    m = x[rng.integers(0, x.size, size=(n, x.size))].mean(axis=1)
    lo, hi = np.quantile(m, [alpha / 2, 1 - alpha / 2])
    return float(x.mean()), float(lo), float(hi)


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default="bps_n3_rho020_summary.json")
    ap.add_argument("--tag", default=None)
    args = ap.parse_args()
    ctrl_path = args.summary if os.path.isabs(args.summary) else os.path.join(BPS, args.summary)
    s = json.load(open(ctrl_path, encoding="utf-8"))
    env, algo = s["env"], s["algo"]
    pfx = f"{env.replace('/', '-')}_{algo}_Nna"
    seeds = [int(x) for x in s["final_seeds"]]
    bm = s["budget_matched_baseline"]
    bm_steps = bm["steps"]

    base = {}
    for sd in seeds:
        d = load(os.path.join(BPS, f"{pfx}_final_base_s{sd}.json"))
        if d:
            base[sd] = float(d["final_return"])
    bmv = {}
    for sd in seeds:
        # step-specific key only: the bare ``base_bm`` slot is a legacy alias that
        # holds a run trained to a *different* budget (P6).
        d = load(os.path.join(BPS, f"{pfx}_final_base_bm{bm_steps}_s{sd}.json"))
        if d is not None:
            bmv[sd] = float(d["final_return"])
    print(f"baselines loaded: unshaped {len(base)} seeds, budget-matched {len(bmv)} seeds "
          f"at {bm_steps} steps")

    base_probe = {}
    for sd in (200, 201, 202, 203, 204):
        d = load(os.path.join(BPS, f"{pfx}_probe_base_s{sd}.json")) or \
            load(os.path.join(BPS, f"probe_base_s{sd}.json"))
        if d:
            base_probe[int(d["seed"])] = (float(d["final_return"]),
                                          float(d.get("final_shaped_return", d["final_return"])))

    def finals(key):
        v = {}
        for sd in seeds:
            d = load(os.path.join(BPS, f"{pfx}_final_{key}_s{sd}.json"))
            if d:
                v[sd] = float(d["final_return"])
        return v

    # task-aligned config: ``per_config`` maps a weight hash -> display name, so the
    # aligned candidate is located by its *name*, not its key.
    aligned_key = None
    for k, v in s.get("per_config", {}).items():
        nm = v.get("name") if isinstance(v, dict) else v
        if nm and "task_aligned" in str(nm):
            aligned_key = k
            break
    print(f"{env} [{algo}]: aligned config = {aligned_key}")

    rules = {r: {"deploy": []} for r in
             ("abstain", "aligned", "lcb", "mean>0", "argmax", "random", "shaped-lcb")}

    skipped = 0
    for d in s["decisions"]:
        pseeds = [int(x) for x in d["probe_seeds"]]
        # Older summaries use different field names for the replicate's candidate set;
        # a replicate we cannot reconstruct is skipped and counted, never guessed.
        kept = d.get("kept") or d.get("pool") or d.get("candidates") or []
        if not kept:
            skipped += 1
            continue
        rows = []
        for k in kept:
            rr, ss = [], []
            for sd in pseeds:
                pr = load(probe_path(pfx, k, sd))
                if pr is None or sd not in base_probe:
                    continue
                rr.append(float(pr["final_return"]) - base_probe[sd][0])
                ss.append(float(pr.get("final_shaped_return", pr["final_return"]))
                          - base_probe[sd][1])
            if len(rr) < 2:
                continue
            rr, ss = np.asarray(rr), np.asarray(ss)
            rows.append({"key": k, "mean": float(rr.mean()),
                         "lcb": float(rr.mean() - Z * rr.std(ddof=1) / np.sqrt(rr.size)),
                         "smean": float(ss.mean()),
                         "slcb": float(ss.mean() - Z * ss.std(ddof=1) / np.sqrt(ss.size))})
        if not rows:
            continue

        def pick(rule):
            if rule == "abstain":
                return None
            if rule == "aligned":
                return aligned_key
            if rule == "lcb":
                b = max(rows, key=lambda r: r["lcb"])
                return b["key"] if b["lcb"] > 0 else None
            if rule == "mean>0":
                b = max(rows, key=lambda r: r["mean"])
                return b["key"] if b["mean"] > 0 else None
            if rule == "argmax":
                return max(rows, key=lambda r: r["mean"])["key"]
            if rule == "shaped-lcb":
                b = max(rows, key=lambda r: r["slcb"])
                return b["key"] if b["slcb"] > 0 else None
            if rule == "random":
                rc = d.get("random_choice")
                rc = rc.get("key") if isinstance(rc, dict) else rc
                return rc
            raise ValueError(rule)

        for rule in rules:
            rules[rule]["deploy"].append(pick(rule))
    if skipped:
        print(f"NOTE: {skipped}/{len(s['decisions'])} replicates were not reconstructible "
              f"from this summary's records (older format or missing probe files); "
              f"their rules are reported over the reconstructible subset only.")

    print(f"\n{'rule':<12s} {'vs unshaped':>26s} {'vs budget-matched':>26s}  deploys")
    out = {}
    for rule, R in rules.items():
        gb, gm, n = [], [], 0
        for key in R["deploy"]:
            n += 1 if key else 0
            # Abstaining means the baseline is what you get, so the gain is exactly 0
            # by construction -- using a 0.0 sentinel would report a spurious gain.
            if key is None:
                vals = dict(base)
            else:
                vals = finals(key)
            sh = [sd for sd in seeds if sd in vals and sd in base]
            gb += [vals[sd] - base[sd] for sd in sh]
            shb = [sd for sd in sh if sd in bmv]
            gm += [vals[sd] - bmv[sd] for sd in shb]
        mb, lob, hib = boot_ci(gb)
        mm, lom, him = boot_ci(gm)
        out[rule] = {"gain_vs_base": mb, "vs_base_lo": lob, "vs_base_hi": hib,
                     "gain_vs_bm": mm, "vs_bm_lo": lom, "vs_bm_hi": him,
                     "n_deploy": n, "n_pairs": len(gb)}
        print(f"{rule:<12s} {mb:+9.2f} [{lob:+7.2f},{hib:+7.2f}] "
              f"{mm:+9.2f} [{lom:+7.2f},{him:+7.2f}]  {n}/{len(R['deploy'])}")

    print("\nread: a rule 'explains the benefit' if its interval overlaps the LCB rule's;"
          "\nthe go/no-go question (P5) is whether any simple rule matches 'lcb'.")
    tag = args.tag or os.path.basename(ctrl_path).replace("_summary.json", "")
    json.dump({"settings": os.path.basename(ctrl_path), "rules": out},
              open(os.path.join(ROOT, "artifacts", "diagnostics",
                                f"strong_controls_{tag}.json"), "w"), indent=2)
    print("\nwrote", OUT)


if __name__ == "__main__":
    main()
