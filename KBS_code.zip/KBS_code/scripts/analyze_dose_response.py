"""Aggregate the coefficient dose-response runs into paired statistics.

Scans every per-run record in ``artifacts/diagnostics/dose`` (which may have been
produced by more than one invocation, e.g. a main sweep and a confirmatory
extension on extra seeds), pairs each shaped run with the unshaped baseline on
the same held-out seed, and reports the mean paired change in raw return with a
bootstrap interval. Writes ``feasibility_dose_response.json``.

Nothing is recomputed from training; this reads only the per-run logs.
"""
from __future__ import annotations

import glob
import json
import os
import re

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
DOSE_DIR = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "dose")
BPS_DIR = os.path.join(PROJECT_ROOT, "artifacts", "bps_gate")
OUT = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics", "dose_response_merged.json")

# The calibration of THESE runs. The dose sweep runs at the 80-cycle episode convention
# (``--max-cycles 80``), for which the closed-form coefficient differs from the
# feasibility-table values (47.84 / 52.90, quoted per the original episode convention).
# The dose experiment was designed and is analysed around 74.7885 / 29.0996 -- the PLAN of
# ``feasibility_dose_response.py`` centres the grid there, the run records apply them, and
# ``feasibility_dose_response.json`` stores them as ``lambda_star`` (with
# ``rho_over_rhostar = lambda / lambda_star`` consistent). The figure and the text must
# normalise by the same values.
LAMBDA_STAR = {"spread_coverage": 74.7885, "spread_assignment": 29.0996}
PAT = re.compile(r"dose_(?P<pot>.+)_lam(?P<lam>[0-9.]+)_s(?P<seed>\d+)\.json$")
NUM_ENVS, HORIZON = 16, 80


def realized(steps: int) -> int:
    return max(1, int(steps) // (NUM_ENVS * HORIZON)) * (NUM_ENVS * HORIZON)


def bootstrap_ci(x, n_boot=20_000, alpha=0.05, seed=0):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return float("nan"), float("nan")
    idx = rng.integers(0, x.size, size=(n_boot, x.size))
    means = x[idx].mean(axis=1)
    lo, hi = np.quantile(means, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


def main() -> None:
    env = "simple_spread_v3"
    # baseline final runs (lambda = 0), validated by budget/horizon
    base = {}
    for p in glob.glob(os.path.join(BPS_DIR, f"{env}_ippo_Nna_final_base_s*.json")):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        if d.get("dsl") is not None or abs(float(d.get("shaping_lambda", -1))) > 1e-9:
            continue
        if d.get("env") != env or int(d.get("max_cycles", -1)) != 80:
            continue
        base[int(d["seed"])] = float(d["final_return"])
    base_steps = None

    grouped: dict[tuple[str, float], dict[int, float]] = {}
    shaped: dict[tuple[str, float], dict[int, float]] = {}
    steps_seen: set[int] = set()
    for p in glob.glob(os.path.join(DOSE_DIR, "dose_*.json")):
        m = PAT.search(os.path.basename(p))
        if not m:
            continue
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        if d.get("env") != env or int(d.get("max_cycles", -1)) != 80:
            continue
        pot, lam, seed = m.group("pot"), float(m.group("lam")), int(m.group("seed"))
        if abs(float(d.get("shaping_lambda", -1)) - lam) > 1e-6:
            continue
        grouped.setdefault((pot, lam), {})[seed] = float(d["final_return"])
        shaped.setdefault((pot, lam), {})[seed] = float(d.get("final_shaped_return",
                                                                 d["final_return"]))
        steps_seen.add(int(d.get("steps", -1)))

    if len(steps_seen) != 1:
        print(f"warning: mixed step counts in dose dir: {sorted(steps_seen)}")
    steps = sorted(steps_seen)[-1] if steps_seen else 0
    base = {s: v for s, v in base.items() if True}

    rows = []
    for pot in sorted({k[0] for k in grouped}):
        lam_star = LAMBDA_STAR.get(pot, float("nan"))
        lams = sorted(l for (p_, l) in grouped if p_ == pot)
        print(f"\n{pot}  (lambda* = {lam_star:.2f}); baseline n={len(base)}, "
              f"mean {np.mean(list(base.values())):.2f}")
        print(f"{'lambda':>10s} {'lam/lam*':>9s} {'n':>3s} {'raw mean':>10s} "
              f"{'delta':>9s} {'95% CI':>20s} {'sign':>4s} {'shaped delta':>13s}")
        for lam in lams:
            got = grouped[(pot, lam)]
            common = sorted(s for s in got if s in base)
            if len(common) < 2:
                continue
            d = np.asarray([got[s] - base[s] for s in common], dtype=float)
            lo, hi = bootstrap_ci(d)
            mean = float(d.mean())
            sign = "+" if lo > 0 else ("-" if hi < 0 else "0")
            sh = shaped.get((pot, lam), {})
            sh_delta = float(np.mean([sh[s] - base[s] for s in common if s in sh])) \
                if any(s in sh for s in common) else float("nan")
            rows.append({"potential": pot, "lambda": lam, "lambda_star": lam_star,
                         "rho_over_rhostar": lam / lam_star if lam_star else float("nan"),
                         "n": len(common),
                         "raw_mean": float(np.mean([got[s] for s in common])),
                         "base_mean": float(np.mean([base[s] for s in common])),
                         "delta": mean, "delta_std": float(d.std(ddof=1)),
                         "ci_lo": lo, "ci_hi": hi,
                         "shaped_delta": sh_delta,
                         "significantly_different": bool(lo > 0 or hi < 0)})
            print(f"{lam:>10.4f} {lam/lam_star:>9.4f} {len(common):>3d} "
                  f"{np.mean([got[s] for s in common]):>10.2f} {mean:>+9.2f} "
                  f"{f'[{lo:+.2f},{hi:+.2f}]':>20s} {sign:>4s} {sh_delta:>+13.2f}")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"env": env, "steps": steps, "grid_ceiling": 0.4,
                   "base_mean": float(np.mean(list(base.values()))) if base else None,
                   "base_n": len(base), "rows": rows}, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
