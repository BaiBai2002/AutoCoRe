# Follow-up runner: completes the grounded-proposer study.
#
# Waits for the first queue to finish, then re-runs EVERY expected draw that has no summary
# (so the GPT-6 timeouts and any other silent loss are repaired), with up to 3 attempts per
# draw and an explicit FAILED/GAVE_UP line in the log. Finally runs the repair-arm ablation.
#
# Usage:  powershell -NoProfile -File scripts/run_grounded_followup.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/followup.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt $a) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000",
            "--probe-seeds", "200,201,202", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

# ---- wait for the first queue to finish so the two never contend for the GPU
Write-Log "waiting for the first queue to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/grounded_queue.log" -Pattern "GROUNDED_QUEUE_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}
Write-Log "first queue is done; completing the study"

$commonGrounded = @("--llm-v2", "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
    "--final-steps", "300000", "--final-seeds", "100,101,102,103,104")

# ---- 1. frontier models, grounded, N=3 (only the missing draws actually run)
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confv2gpt_6_astra_r$r" -Extra (@("--provider", "gpt_6_astra") + $commonGrounded + @("--rep-offset", "$r"))
    Run-Draw -Tag "confv2gemini_31_pro_r$r" -Extra (@("--provider", "gemini_31_pro") + $commonGrounded + @("--rep-offset", "$r"))
    Run-Draw -Tag "confv2claude_sonnet_46_r$r" -Extra (@("--provider", "claude_sonnet_46") + $commonGrounded + @("--rep-offset", "$r"))
    Run-Draw -Tag "confv2grok_47_r$r" -Extra (@("--provider", "grok_47") + $commonGrounded + @("--rep-offset", "$r"))
}

# ---- 2. finish the DeepSeek grounded cross-configuration check
foreach ($r in 1, 2) {
    Run-Draw -Tag "confv2n5_r$r" -Extra (@("--provider", "deepseek_v4_flash", "--num-agents", "5") + $commonGrounded + @("--rep-offset", "$r"))
}
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confv2mappo_r$r" -Extra @("--provider", "deepseek_v4_flash", "--algo", "mappo",
        "--llm-v2", "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
        "--rep-offset", "$r", "--final-steps", "200000", "--final-seeds", "100,101,102,103")
}

# ---- 3. repair-arm ablation (permissive whitelist, then fix what fails), N=3 DeepSeek
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confrepair_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-repair",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12",
        "--rep-offset", "$r", "--final-steps", "300000", "--final-seeds", "100,101,102,103,104")
}

Write-Log "FOLLOWUP_DONE"
