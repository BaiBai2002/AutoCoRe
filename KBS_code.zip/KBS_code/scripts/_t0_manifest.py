import csv, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import preflight  # noqa: E402

GRID = [0.025, 0.05, 0.1, 0.2, 0.4]
rows = []

runs, summ = preflight._clean_fixture()
res = {x["rule"]: x["status"] for x in preflight.run_all(runs, summ, GRID)}
clean_ok = all(v == "PASS" for k, v in res.items() if k != "P5")
rows.append({
    "id": "C00", "kind": "clean_control", "label": "no defect injected",
    "rule": "(none)", "expected": "no FAIL", "actual": "no FAIL" if clean_ok else "FAIL present",
    "caught": clean_ok,
})

for i, (label, r_, s_, rule) in enumerate(preflight._injections(), 1):
    res = {x["rule"]: x["status"] for x in preflight.run_all(r_, s_, GRID)}
    caught = res.get(rule) == "FAIL"
    rows.append({
        "id": f"I{i:02d}", "kind": "injection", "label": label,
        "rule": rule, "expected": f"{rule}=FAIL", "actual": f"{rule}={res.get(rule)}",
        "caught": caught,
    })

out = os.path.join(ROOT, "audit", "preflight_case_manifest.csv")
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["id", "kind", "label", "rule", "expected", "actual", "caught"])
    w.writeheader()
    w.writerows(rows)

n_ok = sum(1 for r in rows if r["caught"])
print(f"manifest: {n_ok}/{len(rows)} behaved as required -> {out}")
for r in rows:
    print(f"  {r['id']}  {r['kind']:<13} {r['label']:<42} {r['expected']:<10} {r['actual']}")
