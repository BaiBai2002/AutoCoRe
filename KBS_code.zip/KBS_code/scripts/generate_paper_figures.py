"""Generate paper-ready figures."""
import sys, os, json, glob
from pathlib import Path
from collections import defaultdict
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from autocore.utils.io import ensure_dir

OUT = PROJECT_ROOT / "artifacts/figures/paper_ready"
ensure_dir(str(OUT))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 10, 'figure.dpi': 200, 'savefig.bbox': 'tight'})

METHODS_MAIN = ["base","human_pb","random_valid_best_of_k","autocore_single","autocore_select"]
METHOD_LABELS = ["Base","Human PB","RandK","AutoCoRe","CoReSel"]
COLORS = ['#7f8c8d','#3498db','#e67e22','#e74c3c','#27ae60']

def load():
    all_data = []
    for f in glob.glob(str(PROJECT_ROOT / "artifacts/processed/ckpt_v2_main.json")):
        try: all_data.extend(json.load(open(f)))
        except: pass
    for f in glob.glob(str(PROJECT_ROOT / "artifacts/processed/ckpt_*.json")):
        try: all_data.extend(json.load(open(f)))
        except: pass
    return all_data

def fig2_learning_curves(all_data):
    completed = [r for r in all_data if r.get('status')=='completed' and r.get('eval_returns')]
    envs = sorted(set(r['env_id'] for r in completed))
    if not envs: return
    fig, axes = plt.subplots(1, len(envs), figsize=(5.5*len(envs), 4), squeeze=False)
    for ai, eid in enumerate(envs):
        ax = axes[0, ai]
        ed = [r for r in completed if r['env_id']==eid]
        for i, m in enumerate(METHODS_MAIN):
            md = [r for r in ed if r.get('method')==m]
            curves = []
            for r in md:
                er = r.get('eval_returns',[])
                es = r.get('eval_steps',[])
                if er and es: curves.append((es, er))
            if not curves: continue
            max_len = max(len(c[1]) for c in curves)
            pad = []
            for es, er in curves:
                if len(er)<max_len: er = list(er)+[er[-1]]*(max_len-len(er))
                pad.append(er)
            arr = np.array(pad)
            x = np.arange(arr.shape[1])
            ax.plot(x, arr.mean(0), color=COLORS[i], label=METHOD_LABELS[i], lw=1.2)
            ax.fill_between(x, arr.mean(0)-arr.std(0), arr.mean(0)+arr.std(0), color=COLORS[i], alpha=0.12)
        ax.set_title(eid.replace('_',' ').title()); ax.set_xlabel('Eval Point'); ax.set_ylabel('Return')
        ax.legend(fontsize=7); ax.grid(alpha=0.3)
    fig.suptitle('Learning Curves (mean +/- std)', fontsize=11, y=1.02)
    fig.tight_layout()
    fig.savefig(OUT/'fig2_learning_curves.pdf'); fig.savefig(OUT/'fig2_learning_curves.png', dpi=300)
    plt.close(fig)
    print(f"  fig2_learning_curves saved")

def fig7_ablation(all_data):
    completed = [r for r in all_data if r.get('status')=='completed' and r.get('final_return') is not None]
    em = defaultdict(list)
    for r in completed: em[(r['env_id'], r['method'])].append(r['final_return'])
    envs = sorted(set(e for e,_ in em.keys()))
    all_ms = sorted(set(m for _,m in em.keys()))
    fig, axes = plt.subplots(1, len(envs), figsize=(5*len(envs), 3.5), squeeze=False)
    for ai, eid in enumerate(envs):
        ax = axes[0, ai]
        xs, ms_, ss_, ls_ = [], [], [], []
        for i, m in enumerate(all_ms):
            vals = em.get((eid,m),[]); xs.append(len(xs))
            ms_.append(np.mean(vals) if vals else 0); ss_.append(np.std(vals,ddof=1) if len(vals)>1 else 0)
            ls_.append(m[:12])
        ax.bar(xs, ms_, yerr=ss_, color=plt.cm.Set3(np.linspace(0,1,len(xs))), capsize=3)
        ax.set_xticks(xs); ax.set_xticklabels(ls_, rotation=45, ha='right', fontsize=7)
        ax.set_title(eid.replace('_',' ').title()); ax.set_ylabel('Return'); ax.grid(alpha=0.3)
    fig.suptitle('Ablation Study', fontsize=11); fig.tight_layout()
    fig.savefig(OUT/'fig7_ablation.pdf'); fig.savefig(OUT/'fig7_ablation.png', dpi=300)
    plt.close(fig)
    print(f"  fig7_ablation saved")

if __name__ == "__main__":
    data = load()
    print(f"Loaded {len(data)} runs")
    fig2_learning_curves(data)
    fig7_ablation(data)
    print(f"\nFigures saved to {OUT}")
