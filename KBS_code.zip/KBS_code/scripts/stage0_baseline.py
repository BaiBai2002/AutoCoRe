"""Stage-0 baseline: does IPPO learn on simple_spread_v3 with this codebase?

Reports:
  - no-op and random-policy reference returns (20 seeds)
  - the IPPO eval curve over 100K steps
  - comparison against the known-good range for this task
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np
from gymnasium import spaces

from autocore.algos.ippo import IPPOConfig, IPPOTrainer
from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.experiments.train import TrainingLogger, evaluate_agent, train_agent

ENV_ID = os.environ.get("DIAG_ENV", "simple_spread_v3")
STEPS = int(os.environ.get("DIAG_STEPS", "100000"))
MAX_CYCLES = 80
SEED = 42
ALG_CFG = dict(lr=3e-4, gamma=0.99, gae_lambda=0.95, clip_epsilon=0.2,
               entropy_coef=0.01, value_coef=0.5, max_grad_norm=0.5,
               hidden_dim=384, batch_size=256, update_epochs=4, device="cuda")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "artifacts", "diagnostics", "stage0_baseline.json")


def ref_returns(env, policy, seeds=range(20)):
    aspace = env.action_space(env.possible_agents[0])
    total = []
    for s in seeds:
        rng = np.random.default_rng(s)
        res = env.reset(seed=s)
        obs = res[0] if isinstance(res, tuple) else res
        ret, n = 0.0, 0
        while n < 200:
            acts = {}
            for a in env.agents:
                if policy == "noop":
                    acts[a] = 0
                elif isinstance(aspace, spaces.Discrete):
                    acts[a] = int(rng.integers(aspace.n))
                else:
                    acts[a] = rng.uniform(aspace.low, aspace.high).astype(np.float32)
            res = env.step(acts)
            obs, rew, term, trunc = res[0], res[1], res[2], res[3]
            ret += float(sum(rew.values()))
            n += 1
            if all(term.values()) or all(trunc.values()):
                break
        total.append(ret)
    return float(np.mean(total)), float(np.std(total))


def main():
    env = make_mpe_env(ENV_ID, max_cycles=MAX_CYCLES)
    a0 = env.possible_agents[0]
    aspace = env.action_space(a0)
    discrete = isinstance(aspace, spaces.Discrete)

    print(f"env={ENV_ID} obs={env.observation_space(a0)} act={aspace} max_cycles={MAX_CYCLES}")
    mu_noop, sd_noop = ref_returns(env, "noop")
    mu_rnd, sd_rnd = ref_returns(env, "random")
    print(f"no-op  return: {mu_noop:9.2f} +- {sd_noop:.2f}")
    print(f"random return: {mu_rnd:9.2f} +- {sd_rnd:.2f}")

    od = int(np.prod(env.observation_space(a0).shape))
    ad = int(aspace.n) if discrete else int(np.prod(aspace.shape))
    trainer = IPPOTrainer(od, ad, IPPOConfig(**ALG_CFG), discrete_action=discrete)

    logger = TrainingLogger()
    logger = train_agent(env, trainer, num_steps=STEPS, eval_interval=max(STEPS // 10, 500),
                         eval_episodes=10, logger=logger, seed=SEED)

    df = logger.get_dataframe()
    curve = df.loc[df["eval_return"].notna(), ["step", "eval_return"]]
    print("\nIPPO eval curve (10 deterministic episodes per point):")
    for _, row in curve.iterrows():
        print(f"  step {int(row['step']):>7d}  return {row['eval_return']:10.2f}")

    summary = {
        "env": ENV_ID, "steps": STEPS, "seed": SEED, "max_cycles": MAX_CYCLES,
        "action_space": str(aspace),
        "noop_return": mu_noop, "noop_std": sd_noop,
        "random_return": mu_rnd, "random_std": sd_rnd,
        "ippo_curve": [[int(s), float(v)] for s, v in zip(curve["step"], curve["eval_return"])],
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("\nwrote", os.path.normpath(OUT))
    env.close()


if __name__ == "__main__":
    main()
