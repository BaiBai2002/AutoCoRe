"""Phase 0: Environment compatibility diagnostics.
Outputs: artifacts/diagnostics/env_spaces.xlsx, env_spaces.json, env_spaces.md
"""
import sys, os; sys.path.insert(0, '.')
from pathlib import Path
import json, numpy as np
from gymnasium import spaces

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from autocore.envs.pettingzoo_mpe import make_mpe_env
from autocore.utils.io import ensure_dir

ensure_dir('artifacts/diagnostics')

ENVIRONMENTS = {
    "simple_spread_v3": "pettingzoo_mpe",
    "simple_reference_v3": "pettingzoo_mpe",
    "simple_adversary_v3": "pettingzoo_mpe",
}

MULTIWALKER_AVAILABLE = False
try:
    from pettingzoo.sisl import multiwalker_v9
    MULTIWALKER_AVAILABLE = True
except ImportError:
    pass

try:
    from pettingzoo import AECEnv
    from pettingzoo.utils.conversions import aec_to_parallel
    # Try simple_push_v3 as homogeneous alternative
    from pettingzoo.mpe import simple_push_v3, simple_tag_v3, simple_world_comm_v3
    MPE_EXTRA_AVAILABLE = True
except ImportError:
    MPE_EXTRA_AVAILABLE = False

results = []
md_lines = ["# Environment Compatibility Diagnostic Report", "", f"Generated: Phase 0"]

for env_name, source in ENVIRONMENTS.items():
    entry = {"env_name": env_name, "source": source, "status": "unknown",
             "agents": [], "homogeneous": None, "shared_policy_safe": None}
    try:
        env = make_mpe_env(env_name, max_cycles=25)
        obs, _ = env.reset(seed=42)
        possible = env.possible_agents
        agents = env.agents
        entry["num_agents"] = len(possible)
        entry["agents"] = list(possible)

        agent_info = {}
        obs_dims = set()
        act_spaces = set()
        act_dims = set()
        act_types = set()
        for a in agents:
            os_ = env.observation_space(a)
            as_ = env.action_space(a)
            obs_d = int(np.prod(os_.shape))
            act_d = int(as_.n) if isinstance(as_, spaces.Discrete) else int(np.prod(as_.shape))
            act_t = "discrete" if isinstance(as_, spaces.Discrete) else "continuous"
            agent_info[a] = {
                "obs_dim": obs_d, "obs_shape": list(os_.shape),
                "act_dim": act_d, "act_type": act_t,
                "act_dtype": str(as_.dtype) if hasattr(as_, 'dtype') else "float32",
            }
            obs_dims.add(obs_d)
            act_spaces.add(act_t)
            act_dims.add(act_d)
            act_types.add(act_t)

        entry["agent_info"] = agent_info
        entry["homogeneous"] = (len(obs_dims) == 1 and len(act_types) == 1)
        entry["shared_policy_safe"] = entry["homogeneous"]
        entry["obs_dim_unique"] = sorted(obs_dims)
        entry["act_types"] = sorted(act_types)
        entry["status"] = "ok"
        entry["max_cycles"] = getattr(env, 'max_num_agents', 25) if hasattr(env, 'unwrapped') else 25
        env.close()
        print(f"  {env_name}: OK agents={len(possible)} homogeneous={entry['homogeneous']} obs_dims={sorted(obs_dims)} act_types={sorted(act_types)}")
    except Exception as e:
        entry["status"] = "failed"
        entry["error"] = str(e)[:200]
        print(f"  {env_name}: FAILED - {str(e)[:120]}")

    results.append(entry)

# Multiwalker check
mw_entry = {"env_name": "multiwalker_v9", "source": "pettingzoo_sisl",
            "status": "available" if MULTIWALKER_AVAILABLE else "unavailable",
            "error": "Box2D not installed. Run: pip install Box2D" if not MULTIWALKER_AVAILABLE else None}
if MULTIWALKER_AVAILABLE:
    try:
        env = multiwalker_v9.parallel_env(n_walkers=3, max_cycles=500)
        env.reset(seed=42)
        agents = env.possible_agents
        mw_entry["num_agents"] = len(agents)
        agent_info = {}
        obs_dims = set(); act_types = set()
        for a in agents:
            os_ = env.observation_space(a)
            as_ = env.action_space(a)
            obs_d = int(np.prod(os_.shape))
            act_t = "discrete" if isinstance(as_, spaces.Discrete) else "continuous"
            agent_info[a] = {
                "obs_dim": obs_d, "obs_shape": list(os_.shape),
                "act_dim": int(np.prod(as_.shape)) if act_t == "continuous" else int(as_.n),
                "act_type": act_t,
            }
            obs_dims.add(obs_d); act_types.add(act_t)
        mw_entry["agent_info"] = agent_info
        mw_entry["homogeneous"] = (len(obs_dims) == 1 and len(act_types) == 1)
        mw_entry["shared_policy_safe"] = mw_entry["homogeneous"]
        mw_entry["obs_dim_unique"] = sorted(obs_dims)
        mw_entry["act_types"] = sorted(act_types)
        mw_entry["status"] = "ok"
        env.close()
        print(f"  multiwalker_v9: OK agents={len(agents)} homogeneous={mw_entry['homogeneous']} obs_dims={sorted(obs_dims)} act_types={sorted(act_types)}")
    except Exception as e:
        mw_entry["status"] = "failed"
        mw_entry["error"] = str(e)[:200]
        print(f"  multiwalker_v9: FAILED - {str(e)[:120]}")
results.append(mw_entry)

# Check extra MPE envs
for env_name in ["simple_push_v3", "simple_tag_v3", "simple_world_comm_v3"]:
    if not MPE_EXTRA_AVAILABLE: break
    extra = {"env_name": env_name, "source": "pettingzoo_mpe_extra"}
    try:
        env_map = {"simple_push_v3": simple_push_v3, "simple_tag_v3": simple_tag_v3, "simple_world_comm_v3": simple_world_comm_v3}
        env = env_map[env_name].parallel_env(max_cycles=25)
        env.reset(seed=42)
        agents = env.possible_agents
        obs_dims = set(); act_types = set()
        for a in agents:
            os_ = env.observation_space(a)
            as_ = env.action_space(a)
            obs_dims.add(int(np.prod(os_.shape)))
            act_types.add("discrete" if isinstance(as_, spaces.Discrete) else "continuous")
        extra["num_agents"] = len(agents)
        extra["homogeneous"] = (len(obs_dims) == 1 and len(act_types) == 1)
        extra["obs_dim_unique"] = sorted(obs_dims)
        extra["act_types"] = sorted(act_types)
        extra["status"] = "ok"
        env.close()
        print(f"  {env_name}: OK agents={len(agents)} homogeneous={extra['homogeneous']} obs_dims={sorted(obs_dims)}")
    except Exception as e:
        extra["status"] = "failed"; extra["error"] = str(e)[:200]
        print(f"  {env_name}: FAILED - {str(e)[:120]}")
    results.append(extra)

# Save
with open('artifacts/diagnostics/env_spaces.json', 'w') as f:
    json.dump(results, f, indent=2)

# MD report
md_lines += ["", "## Environment Summary", "", "| Env | Agents | Homogeneous | Obs Dims | Action | Shared Policy |",
             "|-----|--------|-------------|----------|--------|---------------|"]
for r in results:
    h = "✅" if r.get("homogeneous") else "❌"
    sp = "✅" if r.get("shared_policy_safe") else "❌"
    od = str(r.get("obs_dim_unique", "N/A"))
    at = str(r.get("act_types", "N/A"))
    md_lines.append(f"| {r['env_name']} | {r.get('num_agents', '?')} | {h} | {od} | {at} | {sp} |")

md_lines += ["", "## Failed Environments", ""]
for r in results:
    if r.get("status") != "ok":
        md_lines.append(f"### {r['env_name']}")
        md_lines.append(f"Error: `{r.get('error', 'N/A')}`")
        md_lines.append("")

md_lines += ["", "## Recommendation", "",
             "- **Primary env 1**: simple_spread_v3 (homogeneous, discrete, shared policy OK)",
             "- **Primary env 2**: simple_reference_v3 (homogeneous, discrete, shared policy OK)",
             "- **Primary env 3**: Simple Push or Simple Tag (homogeneous, available without Box2D)",
             "- **Multiwalker**: Requires Box2D installation. If not available, use simple_push_v3 or simple_tag_v3."]

with open('artifacts/diagnostics/env_spaces.md', 'w') as f:
    f.write('\n'.join(md_lines))
with open('artifacts/diagnostics/environment_compatibility_report.md', 'w') as f:
    f.write('\n'.join(md_lines))

print(f"\nReports saved: artifacts/diagnostics/env_spaces.json, env_spaces.md")
