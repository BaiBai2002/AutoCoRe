"""LLM-proposal vs control-pool experiment (protocol in research_upgrade/04_PROTOCOL.md).

Question: at a matched candidate count and a matched *total* budget, does a
pre-training audit deploy better value from an LLM pool than from a random-valid
pool, a hand-designed pool, and an ungated LLM pool?

Pool arms
  llm         structured LLM proposals (8 families), filtered by the env-applicability gate
  llm_raw     the same LLM proposals WITHOUT the env-applicability gate
  rand        random *valid* compositions over the env's allowed predicate/potential set
  hand        hand-designed coverage / assignment potentials

Decision rules (frozen): rank by the raw-return probe; deploy iff the paired probe
mean >= 0; else abstain. An LCB variant is recorded for comparison only.

All training goes through scripts/stage0_train.py with an explicit ``--lam`` so the
coefficient convention is written down: the calibrated team-level lambda* is passed
per-agent as lambda*/N (the wrappers add the term to each agent's reward).

Nothing here is reported unless it comes from a stored run in ``--outdir``.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
TRAIN = os.path.join(PROJECT_ROOT, "scripts", "stage0_train.py")
DEFAULT_OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "llm_proposal")


# ----------------------------------------------------------------------------- pools
def load_env_spec(env_id: str) -> dict:
    from autocore.utils.io import load_yaml
    spec = load_yaml(os.path.join(PROJECT_ROOT, "configs", "env_specs", f"{env_id}.yaml"))
    spec = spec.get("env_spec", spec)
    spec["available_state_variables"] = spec.get("allowed_state_variables", [])
    return spec


LANDMARK_PREDICATES = {
    "min_distance_landmark_coverage", "mean_distance_to_nearest_landmark",
    "max_uncovered_landmark_distance", "coverage_entropy_or_balance",
    "agent_target_assignment_distance",
}


def _dsl_from_subgoals(task: str, subgoals: list[dict], description: str = "") -> dict:
    return {"task_name": task, "version": "1.0", "description": description,
            "subgoals": subgoals}


def pred_args(pred: str) -> dict:
    if pred in LANDMARK_PREDICATES:
        return {"agent_key": "agent_positions", "landmark_key": "landmark_positions"}
    return {"agent_key": "agent_positions"}


def gen_llm_pool(provider: str, env_spec: dict, replicate: int, k: int,
                 use_gate: bool, grounded: bool = False, repair: bool = False,
                 extra_params: dict | None = None, effort_tag: str = "",
                 template: str = "autocore_select_v3",
                 exclude_predicates: tuple[str, ...] = ()) -> list[dict]:
    """Generate the LLM pool for one replicate.

    ``grounded=True`` restricts the proposer's whitelist to the environment's own
    allowed predicates/potentials. This is a *fairness* device, not a thumb on the
    scale: it stops the proposer wasting proposals on primitives that cannot be
    implemented on the target environment, and makes the LLM search space identical
    to the random-valid arm's. Temperatures shift with the replicate so replicates
    are independent draws (the cache key includes the temperature).
    """
    from autocore.llm import semantic_candidate_generator as scg

    base = [0.2, 0.4, 0.6, 0.8]
    temps = [min(1.0, t + 0.1 * replicate) for t in base]
    gen = scg.SemanticCandidateGenerator(provider=provider)

    kw: dict = {}
    _excl = set(exclude_predicates)
    allowed_preds = [p for p in env_spec.get("allowed_predicates", []) if p not in _excl]
    allowed_pots = list(env_spec.get("allowed_potentials", []))
    if grounded and allowed_preds and allowed_pots:
        pd = {n: d for n, d in scg._DEFAULT_ALLOWED_PREDICATES}
        qd = {n: d for n, d in scg._DEFAULT_ALLOWED_POTENTIALS}
        kw["allowed_predicates"] = [(p, pd.get(p, p)) for p in allowed_preds]
        kw["allowed_potentials"] = [(q, qd.get(q, q)) for q in allowed_pots]

    cands = gen.generate(env_spec, temperatures=temps, extra_params=extra_params,
                         effort_tag=effort_tag, template=template, **kw)

    allowed = set(allowed_preds)
    out: list[dict] = []
    seen: set[str] = set()
    rejected: list[tuple[str, dict]] = []
    for i, c in enumerate(cands):
        preds = [sg.get("predicate", {}).get("type") for sg in c.subgoals]
        dsl = _dsl_from_subgoals(c.task_name or env_spec.get("env_name", ""),
                                 c.subgoals, c.rationale or "")
        if not preds or any(p not in allowed for p in preds):
            if use_gate:
                rejected.append((f"predicate types {preds} are not implementable here; "
                                 f"allowed={sorted(allowed)}", dsl))
                continue
        sig = json.dumps(dsl, sort_keys=True)
        if sig in seen:
            continue
        seen.add(sig)
        out.append({"name": f"llm_r{replicate}:{i}_{c.family_name}", "dsl": dsl})

    if repair and len(out) < k:
        for error, bad in rejected:
            if len(out) >= k:
                break
            try:
                fixed = repair_candidate(provider, env_spec, bad, error,
                                         extra_params=extra_params, effort_tag=effort_tag)
            except Exception as exc:  # a failed repair must never abort the search
                print(f"[warn] repair attempt failed: {type(exc).__name__}: {exc}")
                continue
            if fixed is None:
                continue
            sig = json.dumps(fixed, sort_keys=True)
            if sig in seen:
                continue
            seen.add(sig)
            out.append({"name": f"llm_r{replicate}:repaired{len(out)}", "dsl": fixed})
    return out[:k]


def gen_random_pool(k: int, allowed_preds: list[str], allowed_pots: list[str],
                    task: str, rng: np.random.Generator) -> list[dict]:
    out = []
    for i in range(k):
        n_sub = int(rng.integers(1, 3))
        subs = []
        for _ in range(n_sub):
            pred = str(rng.choice(allowed_preds))
            pot = str(rng.choice(allowed_pots))
            clip = [-1.0, 0.0] if pot != "balanced_coverage" else [-1.0, 1.0]
            subs.append({"name": f"sg{rng.integers(0, 10**6)}", "scope": "global",
                         "weight": float(np.round(rng.uniform(0.1, 1.0), 3)),
                         "predicate": {"type": pred, "args": pred_args(pred)},
                         "potential": {"type": pot, "clip": clip},
                         "rationale": "random valid composition"})
        out.append({"name": f"rand_r{rng.integers(0, 10**9)}:{i}",
                    "dsl": _dsl_from_subgoals(task, subs, "random valid")})
    return out


def load_hand_pool(task: str) -> list[dict]:
    out = []
    for f, nm in (("spread_coverage.json", "hand:coverage"),
                  ("spread_assignment.json", "hand:assignment")):
        p = os.path.join(PROJECT_ROOT, "configs", "dsl", f)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as fh:
                out.append({"name": nm, "dsl": json.load(fh)})
    return out


# ------------------------------------------------------------------------- calibration
def calibrate(dsl: dict, env_id: str, max_cycles: int, rho: float,
              num_agents: int | None, seed: int = 0) -> dict:
    from autocore.dsl.compiler import compile_dsl
    from autocore.selection.magnitude_calibration import estimate_scales
    from autocore.shaping.potentials import PotentialFunction, ShapingConfig

    compiled = compile_dsl(dsl)
    pf = PotentialFunction(compiled, ShapingConfig(gamma=0.99, shaping_lambda=0.0,
                                                   potential_clip=(-1.0, 1.0)))
    est = estimate_scales(env_id, pf.compute_potential, gamma=0.99,
                          max_cycles=max_cycles, n_episodes=24, seed=seed,
                          num_agents=num_agents)
    lam_star = est.required_lambda(rho)
    return {"mean_abs_return": est.mean_abs_return,
            "mean_abs_delta_phi": est.mean_abs_delta_phi,
            "lambda_star": lam_star, "compiled_ok": True}


# ----------------------------------------------------------------------------- training
def _key(name: str) -> str:
    return hashlib.md5(name.encode()).hexdigest()[:12]


def repair_candidate(provider: str, env_spec: dict, bad_dsl: dict, error: str,
                     temperature: float = 0.2, extra_params: dict | None = None,
                     effort_tag: str = "") -> dict | None:
    """One verify-and-repair round: hand the failed DSL and the validator's message back to
    the proposer, restricted to the allowed primitives, and take the corrected DSL if it
    parses and compiles. This is the counterexample-guided repair of the AutoCoRe line,
    applied to the shaping DSL."""
    from autocore.dsl.compiler import compile_dsl
    from autocore.llm import semantic_candidate_generator as scg
    from autocore.llm.cache import LLMCache
    from autocore.llm.client import LLMClient
    from autocore.llm.providers import load_providers

    provider_cfg = load_providers()[provider]
    preds = list(env_spec.get("allowed_predicates", []))
    pots = list(env_spec.get("allowed_potentials", []))
    system = (
        "You repair reward-shaping specifications for cooperative multi-agent environments. "
        "Return ONLY minified JSON with keys task_name, version, description, subgoals. Each "
        "subgoal has name, scope='global', weight, predicate{type,args}, potential{type,clip}. "
        "Use ONLY the allowed predicate and potential types. No prose, no code fences."
    )
    user = (
        f"Allowed predicate types: {preds}\n"
        f"Allowed potential types: {pots}\n"
        f"Environment: {env_spec.get('env_name')} with num_agents={env_spec.get('num_agents')}.\n"
        f"The previous specification FAILED with: {error}\n"
        f"Previous specification: {json.dumps(bad_dsl)}\n"
        "Return a corrected specification that keeps the same intent but uses only the allowed primitives."
    )
    cache = LLMCache()
    key = LLMCache.make_key(provider=provider_cfg.name, model=provider_cfg.model,
                            prompt_hash=LLMCache.hash_content(system + user),
                            env_spec_hash=LLMCache.hash_content(json.dumps(env_spec, sort_keys=True)),
                            method_version=f"repair-v1-t{temperature}{effort_tag}")
    raw = cache.get(key)
    if raw is None:
        pd = provider_cfg.to_dict()
        pd["api_key"] = provider_cfg.api_key
        with LLMClient(pd) as client:
            resp = client.generate(
                [{"role": "system", "content": system}, {"role": "user", "content": user}],
                temperature=temperature, max_tokens=2048, extra_params=extra_params)
        raw = {"content": resp.get("content", ""), "model": resp.get("model", "")}
        cache.put(key, raw)
    obj = scg._extract_json(raw.get("content", ""))
    if obj is None:
        return None
    dsl = _dsl_from_subgoals(obj.get("task_name") or env_spec.get("env_name", ""),
                             obj.get("subgoals", []), obj.get("description", ""))
    allowed = set(preds)
    sub = dsl.get("subgoals", [])
    if not sub or any(not isinstance(sg, dict) or
                      sg.get("predicate", {}).get("type") not in allowed for sg in sub):
        return None
    try:
        compile_dsl(dsl)
    except Exception:
        return None
    return dsl


def _safe(s: str) -> str:
    """Make a candidate key usable inside a filename / run id (Windows forbids ':')."""
    return s.replace("::", "_").replace(":", "_")


def train_one(env: str, algo: str, num_agents: int | None, steps: int, seed: int,
              dsl_path: str | None, lam: float, rid: str, max_cycles: int,
              hidden: int, outdir: str, rho_target: float) -> float | None:
    # The record path must encode everything that changes the result (P6). The run
    # id already carries the candidate; the learner, agent count and horizon are
    # appended here so that an IPPO N=3 record can never be served to a MAPPO or
    # N=5 run. The suffix is omitted for the default configuration (ippo, default
    # agent count, horizon 80) so that earlier records stay reusable.
    suffix = ""
    if algo != "ippo" or num_agents is not None or int(max_cycles) != 80:
        na = "na" if num_agents is None else num_agents
        suffix = f"__{algo}_N{na}_mc{max_cycles}"
    out = os.path.join(outdir, "runs", f"{rid}{suffix}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out):
        try:
            with open(out, encoding="utf-8") as f:
                rec = json.load(f)
            same = (
                int(rec.get("steps", -1)) == steps
                and rec.get("env") == env
                and rec.get("seed") == seed
                and rec.get("algo") == algo
                and rec.get("num_agents") == num_agents
                and int(rec.get("max_cycles", -1)) == int(max_cycles)
                and abs(float(rec.get("shaping_lambda", 0.0)) - float(lam)) < 1e-9
            )
            if same:
                return float(rec["final_return"])
        except Exception:
            pass
    cmd = [sys.executable, "-u", TRAIN, "--env", env, "--steps", str(steps),
           "--eval-every", str(max(steps // 4, 5000)), "--seed", str(seed),
           "--hidden", str(hidden), "--entropy", "0.003", "--epochs", "8",
           "--minibatches", "8", "--algo", algo, "--out", out, "--tag", rid,
           "--rho-target", str(rho_target), "--max-cycles", str(max_cycles)]
    if num_agents is not None:
        cmd += ["--num-agents", str(num_agents)]
    if dsl_path:
        cmd += ["--dsl", dsl_path, f"--lam={lam:.8f}"]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    if proc.returncode != 0 or not os.path.exists(out):
        sys.stderr.write(f"run failed {rid}: {(proc.stderr or '')[-200:]}\n")
        return None
    try:
        with open(out, encoding="utf-8") as f:
            return float(json.load(f)["final_return"])
    except Exception:
        return None


def run_batch(jobs: list[tuple], workers: int) -> dict[str, float]:
    res: dict[str, float] = {}
    with cf.ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(train_one, **j): j["rid"] for j in jobs}
        for fut in cf.as_completed(futs):
            rid = futs[fut]
            try:
                v = fut.result()
            except Exception:
                v = None
            if v is not None:
                res[rid] = v
    return res


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", default="deepseek_v4_flash")
    ap.add_argument("--env", default="simple_spread_v3")
    ap.add_argument("--algo", default="ippo")
    ap.add_argument("--num-agents", type=int, default=None)
    ap.add_argument("--k-llm", type=int, default=7)
    ap.add_argument("--k-rand", type=int, default=7)
    ap.add_argument("--k-raw", type=int, default=6,
                    help="size of the UNGATED LLM pool (selects the first k ungated candidates)")
    ap.add_argument("--llm-v2", action="store_true",
                    help="grounded proposer: restrict the LLM whitelist to the environment's own "
                         "allowed predicate/potential set (removes wasted proposals) and deduplicate")
    ap.add_argument("--llm-repair", action="store_true",
                    help="counterexample-guided repair: return gate-rejected proposals to the "
                         "proposer with the validator message and accept the corrected DSL")
    ap.add_argument("--effort", default="", choices=["", "low", "medium", "high"],
                    help="inference-time reasoning-effort hint sent to the proposer; it is folded "
                         "into the response cache key so effort levels never mix")
    ap.add_argument("--prompt", default="v3", choices=["v3", "v4"],
                    help="proposer prompt template; the response cache key records it, so prompt "
                         "variants never share cached responses and can be compared as a factor")
    ap.add_argument("--exclude-predicates", default="",
                    help="comma-separated predicate types to remove from the grounded whitelist AND "
                         "from the gate's allowed set (causal ablation: e.g. remove the task-relevant "
                         "primitive to test whether its reachability is the mechanism)")
    ap.add_argument("--union-providers", default="",
                    help="comma-separated providers whose grounded pools are UNIONED into the LLM arm "
                         "before the same probe-based selection (multi-proposer ensemble); the probe "
                         "cost grows with the union and is charged, so this buys search, not free gain")
    ap.add_argument("--replicates", type=int, default=1)
    ap.add_argument("--rep-offset", type=int, default=0,
                    help="shift the replicate index; gives an independent LLM draw "
                         "(temperatures + random-pool RNG) without re-running the whole grid")
    ap.add_argument("--probe-steps", type=int, default=50_000)
    ap.add_argument("--probe-seeds", default="200,201,202")
    ap.add_argument("--final-steps", type=int, default=300_000)
    ap.add_argument("--final-seeds", default="100,101,102,103,104")
    ap.add_argument("--rho-target", type=float, default=0.2)
    ap.add_argument("--z", type=float, default=0.5)
    ap.add_argument("--max-cycles", type=int, default=80)
    ap.add_argument("--hidden", type=int, default=512)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--tag", default="llm_prop")
    ap.add_argument("--outdir", default=DEFAULT_OUTDIR)
    ap.add_argument("--final-all-pool", action="store_true",
                    help="final-train EVERY candidate (removes selection bias)")
    ap.add_argument("--skip-llm", action="store_true",
                    help="use only rand/hand pools (code validation, no API calls)")
    ap.add_argument("--dry-run", action="store_true",
                    help="build and calibrate the pools only; print the candidate table and exit "
                         "(no probing or training)")
    args = ap.parse_args()

    os.makedirs(os.path.join(args.outdir, "dsl"), exist_ok=True)
    os.makedirs(os.path.join(args.outdir, "runs"), exist_ok=True)

    env_spec = load_env_spec(args.env)
    allowed_preds = list(env_spec.get("allowed_predicates", []))
    allowed_pots = list(env_spec.get("allowed_potentials", []))
    n_agents = args.num_agents or int(env_spec.get("num_agents", 3))
    effort_extra = {"reasoning_effort": args.effort} if args.effort else None
    effort_tag = f"-eff{args.effort}" if args.effort else ""
    template = "autocore_select_v3" if args.prompt == "v3" else "autocore_select_v4"
    prompt_tag = "" if args.prompt == "v3" else f"-p{args.prompt}"
    if prompt_tag:  # keep prompt variants in separate summary files
        args.tag = args.tag + prompt_tag
    excl = tuple(p.strip() for p in args.exclude_predicates.split(",") if p.strip())
    union = tuple(p.strip() for p in args.union_providers.split(",") if p.strip())
    probe_seeds = [int(s) for s in args.probe_seeds.split(",")]
    final_seeds = [int(s) for s in args.final_seeds.split(",")]
    print(f"env={args.env} N={n_agents} allowed_preds={len(allowed_preds)} "
          f"allowed_pots={len(allowed_pots)} replicates={args.replicates}")

    # ---- build arms
    arms: dict[str, list[dict]] = {"llm": [], "llm_raw": [], "rand": [], "hand": []}
    for r in range(args.rep_offset, args.rep_offset + args.replicates):
        if not args.skip_llm:
            if union:
                # Multi-proposer ensemble: the pool is the union of the grounded proposals of
                # several models, and the SAME probe-based rule selects from it. Probe cost grows
                # with the pool, so the union arm is charged 2K probes rather than K and must be
                # read as "a larger proposer budget", not as a free improvement.
                for prov in union:
                    arms["llm"] += gen_llm_pool(prov, env_spec, r, args.k_llm, True,
                                                grounded=args.llm_v2, repair=args.llm_repair,
                                                extra_params=effort_extra, effort_tag=effort_tag,
                                                template=template, exclude_predicates=excl)
            else:
                arms["llm"] += gen_llm_pool(args.provider, env_spec, r, args.k_llm, True,
                                            grounded=args.llm_v2, repair=args.llm_repair,
                                            extra_params=effort_extra, effort_tag=effort_tag,
                                            template=template, exclude_predicates=excl)
            arms["llm_raw"] += gen_llm_pool(args.provider, env_spec, r, args.k_raw, False,
                                            extra_params=effort_extra, effort_tag=effort_tag,
                                            template=template, exclude_predicates=excl)
        rng = np.random.default_rng(7000 + r)
        arms["rand"] += gen_random_pool(args.k_rand, allowed_preds, allowed_pots,
                                        args.env, rng)
    arms["hand"] = load_hand_pool(args.env)
    for a, v in arms.items():
        print(f"  arm {a}: {len(v)} candidates")

    # ---- write DSL files + calibrate (skip candidates that do not compile)
    cands: dict[str, dict] = {}
    for arm, items in arms.items():
        for c in items:
            cid = f"{arm}::{_key(c['name'] + json.dumps(c['dsl'], sort_keys=True))}"
            path = os.path.join(args.outdir, "dsl", f"{cid.replace('::', '_')}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(c["dsl"], f, indent=2)
            try:
                cal = calibrate(c["dsl"], args.env, args.max_cycles, args.rho_target,
                                args.num_agents)
            except Exception as e:  # noqa: BLE001
                cands[cid] = {"arm": arm, "name": c["name"], "dsl_path": path,
                              "compile_ok": False, "error": f"{type(e).__name__}: {e}"}
                continue
            cands[cid] = {"arm": arm, "name": c["name"], "dsl_path": path,
                          "dsl": c["dsl"], **cal}

    ok = {k: v for k, v in cands.items() if v.get("compiled_ok")}
    for k, v in cands.items():
        if not v.get("compiled_ok"):
            print(f"  [skip] {v['arm']} {v['name']}: {v.get('error')}")
    print(f"compiled {len(ok)}/{len(cands)} candidates")
    for arm in ("llm", "llm_raw", "rand", "hand"):
        sub = [v for v in ok.values() if v["arm"] == arm]
        if sub:
            lams = [v["lambda_star"] for v in sub]
            print(f"  {arm}: n={len(sub)} lambda* median={np.median(lams):.2f} "
                  f"range=[{min(lams):.2f},{max(lams):.2f}]")

    lam_of = {k: v["lambda_star"] / n_agents for k, v in ok.items()}

    if args.dry_run:
        for k, v in ok.items():
            preds = [sg.get("predicate", {}).get("type") if isinstance(sg, dict) else str(sg)[:24]
                     for sg in v["dsl"].get("subgoals", [])]
            print(f"  {v['arm']:<8s} {v['name'][:34]:<34s} lambda*={v['lambda_star']:9.2f} "
                  f"lam={lam_of[k]:8.2f} preds={preds}")
        print("dry-run complete; no training executed")
        return

    # ---- probe
    probe_jobs = []
    for k, v in ok.items():
        for s in probe_seeds:
            probe_jobs.append(dict(env=args.env, algo=args.algo, num_agents=args.num_agents,
                                   steps=args.probe_steps, seed=s, dsl_path=v["dsl_path"],
                                   lam=lam_of[k], rid=f"probe_{_safe(k)}_s{s}",
                                   max_cycles=args.max_cycles, hidden=args.hidden,
                                   outdir=args.outdir, rho_target=args.rho_target))
    base_probe_jobs = [dict(env=args.env, algo=args.algo, num_agents=args.num_agents,
                            steps=args.probe_steps, seed=s, dsl_path=None, lam=0.0,
                            rid=f"probebase_s{s}", max_cycles=args.max_cycles,
                            hidden=args.hidden, outdir=args.outdir,
                            rho_target=args.rho_target) for s in probe_seeds]
    print(f"probing {len(probe_jobs)} candidate runs + {len(base_probe_jobs)} base runs "
          f"x {args.probe_steps} steps")
    probe = run_batch(probe_jobs + base_probe_jobs, args.workers)

    # ---- decide per arm
    base_probe = {s: probe.get(f"probebase_s{s}") for s in probe_seeds}
    decisions = {}
    for arm in ("llm", "llm_raw", "rand", "hand"):
        scored = []
        for k, v in ok.items():
            if v["arm"] != arm:
                continue
            d = [probe[f"probe_{_safe(k)}_s{s}"] - base_probe[s] for s in probe_seeds
                 if f"probe_{_safe(k)}_s{s}" in probe and base_probe.get(s) is not None]
            if len(d) < 2:
                continue
            d = np.asarray(d, dtype=float)
            lcb = float(d.mean() - args.z * d.std(ddof=1) / np.sqrt(len(d)))
            scored.append({"key": k, "name": v["name"], "probe_mean_gain": float(d.mean()),
                           "probe_lcb": lcb, "n": len(d)})
        # Frozen rule (04_PROTOCOL.md): rank by the raw-return probe mean and deploy the best
        # candidate whose paired probe mean is non-negative; else abstain. The LCB ranking is
        # recorded alongside for transparency but does not drive the deployment.
        scored.sort(key=lambda x: -x["probe_mean_gain"])
        top = scored[0] if scored else None
        top_lcb = max(scored, key=lambda x: x["probe_lcb"]) if scored else None
        deployed = top if top and top["probe_mean_gain"] >= 0 else None
        decisions[arm] = {"top_by_lcb": top_lcb, "top_by_mean": top, "deployed": deployed,
                          "abstain": deployed is None, "probe_table": scored}
        print(f"  [{arm}] probe table: " +
              ", ".join(f"{s['name'][:28]}={s['probe_mean_gain']:+.1f}" for s in scored[:6]))
        print(f"  [{arm}] deploy -> {deployed['name'] if deployed else 'ABSTAIN'}")

    # ---- final training set
    need: dict[str, dict] = {}
    for arm, d in decisions.items():
        if d["deployed"]:
            k = d["deployed"]["key"]
            need[k] = ok[k]
    if args.final_all_pool:
        for k, v in ok.items():
            need.setdefault(k, v)
    print(f"final-training {len(need)} shaped configs + base on {len(final_seeds)} seeds")

    final_jobs = [dict(env=args.env, algo=args.algo, num_agents=args.num_agents,
                       steps=args.final_steps, seed=s, dsl_path=None, lam=0.0,
                       rid=f"finalbase_s{s}", max_cycles=args.max_cycles,
                       hidden=args.hidden, outdir=args.outdir, rho_target=args.rho_target)
                  for s in final_seeds]
    for k, v in need.items():
        for s in final_seeds:
            final_jobs.append(dict(env=args.env, algo=args.algo, num_agents=args.num_agents,
                                   steps=args.final_steps, seed=s, dsl_path=v["dsl_path"],
                                   lam=lam_of[k], rid=f"final_{_safe(k)}_s{s}",
                                   max_cycles=args.max_cycles, hidden=args.hidden,
                                   outdir=args.outdir, rho_target=args.rho_target))
    print(f"final: {len(final_jobs)} runs x {args.final_steps} steps")
    fin = run_batch(final_jobs, args.workers)

    base_final = {s: fin.get(f"finalbase_s{s}") for s in final_seeds}
    base_vals = [v for v in base_final.values() if v is not None]
    base_mean = float(np.mean(base_vals)) if base_vals else float("nan")

    per_arm = {}
    for arm, d in decisions.items():
        entry = {"deployed": d["deployed"]["name"] if d["deployed"] else None,
                 "abstain": d["abstain"]}
        if d["deployed"]:
            k = d["deployed"]["key"]
            vals = [fin[f"final_{_safe(k)}_s{s}"] - base_final[s] for s in final_seeds
                    if f"final_{_safe(k)}_s{s}" in fin and base_final.get(s) is not None]
            if vals:
                arr = np.asarray(vals, dtype=float)
                entry["deployed_mean_gain"] = float(arr.mean())
                entry["deployed_ci95"] = [float(np.percentile(arr, 2.5)),
                                          float(np.percentile(arr, 97.5))]
                entry["deployed_n"] = int(arr.size)
        per_arm[arm] = entry

    oracle = {}
    if args.final_all_pool:
        for arm in ("llm", "llm_raw", "rand", "hand"):
            best, best_g = None, -np.inf
            for k, v in ok.items():
                if v["arm"] != arm:
                    continue
                vals = [fin[f"final_{_safe(k)}_s{s}"] - base_final[s] for s in final_seeds
                        if f"final_{_safe(k)}_s{s}" in fin and base_final.get(s) is not None]
                if vals and np.mean(vals) > best_g:
                    best, best_g = v["name"], float(np.mean(vals))
            oracle[arm] = {"best": best, "mean_gain": None if best is None else best_g}

    summary = {"env": args.env, "provider": args.provider, "N": n_agents,
               "rho_target": args.rho_target, "z": args.z, "effort": args.effort,
               "replicates": args.replicates, "k_llm": args.k_llm, "k_rand": args.k_rand,
               "probe_steps": args.probe_steps, "probe_seeds": probe_seeds,
               "final_steps": args.final_steps, "final_seeds": final_seeds,
               "n_candidates": {a: sum(1 for v in ok.values() if v["arm"] == a)
                                for a in ("llm", "llm_raw", "rand", "hand")},
               "lambda_star": {k: round(v["lambda_star"], 4) for k, v in ok.items()},
               "lambda_used_per_agent": {k: round(lam_of[k], 4) for k in ok},
               "decisions": {a: {"deployed": decisions[a]["deployed"],
                                 "abstain": decisions[a]["abstain"],
                                 "probe_table": decisions[a]["probe_table"]}
                             for a in decisions},
               "base_final_mean": base_mean, "base_final_by_seed": base_final,
               "per_arm": per_arm, "oracle": oracle,
               "finals": fin}
    out = os.path.join(args.outdir, f"{args.tag}_summary.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("\n=== summary ===")
    print(f"base final mean = {base_mean:.2f}")
    for a, e in per_arm.items():
        print(f"  {a:<8s} deploy={str(e['deployed'])[:30]:<30s} "
              f"gain={e.get('deployed_mean_gain')} ci={e.get('deployed_ci95')}")
    for a, e in oracle.items():
        print(f"  oracle[{a}] = {e['best']} ({e['mean_gain']})")
    print("wrote", os.path.normpath(out))


if __name__ == "__main__":
    main()
