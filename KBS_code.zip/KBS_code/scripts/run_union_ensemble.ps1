# Multi-proposer ensemble (method improvement): a union pool, probe-selected.
#
# The strongest single grounded proposer ties or approaches a hand design but never clears it. The
# natural way to make the METHOD better WITHOUT touching the data is to stop betting on one model:
# union the grounded proposals of several models into one pool and let the SAME frozen probe rule
# select from it. The union's probe maximum is at least each member's, so the deployed reward can
# only improve or stay equal, and everything else (gate, calibration, seeds, rule) is unchanged.
#
# Honest accounting: the union has 2K candidates instead of K, so it is charged 2K probes. It is
# therefore reported as "a larger proposer budget", never as a free gain, and the section must show
# the cost next to the benefit.
#
# Usage:  powershell -NoProfile -File scripts/run_union_ensemble.ps1

$env:PYTHONPATH = "src"
$log = "artifacts/llm_proposal/union.log"
New-Item -ItemType Directory -Force -Path "artifacts/llm_proposal" | Out-Null

function Write-Log([string]$m) {
    $m | Tee-Object -FilePath $log -Append | Out-Null
}

function Run-Draw {
    param([string]$Tag, [string[]]$Extra)
    $summary = "artifacts/llm_proposal/${Tag}_summary.json"
    if (Test-Path $summary) { Write-Log "SKIP (already done): $Tag"; return }
    for ($a = 1; $a -le 3; $a++) {
        Write-Log "=== $Tag (attempt ${a}) ==="
        $argv = @("-u", "scripts/llm_proposal_experiment.py") + $Extra + @(
            "--replicates", "1", "--probe-steps", "50000", "--probe-seeds", "200,201,202",
            "--final-steps", "300000", "--final-seeds", "100,101,102,103,104", "--tag", $Tag)
        & python @argv 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
        if (Test-Path $summary) { Write-Log "OK: $Tag"; return }
        Write-Log "FAILED attempt ${a} for $Tag"
        Start-Sleep -Seconds 90
    }
    Write-Log "GAVE_UP: $Tag"
}

Write-Log "waiting for the confirmation queue to finish ..."
while (-not (Select-String -Path "artifacts/llm_proposal/confirm.log" -Pattern "CONFIRM_DRAWS_DONE" -Quiet -ErrorAction SilentlyContinue)) {
    Start-Sleep -Seconds 300
}

Write-Log "--- stage 3: multi-proposer ensemble (union of DeepSeek + GPT-6 Astra grounded pools) ---"
foreach ($r in 0, 1, 2) {
    Run-Draw -Tag "confunion_r$r" -Extra @("--provider", "deepseek_v4_flash", "--llm-v2",
        "--union-providers", "deepseek_v4_flash,gpt_6_astra",
        "--k-llm", "12", "--k-raw", "6", "--k-rand", "12", "--rep-offset", "$r")
}

Write-Log "UNION_ENSEMBLE_DONE"
