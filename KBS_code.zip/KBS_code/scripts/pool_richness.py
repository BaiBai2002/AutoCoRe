"""How much does pool richness buy? A subsampling study on the rich pool.

The paper's central practical claim is that the candidate pool, not the threshold,
is the binding constraint. This script makes that quantitative: from the one pool
whose candidates were all trained to the full budget (spread N=3, 37 candidates with
ten held-out seeds), it draws random sub-pools of increasing size and reports what
the LCB gate would have realised on each draw --- including the option of declining
to deploy, which is worth exactly zero.

The oracle column is the best candidate in the sub-pool, i.e. the ceiling that a
perfect selector could reach. The gap between the two is what selection can
contribute given the pool.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gate_calibration_fix import build_table, FULL_POOL  # noqa: E402

OUTDIR = os.path.join(PROJECT_ROOT, "artifacts", "diagnostics")
RESULT = os.path.join(OUTDIR, "pool_richness.json")


def main() -> None:
    rows = [r for r in build_table([f"{FULL_POOL}_summary.json"]) if r["setting"] == FULL_POOL]
    if not rows:
        raise SystemExit("rich pool not found")
    gain = np.asarray([r["gain"] for r in rows], dtype=float)
    lcb = np.asarray([r["lcb"] for r in rows], dtype=float)
    n = rows.__len__()
    rng = np.random.default_rng(0)
    draws = 400

    print(f"rich pool: n={n} candidates, {draws} random sub-pools per size")
    print(f"  {'pool':>5s} {'gate gain':>10s} {'gate err':>9s} {'no deploy':>10s} {'oracle':>9s}")
    out = {"n_pool": n, "draws": draws, "rows": []}
    for k in (2, 3, 4, 6, 8, 12, 18, 25, n):
        g, e, nd, orc = [], [], 0, []
        for _ in range(draws):
            idx = rng.choice(n, size=k, replace=False)
            sub_lcb, sub_gain = lcb[idx], gain[idx]
            sel = sub_gain[sub_lcb >= 0]
            if sel.size:
                g.append(float(sel.mean()))
                e.append(float((sel < 0).mean()))
            else:
                g.append(0.0)          # declining to deploy is worth zero
                nd += 1
            orc.append(float(sub_gain.max()))
        rec = {"pool_size": k, "gate_mean_gain": float(np.mean(g)),
               "gate_err": float(np.mean(e)) if e else float("nan"),
               "frac_no_deploy": nd / draws, "oracle_mean_gain": float(np.mean(orc))}
        out["rows"].append(rec)
        print(f"  {k:>5d} {rec['gate_mean_gain']:>+10.2f} {rec['gate_err']:>9.1%} "
              f"{rec['frac_no_deploy']:>10.1%} {rec['oracle_mean_gain']:>+9.2f}")

    with open(RESULT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("\nwrote", os.path.normpath(RESULT))


if __name__ == "__main__":
    main()
