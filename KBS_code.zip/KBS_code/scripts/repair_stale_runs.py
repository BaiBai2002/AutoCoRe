"""Repair runs whose cached step count does not match the intended budget.

``bps_gate_experiment.train`` caches by run id, and the run id does not encode
the number of training steps. A stale short run left over from an earlier smoke
test can therefore be silently returned as a full-budget result. This script
scans a summary, compares every recorded run's ``steps`` against the budget the
summary claims, and re-trains the mismatching ones (overwriting the cache
entry). Weights are recovered from the summary's decision tables, so no
information is lost.

Usage:
    python scripts/repair_stale_runs.py --summary artifacts/bps_gate/spread_n3_summary.json
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import bps_gate_experiment as bge  # noqa: E402

import numpy as np  # noqa: E402

OUTDIR = bge.OUTDIR


def weights_for(summary: dict, key: str):
    for d in summary.get("decisions", []):
        for slot in ("probe_table", "top_by_probe", "gate_choice", "random_choice"):
            entries = d.get(slot)
            if entries is None:
                continue
            if isinstance(entries, dict):
                entries = [entries]
            for c in entries:
                if c.get("key") == key:
                    return c.get("weights")
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", required=True)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    with open(args.summary, encoding="utf-8") as f:
        s = json.load(f)
    env, algo, n = s["env"], s["algo"], s["num_agents"]
    final_steps = s["final_steps"]
    bm = s.get("budget_matched_baseline")
    bm_steps = bm["steps"] if bm else None

    jobs = []
    for full_key, seedmap in s["finals"].items():
        key = full_key.split("_final_")[-1]
        expected = bm_steps if key.startswith("base_bm") else final_steps
        if expected is None:
            continue
        for seed in seedmap:
            path = os.path.join(OUTDIR, f"{full_key}_s{seed}.json")
            if not os.path.exists(path):
                continue
            with open(path, encoding="utf-8") as f:
                got = int(json.load(f).get("steps", -1))
            if got != bge.realized_steps(expected):
                jobs.append((full_key, key, int(seed), int(expected), got))

    print(f"{os.path.basename(args.summary)}: {len(jobs)} stale runs")
    for full_key, key, seed, expected, got in jobs:
        print(f"  {key:<34s} s{seed:<4d} cached={got:<8d} expected={expected}")
    if args.dry_run or not jobs:
        return

    def task(job):
        full_key, key, seed, expected, _got = job
        w = weights_for(s, key)
        rid = f"{full_key}_s{seed}"
        val = bge.train(env, algo, n, expected, seed,
                        None if w is None else np.asarray(w, dtype=float),
                        rid, s["rho_target"])
        return key, seed, val

    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for key, seed, val in pool.map(task, jobs):
            status = "ok" if val is not None else "FAILED"
            print(f"  repaired {key} s{seed} -> {val} ({status})", flush=True)


if __name__ == "__main__":
    main()
