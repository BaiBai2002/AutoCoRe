"""Task-level metrics for a PettingZoo SISL task.

Two modes.

``--probe`` (default) walks episodes with a random policy and reports the episode
length, the total reward and whether episodes end by capture or by timeout. This
establishes whether a capture-rate metric adds information beyond the return.

``--summary PATH`` reads a harness summary and reports, for the unshaped baseline
and for every final-trained candidate, the mean return and the mean capture rate
(the fraction of evaluation episodes that ended before the step limit) over the
held-out seeds.
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

import numpy as np


def probe(env_id: str, max_cycles: int, n_episodes: int) -> None:
    from autocore.envs.vec_pz import make_pz_env

    rng = np.random.default_rng(0)
    lengths, totals, remaining = [], [], []
    for ep in range(n_episodes):
        env = make_pz_env(env_id, max_cycles=max_cycles)
        try:
            env.reset(seed=10_000 + 137 * ep)
        except TypeError:
            env.reset()
        total = 0.0
        steps = 0
        while env.agents and steps < max_cycles:
            acts = {a: int(rng.integers(0, env.action_space(a).n)) for a in env.agents}
            _obs, rew, _term, _trunc, _info = env.step(acts)
            total += float(sum(rew.values()))
            steps += 1
        lengths.append(steps)
        totals.append(total)
        remaining.append(len(env.agents))
        env.close()

    lengths = np.asarray(lengths)
    totals = np.asarray(totals)
    print(f"{env_id}  max_cycles={max_cycles}  episodes={n_episodes}  random policy")
    print(f"  episode length        mean {lengths.mean():7.2f}  min {lengths.min()}  max {lengths.max()}")
    print(f"  total team reward     mean {totals.mean():7.2f}  min {totals.min():.1f}  max {totals.max():.1f}")
    print(f"  active agents at end  mean {np.mean(remaining):7.2f}  (0 = episode terminated)")
    print(f"  ended early (captured)   {int((lengths < max_cycles).sum())}/{n_episodes}")
    if lengths.std() > 0 and totals.std() > 0:
        print(f"  corr(length, reward)  {np.corrcoef(lengths, totals)[0, 1]:+.3f}")
    print(f"  mean team reward/step {totals.mean() / lengths.mean():+.4f}")


def summarise(path: str) -> None:
    outdir = os.path.dirname(os.path.abspath(path))
    with open(path, encoding="utf-8") as f:
        s = json.load(f)
    n = "na" if s["num_agents"] is None else str(s["num_agents"])
    pre = f"{s['env']}_{s['algo']}_N{n}_final_"

    def stats(key: str):
        rets, caps = [], []
        for f in glob.glob(os.path.join(outdir, pre + key + "_s*.json")):
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
            rets.append(float(d["final_return"]))
            caps.append(d.get("final_success_rate"))
        cap = (float(np.mean([c for c in caps if c is not None]))
               if any(c is not None for c in caps) else float("nan"))
        return len(rets), (float(np.mean(rets)) if rets else float("nan")), cap

    print(f"{os.path.basename(path)}   final_steps={s['final_steps']}  "
          f"seeds={len(s['final_seeds'])}")
    print(f"{'config':<26s} {'n':>3s} {'return':>9s} {'capture rate':>13s}")
    nn, rr, cc = stats("base")
    print(f"{'base (no shaping)':<26s} {nn:>3d} {rr:>9.2f} {cc:>13.2f}")
    for k, v in s.get("per_config", {}).items():
        if k.startswith("dsl::"):
            continue
        nn, rr, cc = stats(k)
        print(f"{v['name']:<26s} {nn:>3d} {rr:>9.2f} {cc:>13.2f}")
    bn = stats("base_bm" + str(s.get("budget_matched_baseline", {}).get("steps", "")))
    if bn[0]:
        print(f"{'budget-matched baseline':<26s} {bn[0]:>3d} {bn[1]:>9.2f} {bn[2]:>13.2f}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="pursuit_v5")
    ap.add_argument("--max-cycles", type=int, default=100)
    ap.add_argument("--episodes", type=int, default=20)
    ap.add_argument("--summary", default=None)
    args = ap.parse_args()
    if args.summary:
        summarise(args.summary)
    else:
        probe(args.env, args.max_cycles, args.episodes)


if __name__ == "__main__":
    main()
