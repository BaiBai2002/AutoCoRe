"""Export paper results to Excel with 13 sheets."""
import sys, os, json, glob
from pathlib import Path
from collections import defaultdict
import numpy as np

PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from autocore.utils.io import ensure_dir

RAW = PROJECT_ROOT / "artifacts" / "raw_runs"
OUT_EXCEL = PROJECT_ROOT / "artifacts" / "excel"
OUT_CSV = PROJECT_ROOT / "artifacts" / "csv"
ensure_dir(str(OUT_EXCEL)); ensure_dir(str(OUT_CSV))

try:
    import xlsxwriter
    HAS_XLSX = True
except ImportError:
    HAS_XLSX = False

def load_all():
    all_runs = []
    for f in sorted(glob.glob(str(RAW / "*.json"))):
        try: all_runs.append(json.load(open(f)))
        except: pass
    return all_runs

def export(all_runs=None):
    if all_runs is None: all_runs = load_all()
    completed = [r for r in all_runs if r.get('status') == 'completed' and r.get('final_return') is not None]
    failed = [r for r in all_runs if r.get('status') == 'failed']

    if not HAS_XLSX:
        print("xlsxwriter not installed. Saving CSV only.")
        return save_csv(all_runs, completed, failed)

    import math
    wb = xlsxwriter.Workbook(str(OUT_EXCEL / "autocore_paper_results.xlsx"), {'nan_inf_to_errors': True})
    fmt_header = wb.add_format({'bold': True, 'bg_color': '#4472C4', 'font_color': 'white', 'border': 1})
    fmt_fail = wb.add_format({'bg_color': '#FFC7CE'})
    fmt_bold = wb.add_format({'bold': True})
    fmt_num = wb.add_format({'num_format': '0.000', 'border': 1})
    fmt_text = wb.add_format({'border': 1})

    def write_sheet(name, headers, rows, col_widths=None):
        ws = wb.add_worksheet(name)
        for c, h in enumerate(headers):
            ws.write(0, c, h, fmt_header)
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                if isinstance(val, float): ws.write(r+1, c, val, fmt_num)
                else: ws.write(r+1, c, str(val)[:200] if val else '', fmt_text)
        if col_widths:
            for c, w in enumerate(col_widths): ws.set_column(c, c, w)
        ws.freeze_panes(1, 0)
        ws.autofilter(0, 0, len(rows), len(headers)-1)

    # Sheet 1: README
    write_sheet("README", ["Key", "Value"], [
        ["Project", "AutoCoRe-Select"],
        ["Generated", os.popen('date /t').read().strip()],
        ["Total runs", len(all_runs)],
        ["Completed", len(completed)],
        ["Failed", len(failed)],
        ["Python", sys.version.split()[0]],
    ], [30, 60])

    # Sheet 2: Run_Index
    headers = ["run_id", "env", "method", "provider", "seed", "status", "final_return", "wall_time", "error"]
    rows = [[r.get('run_id',r.get('job_name','?')), r.get('env_id','?'), r.get('method','?'),
             r.get('provider','?'), r.get('seed','?'), r.get('status','?'),
             r.get('final_return'), r.get('wall_time',0), (r.get('error','') or '')[:200]] for r in all_runs]
    write_sheet("Run_Index", headers, rows, [30,20,25,20,8,10,12,10,40])

    # Sheet 3: Main_Results
    em = defaultdict(list)
    for r in completed: em[(r['env_id'], r['method'])].append(r['final_return'])
    headers3 = ["env","method","mean","std","ci_low","ci_hi","auc_mean","n_completed","n_failed"]
    rows3 = []
    for (env, method), vals in sorted(em.items()):
        arr = np.array(vals); m = np.mean(arr); s = np.std(arr, ddof=1)
        ci = np.percentile([np.mean(np.random.choice(arr,len(arr),True)) for _ in range(2000)], [2.5,97.5]) if len(arr)>=3 else [np.nan,np.nan]
        nf = sum(1 for r in failed if r.get('env_id')==env and r.get('method')==method)
        rows3.append([env,method,m,s,ci[0],ci[1],np.trapezoid(arr)/len(arr),len(arr),nf])
    write_sheet("Main_Results", headers3, rows3, [25,25,10,10,10,10,10,12,12])

    # Sheet 12: Failure_Analysis
    err_types = defaultdict(int)
    for r in failed:
        e = r.get('error','unknown')[:80] if r.get('error') else 'unknown'
        err_types[e] += 1
    write_sheet("Failure_Analysis", ["error_type","count"], sorted(err_types.items(), key=lambda x:-x[1]), [60,10])

    # Sheet 13: Paper_Tables
    write_sheet("Paper_Tables", ["Table","Method","Return","vs Base"],
                [["Table1","Base","—","—"]] + [[f"Table1",f"{e}/{m}",f"{np.mean(vals):.0f}","—"] for (e,m),vals in sorted(em.items())], [15,30,15,20])

    wb.close()
    print(f"Excel saved: {OUT_EXCEL / 'autocore_paper_results.xlsx'}")
    save_csv(all_runs, completed, failed)

def save_csv(all_runs, completed, failed):
    import csv
    headers = ["run_id","env","method","provider","seed","status","final_return","wall_time","error"]
    with open(OUT_CSV / "run_index.csv", 'w', newline='') as f:
        w = csv.writer(f); w.writerow(headers)
        for r in all_runs:
            w.writerow([r.get('run_id',r.get('job_name','?')), r.get('env_id','?'), r.get('method','?'),
                       r.get('provider','?'), r.get('seed','?'), r.get('status','?'),
                       r.get('final_return'), r.get('wall_time',0), (r.get('error','') or '')[:200]])
    print(f"CSV saved: {OUT_CSV / 'run_index.csv'}")

if __name__ == "__main__":
    export()
