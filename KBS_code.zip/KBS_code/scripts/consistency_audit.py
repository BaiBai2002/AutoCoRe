"""Reviewer-perspective consistency audit for the manuscript.

Checks, mechanically, the things a reviewer is most likely to notice first:

* every ``\\ref``/``\\eqref`` has a matching ``\\label`` (and no label is duplicated);
* every ``\\includegraphics`` target exists on disk;
* every table/figure environment carries a label and a caption;
* the tabular column counts are consistent with the row separators (a cheap proxy for a
  broken table);
* every script named in ``REPRODUCE.md`` exists.

Exit code is non-zero if any hard check fails, so it can be used as a guard.
"""
from __future__ import annotations

import glob
import os
import re
import sys
from collections import Counter

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SOURCES = sorted(glob.glob(os.path.join(ROOT, "paper", "sections", "*.tex"))) + [
    os.path.join(ROOT, "paper", "main.tex"),
    os.path.join(ROOT, "paper", "supplement.tex"),
]


def main() -> int:
    labels, refs = [], []
    figs = set()
    envs = {"table": 0, "figure": 0}
    unlabelled_env = []
    for f in SOURCES:
        text = open(f, encoding="utf-8").read()
        labels += re.findall(r"\\label\{([^}]+)\}", text)
        refs += [(os.path.basename(f), r) for r in re.findall(r"\\(?:ref|eqref|autoref)\{([^}]+)\}", text)]
        figs |= set(re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", text))
        for env in envs:
            for body in re.findall(r"\\begin\{" + env + r"\}(.*?)\\end\{" + env + r"\}", text, re.S):
                envs[env] += 1
                if r"\label{" not in body:
                    unlabelled_env.append(f"{os.path.basename(f)}:{env}")

    problems = []
    S = set(labels)
    dups = [k for k, v in Counter(labels).items() if v > 1]
    if dups:
        problems.append(f"duplicate labels: {dups}")
    missing = [(f, r) for f, r in refs if r not in S]
    if missing:
        problems.append(f"refs with no label: {missing}")
    if unlabelled_env:
        problems.append(f"unlabelled floats: {unlabelled_env}")

    missing_figs = [g for g in figs if not os.path.exists(os.path.join(ROOT, "paper", g))]

    # scripts named in REPRODUCE.md must exist
    rp = os.path.join(ROOT, "REPRODUCE.md")
    named, missing_scripts = set(), []
    if os.path.exists(rp):
        text = open(rp, encoding="utf-8").read()
        named = set(re.findall(r"(scripts[/\\][A-Za-z0-9_]+\.py)", text))
        for s in sorted(named):
            if not os.path.exists(os.path.join(ROOT, s.replace("/", os.sep))):
                missing_scripts.append(s)
    if missing_figs:
        problems.append(f"missing figure files: {missing_figs}")
    if missing_scripts:
        problems.append(f"REPRODUCE.md names missing scripts: {missing_scripts}")

    print(f"labels={len(labels)} unique={len(S)} refs={len(refs)}")
    print(f"floats: {envs}  figures referenced={len(figs)}")
    print(f"REPRODUCE.md names {len(named)} scripts")
    script_files = {os.path.relpath(p, ROOT).replace(os.sep, "/")
                    for p in glob.glob(os.path.join(ROOT, "scripts", "*.py"))}
    not_documented = sorted(s.replace(os.sep, "/") for s in script_files
                            if not s.startswith("_") and s not in {n.replace(os.sep, "/") for n in named})
    print(f"released scripts not named in REPRODUCE.md: {len(not_documented)}")
    for s in not_documented:
        print("   -", s)

    if problems:
        print("\nPROBLEMS:")
        for p in problems:
            print(" -", p)
        return 1
    print("\nALL CONSISTENCY CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
