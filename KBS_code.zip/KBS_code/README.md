# Code and environment bundle

This bundle accompanies the manuscript *Grounding the proposer: a knowledge-based
decision procedure for potential-based reward shaping in cooperative multi-agent
reinforcement learning* (submitted to Knowledge-Based Systems). It contains the
complete code layer of the study: the pipeline source, every experiment, analysis and
figure script, all configurations, the environment specifications of the two tasks, the
test suite, and the lightweight transparency artefacts the manuscript names (the claim
ledger, the protocol-deviation table, the three pre-registration protocols and the
decision-record schema).

## What is in this bundle

    src/autocore/        the pipeline library: DSL compiler and verifier, shaping
                         potentials (PBRS), probe/deployment selection, IPPO/MAPPO/QMIX
                         learners, provider clients, evaluation
    scripts/             every script that runs an experiment, a diagnostic, an audit,
                         a figure or an analysis quoted in the manuscript
    configs/             environment specifications (configs/env_specs/), the PBRS DSL
                         programs (configs/dsl/), the study configurations and the
                         provider definitions (credentials are referenced by
                         environment-variable name only; no key material is present)
    tests/               the unit/integration test suite of the pipeline
    ledgers/             CLAIM_LEDGER.tsv (claim to evidence map), PROTOCOL_DEVIATIONS.tsv,
                         the pre-registration protocols (CONFIRM_*.md) and
                         decision_record.schema.json
    REPRODUCE.md         script-to-table/figure map: which command regenerates which
                         artefact of the manuscript
    ENVIRONMENT.md       exact environment: interpreter, libraries, benchmarks, install
    SHA256SUMS.txt       SHA-256 of every member of this archive

## What is deliberately NOT in this bundle

The data layer: per-run records, probe and final-training logs, response caches and the
aggregated result files. Those are released as the supplementary *data* bundle, so that
this archive stays a code-and-environment submission. The manuscript states the split
explicitly in its data-availability note. `REPRODUCE.md` marks, for each script, whether
it consumes run records (re-analysis, executable immediately if the data bundle is
present) or produces them (re-running an experiment; needs the environment of
`ENVIRONMENT.md`, a GPU, and provider credentials).

## Quick start (code layer)

    python -m venv .venv && . .venv/bin/activate     # or conda; see ENVIRONMENT.md
    pip install -e .
    pip install -r requirements.txt
    pytest tests/ -q                                  # the pipeline's own test suite

Analysis scripts assume the run records of the data bundle are present under
`artifacts/`; they fail loudly rather than silently substituting anything when a record
is missing. Experiment scripts regenerate records from scratch and are subject to the
budgets documented in the manuscript.

## Credentials

No key material ships. `configs/providers.yaml` names the environment variable for each
provider; copy `.env.example`, fill in your own keys, and export them before running any
experiment script. The cache guard in `tests/test_llm_cache_no_secrets.py` enforces that
no call record can store a key.
